Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

Demo for FastReport included in ODAC was built and tested using
Fast Report 2.4 for Delphi 7.

IMPORTANT NOTE:
  Demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of Fast Report.