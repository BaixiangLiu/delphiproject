Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

This demo was built and tested using 
InfoPower 2000 Trial for Delphi 5

To install TwwOraQuery, TwwSmartQuery, TwwOraTable, and TwwOraStoredProc 
components, compile and install the OraIPPack package.
The OraIPPack package requires InfoPower (ip*.dcp). To make it you need
to compile the InfoPower package (ip*.dpk).

You can recompile it under other versions by changing the Requires section
in the OraIPPack.dpk file manually.

IMPORTANT NOTE:
  This demo is provided "as is", and there is no warranty that it is fully
  compatible with other versions of InfoPower.