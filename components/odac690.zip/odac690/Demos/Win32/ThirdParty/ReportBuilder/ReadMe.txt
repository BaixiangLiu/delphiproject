Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

There are several demos for ReportBuilder Pro included in ODAC:

  1. Demos\ReportBuilder\RB5 demo was built and tested using
     Report Builder Pro 5.0 for Delphi 5

  2. Demos\ReportBuilder\RB6 demo was built and tested using
     Report Builder Pro 6.01 for Delphi 6

  3. Demos\ReportBuilder\RB7 demo was built and tested using
     Report Builder Pro 7.0 for Delphi 6

  4. Demos\ReportBuilder\RB9 demo was built and tested using
     Report Builder Pro 9.0 for Delphi 7

You can recompile it under other versions by changing the Requires section
in the rbODAC.dpk file manually.

IMPORTANT NOTE:
  Demos are provided "as is", and there is no warranty that they are fully
  compatible with other versions of Report Builder Pro.