Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

Uses external procedures to save LOB data to file on the Oracle server and
store the file name and file date in a database. This demo project uses
the external procedure DLL file described in the Writing Oracle external
procedures with ODAC topic.
