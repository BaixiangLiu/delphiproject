Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

A general demo project about creating ODAC-based applications with
C++Builder. Lets you execute SQL scripts and work with result sets in a
grid. This is one of two ODAC demos for C++Builder.
