//---------------------------------------------------------------------------
#include <vcl.h>  
#pragma hdrstop

#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "MemDS"
#pragma link "Ora"
#pragma link "DBAccess"
#pragma link "OdacVcl"
#pragma resource "*.dfm"
TfmMain *fmMain;
//---------------------------------------------------------------------------
__fastcall TfmMain::TfmMain(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::btOpenClick(TObject *Sender)
{
  OraQuery->Open();
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::btCloseClick(TObject *Sender)
{
  OraQuery->Close();
}
//---------------------------------------------------------------------------
void __fastcall TfmMain::btDisconnectClick(TObject *Sender)
{
  OraSession->Disconnect();
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::btExecuteClick(TObject *Sender)
{
  OraQuery->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::FormShow(TObject *Sender)
{
  meSQL->Lines->Assign(OraQuery->SQL);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::meSQLExit(TObject *Sender)
{
  if (meSQL->Lines->Text != OraQuery->SQL->Text)
    OraQuery->SQL->Assign(meSQL->Lines);
}
//---------------------------------------------------------------------------

void __fastcall TfmMain::btConnectClick(TObject *Sender)
{
  OraSession->Connect();        
}
//---------------------------------------------------------------------------

