Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates how to work with DLLs in ODAC-based applications. This demo
project includes two projects:
  1) The OraDll project represents a dll containing a form that can send SQL queries 
     to the server and display results of these queries.
  2) OraExe represents a project that uses the OraDll library to work with Oracle.

Note, before testing OraExe, you should build the OraDll project.