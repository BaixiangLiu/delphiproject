Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

Demonstrates using the MIDAS technology with ODAC. This project consists of
two parts: 
	1) a MIDAS server that processes requests to the database 
	2) a thin MIDAS client that displays an interactive grid.
This demo shows how to build thin clients that display interactive components and delegate
all database interaction to a server application for processing. 
