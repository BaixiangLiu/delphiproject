Oracle Data Access Components
Copyright 1997-2009, Devart. All Rights Reserved
--------------------------------------------------

Uses OraDataAdapter to create a simple ASP .NET application. This
application creates an ASP.NET application that lets you connect to
databases and execute queries. Shows how to display query results
in DataGrid and how to send user's changes back to the database.