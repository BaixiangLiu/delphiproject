// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crgrid.pas' rev: 21.00

#ifndef CrgridHPP
#define CrgridHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Grids.hpp>	// Pascal unit
#include <Dbgrids.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Menus.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Comctrls.hpp>	// Pascal unit
#include <Types.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crgrid
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSortOrder { soNone, soAsc, soDesc };
#pragma option pop

#pragma option push -b-
enum TSummaryMode { smNone, smSum, smAvr, smMax, smMin, smLabel };
#pragma option pop

typedef void __fastcall (__closure *TOnMemoClick)(System::TObject* Sender, Dbgrids::TColumn* Column);

class DELPHICLASS TCRColumnTitle;
class PASCALIMPLEMENTATION TCRColumnTitle : public Dbgrids::TColumnTitle
{
	typedef Dbgrids::TColumnTitle inherited;
	
private:
	HIDESBASE System::UnicodeString __fastcall GetCaption(void);
	HIDESBASE bool __fastcall IsCaptionStored(void);
	
protected:
	HIDESBASE void __fastcall SetCaption(const System::UnicodeString Value);
	
__published:
	__property System::UnicodeString Caption = {read=GetCaption, write=SetCaption, stored=IsCaptionStored};
public:
	/* TColumnTitle.Create */ inline __fastcall TCRColumnTitle(Dbgrids::TColumn* Column) : Dbgrids::TColumnTitle(Column) { }
	/* TColumnTitle.Destroy */ inline __fastcall virtual ~TCRColumnTitle(void) { }
	
};


class DELPHICLASS TCRColumn;
class PASCALIMPLEMENTATION TCRColumn : public Dbgrids::TColumn
{
	typedef Dbgrids::TColumn inherited;
	
private:
	int FMinWidth;
	System::UnicodeString FTotalString;
	System::Variant FTotalValue;
	bool FTotalLoaded;
	TSummaryMode FSummaryMode;
	System::Extended FTotalFloat;
	__int64 FTotalInt;
	int FFloatDigits;
	int FFloatPrecision;
	Sysutils::TFloatFormat FFloatFormat;
	System::UnicodeString FFilterExpression;
	double FTableSpacePercent;
	TSortOrder __fastcall GetSortOrder(void);
	void __fastcall SetSortOrder(TSortOrder Value);
	int __fastcall GetSortSequence(void);
	void __fastcall SetSortSequence(int Value);
	System::UnicodeString __fastcall GetTotalString(void);
	System::Variant __fastcall GetTotalValue(void);
	void __fastcall SetSummaryMode(TSummaryMode Value);
	void __fastcall SetFloatDigits(const int Value);
	void __fastcall SetFloatFormat(const Sysutils::TFloatFormat Value);
	void __fastcall SetFloatPrecision(const int Value);
	void __fastcall SetFilterExpression(const System::UnicodeString Value);
	HIDESBASE void __fastcall SetWidth(const int Value);
	HIDESBASE int __fastcall GetWidth(void);
	HIDESBASE void __fastcall SetVisible(bool Value);
	HIDESBASE bool __fastcall GetVisible(void);
	void __fastcall ResetTotal(void);
	void __fastcall LoadTotal(void);
	void __fastcall SetTotal(void);
	bool __fastcall CanBeSorted(void);
	TCRColumnTitle* __fastcall GetTitle(void);
	HIDESBASE void __fastcall SetTitle(TCRColumnTitle* Value);
	
protected:
	virtual Dbgrids::TColumnTitle* __fastcall CreateTitle(void);
	void __fastcall ChangedTitle(bool Rebild);
	System::UnicodeString __fastcall GetFilterExpression(const System::UnicodeString RawFilter);
	
public:
	__fastcall virtual TCRColumn(Classes::TCollection* Collection);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	__property System::UnicodeString TotalString = {read=GetTotalString, write=FTotalString};
	__property System::Variant TotalValue = {read=GetTotalValue};
	
__published:
	__property int Width = {read=GetWidth, write=SetWidth, nodefault};
	__property bool Visible = {read=GetVisible, write=SetVisible, nodefault};
	__property System::UnicodeString FilterExpression = {read=FFilterExpression, write=SetFilterExpression};
	__property int MinWidth = {read=FMinWidth, write=FMinWidth, default=0};
	__property TSortOrder SortOrder = {read=GetSortOrder, write=SetSortOrder, default=0};
	__property int SortSequence = {read=GetSortSequence, write=SetSortSequence, default=0};
	__property TSummaryMode SummaryMode = {read=FSummaryMode, write=SetSummaryMode, default=0};
	__property Sysutils::TFloatFormat FloatFormat = {read=FFloatFormat, write=SetFloatFormat, default=0};
	__property int FloatPrecision = {read=FFloatPrecision, write=SetFloatPrecision, default=0};
	__property int FloatDigits = {read=FFloatDigits, write=SetFloatDigits, default=0};
	__property TCRColumnTitle* Title = {read=GetTitle, write=SetTitle};
public:
	/* TColumn.Destroy */ inline __fastcall virtual ~TCRColumn(void) { }
	
};


class DELPHICLASS TCRDBGridColumns;
class PASCALIMPLEMENTATION TCRDBGridColumns : public Dbgrids::TDBGridColumns
{
	typedef Dbgrids::TDBGridColumns inherited;
	
public:
	TCRColumn* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TCRColumn* __fastcall GetColumn(int Index);
	HIDESBASE void __fastcall SetColumn(int Index, TCRColumn* Value);
	void __fastcall ColumnAdded(void);
	
public:
	__property TCRColumn* Items[int Index] = {read=GetColumn, write=SetColumn/*, default*/};
public:
	/* TDBGridColumns.Create */ inline __fastcall TCRDBGridColumns(Dbgrids::TCustomDBGrid* Grid, Dbgrids::TColumnClass ColumnClass) : Dbgrids::TDBGridColumns(Grid, ColumnClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TCRDBGridColumns(void) { }
	
};


class DELPHICLASS TCRGridTitleEdit;
class DELPHICLASS TCRDBGrid;
class PASCALIMPLEMENTATION TCRGridTitleEdit : public Stdctrls::TCustomStaticText
{
	typedef Stdctrls::TCustomStaticText inherited;
	
private:
	typedef DynamicArray<System::UnicodeString> _TCRGridTitleEdit__1;
	
	
private:
	TCRDBGrid* FCRDBGrid;
	Stdctrls::TEdit* FEdit;
	bool FAsFilter;
	Dbgrids::TColumn* FActiveColumn;
	_TCRGridTitleEdit__1 FFilterExpressions;
	bool FEditingFilter;
	void __fastcall SetCRDBGrid(const TCRDBGrid* Value);
	void __fastcall FEditKeyPress(System::TObject* Sender, System::WideChar &Key);
	HIDESBASE MESSAGE void __fastcall WMMouseWheel(Messages::TWMMouseWheel &Message);
	void __fastcall FEditKeyDown(System::TObject* Sender, System::Word &Key, Classes::TShiftState Shift);
	void __fastcall FEditChange(System::TObject* Sender);
	void __fastcall FEditExit(System::TObject* Sender);
	void __fastcall ProcessEdit(void);
	MESSAGE void __fastcall WMGetDlgCode(Messages::TWMNoParams &Message);
	void __fastcall GotoUpperCell(void);
	void __fastcall GotoLowerCell(void);
	void __fastcall GotoNextCell(void);
	void __fastcall GotoPrevCell(void);
	void __fastcall SetEditingFilter(const bool Value);
	void __fastcall PostFilter(void);
	
protected:
	virtual void __fastcall PaintWindow(HDC DC);
	DYNAMIC void __fastcall KeyDown(System::Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall DoExit(void);
	HIDESBASE MESSAGE void __fastcall WMChar(Messages::TWMKey &Message);
	
public:
	__fastcall virtual TCRGridTitleEdit(Classes::TComponent* AOwner);
	virtual void __fastcall SetFocus(void);
	void __fastcall ActivateAt(const Types::TRect &ARect, Dbgrids::TColumn* ActiveColumn, bool AsFilter);
	void __fastcall SetClientRect(const Types::TRect &ARect);
	void __fastcall StartEdit(void);
	void __fastcall StopEdit(bool AcceptChanges);
	__property TCRDBGrid* CRDBGrid = {read=FCRDBGrid, write=SetCRDBGrid};
	__property Stdctrls::TEdit* Edit = {read=FEdit};
	__property bool EditingFilter = {read=FEditingFilter, write=SetEditingFilter, nodefault};
public:
	/* TWinControl.CreateParented */ inline __fastcall TCRGridTitleEdit(HWND ParentWindow) : Stdctrls::TCustomStaticText(ParentWindow) { }
	/* TWinControl.Destroy */ inline __fastcall virtual ~TCRGridTitleEdit(void) { }
	
};


class DELPHICLASS TMemoEditorForm;
class PASCALIMPLEMENTATION TMemoEditorForm : public Forms::TCustomForm
{
	typedef Forms::TCustomForm inherited;
	
private:
	Stdctrls::TMemo* FMemo;
	Stdctrls::TButton* FOKBtn;
	Stdctrls::TButton* FCancelBtn;
	bool FReadOnly;
	Stdctrls::TCheckBox* FCheckBox;
	void __fastcall SetReadOnly(const bool Value);
	void __fastcall MemoKeyDown(System::TObject* Sender, System::Word &Key, Classes::TShiftState Shift);
	void __fastcall CheckBoxClick(System::TObject* Sender);
	
public:
	__fastcall virtual TMemoEditorForm(Classes::TComponent* AOwner);
	virtual bool __fastcall CloseQuery(void);
	__property bool ReadOnly = {read=FReadOnly, write=SetReadOnly, nodefault};
public:
	/* TCustomForm.CreateNew */ inline __fastcall virtual TMemoEditorForm(Classes::TComponent* AOwner, int Dummy) : Forms::TCustomForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TMemoEditorForm(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TMemoEditorForm(HWND ParentWindow) : Forms::TCustomForm(ParentWindow) { }
	
};


#pragma option push -b-
enum TCRDBGridOptionEx { dgeEnableSort, dgeFilterBar, dgeLocalFilter, dgeLocalSorting, dgeRecordCount, dgeSearchBar, dgeStretch, dgeSummary };
#pragma option pop

typedef Set<TCRDBGridOptionEx, dgeEnableSort, dgeSummary>  TCRDBGridOptionsEx;

#pragma option push -b-
enum Crgrid__6 { geHighlight, geActiveRow, geMultiSelected };
#pragma option pop

typedef Set<Crgrid__6, geHighlight, geMultiSelected>  TGridDrawStateEx;

typedef void __fastcall (__closure *TGetCellParamsEvent)(System::TObject* Sender, Db::TField* Field, Graphics::TFont* AFont, Graphics::TColor &Background, Grids::TGridDrawState State, TGridDrawStateEx StateEx);

class DELPHICLASS TSortColInfo;
class PASCALIMPLEMENTATION TSortColInfo : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	int Index;
	bool Desc;
public:
	/* TObject.Create */ inline __fastcall TSortColInfo(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TSortColInfo(void) { }
	
};


#pragma option push -b-
enum TIndicatorColButton { icbNone, icbMenu, icbFilter, icbSearch };
#pragma option pop

class DELPHICLASS TCRGridDataLink;
class PASCALIMPLEMENTATION TCRGridDataLink : public Dbgrids::TGridDataLink
{
	typedef Dbgrids::TGridDataLink inherited;
	
protected:
	bool FDataSetChanging;
	virtual void __fastcall DataSetChanged(void);
public:
	/* TGridDataLink.Create */ inline __fastcall TCRGridDataLink(Dbgrids::TCustomDBGrid* AGrid) : Dbgrids::TGridDataLink(AGrid) { }
	/* TGridDataLink.Destroy */ inline __fastcall virtual ~TCRGridDataLink(void) { }
	
};


class PASCALIMPLEMENTATION TCRDBGrid : public Dbgrids::TCustomDBGrid
{
	typedef Dbgrids::TCustomDBGrid inherited;
	
private:
	bool FDefaultDrawing;
	TCRDBGridOptionsEx FOptionsEx;
	bool FSoft;
	TGetCellParamsEvent FOnGetCellParams;
	bool FExecSorting;
	bool FExecColAjust;
	Classes::TList* FSortInfo;
	bool FActiveRowSelected;
	int FTitleButtonDown;
	bool FTitleBarUp;
	int FOldTitleButtonDown;
	int FCellButtonDown;
	int FCellButtonRow;
	int FCellButtonCol;
	bool FCellButtonPressed;
	Types::TRect FCellButtonRect;
	Types::TRect FCellButtonBRect;
	int FTotalYOffset;
	TOnMemoClick FOnMemoClick;
	System::WideChar FLevelDelimiterChar;
	TIndicatorColButton FIndicatorColBtnDown;
	TIndicatorColButton FOldIndicatorColBtnDown;
	Menus::TPopupMenu* FOptionsMenu;
	Menus::TPopupMenu* FOptionsMenuDef;
	TCRGridTitleEdit* CRGridTitleEdit;
	Types::TRect FStatusRect;
	bool FFiltered;
	bool FContinueEditingFilter;
	int FMemoWidth;
	int FMemoHeight;
	bool FMemoWordWrap;
	void __fastcall SetOptionsEx(TCRDBGridOptionsEx Value);
	void __fastcall UpdateHeaderHeight(void);
	HIDESBASE void __fastcall RecordChanged(Db::TField* Field);
	void __fastcall DrawButton(int X, int Y, bool State);
	bool __fastcall IsOnButton(int X, int Y);
	Types::TRect __fastcall GetButtonRect(const Grids::TGridCoord &Cell);
	void __fastcall SetLevelDelimiterchar(const System::WideChar Value);
	HIDESBASE MESSAGE void __fastcall WMSetCursor(Messages::TWMSetCursor &Message);
	Types::TRect __fastcall CalcSearchBar(Dbgrids::TColumn* Column);
	Types::TRect __fastcall CalcFilterBar(Dbgrids::TColumn* Column);
	bool __fastcall MouseInFilterBar(int X, int Y, Dbgrids::TColumn* Column = (Dbgrids::TColumn*)(0x0));
	bool __fastcall MouseInFilterEdit(int X, int Y, Dbgrids::TColumn* Column = (Dbgrids::TColumn*)(0x0));
	bool __fastcall MouseInSortBar(int X, int Y, Dbgrids::TColumn* Column = (Dbgrids::TColumn*)(0x0));
	bool __fastcall MouseInSortEdit(int X, int Y, Dbgrids::TColumn* Column = (Dbgrids::TColumn*)(0x0));
	bool __fastcall MouseInLowerstLevel(int X, int Y, Dbgrids::TColumn* Column = (Dbgrids::TColumn*)(0x0));
	void __fastcall DoOnMemoClick(Dbgrids::TColumn* Column);
	void __fastcall DrawTitleBarCell(Graphics::TCanvas* Canvas, Dbgrids::TColumn* Column, const Types::TRect &Rect, System::UnicodeString Text);
	void __fastcall DrawTitleIndicatorCell(Graphics::TCanvas* Canvas, const Types::TRect &ARect);
	TIndicatorColButton __fastcall GetIndicatorButton(int X, int Y);
	void __fastcall IndicatorClick(TIndicatorColButton Button, int X, int Y);
	void __fastcall BuildMenu(void);
	void __fastcall FilteredItemClick(System::TObject* Sender);
	void __fastcall FilterItemClick(System::TObject* Sender);
	void __fastcall SearchItemClick(System::TObject* Sender);
	void __fastcall CalcTableSpacePercent(void);
	void __fastcall SetFiltered(const bool Value);
	HIDESBASE void __fastcall UpdateRowCount(void);
	TCRDBGridColumns* __fastcall GetColumns(void);
	HIDESBASE void __fastcall SetColumns(const TCRDBGridColumns* Value);
	
protected:
	int FHeaderHeight;
	bool FExecSizing;
	virtual Types::TRect __fastcall GetClientRect(void);
	virtual void __fastcall Loaded(void);
	DYNAMIC Dbgrids::TDBGridColumns* __fastcall CreateColumns(void);
	DYNAMIC Dbgrids::TGridDataLink* __fastcall CreateDataLink(void);
	void __fastcall Reorder(void);
	TSortColInfo* __fastcall FindSortColInfo(int Index, int &SortNum);
	DYNAMIC void __fastcall ColWidthsChanged(void);
	DYNAMIC void __fastcall Resize(void);
	void __fastcall ResizeColumns(int ResizedColumn = 0xffffffff);
	DYNAMIC bool __fastcall EndColumnDrag(int &Origin, int &Destination, const Types::TPoint &MousePt);
	DYNAMIC void __fastcall DrawColumnCell(const Types::TRect &Rect, int DataCol, Dbgrids::TColumn* Column, Grids::TGridDrawState State);
	DYNAMIC void __fastcall GetCellProps(Db::TField* Field, Graphics::TFont* AFont, Graphics::TColor &Background, Grids::TGridDrawState State, TGridDrawStateEx StateEx);
	virtual void __fastcall DrawCell(int ACol, int ARow, const Types::TRect &ARect, Grids::TGridDrawState AState);
	DYNAMIC void __fastcall KeyDown(System::Word &Key, Classes::TShiftState Shift);
	DYNAMIC void __fastcall MouseDown(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseMove(Classes::TShiftState Shift, int X, int Y);
	DYNAMIC void __fastcall MouseUp(Controls::TMouseButton Button, Classes::TShiftState Shift, int X, int Y);
	virtual void __fastcall LinkActive(bool Value);
	virtual void __fastcall Paint(void);
	void __fastcall ResetTotals(void);
	void __fastcall LoadTotals(void);
	virtual bool __fastcall CanEditShow(void);
	DYNAMIC void __fastcall TopLeftChanged(void);
	DYNAMIC void __fastcall DoExit(void);
	HIDESBASE MESSAGE void __fastcall WMMouseWheel(Messages::TWMMouseWheel &Message);
	DYNAMIC void __fastcall TitleClick(Dbgrids::TColumn* Column);
	HIDESBASE void __fastcall MoveColRow(int ACol, int ARow, bool MoveAnchor, bool Show);
	HIDESBASE int __fastcall DataToRawColumn(int ACol);
	HIDESBASE void __fastcall InvalidateCol(int ACol);
	HIDESBASE void __fastcall InvalidateRow(int ARow);
	virtual void __fastcall LayoutChanged(void);
	__property DefaultRowHeight = {default=24};
	__property DataLink;
	
public:
	int __fastcall GetGridSize(void);
	__fastcall virtual TCRDBGrid(Classes::TComponent* Owner);
	HIDESBASE void __fastcall DataChanged(void);
	__fastcall virtual ~TCRDBGrid(void);
	void __fastcall ClearSorting(void);
	void __fastcall ClearFilters(void);
	void __fastcall ActivateFilterEdit(Dbgrids::TColumn* Column);
	void __fastcall ActivateSearchEdit(Dbgrids::TColumn* Column);
	__property Canvas;
	__property SelectedRows;
	void __fastcall CalcTitleLevel(int Level, Types::TRect &aRect);
	Types::TRect __fastcall GetTitleLevel(int Level);
	void __fastcall ApplyFilter(void);
	void __fastcall AdjustColumns(void);
	__property Col;
	__property Row;
	__property TopRow;
	__property LeftCol;
	__property Menus::TPopupMenu* OptionsMenu = {read=FOptionsMenu, write=FOptionsMenu};
	
__published:
	__property bool DefaultDrawing = {read=FDefaultDrawing, write=FDefaultDrawing, default=1};
	__property System::WideChar LevelDelimiterChar = {read=FLevelDelimiterChar, write=SetLevelDelimiterchar, default=124};
	__property bool Filtered = {read=FFiltered, write=SetFiltered, default=1};
	__property TCRDBGridOptionsEx OptionsEx = {read=FOptionsEx, write=SetOptionsEx, default=29};
	__property TOnMemoClick OnMemoClick = {read=FOnMemoClick, write=FOnMemoClick};
	__property TGetCellParamsEvent OnGetCellParams = {read=FOnGetCellParams, write=FOnGetCellParams};
	__property Align = {default=0};
	__property Anchors = {default=3};
	__property BiDiMode;
	__property BorderStyle = {default=1};
	__property Color = {default=-16777211};
	__property TCRDBGridColumns* Columns = {read=GetColumns, write=SetColumns, stored=false};
	__property Constraints;
	__property Ctl3D;
	__property DataSource;
	__property DragCursor = {default=-12};
	__property DragMode = {default=0};
	__property Enabled = {default=1};
	__property FixedColor = {default=-16777201};
	__property Font;
	__property ImeMode = {default=3};
	__property ImeName;
	__property Options = {default=27901};
	__property ParentBiDiMode = {default=1};
	__property ParentColor = {default=0};
	__property ParentCtl3D = {default=1};
	__property ParentFont = {default=1};
	__property ParentShowHint = {default=1};
	__property PopupMenu;
	__property ReadOnly = {default=0};
	__property ShowHint;
	__property TabOrder = {default=-1};
	__property TabStop = {default=1};
	__property TitleFont;
	__property Visible = {default=1};
	__property OnCellClick;
	__property OnColEnter;
	__property OnColExit;
	__property OnColumnMoved;
	__property OnDrawDataCell;
	__property OnDrawColumnCell;
	__property OnDblClick;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnEditButtonClick;
	__property OnEndDock;
	__property OnEndDrag;
	__property OnEnter;
	__property OnExit;
	__property OnKeyDown;
	__property OnKeyPress;
	__property OnKeyUp;
	__property OnMouseDown;
	__property OnMouseMove;
	__property OnMouseUp;
	__property OnStartDock;
	__property OnStartDrag;
	__property OnTitleClick;
public:
	/* TWinControl.CreateParented */ inline __fastcall TCRDBGrid(HWND ParentWindow) : Dbgrids::TCustomDBGrid(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::ResourceString _SFiltered;
#define Crgrid_SFiltered System::LoadResourceString(&Crgrid::_SFiltered)
extern PACKAGE System::ResourceString _SFilterBar;
#define Crgrid_SFilterBar System::LoadResourceString(&Crgrid::_SFilterBar)
extern PACKAGE System::ResourceString _SSearchBar;
#define Crgrid_SSearchBar System::LoadResourceString(&Crgrid::_SSearchBar)
extern PACKAGE System::ResourceString _sWordWrap;
#define Crgrid_sWordWrap System::LoadResourceString(&Crgrid::_sWordWrap)
extern PACKAGE System::ResourceString _SOK;
#define Crgrid_SOK System::LoadResourceString(&Crgrid::_SOK)
extern PACKAGE System::ResourceString _SCancel;
#define Crgrid_SCancel System::LoadResourceString(&Crgrid::_SCancel)
extern PACKAGE System::ResourceString _SClose;
#define Crgrid_SClose System::LoadResourceString(&Crgrid::_SClose)
extern PACKAGE System::ResourceString _fmtModifiedWarning;
#define Crgrid_fmtModifiedWarning System::LoadResourceString(&Crgrid::_fmtModifiedWarning)

}	/* namespace Crgrid */
using namespace Crgrid;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrgridHPP
