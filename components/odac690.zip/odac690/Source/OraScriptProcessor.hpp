// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Orascriptprocessor.pas' rev: 21.00

#ifndef OrascriptprocessorHPP
#define OrascriptprocessorHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Dascript.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Orascriptprocessor
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOraScriptProcessor;
class PASCALIMPLEMENTATION TOraScriptProcessor : public Dascript::TDAScriptProcessor
{
	typedef Dascript::TDAScriptProcessor inherited;
	
private:
	typedef DynamicArray<int> _TOraScriptProcessor__1;
	
	
protected:
	_TOraScriptProcessor__1 FCodes;
	int FStatementType;
	virtual Crparser::TSQLParserClass __fastcall GetParserClass(void);
	virtual void __fastcall CheckLexem(int Code, int &StatementType, bool &Omit);
	virtual bool __fastcall GetReady(int Code);
	virtual void __fastcall DoBeforeStatementExecute(System::UnicodeString &SQL, int StatementType, bool &Omit);
	
public:
	__fastcall virtual TOraScriptProcessor(Dascript::TDAScript* Owner);
public:
	/* TDAScriptProcessor.Destroy */ inline __fastcall virtual ~TOraScriptProcessor(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt ST_NORMAL = 0x64;
static const Word ST_SQLPLUS = 0x100;
static const Word ST_IGNORED = 0x101;
static const Word ST_CONNECT = 0x102;
static const Word ST_DISCONNECT = 0x103;
static const Word ST_DEFINE = 0x104;
static const Word ST_EXECUTE = 0x105;

}	/* namespace Orascriptprocessor */
using namespace Orascriptprocessor;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OrascriptprocessorHPP
