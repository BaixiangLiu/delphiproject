// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crconnectionpool.pas' rev: 21.00

#ifndef CrconnectionpoolHPP
#define CrconnectionpoolHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crconnectionpool
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TCRConnectionParametersClass;

typedef TMetaClass* TCRConnectionPoolManagerClass;

class DELPHICLASS TCRConnectionParameters;
class PASCALIMPLEMENTATION TCRConnectionParameters : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
protected:
	Crvio::THttpOptions* FHttpOptions;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	int MinPoolSize;
	int MaxPoolSize;
	System::UnicodeString Username;
	System::UnicodeString Server;
	System::UnicodeString Password;
	int ConnectionLifeTime;
	bool Validate;
	Crvio::TCRIOHandler* IOHandler;
	Craccess::TErrorProc OnError;
	__fastcall virtual TCRConnectionParameters(void);
	__fastcall virtual ~TCRConnectionParameters(void);
	HIDESBASE virtual bool __fastcall Equals(TCRConnectionParameters* ConnectionParameters);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	__property Crvio::THttpOptions* HttpOptions = {read=FHttpOptions};
};


class DELPHICLASS TCRConnectionPool;
class DELPHICLASS TCRConnectionPoolManager;
class PASCALIMPLEMENTATION TCRConnectionPool : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TCRConnectionParameters* FConnectionParameters;
	TCRConnectionPoolManager* FManager;
	
protected:
	int FTakenConnectionsCount;
	virtual void __fastcall Validate(void);
	virtual void __fastcall Clear(void);
	virtual void __fastcall AsyncClear(void);
	virtual int __fastcall GetTotalConnectionsCount(void);
	virtual void __fastcall InternalPutConnection(Craccess::TCRConnection* CRConnection) = 0 ;
	__property TCRConnectionParameters* ConnectionParameters = {read=FConnectionParameters};
	
public:
	__fastcall virtual TCRConnectionPool(TCRConnectionPoolManager* Manager, TCRConnectionParameters* ConnectionParameters);
	__fastcall virtual ~TCRConnectionPool(void);
	virtual Craccess::TCRConnection* __fastcall GetConnection(void) = 0 ;
	void __fastcall PutConnection(Craccess::TCRConnection* CRConnection);
	virtual void __fastcall Invalidate(void);
	__property int TotalConnectionsCount = {read=GetTotalConnectionsCount, nodefault};
};


typedef DynamicArray<Craccess::TCRConnection*> TCRConnectionsArray;

typedef DynamicArray<int> TIntegerArray;

typedef StaticArray<int, 8> TStatisticsArray;

class DELPHICLASS TCRLocalConnectionPool;
class PASCALIMPLEMENTATION TCRLocalConnectionPool : public TCRConnectionPool
{
	typedef TCRConnectionPool inherited;
	
private:
	TCRConnectionsArray FPooledConnections;
	int FPooledConnectionsCount;
	int FHead;
	int FTail;
	TIntegerArray FVersions;
	int FVersion;
	TStatisticsArray FStatistics;
	int FDoomedConnectionsCount;
	int FInvalidateVersion;
	int FClearVersion;
	Syncobjs::TEvent* hBusy;
	Syncobjs::TCriticalSection* FLockPooled;
	Syncobjs::TCriticalSection* FLockTaken;
	Syncobjs::TCriticalSection* FLockVersion;
	Syncobjs::TCriticalSection* FLockGet;
	bool __fastcall IsLive(Craccess::TCRConnection* CRConnection);
	bool __fastcall CheckIsValid(Craccess::TCRConnection* Connection);
	void __fastcall ReserveConnection(void);
	bool __fastcall InternalGetConnection(Craccess::TCRConnection* &Connection, int &Version, bool Reserve = true);
	void __fastcall InternalReturnConnection(Craccess::TCRConnection* Connection, int Version);
	void __fastcall InternalFreeConnection(Craccess::TCRConnection* Connection, bool Reserved = false);
	
protected:
	virtual Craccess::TCRConnection* __fastcall CreateNewConnector(void) = 0 ;
	virtual void __fastcall Validate(void);
	virtual void __fastcall Clear(void);
	virtual void __fastcall AsyncClear(void);
	virtual int __fastcall GetTotalConnectionsCount(void);
	virtual void __fastcall InternalPutConnection(Craccess::TCRConnection* CRConnection);
	
public:
	__fastcall virtual TCRLocalConnectionPool(TCRConnectionPoolManager* Manager, TCRConnectionParameters* ConnectionParameters);
	__fastcall virtual ~TCRLocalConnectionPool(void);
	virtual Craccess::TCRConnection* __fastcall GetConnection(void);
	virtual void __fastcall Invalidate(void);
};


class DELPHICLASS TValidateThread;
class PASCALIMPLEMENTATION TValidateThread : public Classes::TThread
{
	typedef Classes::TThread inherited;
	
private:
	TCRConnectionPoolManager* FManager;
	Syncobjs::TEvent* FEvent;
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TValidateThread(TCRConnectionPoolManager* Manager);
	__fastcall virtual ~TValidateThread(void);
	HIDESBASE void __fastcall Terminate(void);
};


class PASCALIMPLEMENTATION TCRConnectionPoolManager : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FPools;
	TValidateThread* FValidateThread;
	
protected:
	Syncobjs::TCriticalSection* FLockGet;
	Syncobjs::TCriticalSection* FLockList;
	virtual TCRConnectionPool* __fastcall CreateCRConnectionPool(TCRConnectionParameters* ConnectionParameters) = 0 ;
	void __fastcall InternalClear(void);
	void __fastcall InternalAsyncClear(void);
	TCRConnectionPool* __fastcall GetConnectionPool(TCRConnectionParameters* ConnectionParameters);
	virtual Craccess::TCRConnection* __fastcall InternalGetConnection(TCRConnectionParameters* ConnectionParameters);
	virtual Craccess::TCRConnection* __fastcall InternalCheckConnection(Craccess::TCRConnection* Connection);
	
public:
	__fastcall TCRConnectionPoolManager(void);
	__fastcall virtual ~TCRConnectionPoolManager(void);
	__classmethod virtual Craccess::TCRConnection* __fastcall GetConnection(TCRConnectionParameters* ConnectionParameters);
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt StatisticsCount = 0x8;

}	/* namespace Crconnectionpool */
using namespace Crconnectionpool;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrconnectionpoolHPP
