// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraalerter.pas' rev: 21.00

#ifndef OraalerterHPP
#define OraalerterHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Win32timer.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraalerter
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TEventType { etAlert, etPipe };
#pragma option pop

#pragma option push -b-
enum TMessageType { mtNone, mtNumber, mtString, mtDate };
#pragma option pop

typedef void __fastcall (__closure *TOnEventEvent)(System::TObject* Sender, System::UnicodeString Event, System::UnicodeString Message);

typedef void __fastcall (__closure *TOnTimeOutEvent)(System::TObject* Sender, bool &Continue);

class DELPHICLASS TOraAlerter;
class PASCALIMPLEMENTATION TOraAlerter : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Ora::TOraSession* FSession;
	Ora::TOraSession* InternalSession;
	Ora::TOraSQL* WaitSQL;
	bool FActive;
	bool FStreamedActive;
	System::UnicodeString FEvents;
	TOnEventEvent FOnEvent;
	TOnTimeOutEvent FOnTimeOut;
	int FTimeOut;
	int FInterval;
	TEventType FEventType;
	bool Stoping;
	System::UnicodeString FSelfMessage;
	bool FRegistered;
	bool FAutoCommit;
	bool FSelfEvents;
	Win32timer::TWin32Timer* FTimer;
	void __fastcall SetSession(Ora::TOraSession* Value);
	void __fastcall SetActive(bool Value);
	void __fastcall SetEvents(const System::UnicodeString Value);
	void __fastcall SetEventType(TEventType Value);
	
protected:
	bool FDesignCreate;
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* Component, Classes::TOperation Operation);
	void __fastcall Connect(void);
	void __fastcall RegisterEvents(void);
	void __fastcall RemoveEvents(void);
	virtual void __fastcall DoOnEvent(System::TObject* Sender, System::UnicodeString Event, System::UnicodeString Message);
	void __fastcall AfterExecute(System::TObject* Sender, bool Result);
	void __fastcall OnTimer(System::TObject* Sender);
	__property bool SelfEvents = {read=FSelfEvents, write=FSelfEvents, nodefault};
	
public:
	__fastcall virtual TOraAlerter(Classes::TComponent* Owner);
	__fastcall virtual ~TOraAlerter(void);
	void __fastcall Start(void);
	void __fastcall Stop(void);
	void __fastcall PackMessage(const System::Variant &Item);
	System::Variant __fastcall UnpackMessage(void)/* overload */;
	System::Variant __fastcall UnpackMessage(System::Variant &Item)/* overload */;
	TMessageType __fastcall NextItemType(void);
	void __fastcall SendPipeMessage(System::UnicodeString Name = L"");
	void __fastcall PurgePipe(void);
	void __fastcall SendEvent(System::UnicodeString Name, System::UnicodeString Message);
	void __fastcall PutMessage(const System::Variant &Item);
	System::Variant __fastcall GetMessage(void)/* overload */;
	System::Variant __fastcall GetMessage(System::Variant &Item)/* overload */;
	TMessageType __fastcall NextMessageType(void);
	void __fastcall SendMessage(System::UnicodeString Name = L"");
	__property Ora::TOraSession* AlerterSession = {read=InternalSession};
	
__published:
	__property Ora::TOraSession* Session = {read=FSession, write=SetSession};
	__property System::UnicodeString Events = {read=FEvents, write=SetEvents};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, default=0};
	__property int Interval = {read=FInterval, write=FInterval, default=0};
	__property TEventType EventType = {read=FEventType, write=SetEventType, nodefault};
	__property bool AutoCommit = {read=FAutoCommit, write=FAutoCommit, default=1};
	__property bool Active = {read=FActive, write=SetActive, default=0};
	__property TOnEventEvent OnEvent = {read=FOnEvent, write=FOnEvent};
	__property TOnTimeOutEvent OnTimeOut = {read=FOnTimeOut, write=FOnTimeOut};
};


class DELPHICLASS TOraAlerterUtils;
class PASCALIMPLEMENTATION TOraAlerterUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TOraAlerter* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TOraAlerter* Obj);
public:
	/* TObject.Create */ inline __fastcall TOraAlerterUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraAlerterUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Oraalerter */
using namespace Oraalerter;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraalerterHPP
