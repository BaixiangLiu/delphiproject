// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Memds.pas' rev: 21.00

#ifndef MemdsHPP
#define MemdsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Crxml.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Memds
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TDataSetServiceClass;

#pragma option push -b-
enum Memds__1 { rtModified, rtInserted, rtDeleted, rtUnmodified };
#pragma option pop

typedef Set<Memds__1, rtModified, rtUnmodified>  TUpdateRecordTypes;

typedef void __fastcall (__closure *TUpdateErrorEvent)(Db::TDataSet* DataSet, Db::EDatabaseError* E, Db::TUpdateKind UpdateKind, Db::TUpdateAction &UpdateAction);

typedef void __fastcall (__closure *TUpdateRecordEvent)(Db::TDataSet* DataSet, Db::TUpdateKind UpdateKind, Db::TUpdateAction &UpdateAction);

typedef System::PByte TRecordBuffer;

typedef void * TValueBuffer;

struct TRecInfo;
typedef TRecInfo *PRecInfo;

#pragma pack(push,1)
struct TRecInfo
{
	
public:
	int RecordNumber;
	Db::TUpdateStatus UpdateStatus;
	Db::TBookmarkFlag BookmarkFlag;
	bool RefComplexFields;
};
#pragma pack(pop)


struct TCalcFieldDescMapping
{
	
public:
	Memdata::TFieldDesc* FieldDesc;
	Db::TField* Field;
};


class DELPHICLASS TDataTypesMap;
class PASCALIMPLEMENTATION TDataTypesMap : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod virtual Db::TFieldType __fastcall GetFieldType(System::Word DataType);
	__classmethod virtual int __fastcall GetDataType(Db::TFieldType FieldType);
public:
	/* TObject.Create */ inline __fastcall TDataTypesMap(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TDataTypesMap(void) { }
	
};


typedef TMetaClass* TDataTypesMapClass;

class DELPHICLASS TDataSetUpdater;
class DELPHICLASS TMemDataSet;
class DELPHICLASS TDataSetService;
class PASCALIMPLEMENTATION TDataSetUpdater : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TMemDataSet* FDataSet;
	TDataSetService* FDataSetService;
	virtual bool __fastcall PerformAppend(void);
	virtual bool __fastcall PerformDelete(void);
	virtual bool __fastcall PerformUpdate(void);
	void __fastcall DoPerformAppend(void);
	void __fastcall DoPerformDelete(void);
	void __fastcall DoPerformUpdate(void);
	void __fastcall DoApplyRecord(Memdata::TUpdateRecKind UpdateKind, Memdata::TUpdateRecAction &Action, bool LastItem);
	virtual bool __fastcall BatchUpdate(void);
	virtual bool __fastcall CanFlushBatch(void);
	virtual void __fastcall FlushBatch(void);
	
public:
	__fastcall virtual TDataSetUpdater(TDataSetService* AOwner);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TDataSetUpdater(void) { }
	
};


class PASCALIMPLEMENTATION TDataSetService : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TMemDataSet* FDataset;
	TDataSetUpdater* FUpdater;
	virtual void __fastcall CreateDataSetUpdater(void);
	virtual void __fastcall SetDataSetUpdater(TDataSetUpdater* Value);
	void __fastcall FreeDataSetUpdater(void);
	virtual void __fastcall SetNumberRange(Db::TFieldDef* FieldDef);
	virtual Db::TFieldClass __fastcall GetFieldClass(Db::TFieldType FieldType);
	virtual void __fastcall PreInitCursor(void);
	virtual void __fastcall WriteFieldXMLDataType(Db::TField* Field, Memdata::TFieldDesc* FieldDesc, const System::UnicodeString FieldAlias, Crxml::XmlTextWriter* XMLWriter);
	virtual void __fastcall WriteFieldXMLAttributeType(Db::TField* Field, Memdata::TFieldDesc* FieldDesc, const System::UnicodeString FieldAlias, Crxml::XmlTextWriter* XMLWriter);
	virtual System::WideString __fastcall GetFieldXMLValue(Db::TField* Field, Memdata::TFieldDesc* FieldDesc);
	
public:
	__fastcall virtual TDataSetService(TMemDataSet* AOwner);
	__fastcall virtual ~TDataSetService(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	void __fastcall SaveToXML(Classes::TStream* Destination);
};


class PASCALIMPLEMENTATION TMemDataSet : public Db::TDataSet
{
	typedef Db::TDataSet inherited;
	
private:
	typedef DynamicArray<TCalcFieldDescMapping> _TMemDataSet__1;
	
	
private:
	System::Byte *FOldRecBuf;
	System::Byte *FFilterBuffer;
	bool FCachedUpdates;
	bool FLocalUpdate;
	bool FInInserting;
	bool FInEditing;
	System::UnicodeString FIndexFieldNames;
	_TMemDataSet__1 FCalcFieldsMapping;
	TUpdateRecordTypes FUpdateRecordTypes;
	TUpdateErrorEvent FOnUpdateError;
	TUpdateRecordEvent FOnUpdateRecord;
	bool __fastcall InternalLocateRecord(Classes::TList* KeyFields, const System::Variant &KeyValues, Memdata::TLocateExOptions Options, bool SavePos)/* overload */;
	void __fastcall SetCachedUpdates(bool Value);
	bool __fastcall GetUpdatesPending(void);
	bool __fastcall GetPrepared(void);
	void __fastcall SetPrepared(bool Value);
	Memdata::TItemTypes __fastcall ConvertUpdateRecordTypes(TUpdateRecordTypes Value);
	TUpdateRecordTypes __fastcall GetUpdateRecordTypes(void);
	void __fastcall SetUpdateRecordTypes(TUpdateRecordTypes Value);
	void __fastcall SetIndexFieldNames(System::UnicodeString Value);
	
protected:
	Memdata::TData* Data;
	TDataSetService* FDataSetService;
	int FBookmarkOfs;
	int FRecInfoOfs;
	int FRecBufSize;
	bool FInCacheProcessing;
	bool FInDeferredPost;
	System::Byte *NewCacheRecBuf;
	System::Byte *OldCacheRecBuf;
	System::Byte *OldDeferredPostBuf;
	TMemDataSet* FParentDataSet;
	int FLastParentPos;
	bool FLocalConstraints;
	bool FNumberRange;
	bool FNeedAddRef;
	bool FCacheCalcFields;
	bool FCreateCalcFieldDescs;
	HIDESBASE void __fastcall SetModified(bool Value);
	HIDESBASE Db::TDataSetState __fastcall SetTempState(const Db::TDataSetState Value);
	HIDESBASE void __fastcall RestoreState(const Db::TDataSetState Value);
	virtual void __fastcall DoBeforeRefresh(void);
	virtual void __fastcall DoAfterRefresh(void);
	virtual void __fastcall CreateIRecordSet(void);
	void __fastcall FreeIRecordSet(void);
	virtual void __fastcall SetIRecordSet(Memdata::TData* Value);
	virtual TDataSetServiceClass __fastcall GetDataSetServiceClass(void);
	void __fastcall CreateDataSetService(void);
	void __fastcall FreeDataSetService(void);
	virtual void __fastcall SetDataSetService(TDataSetService* Value);
	void __fastcall CheckDataSetService(void);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall CloseCursor(void);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalClose(void);
	virtual bool __fastcall IsCursorOpen(void);
	virtual void __fastcall DataReopen(void);
	virtual void __fastcall InternalRefresh(void);
	virtual void __fastcall DoAfterOpen(void);
	virtual TDataTypesMapClass __fastcall GetDataTypesMap(void);
	virtual void __fastcall InternalInitFieldDefs(void);
	virtual void __fastcall CreateFieldDefs(void);
	virtual void __fastcall ClearCalcFields(System::PByte Buffer);
	virtual System::UnicodeString __fastcall GetObjectFieldDefName(Db::TFieldDef* Parent, int Index, Memdata::TObjectType* ObjType);
	virtual int __fastcall GetFielDefSize(Db::TFieldType FieldType, Memdata::TFieldDesc* FieldDesc);
	void __fastcall GetObjectTypeNames(Db::TFields* Fields);
	virtual Db::TFieldType __fastcall GetFieldType(System::Word DataType)/* overload */;
	virtual Db::TFieldType __fastcall GetFieldType(Memdata::TFieldDesc* FieldDesc)/* overload */;
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer, bool NativeFormat)/* overload */;
	virtual void __fastcall DataConvert(Db::TField* Field, void * Source, void * Dest, bool ToNative);
	bool __fastcall GetSparseArrays(void);
	HIDESBASE void __fastcall SetSparseArrays(bool Value);
	virtual void __fastcall CheckFieldCompatibility(Db::TField* Field, Db::TFieldDef* FieldDef);
	virtual Db::TFieldClass __fastcall GetFieldClass(Db::TFieldType FieldType)/* overload */;
	virtual System::PByte __fastcall AllocRecordBuffer(void);
	virtual void __fastcall FreeRecordBuffer(System::PByte &Buffer);
	void __fastcall CopyRecordBuffer(void * SrcBuffer, void * DstBuffer);
	virtual void __fastcall InitRecord(System::PByte Buffer);
	virtual void __fastcall InternalInitRecord(System::PByte Buffer);
	System::PByte __fastcall GetOldRecord(void);
	bool __fastcall GetActiveRecBuf(System::PByte &RecBuf);
	virtual Db::TGetResult __fastcall GetRecord(System::PByte Buffer, Db::TGetMode GetMode, bool DoCheck);
	virtual void __fastcall BlockReadNext(void);
	virtual void __fastcall SetBlockReadSize(int Value);
	void __fastcall FreeRefBuffers(void);
	void __fastcall FreeRefComplexFields(System::PByte Buffer, bool WithBlob = true);
	virtual void __fastcall GetBookmarkData(System::PByte Buffer, void * Bookmark)/* overload */;
	virtual void __fastcall SetBookmarkData(System::PByte Buffer, void * Bookmark)/* overload */;
	virtual Db::TBookmarkFlag __fastcall GetBookmarkFlag(System::PByte Buffer);
	virtual void __fastcall SetBookmarkFlag(System::PByte Buffer, Db::TBookmarkFlag Value);
	virtual void __fastcall InternalFirst(void);
	virtual void __fastcall InternalLast(void);
	virtual void __fastcall InternalGotoBookmark(void * Bookmark);
	virtual void __fastcall InternalSetToRecord(System::PByte Buffer);
	virtual void __fastcall InternalAddRecord(void * Buffer, bool Append);
	virtual void __fastcall InternalInsert(void);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalEdit(void);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalCancel(void);
	virtual void __fastcall InternalDeferredPost(void);
	virtual void __fastcall SetDefaultExpressionValues(void);
	virtual void __fastcall DoOnNewRecord(void);
	void __fastcall DoPerformAppend(void);
	void __fastcall DoPerformDelete(void);
	void __fastcall DoPerformUpdate(void);
	void __fastcall DoApplyRecord(Memdata::TUpdateRecKind UpdateKind, Memdata::TUpdateRecAction &Action, bool LastItem);
	void __fastcall DoGetCachedFields(void);
	void __fastcall DoGetCachedBuffer(void * Buffer, void * Source = (void *)(0x0));
	void __fastcall ActivateFilters(void);
	void __fastcall DeactivateFilters(void);
	bool __fastcall RecordFilter(void * RecBuf);
	void __fastcall SetFilterData(const System::UnicodeString Text, Db::TFilterOptions Options);
	virtual void __fastcall SetFiltered(bool Value);
	virtual void __fastcall SetFilterOptions(Db::TFilterOptions Value);
	virtual void __fastcall SetFilterText(const System::UnicodeString Value);
	virtual void __fastcall SetOnFilterRecord(const Db::TFilterRecordEvent Value);
	virtual void __fastcall CopyFieldValue(const System::Variant &Value, /* out */ void * &ValuePtr, /* out */ int &ValueType, Memdata::TFieldDesc* FieldDesc, bool UseFieldType = true);
	bool __fastcall LocateRecord(const System::UnicodeString KeyFields, const System::Variant &KeyValues, Memdata::TLocateExOptions Options, bool SavePos)/* overload */;
	bool __fastcall LocateRecord(Db::TField* const *KeyFields, const int KeyFields_Size, const System::Variant &KeyValues, Memdata::TLocateExOptions Options, bool SavePos)/* overload */;
	virtual bool __fastcall FindRecord(bool Restart, bool GoForward);
	void __fastcall CheckCachedUpdateMode(void);
	Memdata::TBlob* __fastcall InternalGetBlob(Memdata::TFieldDesc* FieldDesc);
	bool __fastcall InternalSetBlob(Memdata::TFieldDesc* FieldDesc, Memdata::TBlob* Blob);
	bool __fastcall SetBlob(Db::TField* Field, Memdata::TBlob* Blob);
	virtual void __fastcall CloseBlob(Db::TField* Field);
	virtual int __fastcall GetRecordCount(void);
	virtual System::Word __fastcall GetRecordSize(void);
	virtual int __fastcall GetRecNo(void);
	virtual void __fastcall SetRecNo(int Value);
	virtual void __fastcall InternalHandleException(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall DataEvent(Db::TDataEvent Event, int Info);
	virtual System::Variant __fastcall GetStateFieldValue(Db::TDataSetState State, Db::TField* Field);
	
public:
	__fastcall virtual TMemDataSet(Classes::TComponent* aOwner);
	__fastcall virtual ~TMemDataSet(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall UnPrepare(void);
	void __fastcall CheckPrepared(void);
	int __fastcall GetFieldDescNo(Db::TField* Field);
	virtual Memdata::TFieldDesc* __fastcall GetFieldDesc(const Db::TField* Field)/* overload */;
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual bool __fastcall GetFieldData(int FieldNo, void * Buffer)/* overload */;
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer, bool NativeFormat)/* overload */;
	Memdata::TBlob* __fastcall GetBlob(const System::UnicodeString FieldName)/* overload */;
	Memdata::TBlob* __fastcall GetBlob(Db::TField* Field)/* overload */;
	virtual void __fastcall Cancel(void);
	void __fastcall DeferredPost(void);
	virtual bool __fastcall BookmarkValid(Sysutils::TBytes Bookmark);
	virtual int __fastcall CompareBookmarks(Sysutils::TBytes Bookmark1, Sysutils::TBytes Bookmark2);
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
	virtual bool __fastcall Locate(const System::UnicodeString KeyFields, const System::Variant &KeyValues, Db::TLocateOptions Options)/* overload */;
	HIDESBASE bool __fastcall Locate(Db::TField* const *KeyFields, const int KeyFields_Size, const System::Variant &KeyValues, Db::TLocateOptions Options)/* overload */;
	bool __fastcall LocateEx(const System::UnicodeString KeyFields, const System::Variant &KeyValues, Memdata::TLocateExOptions Options)/* overload */;
	bool __fastcall LocateEx(Db::TField* const *KeyFields, const int KeyFields_Size, const System::Variant &KeyValues, Memdata::TLocateExOptions Options)/* overload */;
	virtual System::Variant __fastcall Lookup(const System::UnicodeString KeyFields, const System::Variant &KeyValues, const System::UnicodeString ResultFields);
	virtual Db::TUpdateStatus __fastcall UpdateStatus(void);
	Db::TUpdateAction __fastcall UpdateResult(void);
	virtual void __fastcall ApplyUpdates(void);
	void __fastcall CommitUpdates(void);
	void __fastcall CancelUpdates(void);
	void __fastcall RestoreUpdates(void);
	void __fastcall RevertRecord(void);
	void __fastcall SaveToXML(Classes::TStream* Destination)/* overload */;
	void __fastcall SaveToXML(const System::UnicodeString FileName)/* overload */;
	virtual bool __fastcall IsSequenced(void);
	__property bool Prepared = {read=GetPrepared, write=SetPrepared, nodefault};
	__property bool CachedUpdates = {read=FCachedUpdates, write=SetCachedUpdates, default=0};
	__property bool UpdatesPending = {read=GetUpdatesPending, nodefault};
	__property bool LocalUpdate = {read=FLocalUpdate, write=FLocalUpdate, default=0};
	__property TUpdateRecordTypes UpdateRecordTypes = {read=GetUpdateRecordTypes, write=SetUpdateRecordTypes, default=11};
	__property bool SparseArrays = {read=GetSparseArrays, write=SetSparseArrays, nodefault};
	__property bool LocalConstraints = {read=FLocalConstraints, write=FLocalConstraints, default=1};
	__property TUpdateErrorEvent OnUpdateError = {read=FOnUpdateError, write=FOnUpdateError};
	__property TUpdateRecordEvent OnUpdateRecord = {read=FOnUpdateRecord, write=FOnUpdateRecord};
	__property System::UnicodeString IndexFieldNames = {read=FIndexFieldNames, write=SetIndexFieldNames};
	
/* Hoisted overloads: */
	
protected:
	inline Db::TFieldClass __fastcall  GetFieldClass(Db::TFieldDef* FieldDef){ return Db::TDataSet::GetFieldClass(FieldDef); }
	
};


class DELPHICLASS TBlobStream;
class PASCALIMPLEMENTATION TBlobStream : public Classes::TStream
{
	typedef Classes::TStream inherited;
	
protected:
	Db::TBlobField* FField;
	TMemDataSet* FDataSet;
	System::Byte *FBuffer;
	Db::TBlobStreamMode FMode;
	int FFieldNo;
	bool FOpened;
	bool FModified;
	int FPosition;
	int __fastcall GetBlobSize(void);
	virtual void __fastcall SetSize(int NewSize)/* overload */;
	
public:
	__fastcall TBlobStream(Db::TBlobField* Field, Db::TBlobStreamMode Mode);
	__fastcall virtual ~TBlobStream(void);
	virtual int __fastcall Read(void *Buffer, int Count);
	virtual int __fastcall Write(const void *Buffer, int Count);
	virtual int __fastcall Seek(int Offset, System::Word Origin)/* overload */;
	void __fastcall Truncate(void);
	
/* Hoisted overloads: */
	
protected:
	inline void __fastcall  SetSize(const __int64 NewSize){ Classes::TStream::SetSize(NewSize); }
	
public:
	inline __int64 __fastcall  Seek(const __int64 Offset, Classes::TSeekOrigin Origin){ return Classes::TStream::Seek(Offset, Origin); }
	
};


class DELPHICLASS TMemDSUtils;
class PASCALIMPLEMENTATION TMemDSUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod bool __fastcall SetBlob(TMemDataSet* Obj, Db::TField* Field, Memdata::TBlob* Blob);
	__classmethod Memdata::TBlob* __fastcall GetBlob(TMemDataSet* Obj, Memdata::TFieldDesc* FieldDesc);
public:
	/* TObject.Create */ inline __fastcall TMemDSUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TMemDSUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt uaDefault = 0xa;
extern PACKAGE bool SendDataSetChangeEventAfterOpen;
extern PACKAGE bool DoNotRaiseExcetionOnUaFail;
extern PACKAGE bool DefaultExpressionOldBehavior;
extern PACKAGE System::UnicodeString __fastcall ChangeDecimalSeparator(const System::UnicodeString Value, System::UnicodeString OldSeparator, System::UnicodeString NewSeparator);

}	/* namespace Memds */
using namespace Memds;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MemdsHPP
