// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Virtualtable.pas' rev: 21.00

#ifndef VirtualtableHPP
#define VirtualtableHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Strutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Virtualtable
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TCRFileFormat { ffVTD, ffXML };
#pragma option pop

#pragma option push -b-
enum TVirtualTableOption { voPersistentData, voStored };
#pragma option pop

typedef Set<TVirtualTableOption, voPersistentData, voStored>  TVirtualTableOptions;

class DELPHICLASS TVirtualTable;
class PASCALIMPLEMENTATION TVirtualTable : public Memds::TMemDataSet
{
	typedef Memds::TMemDataSet inherited;
	
private:
	TVirtualTableOptions FOptions;
	bool FStreamedActive;
	bool FAvoidRefreshData;
	int FAvoidReload;
	Classes::TMemoryStream* FRecordDataStream;
	bool FIsCursorOpen;
	void __fastcall ReadBinaryData(Classes::TStream* Stream);
	void __fastcall WriteBinaryData(Classes::TStream* Stream);
	bool __fastcall IsFieldDefsStored(void);
	Db::TFieldDefs* __fastcall GetFieldDefs(void);
	HIDESBASE void __fastcall SetFieldDefs(Db::TFieldDefs* Value);
	
protected:
	bool FFieldDefsByField;
	virtual void __fastcall Loaded(void);
	virtual void __fastcall CreateIRecordSet(void);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalClose(void);
	virtual bool __fastcall IsCursorOpen(void);
	virtual void __fastcall CreateFieldDefs(void);
	virtual void __fastcall DefChanged(System::TObject* Sender);
	void __fastcall Reload(void);
	virtual void __fastcall DataEvent(Db::TDataEvent Event, int Info);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall AssignDataSet(Db::TDataSet* Source);
	virtual void __fastcall SetActive(bool Value);
	
public:
	__fastcall virtual TVirtualTable(Classes::TComponent* Owner);
	__fastcall virtual ~TVirtualTable(void);
	virtual bool __fastcall IsSequenced(void);
	void __fastcall AddField(System::UnicodeString Name, Db::TFieldType FieldType, int Size = 0x0, bool Required = false);
	void __fastcall DeleteField(System::UnicodeString Name);
	void __fastcall DeleteFields(void);
	void __fastcall Clear(void);
	void __fastcall LoadFromStream(Classes::TStream* Stream, bool LoadFields = true);
	void __fastcall SaveToStream(Classes::TStream* Stream, bool StoreFields = true);
	void __fastcall LoadFromFile(const System::UnicodeString FileName);
	void __fastcall SaveToFile(const System::UnicodeString FileName);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property TVirtualTableOptions Options = {read=FOptions, write=FOptions, default=3};
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property Db::TFieldDefs* FieldDefs = {read=GetFieldDefs, write=SetFieldDefs, stored=IsFieldDefsStored};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool VTOldBehavior;

}	/* namespace Virtualtable */
using namespace Virtualtable;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VirtualtableHPP
