// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Mtscall.pas' rev: 21.00

#ifndef MtscallHPP
#define MtscallHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Mtscall
{
//-- type declarations -------------------------------------------------------
struct CRBOID;
typedef CRBOID *PCRBoid;

#pragma pack(push,1)
struct CRBOID
{
	
public:
	StaticArray<System::Byte, 16> rgb_;
};
#pragma pack(pop)


typedef CRBOID TCRBoid;

struct CRXACTOPT;
typedef CRXACTOPT *PCRXactOpt;

#pragma pack(push,1)
struct CRXACTOPT
{
	
public:
	unsigned ulTimeout;
	StaticArray<System::ShortInt, 40> szDescription;
};
#pragma pack(pop)


typedef CRXACTOPT TCRXActOpt;

struct CRXACTTRANSINFO;
typedef CRXACTTRANSINFO *PCRXactTransInfo;

#pragma pack(push,1)
struct CRXACTTRANSINFO
{
	
public:
	CRBOID uow;
	int isoLevel;
	unsigned isoFlags;
	unsigned grfTCSupported;
	unsigned grfRMSupported;
	unsigned grfTCSupportedRetaining;
	unsigned grfRMSupportedRetaining;
};
#pragma pack(pop)


typedef CRXACTTRANSINFO TCRXactTransInfo;

__interface ICRTransaction;
typedef System::DelphiInterface<ICRTransaction> _di_ICRTransaction;
__interface  INTERFACE_UUID("{0FB15084-AF41-11CE-BD2B-204C4F4F5020}") ICRTransaction  : public System::IInterface 
{
	
public:
	virtual HRESULT __stdcall Commit(BOOL fRetaining, unsigned grfTC, unsigned grfRM) = 0 ;
	virtual HRESULT __stdcall Abort(PCRBoid pboidReason, BOOL fRetaining, BOOL fAsync) = 0 ;
	virtual HRESULT __stdcall GetTransactionInfo(/* out */ CRXACTTRANSINFO &pinfo) = 0 ;
};

__interface ICRTransactionOptions;
typedef System::DelphiInterface<ICRTransactionOptions> _di_ICRTransactionOptions;
__interface  INTERFACE_UUID("{3A6AD9E0-23B9-11CF-AD60-00AA00A74CCD}") ICRTransactionOptions  : public System::IInterface 
{
	
public:
	virtual HRESULT __stdcall SetOptions(CRXACTOPT &pOptions) = 0 ;
	virtual HRESULT __stdcall GetOptions(CRXACTOPT &pOptions) = 0 ;
};

__interface ICRTransactionSC;
typedef System::DelphiInterface<ICRTransactionSC> _di_ICRTransactionSC;
__interface  INTERFACE_UUID("{0FB15084-AF41-11CE-BD2B-204C4F4F5020}") ICRTransactionSC  : public System::IInterface 
{
	
public:
	virtual HRESULT __safecall Commit(BOOL fRetaining, unsigned grfTC, unsigned grfRM) = 0 ;
	virtual HRESULT __safecall Abort(PCRBoid pboidReason, BOOL fRetaining, BOOL fAsync) = 0 ;
	virtual HRESULT __safecall GetTransactionInfo(/* out */ CRXACTTRANSINFO &pinfo) = 0 ;
};

__interface ICRTransactionOptionsSC;
typedef System::DelphiInterface<ICRTransactionOptionsSC> _di_ICRTransactionOptionsSC;
__interface  INTERFACE_UUID("{3A6AD9E0-23B9-11CF-AD60-00AA00A74CCD}") ICRTransactionOptionsSC  : public System::IInterface 
{
	
public:
	virtual HRESULT __safecall SetOptions(CRXACTOPT &pOptions) = 0 ;
	virtual HRESULT __safecall GetOptions(CRXACTOPT &pOptions) = 0 ;
};

__interface ICRTransactionDispenserSC;
typedef System::DelphiInterface<ICRTransactionDispenserSC> _di_ICRTransactionDispenserSC;
__interface  INTERFACE_UUID("{3A6AD9E1-23B9-11CF-AD60-00AA00A74CCD}") ICRTransactionDispenserSC  : public System::IInterface 
{
	
public:
	virtual HRESULT __safecall GetOptionsObject(/* out */ _di_ICRTransactionOptions &ppOptions) = 0 ;
	virtual HRESULT __safecall BeginTransaction(const System::_di_IInterface punkOuter, int isoLevel, unsigned isoFlags, const _di_ICRTransactionOptions pOptions, /* out */ _di_ICRTransaction &ppTransaction) = 0 ;
};

typedef int __cdecl (*_DtcGetTransactionManagerEx)(char * pszHost, char * pszTmName, const GUID &riid, int grfOptions, void * pvConfigParams, /* out */ _di_ICRTransactionDispenserSC &ppvObject);

//-- var, const, procedure ---------------------------------------------------
static const Word ISOLATIONLEVEL_READUNCOMMITTED = 0x100;
static const Word ISOLATIONLEVEL_READCOMMITTED = 0x1000;
static const int ISOLATIONLEVEL_REPEATABLEREAD = 0x10000;
static const int ISOLATIONLEVEL_SERIALIZABLE = 0x100000;
extern PACKAGE GUID IID_ITransactionDispenser;
extern PACKAGE _DtcGetTransactionManagerEx DtcGetTransactionManagerEx;
extern PACKAGE void __fastcall InitMSDTC(void);
extern PACKAGE void __fastcall FreeMSDTC(void);

}	/* namespace Mtscall */
using namespace Mtscall;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MtscallHPP
