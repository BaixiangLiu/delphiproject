// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraloader.pas' rev: 21.00

#ifndef OraloaderHPP
#define OraloaderHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Daloader.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraloader
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDPColumn;
class PASCALIMPLEMENTATION TDPColumn : public Daloader::TDAColumn
{
	typedef Daloader::TDAColumn inherited;
	
private:
	int FSize;
	int FPrecision;
	int FScale;
	System::UnicodeString FDateFormat;
	int __fastcall GetSize(void);
	void __fastcall SetSize(int Value);
	
protected:
	virtual Daloader::TDAColumnDataType __fastcall GetDataType(void);
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	
public:
	__fastcall virtual TDPColumn(Classes::TCollection* Collection);
	
__published:
	__property DataType = {stored=false};
	__property int Size = {read=GetSize, write=SetSize, default=0};
	__property int Precision = {read=FPrecision, write=FPrecision, default=0};
	__property int Scale = {read=FScale, write=FScale, default=0};
	__property System::UnicodeString DateFormat = {read=FDateFormat, write=FDateFormat};
public:
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TDPColumn(void) { }
	
};


#pragma option push -b-
enum TLoadMode { lmDirect, lmDML };
#pragma option pop

class DELPHICLASS TOraLoader;
typedef void __fastcall (__closure *TDPPutDataEvent)(TOraLoader* Sender);

typedef void __fastcall (__closure *TDPGetColumnDataEvent)(System::TObject* Sender, TDPColumn* Column, int Row, System::Variant &Value, bool &IsEOF);

#pragma option push -b-
enum TDPErrorAction { dpAbort, dpFail, dpIgnore };
#pragma option pop

typedef void __fastcall (__closure *TDPErrorEvent)(TOraLoader* Sender, Sysutils::Exception* E, int Col, int Row, TDPErrorAction &Action);

class PASCALIMPLEMENTATION TOraLoader : public Daloader::TDALoader
{
	typedef Daloader::TDALoader inherited;
	
private:
	TLoadMode FLoadMode;
	TDPPutDataEvent FOnPutData;
	TDPGetColumnDataEvent FOnGetColumnData;
	TDPErrorEvent FOnError;
	Ora::TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(Ora::TOraSession* Value);
	void __fastcall SetLoadMode(TLoadMode Value);
	void __fastcall SetOnError(const TDPErrorEvent Value);
	void __fastcall SetOnPutData(const TDPPutDataEvent Value);
	void __fastcall SetOnGetColumnData(const TDPGetColumnDataEvent Value);
	void __fastcall DAPutDataEvent(Daloader::TDALoader* Sender);
	void __fastcall DAGetColumnDataEvent(System::TObject* Sender, Daloader::TDAColumn* Column, int Row, System::Variant &Value, bool &IsEOF);
	void __fastcall DoOnError(Sysutils::Exception* E, int Col, int Row, Oraclasses::_TDPErrorAction &Action);
	
protected:
	virtual Craccess::TCRLoaderClass __fastcall GetInternalLoaderClass(void);
	virtual void __fastcall SetInternalLoader(Craccess::TCRLoader* Value);
	__classmethod virtual Daloader::TDAColumnClass __fastcall GetColumnClass();
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMapClass(void);
	virtual Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	virtual void __fastcall ReadColumn(Daloader::TDAColumn* Column, Craccess::TCRLoaderColumn* CRColumn);
	virtual void __fastcall WriteColumn(Daloader::TDAColumn* Column, Craccess::TCRLoaderColumn* CRColumn);
	
public:
	__fastcall virtual TOraLoader(Classes::TComponent* Owner);
	__fastcall virtual ~TOraLoader(void);
	
__published:
	__property Ora::TOraSession* Session = {read=GetSession, write=SetSession};
	__property TableName;
	__property Columns;
	__property TLoadMode LoadMode = {read=FLoadMode, write=SetLoadMode, default=0};
	__property TDPPutDataEvent OnPutData = {read=FOnPutData, write=SetOnPutData};
	__property TDPGetColumnDataEvent OnGetColumnData = {read=FOnGetColumnData, write=SetOnGetColumnData};
	__property TDPErrorEvent OnError = {read=FOnError, write=SetOnError};
	__property OnProgress;
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Oraloader */
using namespace Oraloader;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraloaderHPP
