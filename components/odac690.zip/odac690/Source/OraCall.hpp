// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oracall.pas' rev: 21.00

#ifndef OracallHPP
#define OracallHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Mtscall.hpp>	// Pascal unit
#include <Daconsts.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------
namespace Oracall {
  #pragma option push -b-
  enum TChangeNotifyOperation { cnoInsert, cnoUpdate, cnoDelete, cnoAllRows, cnoAlter, cnoDrop };
  typedef Set<TChangeNotifyOperation, cnoInsert, cnoDrop> TChangeNotifyOperations;
  typedef TChangeNotifyOperation TChangeNotifyDMLOperation;
  typedef Set<TChangeNotifyDMLOperation, cnoInsert, cnoDelete> TChangeNotifyDMLOperations;
  #pragma option pop
}

namespace Oracall
{
//-- type declarations -------------------------------------------------------
typedef int eword;

typedef unsigned uword;

typedef int sword;

typedef System::ShortInt eb1;

typedef System::Byte ub1;

typedef System::ShortInt sb1;

typedef System::Byte *pub1;

typedef System::ShortInt *psb1;

typedef pub1 *ppub1;

typedef ppub1 *pppub1;

typedef System::Word *pub2;

typedef short *psb2;

typedef pub2 *ppub2;

typedef int *psb4;

typedef unsigned *pub4;

typedef pub4 *ppub4;

typedef __int64 *pub8;

typedef pub8 *ppub8;

typedef void * *PPointer;

typedef int *pbool;

typedef short eb2;

typedef System::Word ub2;

typedef short sb2;

typedef int eb4;

typedef unsigned ub4;

typedef int sb4;

typedef __int64 ub8;

typedef int tbool;

typedef int tsize;

#pragma pack(push,1)
struct TRD
{
	
public:
	unsigned rcs4;
	System::Word rcs5;
	System::Byte rcs6;
};
#pragma pack(pop)


typedef TRD *PTRD;

#pragma pack(push,1)
struct TRowId7
{
	
public:
	TRD rd;
	unsigned rcs7;
	unsigned rcs8;
};
#pragma pack(pop)


typedef TRowId7 *PRowId7;

#pragma pack(push,1)
struct TCDAHead
{
	
public:
	short v2_rc;
	System::Word ft;
	unsigned rpc;
	System::Word peo;
	System::Byte fc;
	System::Byte rcs1;
	System::Word rc;
	System::Byte wrn;
	System::Byte rcs2;
	int rcs3;
	TRowId7 rid;
	int ose;
	System::Byte chk;
	void *rcsp;
};
#pragma pack(pop)


#pragma pack(push,1)
struct TCDA
{
	
public:
	short v2_rc;
	System::Word ft;
	unsigned rpc;
	System::Word peo;
	System::Byte fc;
	System::Byte rcs1;
	System::Word rc;
	System::Byte wrn;
	System::Byte rcs2;
	int rcs3;
	TRowId7 rid;
	int ose;
	System::Byte chk;
	void *rcsp;
	StaticArray<System::Byte, 20> rcs9;
};
#pragma pack(pop)


typedef TCDA *PCDA;

typedef TCDA TLDA;

typedef PCDA PLDA;

typedef StaticArray<System::Byte, 256> THDA;

typedef THDA *PHDA;

typedef int __cdecl (*_obindps)(void * cursor, System::Byte opcode, char * sqlvar, int sqlvl, pub1 pvctx, int progvl, int ftype, int scale, psb2 indp, pub2 alen, pub2 arcode, int pv_skip, int ind_skip, int alen_skip, int rc_skip, unsigned maxsiz, pub4 cursiz, void * fmt, int fmtl, int fmtt);

typedef int __cdecl (*_obreak)(void * lda);

typedef int __cdecl (*_ocan)(void * cursor);

typedef int __cdecl (*_oclose)(void * cursor);

typedef int __cdecl (*_ocof)(void * lda);

typedef int __cdecl (*_ocom)(void * lda);

typedef int __cdecl (*_ocon)(void * lda);

typedef int __cdecl (*_odefinps)(void * cursor, System::Byte opcode, int pos, void * bufctx, int bufl, int ftype, int scale, psb2 indp, void * fmt, int fmtl, int fmtt, pub2 rlen, pub2 rcode, int pv_skip, int ind_skip, int alen_skip, int rc_skip);

typedef int __cdecl (*_odessp)(void * lda, char * objnam, int onlen, pub1 rsv1, int rsv1ln, pub1 rsv2, int rsv2ln, pub2 ovrld, pub2 pos, pub2 level, void * argnam, pub2 arnlen, pub2 dtype, pub1 defsup, pub1 mode, pub4 dtsiz, psb2 prec, psb2 scale, pub1 radix, pub4 spare, unsigned &arrsiz);

typedef int __cdecl (*_odescr)(void * cursor, int pos, int &dbsize, short &dbtype, void * cbuf, int &cbufl, int &dsize, short &prec, short &scale, short &nullok);

typedef int __cdecl (*_oerhms)(void * lda, short rcode, void * buf, int bufsiz);

typedef int __cdecl (*_oermsg)(short rcode, char * buf);

typedef int __cdecl (*_oexec)(void * cursor);

typedef int __cdecl (*_oexfet)(void * cursor, unsigned nrows, int cancel, int exact);

typedef int __cdecl (*_oexn)(void * cursor, int iters, int rowoff);

typedef int __cdecl (*_ofen)(void * cursor, int nrows);

typedef int __cdecl (*_ofetch)(void * cursor);

typedef int __cdecl (*_oflng)(void * cursor, int pos, pub1 buf, int bufl, int dtype, pub4 retl, int offset);

typedef int __cdecl (*_ogetpi)(void * cursor, System::Byte &piecep, void * &ctxpp, unsigned &iterp, unsigned &indexp);

typedef int __cdecl (*_oopt)(void * cursor, int rbopt, int waitopt);

typedef int __cdecl (*_opinit)(unsigned mode);

typedef int __cdecl (*_olog)(void * lda, PHDA hda, char * uid, int uidl, char * pswd, int pswdl, char * conn, int connl, unsigned mode);

typedef int __cdecl (*_ologof)(void * lda);

typedef int __cdecl (*_oopen)(void * cursor, void * lda, void * dbn, int dbnl, int arsize, void * uid, int uidl);

typedef int __cdecl (*_oparse)(void * cursor, char * sqlstm, int sqllen, int defflg, unsigned lngflg);

typedef int __cdecl (*_orol)(void * lda);

typedef int __cdecl (*_osetpi)(void * cursor, System::Byte piece, void * bufp, unsigned &lenp);

typedef void __cdecl (*_sqlld2)(void * lda, char * cname, psb4 cnlen);

typedef void __cdecl (*_sqllda)(void * lda);

typedef int __cdecl (*_onbset)(void * lda);

typedef int __cdecl (*_onbtst)(void * lda);

typedef int __cdecl (*_onbclr)(void * lda);

typedef int __cdecl (*_ognfd)(void * lda, void * fdp);

typedef int __cdecl (*_obndra)(void * cursor, char * sqlvar, int sqlvl, pub1 progv, int progvl, int ftype, int scale, psb2 indp, pub2 alen, pub2 arcode, unsigned maxsiz, pub4 cursiz, void * fmt, int fmtl, int fmtt);

typedef int __cdecl (*_obndrn)(void * cursor, int sqlvn, pub1 progv, int progvl, int ftype, int scale, psb2 indp, char * fmt, int fmtl, int fmtt);

typedef int __cdecl (*_obndrv)(void * cursor, char * sqlvar, int sqlvl, void * progv, int progvl, int ftype, int scale, psb2 indp, void * fmt, int fmtl, int fmtt);

typedef int __cdecl (*_odefin)(void * cursor, int pos, void * buf, int bufl, int ftype, int scale, psb2 indp, void * fmt, int fmtl, int fmtt, pub2 rlen, pub2 rcode);

struct OCIDirPathCtx
{
	
};


struct OCIDirPathColArray
{
	
};


struct OCIDirPathStream
{
	
};


struct OCIDirPathDesc
{
	
};


typedef OCIDirPathCtx *pOCIDirPathCtx;

typedef OCIDirPathColArray *pOCIDirPathColArray;

typedef OCIDirPathStream *pOCIDirPathStream;

typedef OCIDirPathDesc *pOCIDirPathDesc;

#pragma pack(push,1)
struct TRowId8
{
	
public:
	unsigned ridobjnum;
	System::Word ridfilenum;
	System::Word filler;
	unsigned ridblocknum;
	System::Word ridslotnum;
};
#pragma pack(pop)


typedef TRowId8 *PRowid8;

#pragma pack(push,1)
struct TRowId81
{
	
public:
	System::Byte filler;
	unsigned ridobjnum;
	System::Word ridfilenum;
	unsigned ridblocknum;
	System::Word ridslotnum;
};
#pragma pack(pop)


typedef TRowId81 *PRowid81;

#pragma pack(push,1)
struct OCIRowid
{
	
public:
	StaticArray<System::Byte, 8> Unknown;
	TRowId8 RowId;
};
#pragma pack(pop)


typedef OCIRowid *POCIRowid;

#pragma pack(push,1)
struct OCIRowid81
{
	
public:
	StaticArray<System::Byte, 8> Unknown;
	TRowId81 *RowId;
};
#pragma pack(pop)


typedef OCIRowid81 *POCIRowid81;

struct OCINumber
{
	
public:
	StaticArray<System::Byte, 22> OCINumberPart;
};


#pragma pack(push,1)
struct OCITime
{
	
public:
	System::Byte OCITimeHH;
	System::Byte OCITimeMI;
	System::Byte OCITimeSS;
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIDate
{
	
public:
	short OCIDateYYYY;
	System::Byte OCIDateMM;
	System::Byte OCIDateDD;
	OCITime OCIDateTime;
};
#pragma pack(pop)


typedef int __cdecl (*TOCICallbackFailover)(void * svchp, void * envhp, void * fo_ctx, unsigned fo_type, unsigned fo_event);

#pragma pack(push,1)
struct TOCIFoCbkStruct
{
	
public:
	void *callback_function;
	void *fo_ctx;
};
#pragma pack(pop)


typedef void * pOCIBind;

typedef void * pOCIDefine;

typedef void * pOCIDescribe;

typedef void * pOCIEnv;

typedef void * pOCIError;

typedef void * pOCIServer;

typedef void * pOCISession;

typedef void * pOCIStmt;

typedef void * pOCISvcCtx;

typedef void * pOCITrans;

typedef void * pOCIComplexObject;

typedef void * pOCISPool;

typedef void * pOCIAuthInfo;

typedef void * pOCIParam;

typedef void * pOCISnapshot;

typedef void * pOCILobLocator;

typedef void * pOCIDateTime;

typedef void * pOCIInterval;

typedef void * pOCIType;

typedef void * ppOCIString;

typedef void * pOCINumber;

typedef void * pOCIDate;

typedef void * pOCIString;

typedef void * pOCIRaw;

typedef void * pOCIRef;

typedef void * pOCIColl;

typedef void * pOCIArray;

typedef void * pOCITable;

typedef void * pOCIExtProcContext;

typedef void * pOCISubscription;

typedef void * *ppOCIEnv;

typedef void * *ppOCIBind;

typedef void * *ppOCIDefine;

typedef void * *ppOCIStmt;

typedef void * *ppOCISvcCtx;

typedef void * pOCIHandle;

typedef void * *ppOCIHandle;

typedef int OCIParam;

typedef int OCISnapshot;

typedef int OCILobLocator;

typedef int OCIDateTime;

typedef int OCIInterval;

typedef void * pOCIDescriptor;

typedef void * *ppOCIDescriptor;

typedef void * *ppOCIParam;

typedef void * *ppOCILobLocator;

typedef void * *ppOCIDateTime;

typedef void * *ppOCIInterval;

typedef int OCIType;

#pragma pack(push,1)
struct OCIString
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIRaw
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIRef
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIColl
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIArray
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCITable
{
	
};
#pragma pack(pop)


#pragma pack(push,1)
struct OCIIter
{
	
};
#pragma pack(pop)


typedef void * *ppOCIType;

typedef void * *ppOCIRef;

typedef int tenum;

typedef System::Word OCIDuration;

typedef short OCIInd;

typedef int OCILockOpt;

typedef int OCIMarkOpt;

typedef int OCIObjectEvent;

typedef int OCIObjectProperty;

typedef int OCIPinOpt;

typedef int OCIRefreshOpt;

typedef System::Word OCITypeCode;

typedef int OCITypeEncap;

typedef int OCITypeGetOpt;

typedef int OCITypeMethodFlag;

typedef int OCITypeParamMode;

typedef System::Byte OCIObjectPropId;

typedef int OCIObjectLifetime;

typedef unsigned OCIObjectMarkstatus;

typedef short *pOCIInd;

#pragma pack(push,1)
struct TXID
{
	
public:
	int FormatID;
	int Gtrid_length;
	int Bqual_length;
	StaticArray<System::Byte, 128> Data;
};
#pragma pack(pop)


typedef int __cdecl (*TOCISubscriptionNotify)(void * pCtx, void * pSubscrHp, void * pPayload, unsigned iPayloadLen, void * pDescriptor, unsigned iMode);

typedef int __cdecl (*_OCIAttrGet1)(void * trgthndlp, unsigned trghndltyp, void * attributep, pub4 sizep, unsigned attrtype, void * errhp);

typedef int __cdecl (*_OCIAttrGet2)(void * trgthndlp, unsigned trghndltyp, int &attributep, pub4 sizep, unsigned attrtype, void * errhp);

typedef int __cdecl (*_OCIAttrSet1)(void * trgthndlp, unsigned trghndltyp, void * attributep, unsigned size, unsigned attrtype, void * errhp);

typedef int __cdecl (*_OCIAttrSet2)(void * trgthndlp, unsigned trghndltyp, int &attributep, unsigned size, unsigned attrtype, void * errhp);

typedef int __cdecl (*_OCIBindArrayOfStruct)(void * bindp, void * errhp, unsigned pvskip, unsigned indskip, unsigned alskip, unsigned rcskip);

typedef int __cdecl (*_OCIBindByName)(void * stmtp, void * &bindpp, void * errhp, void * placeholder, int placeh_len, void * valuep, int value_sz, System::Word dty, void * indp, pub2 alenp, pub2 rcodep, unsigned maxarr_len, pub4 curelep, unsigned mode);

typedef int __cdecl (*_OCIBindByPos)(void * stmtp, void * &bindpp, void * errhp, unsigned position, void * valuep, int value_sz, System::Word dty, void * indp, pub2 alenp, pub2 rcodep, unsigned maxarr_len, pub4 curelep, unsigned mode);

typedef int __cdecl (*TOCICallbackInBind)(void * ictxp, void * bindp, unsigned iter, unsigned index, void * &bufpp, unsigned &alenp, System::Byte &piecep, void * &indpp);

typedef int __cdecl (*TOCICallbackOutBind)(void * octxp, void * bindp, unsigned iter, unsigned index, void * &bufpp, pub4 &alenpp, System::Byte &piecep, void * &indpp, pub2 &rcodepp);

typedef int __cdecl (*_OCIBindDynamic)(void * bindp, void * errhp, void * ictxp, void * icbfp, void * octxp, void * ocbfp);

typedef int __cdecl (*_OCIBindObject)(void * bindp, void * errhp, const void * otype, void * pgvpp, pub4 pvszsp, void * indpp, pub4 indszp);

typedef int __cdecl (*_OCIBreak)(void * hndlp, void * errhp);

typedef int __cdecl (*_OCIDefineArrayOfStruct)(void * defnp, void * errhp, unsigned pvskip, unsigned indskip, unsigned rlskip, unsigned rcskip);

typedef int __cdecl (*_OCIDefineByPos)(void * stmtp, void * &defnpp, void * errhp, unsigned position, void * valuep, int value_sz, System::Word dty, void * indp, pub2 rlenp, pub2 rcodep, unsigned mode);

typedef int __cdecl (*TOCICallbackDefine)(void * octxp, void * defnp, unsigned iter, void * &bufpp, pub4 &alenpp, System::Byte &piecep, void * &indpp, pub2 &rcodep);

typedef int __cdecl (*_OCIDefineDynamic)(void * defnp, void * errhp, void * octxp, void * ocbfp);

typedef int __cdecl (*_OCIDefineObject)(void * defnp, void * errhp, const void * otype, void * pgvpp, pub4 pvszsp, void * indpp, pub4 indszp);

typedef int __cdecl (*_OCIDescribeAny)(void * svchp, void * errhp, void * objptr, unsigned objnm_len, System::Byte objptr_typ, System::Byte info_level, System::Byte objtyp, void * dschp);

typedef int __cdecl (*_OCIDescriptorAlloc)(void * parenth, void * &descpp, unsigned dtype, int xtramem_sz, void * usrmempp);

typedef int __cdecl (*_OCIDescriptorFree)(void * descp, unsigned dtype);

typedef int __cdecl (*_OCIEnvInit)(void * &envhpp, unsigned mode, int xtramemsz, void * usrmempp);

typedef int __cdecl (*_OCIErrorGet)(void * hndlp, unsigned recordno, void * sqlstate, int &errcodep, void * bufp, unsigned bufsiz, unsigned htype);

typedef int __cdecl (*_OCIHandleAlloc)(void * parenth, void * &hndlpp, unsigned htype, int xtramem_sz, void * usrmempp);

typedef int __cdecl (*_OCIHandleFree)(void * hndlp, unsigned htype);

typedef int __cdecl (*_OCIInitialize)(unsigned mode, void * ctxp, void * malocfp, void * ralocfp, void * mfreefp);

typedef int __cdecl (*_OCILdaToSvcCtx)(void * &svchpp, void * errhp, void * ldap);

typedef int __cdecl (*_OCIParamGet)(void * hndlp, unsigned htype, void * errhp, void * &parmdpp, unsigned pos);

typedef int __cdecl (*_OCIPasswordChange)(void * svchp, void * errhp, const void * user_name, unsigned usernm_len, const void * opasswd, unsigned opasswd_len, const void * npasswd, int npasswd_len, unsigned mode);

typedef int __cdecl (*_OCIServerAttach)(void * srvhp, void * errhp, void * dblink, int dblink_len, unsigned mode);

typedef int __cdecl (*_OCIServerDetach)(void * srvhp, void * errhp, unsigned mode);

typedef int __cdecl (*_OCIServerVersion)(void * hndlp, void * errhp, void * bufp, unsigned bufsz, System::Byte hndltype);

typedef int __cdecl (*_OCISessionBegin)(void * svchp, void * errhp, void * usrhp, unsigned credt, unsigned mode);

typedef int __cdecl (*_OCISessionEnd)(void * svchp, void * errhp, void * usrhp, unsigned mode);

typedef int __cdecl (*_OCISessionGet)(void * envhp, void * errhp, void * &svchp, void * authhp, void * poolName, unsigned poolName_len, void * tagInfo, unsigned tagInfo_len, void * &retTagInfo, unsigned &retTagInfo_len, BOOL &found, unsigned mode);

typedef int __cdecl (*_OCISessionRelease)(void * svchp, void * errhp, void * tag, unsigned tag_len, unsigned mode);

typedef int __cdecl (*_OCISessionPoolCreate)(void * envhp, void * errhp, void * spoolhp, void * &poolName, unsigned &poolNameLen, void * connStr, unsigned connStrLen, unsigned sessMin, unsigned sessMax, unsigned sessIncr, void * userid, unsigned useridLen, void * password, unsigned passwordLen, unsigned mode);

typedef int __cdecl (*_OCISessionPoolDestroy)(void * spoolhp, void * errhp, unsigned mode);

typedef int __cdecl (*_OCITransStart)(void * svchp, void * errhp, System::Word timeout, unsigned flags);

typedef int __cdecl (*_OCITransRollback)(void * svchp, void * errhp, unsigned flags);

typedef int __cdecl (*_OCITransCommit)(void * svchp, void * errhp, unsigned flags);

typedef int __cdecl (*_OCITransDetach)(void * svchp, void * errhp, unsigned flags);

typedef int __cdecl (*_OCITransPrepare)(void * svchp, void * errhp, unsigned flags);

typedef int __cdecl (*_OCITransForget)(void * svchp, void * errhp, unsigned flags);

typedef int __cdecl (*_OCIStmtExecute)(void * svchp, void * stmtp, void * errhp, unsigned iters, unsigned rowoff, void * snap_in, void * snap_out, unsigned mode);

typedef int __cdecl (*_OCIStmtFetch)(void * stmtp, void * errhp, unsigned nrows, System::Word orientation, unsigned mode);

typedef int __cdecl (*_OCIStmtGetPieceInfo)(void * stmtp, void * errhp, void * &hndlpp, pub4 htypep, pub1 in_outp, pub4 iterp, pub4 idxp, pub1 piecep);

typedef int __cdecl (*_OCIStmtPrepare)(void * stmtp, void * errhp, void * stmt, unsigned stmt_len, unsigned language, unsigned mode);

typedef int __cdecl (*_OCIStmtPrepare2)(void * svchp, void * &stmtp, void * errhp, void * stmt, unsigned stmt_len, void * key, unsigned key_len, unsigned language, unsigned mode);

typedef int __cdecl (*_OCIStmtRelease)(void * stmtp, void * errhp, void * key, unsigned key_len, unsigned mode);

typedef int __cdecl (*_OCIStmtSetPieceInfo)(void * hndlp, unsigned htype, void * errhp, const void * bufp, pub4 alenp, System::Byte piece, const void * indp, pub2 rcodep);

typedef int __cdecl (*_OCISvcCtxToLda)(void * srvhp, void * errhp, void * ldap);

typedef int __cdecl (*_OCILobAppend)(void * svchp, void * errhp, void * dst_locp, void * src_locp);

typedef int __cdecl (*_OCILobAssign)(void * envhp, void * errhp, const void * src_locp, void * &dst_locpp);

typedef int __cdecl (*_OCILobCharSetForm)(void * envhp, void * errhp, const void * locp, System::Byte &csfrm);

typedef int __cdecl (*_OCILobCharSetId)(void * envhp, void * errhp, const void * locp, pub2 csid);

typedef int __cdecl (*_OCILobCopy)(void * svchp, void * errhp, void * dst_locp, void * src_locp, unsigned amount, unsigned dst_offset, unsigned src_offset);

typedef int __cdecl (*_OCILobCreateTemporary)(void * svchp, void * errhp, void * locp, System::Word csid, System::Byte csfrm, System::Byte lobtype, int cache, System::Word duration);

typedef int __cdecl (*_OCILobFreeTemporary)(void * svchp, void * errhp, void * locp);

typedef int __cdecl (*_OCILobIsTemporary)(void * envhp, void * errhp, void * locp, BOOL &is_temporary);

typedef int __cdecl (*_OCILobDisableBuffering)(void * svchp, void * errhp, void * locp);

typedef int __cdecl (*_OCILobEnableBuffering)(void * svchp, void * errhp, void * locp);

typedef int __cdecl (*_OCILobErase)(void * svchp, void * errhp, void * locp, pub4 amount, unsigned offset);

typedef int __cdecl (*_OCILobFileClose)(void * svchp, void * errhp, void * filep);

typedef int __cdecl (*_OCILobFileExists)(void * svchp, void * errhp, void * filep, int &flag);

typedef int __cdecl (*_OCILobFileGetName)(void * envhp, void * errhp, const void * filep, void * dir_alias, pub2 d_length, void * filename, pub2 f_length);

typedef int __cdecl (*_OCILobFileIsOpen)(void * svchp, void * errhp, void * filep, int &flag);

typedef int __cdecl (*_OCILobFileOpen)(void * svchp, void * errhp, void * filep, System::Byte mode);

typedef int __cdecl (*_OCILobFileSetName)(void * envhp, void * errhp, ppOCILobLocator filepp, const void * dir_alias, System::Word d_length, const void * filename, System::Word f_length);

typedef int __cdecl (*_OCILobFlushBuffer)(void * svchp, void * errhp, void * locp, unsigned flag);

typedef int __cdecl (*_OCILobGetLength)(void * svchp, void * errhp, void * locp, unsigned &lenp);

typedef int __cdecl (*_OCILobIsEqual)(void * envhp, const void * x, const void * y, pbool is_equal);

typedef int __cdecl (*_OCILobLoadFromFile)(void * svchp, void * errhp, void * dst_locp, void * src_locp, unsigned amount, unsigned dst_offset, unsigned src_offset);

typedef int __cdecl (*_OCILobLocatorIsInit)(void * envhp, void * errhp, const void * locp, int &is_initialized);

typedef int __cdecl (*_OCILobRead)(void * svchp, void * errhp, void * locp, unsigned &amtp, unsigned offset, void * bufp, unsigned bufl, void * ctxp, void * cbfp, System::Word csid, System::Byte csfrm);

typedef int __cdecl (*_OCILobRead2)(void * svchp, void * errhp, void * locp, __int64 &byte_amtp, __int64 &char_amtp, __int64 offset, void * bufp, __int64 bufl, System::Byte piece, void * ctxp, void * cbfp, System::Word csid, System::Byte csfrm);

typedef int __cdecl (*_OCILobTrim)(void * svchp, void * errhp, void * locp, unsigned newlen);

typedef int __cdecl (*_OCILobWrite)(void * svchp, void * errhp, void * locp, unsigned &amtp, unsigned offset, void * bufp, unsigned bufl, System::Byte piece, void * ctxp, void * cbfp, System::Word csid, System::Byte csfrm);

typedef void * __cdecl (*TGetFlushRef)(void * context, pub1 last);

typedef int __cdecl (*_OCICacheFlush)(void * env, void * err, const void * svc, void * context, TGetFlushRef get, void * &ref);

typedef int __cdecl (*_OCICacheFree)(void * env, void * err, const void * svc);

typedef void * __cdecl (*TGetRefreshRef)(void * context);

typedef int __cdecl (*_OCICacheRefresh)(void * env, void * err, const void * svc, int option, void * context, TGetRefreshRef get, void * &ref);

typedef int __cdecl (*_OCICacheUnmark)(void * env, void * err, const void * svc);

typedef int __cdecl (*_OCICacheUnpin)(void * env, void * err, const void * svc);

typedef int __cdecl (*_OCIObjectCopy)(void * env, void * err, const void * svc, void * source, void * null_source, void * target, void * null_target, void * tdo, System::Word duration, System::Byte option);

typedef int __cdecl (*_OCIObjectExists)(void * env, void * err, void * ins, int &exist);

typedef int __cdecl (*_OCIObjectFlush)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectFree)(void * env, void * err, void * instance, System::Word flags);

typedef int __cdecl (*_OCIObjectGetAttr)(void * env, void * err, void * instance, void * null_struct, void * tdo, void * namesp, const pub4 lengths, const unsigned name_count, const pub4 indexes, const unsigned index_count, pOCIInd attr_null_status, void * attr_null_structp, void * attr_valuep, ppOCIType attr_tdop);

typedef int __cdecl (*_OCIObjectGetInd)(void * env, void * err, void * instance, void * null_structp);

typedef int __cdecl (*_OCIObjectGetObjectRef)(void * env, void * err, void * pobject, void * object_ref);

typedef int __cdecl (*_OCIObjectGetProperty)(void * env, void * err, const void * obj, System::Byte propertyId, System::Byte prop, pub4 size);

typedef int __cdecl (*_OCIObjectGetTypeRef)(void * env, void * err, void * instance, void * type_ref);

typedef int __cdecl (*_OCIObjectIsDirty)(void * env, void * err, void * ins, int &dirty);

typedef int __cdecl (*_OCIObjectIsLocked)(void * env, void * err, void * ins, int &lock);

typedef int __cdecl (*_OCIObjectLock)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectMarkDelete)(void * env, void * err, void * instance);

typedef int __cdecl (*_OCIObjectMarkDeleteByRef)(void * env, void * err, void * object_ref);

typedef int __cdecl (*_OCIObjectMarkUpdate)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectNew)(void * env, void * err, const void * svc, System::Word typecode, void * tdo, void * table, System::Word duration, int value, void * &instance);

typedef int __cdecl (*_OCIObjectPin)(void * env, void * err, void * object_ref, void * corhdl, int pin_option, System::Word pin_duration, int lock_option, void * pobjectp);

typedef int __cdecl (*_OCIObjectPinCountReset)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectPinTable)(void * env, void * err, const void * svc, const void * schema_name, unsigned s_n_length, const void * object_name, unsigned o_n_length, void * not_used, System::Word pin_duration, void * &pobject);

typedef int __cdecl (*_OCIObjectRefresh)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectSetAttr)(void * env, void * err, void * instance, void * null_struct, void * tdo, void * namesp, const pub4 lengths, const unsigned name_count, const pub4 indexes, const unsigned index_count, const short null_status, const void * attr_null_struct, const void * attr_value);

typedef int __cdecl (*_OCIObjectUnmark)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCIObjectUnmarkByRef)(void * env, void * err, void * ref);

typedef int __cdecl (*_OCIObjectUnpin)(void * env, void * err, void * pobject);

typedef int __cdecl (*_OCITypeByName)(void * env, void * err, const void * svc, const void * schema_name, unsigned s_length, const void * type_name, unsigned t_length, void * version_name, unsigned v_length, System::Word pin_duration, int get_option, void * &tdo);

typedef int __cdecl (*_OCITypeByRef)(void * env, void * err, const void * type_ref, System::Word pin_duration, int get_option, void * tdo);

typedef int __cdecl (*_OCICollAppend)(void * env, void * err, const void * elem, const void * elemind, void * coll);

typedef int __cdecl (*_OCICollAssign)(void * env, void * err, const void * rhs, void * lhs);

typedef int __cdecl (*_OCICollAssignElem)(void * env, void * err, int index, const void * elem, const void * elemind, void * coll);

typedef int __cdecl (*_OCICollGetElem)(void * env, void * err, const void * coll, int index, int &exists, void * &elem, void * &elemind);

typedef int __cdecl (*_OCICollMax)(void * env, const void * coll);

typedef int __cdecl (*_OCICollSize)(void * env, void * err, const void * coll, int &size);

typedef int __cdecl (*_OCICollTrim)(void * env, void * err, int trim_num, void * coll);

typedef int __cdecl (*_OCIDateAssign)(void * err, const void * from, void * todate);

typedef int __cdecl (*_OCIDateFromText)(void * err, void * date_str, unsigned d_str_length, const void * fmt, System::Byte fmt_length, const void * lang_name, unsigned lang_length, void * date);

typedef int __cdecl (*_OCIDateGetDate)(const void * date, psb2 year, pub1 month, pub1 day);

typedef int __cdecl (*_OCIDateGetTime)(const void * date, pub1 hour, pub1 min, pub1 sec);

typedef int __cdecl (*_OCIDateSetDate)(void * date, short year, System::Byte month, System::Byte day);

typedef int __cdecl (*_OCIDateSetTime)(void * date, System::Byte hour, System::Byte min, System::Byte sec);

typedef int __cdecl (*_OCIDateToText)(void * err, const void * date, const void * fmt, System::Byte fmt_length, const void * lang_name, unsigned lang_length, pub4 buf_size, void * buf);

typedef int __cdecl (*_OCINumberAssign)(void * err, const void * from, void * tonum);

typedef int __cdecl (*_OCINumberCmp)(void * err, const void * number1, const void * number2, int &result);

typedef int __cdecl (*_OCINumberFromInt)(void * err, __int64 &inum, unsigned inum_length, unsigned inum_s_flag, void * number);

typedef int __cdecl (*_OCINumberFromReal)(void * err, double &rnum, unsigned rnum_length, void * number);

typedef int __cdecl (*_OCINumberFromText)(void * err, const void * str, unsigned str_length, const void * fmt, unsigned fmt_length, const void * nls_params, unsigned nls_p_length, void * number);

typedef int __cdecl (*_OCINumberToInt)(void * err, void * number, unsigned rsl_length, unsigned rsl_flag, __int64 &rsl);

typedef int __cdecl (*_OCINumberToReal)(void * err, const void * number, unsigned rsl_length, double &rsl);

typedef int __cdecl (*_OCINumberToText)(void * err, void * number, const void * fmt, unsigned fmt_length, const void * nls_params, unsigned nls_p_length, unsigned &buf_size, void * buf);

typedef int __cdecl (*_OCIRefAssign)(void * env, void * err, const void * source, void * &target);

typedef int __cdecl (*_OCIRefClear)(void * env, void * ref);

typedef int __cdecl (*_OCIRefIsEqual)(void * env, const void * x, const void * y);

typedef int __cdecl (*_OCIRefIsNull)(void * env, const void * ref);

typedef int __cdecl (*_OCIRefToHex)(void * env, void * err, const void * ref, void * hex, unsigned &hex_length);

typedef int __cdecl (*_OCIStringAllocSize)(void * env, void * err, const void * vs, pub4 allocsize);

typedef int __cdecl (*_OCIStringAssign)(void * env, void * err, const void * rhs, void * lhs);

typedef int __cdecl (*_OCIStringAssignText)(void * env, void * err, const void * rhs, unsigned rhs_len, void * lhs);

typedef void * __cdecl (*_OCIStringPtr)(void * env, const void * vs);

typedef int __cdecl (*_OCIStringResize)(void * env, void * err, unsigned new_size, void * str);

typedef unsigned __cdecl (*_OCIStringSize)(void * env, const void * vs);

typedef int __cdecl (*_OCITableDelete)(void * env, void * err, int index, void * tbl);

typedef int __cdecl (*_OCITableExists)(void * env, void * err, const void * tbl, int index, pbool exists);

typedef int __cdecl (*_OCITableFirst)(void * env, void * err, const void * tbl, psb4 index);

typedef int __cdecl (*_OCITableLast)(void * env, void * err, const void * tbl, psb4 index);

typedef int __cdecl (*_OCITableNext)(void * env, void * err, int index, const void * tbl, int &next_index, int &exists);

typedef int __cdecl (*_OCITablePrev)(void * env, void * err, int index, const void * tbl, psb4 prev_index, pbool exists);

typedef int __cdecl (*_OCITableSize)(void * env, void * err, const void * tbl, int &size);

typedef int __cdecl (*_OCIEnvCreate)(void * &envhpp, unsigned mode, const void * ctxp, const void * malocfp, const void * ralocfp, const void * mfreefp, int xtramemsz, void * usrmempp);

typedef int __cdecl (*_OCIDirPathAbort)(pOCIDirPathCtx dpctx, void * errhp);

typedef int __cdecl (*_OCIDirPathColArrayEntryGet)(pOCIDirPathColArray dpca, void * errhp, unsigned rownum, System::Word colIdx, pub1 &cvalpp, unsigned clenp, pub1 cflgp);

typedef int __cdecl (*_OCIDirPathColArrayEntrySet)(pOCIDirPathColArray dpca, void * errhp, unsigned rownum, System::Word colIdx, pub1 cvalp, unsigned clen, System::Byte cflg);

typedef int __cdecl (*_OCIDirPathColArrayRowGet)(pOCIDirPathColArray dpca, void * errhp, unsigned rownum, pub1 &cvalppp, pub4 &clenpp, ppub1 cflgpp);

typedef int __cdecl (*_OCIDirPathColArrayReset)(pOCIDirPathColArray dpca, void * errhp);

typedef int __cdecl (*_OCIDirPathColArrayToStream)(pOCIDirPathColArray dpca, const pOCIDirPathCtx dpctx, pOCIDirPathStream dpstr, void * errhp, unsigned rowcnt, unsigned rowoff);

typedef int __cdecl (*_OCIDirPathFinish)(pOCIDirPathCtx dpctx, void * errhp);

typedef int __cdecl (*_OCIDirPathLoadStream)(pOCIDirPathCtx dpctx, pOCIDirPathStream dpstr, void * errhp);

typedef int __cdecl (*_OCIDirPathPrepare)(pOCIDirPathCtx dpctx, void * svchp, void * errhp);

typedef int __cdecl (*_OCIDirPathStreamReset)(pOCIDirPathStream dpstr, void * errhp);

typedef int __cdecl (*_OCIDateTimeConstruct)(void * hndl, void * err, void * datetime, short year, System::Byte month, System::Byte day, System::Byte hour, System::Byte min, System::Byte sec, unsigned fsec, void * timezone, int timezone_length);

typedef int __cdecl (*_OCIDateTimeCheck)(void * hndl, void * err, void * date, unsigned &valid);

typedef int __cdecl (*_OCIDateTimeFromText)(void * hndl, void * err, void * date_str, int d_str_length, void * fmt, System::Byte fmt_length, void * lang_name, int lang_length, void * date);

typedef int __cdecl (*_OCIDateTimeToText)(void * hndl, void * err, void * date, void * fmt, System::Byte fmt_length, System::Byte fsprec, void * lang_name, int lang_length, unsigned &buf_size, void * buf);

typedef int __cdecl (*_OCIDateTimeGetDate)(void * hndl, void * err, void * date, short &year, System::Byte &month, System::Byte &day);

typedef int __cdecl (*_OCIDateTimeGetTime)(void * hndl, void * err, void * datetime, System::Byte &hour, System::Byte &minute, System::Byte &sec, unsigned &fsec);

typedef int __cdecl (*_OCIDateTimeGetTimeZoneOffset)(void * hndl, void * err, void * datetime, System::ShortInt &hour, System::ShortInt &minute);

typedef int __cdecl (*_OCIDateTimeGetTimeZoneName)(void * hndl, void * err, void * datetime, pub1 buf, unsigned &buflen);

typedef int __cdecl (*_OCIDateTimeAssign)(void * hndl, void * err, void * src, void * dst);

typedef int __cdecl (*_OCIDateTimeCompare)(void * hndl, void * err, const void * date1, const void * date2, int &result);

typedef int __cdecl (*_OCIIntervalFromText)(void * hndl, void * err, void * inpstr, int str_len, void * result);

typedef int __cdecl (*_OCIIntervalToText)(void * hndl, void * err, void * inter, System::Byte lfprec, System::Byte fsprec, void * buffer, int buflen, int &resultlen);

typedef int __cdecl (*_OCIIntervalCheck)(void * hndl, void * err, void * interval, unsigned &valid);

typedef int __cdecl (*_OCIIntervalAssign)(void * hndl, void * err, void * ininter, void * outinter);

typedef int __cdecl (*_OCIIntervalCompare)(void * hndl, void * err, void * inter1, void * inter2, int &result);

typedef int __cdecl (*_OCIIntervalSetYearMonth)(void * hndl, void * err, int yr, int mnth, void * result);

typedef int __cdecl (*_OCIIntervalGetYearMonth)(void * hndl, void * err, int &yr, int &mnth, void * result);

typedef int __cdecl (*_OCIIntervalSetDaySecond)(void * hndl, void * err, int dy, int hr, int mm, int ss, int fsec, void * result);

typedef int __cdecl (*_OCIIntervalGetDaySecond)(void * hndl, void * err, int &dy, int &hr, int &mm, int &ss, int &fsec, void * result);

typedef int __cdecl (*_OCIIntervalFromNumber)(void * hndl, void * err, void * interval, void * number);

typedef int __cdecl (*_OCIStmtFetch2)(void * stmtp, void * errhp, unsigned nrows, System::Word orientation, int scrollOffset, unsigned mode);

typedef void __cdecl (*_OCIClientVersion)(int &major_version, int &minor_version, int &update_num, int &patch_num, int &port_update_num);

typedef int __cdecl (*_OCIPing)(void * svchp, void * errhp, unsigned mode);

typedef void * pOCIXMLType;

typedef void * pOCIDOMDocument;

typedef void * ppOCIXMLType;

typedef void * ppOCIDOMDocument;

struct OCIXMLType
{
	
};


struct OCIDOMDocument
{
	
};


typedef int __cdecl (*_OCIXMLTypeNew)(void * svchp, void * errhp, System::Word dur, char * elname, unsigned elname_Len, char * schemaURL, unsigned schemaURL_Len, void * &retInstance);

typedef int __cdecl (*_OCIXMLTypeCreateFromSrc)(void * svchp, void * errhp, System::Word dur, System::Byte src_type, void * src_ptr, int ind, void * &retInstance);

typedef int __cdecl (*_OCIXMLTypeExtract)(void * errhp, void * doc, System::Word dur, char * xpathexpr, unsigned xpathexpr_Len, char * nsmap, unsigned nsmap_Len, void * &retDoc);

typedef int __cdecl (*_OCIXMLTypeTransform)(void * errhp, System::Word dur, void * doc, void * xsldoc, void * &retDoc);

typedef int __cdecl (*_OCIXMLTypeExists)(void * errhp, void * doc, char * xpathexpr, unsigned xpathexpr_Len, char * nsmap, unsigned nsmap_Len, unsigned &retval);

typedef int __cdecl (*_OCIXMLTypeIsSchemaBased)(void * errhp, void * doc, unsigned &retval);

typedef int __cdecl (*_OCIXMLTypeGetSchema)(void * errhp, void * doc, void * &schemadoc, void * &schemaURL, unsigned &schemaURL_Len, void * &rootelem, unsigned &rootelem_Len);

typedef int __cdecl (*_OCIXMLTypeValidate)(void * errhp, void * doc, char * schemaURL, unsigned schemaURL_Len, unsigned &retval);

typedef int __cdecl (*_OCIXMLTypeGetDOM)(void * errhp, void * doc, System::Word dur, void * &retDom);

typedef int __cdecl (*_OCIXMLTypeGetFromDOM)(void * errhp, void * domdoc, void * &retXMLType);

typedef int __cdecl (*_OCIDOMFree)(void * errhp, void * domdoc);

typedef int __cdecl (*_OCIPStreamFromXMLType)(void * errhp, void * phOCIDescriptor, void * pobject, int res);

typedef int __cdecl (*_OCIPStreamRead)(void * errhp, void * phOCIDescriptor, void * pStr, __int64 &Len, int res);

typedef int __cdecl (*_OCIPStreamClose)(void * errhp, void * phOCIDescriptor);

typedef int __cdecl (*_OCIRowidToChar)(void * rowidDesc, void * outbfp, System::Word &outbflp, void * errhp);

typedef int __cdecl (*_OCIExtProcGetEnv)(void * with_context, void * &envh, void * &svch, void * &errh);

typedef int __cdecl (*_OCIExtProcAllocCallMemory)(void * with_context, unsigned amount);

typedef int __cdecl (*_OCIExtProcRaiseExcpWithMsg)(void * with_context, int errnum, char * errmsg, int msglen);

typedef int __cdecl (*_OCISubscriptionRegister)(void * svchp, void * &subscrhpp, System::Word count, void * errhp, unsigned mode);

typedef int __cdecl (*_OCISubscriptionUnRegister)(void * svchp, void * subscrhp, void * errhp, unsigned mode);

typedef int __cdecl (*_OCISubscriptionEnable)(void * subscrhp, void * errhp, unsigned mode);

typedef int __cdecl (*_OCISubscriptionDisable)(void * subscrhp, void * errhp, unsigned mode);

typedef int __cdecl (*_OraMTSSvcGet)(char * lpUName, char * lpPsswd, char * lpDbnam, void * &pOCISvc, void * &pOCIEnv, unsigned ConFlg);

typedef int __cdecl (*_OraMTSSvcRel)(void * OCISvc);

typedef int __cdecl (*_OraMTSJoinTxn)(void * svchp, Mtscall::_di_ICRTransactionSC lpTrans);

typedef int __cdecl (*_OraMTSEnlCtxGet)(char * lpUName, char * lpPsswd, char * lpDbnam, void * pOCISvc, void * errhp, unsigned dwFlags, void * &pCtxt);

typedef int __cdecl (*_OraMTSEnlCtxRel)(void * pCtxt);

typedef int __cdecl (*_OraMTSSvcEnlist)(void * OCISvc, void * OCIErr, Mtscall::_di_ICRTransactionSC lpTrans, int dwFlags);

#pragma option push -b-
enum TOCICallStyle { None, OCI73, OCI80 };
#pragma option pop

typedef Set<TOCICallStyle, None, OCI80>  TOCICallStyleSet;

#pragma option push -b-
enum TOracleHome { ohDefault, ohHome0, ohHome1, ohHome2, ohHome3, ohHome4, ohHome5 };
#pragma option pop

class DELPHICLASS EOCIInitError;
class PASCALIMPLEMENTATION EOCIInitError : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall EOCIInitError(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EOCIInitError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EOCIInitError(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EOCIInitError(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EOCIInitError(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EOCIInitError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EOCIInitError(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EOCIInitError(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EOCIInitError(void) { }
	
};


typedef StaticArray<System::UnicodeString, 10> Oracall__2;

typedef StaticArray<System::UnicodeString, 10> Oracall__3;

typedef StaticArray<System::UnicodeString, 10> Oracall__4;

//-- var, const, procedure ---------------------------------------------------
static const ShortInt SQLT_UNK = 0x0;
static const ShortInt SQLT_CHR = 0x1;
static const ShortInt SQLT_NUM = 0x2;
static const ShortInt SQLT_INT = 0x3;
static const ShortInt SQLT_FLT = 0x4;
static const ShortInt SQLT_STR = 0x5;
static const ShortInt SQLT_VNU = 0x6;
static const ShortInt SQLT_PDN = 0x7;
static const ShortInt SQLT_LNG = 0x8;
static const ShortInt SQLT_VCS = 0x9;
static const ShortInt SQLT_NON = 0xa;
static const ShortInt SQLT_RID = 0xb;
static const ShortInt SQLT_DAT = 0xc;
static const ShortInt SQLT_VBI = 0xf;
static const ShortInt SQLT_BFLOAT = 0x15;
static const ShortInt SQLT_BDOUBLE = 0x16;
static const ShortInt SQLT_BIN = 0x17;
static const ShortInt SQLT_LBI = 0x18;
static const ShortInt SQLT_UND = 0x19;
static const ShortInt SQLT_UIN = 0x44;
static const ShortInt SQLT_SLS = 0x5b;
static const ShortInt SQLT_LVC = 0x5e;
static const ShortInt SQLT_LVB = 0x5f;
static const ShortInt SQLT_AFC = 0x60;
static const ShortInt SQLT_AVC = 0x61;
static const ShortInt SQLT_IBFLOAT = 0x64;
static const ShortInt SQLT_IBDOUBLE = 0x65;
static const ShortInt SQLT_CUR = 0x66;
static const ShortInt SQLT_RDD = 0x68;
static const ShortInt SQLT_LAB = 0x69;
static const ShortInt SQLT_OSL = 0x6a;
static const ShortInt SQLT_NTY = 0x6c;
static const ShortInt SQLT_REF = 0x6e;
static const ShortInt SQLT_CLOB = 0x70;
static const ShortInt SQLT_BLOB = 0x71;
static const ShortInt SQLT_BFILEE = 0x72;
static const ShortInt SQLT_CFILEE = 0x73;
static const ShortInt SQLT_RSET = 0x74;
static const ShortInt SQLT_NCO = 0x7a;
static const ShortInt SQLT_VARRAY = 0x7b;
static const Byte SQLT_VST = 0x9b;
static const Byte SQLT_ODT = 0x9c;
static const ShortInt SQLT_FILE = 0x72;
static const ShortInt SQLT_CFILE = 0x73;
static const ShortInt SQLT_BFILE = 0x72;
static const Byte SQLT_DATE = 0xb8;
static const Byte SQLT_TIME = 0xb9;
static const Byte SQLT_TIME_TZ = 0xba;
static const Byte SQLT_TIMESTAMP = 0xbb;
static const Byte SQLT_TIMESTAMP_TZ = 0xbc;
static const Byte SQLT_INTERVAL_YM = 0xbd;
static const Byte SQLT_INTERVAL_DS = 0xbe;
static const Byte SQLT_TIMESTAMP_LTZ = 0xe8;
static const Byte SQLT_REC = 0xfa;
static const Byte SQLT_TAB = 0xfb;
static const Byte SQLT_BOL = 0xfc;
static const ShortInt CDA_SIZE = 0x40;
static const Word HDA_SIZE = 0x100;
static const ShortInt UNKNOWN_TYPE = 0x0;
static const ShortInt VARCHAR2_TYPE = 0x1;
static const ShortInt NUMBER_TYPE = 0x2;
static const ShortInt INTEGER_TYPE = 0x3;
static const ShortInt FLOAT_TYPE = 0x4;
static const ShortInt STRING_TYPE = 0x5;
static const ShortInt LONG_TYPE = 0x8;
static const ShortInt ROWID_TYPE = 0xb;
static const ShortInt DATE_TYPE = 0xc;
static const ShortInt RAW_TYPE = 0x17;
static const ShortInt LONGRAW_TYPE = 0x18;
static const ShortInt CHAR_TYPE = 0x60;
static const ShortInt CHARZ_TYPE = 0x61;
static const ShortInt CURSOR_TYPE = 0x66;
static const short OCI_VAR_NOT_IN_LIST = -303;
static const ShortInt OCI_NO_DATA_FOUND = 0x4;
static const Word OCI_NULL_VALUE_RETURNED = 0x57d;
static const short OCI_BLOCKED = -3123;
static const short OCI_CONNECTION_BUSY = -3127;
static const ShortInt OCI_SESSION_KILLED = 0x1c;
static const Word OCI_NOT_LOGGEDON = 0x3f4;
static const Word OCI_EOF_COMMUNICATION = 0xc29;
static const Word OCI_NOT_CONNECTED = 0xc2a;
static const Word OCI_NO_INTERFACE = 0xc31;
static const short OCI_STILL_IS_PIECE = -3130;
static const short OCI_STILL_IS_PIECE1 = -3129;
static const short OCI_BREAKED = -1013;
static const ShortInt SQL_UNKNOWN = 0x0;
static const ShortInt SQL_SET_ROLE = 0x2;
static const ShortInt SQL_INSERT = 0x3;
static const ShortInt SQL_SELECT = 0x4;
static const ShortInt SQL_UPDATE = 0x5;
static const ShortInt SQL_DELETE = 0x9;
static const ShortInt SQL_EXPLAIN = 0x1b;
static const ShortInt SQL_GRANT = 0x1c;
static const ShortInt SQL_REVOKE = 0x1d;
static const ShortInt SQL_SET_TRANSACTION = 0x21;
static const ShortInt SQL_PLSQL = 0x22;
static const ShortInt SQL_LOCK = 0x23;
static const ShortInt SQL_RENAME = 0x25;
static const ShortInt SQL_COMMENT = 0x26;
static const ShortInt SQL_AUDIT = 0x27;
static const ShortInt SQL_NOAUDIT = 0x28;
static const ShortInt SQL_COMMIT = 0x36;
static const ShortInt SQL_ROLLBACK = 0x37;
static const ShortInt SQL_SAVEPOINT = 0x38;
static const Byte SQL_CALL_METHOD = 0xaa;
static const ShortInt FC_OOPEN = 0xe;
static const ShortInt OCI_EV_DEF = 0x0;
static const ShortInt OCI_EV_TSF = 0x1;
static const ShortInt OCI_LM_DEF = 0x0;
static const ShortInt OCI_LM_NBL = 0x1;
static const ShortInt OCI_ONE_PIECE = 0x0;
static const ShortInt OCI_FIRST_PIECE = 0x1;
static const ShortInt OCI_NEXT_PIECE = 0x2;
static const ShortInt OCI_LAST_PIECE = 0x3;
static const ShortInt OCI_PARSE_NODEFER = 0x0;
static const ShortInt OCI_PARSE_DEFER = 0x1;
static const ShortInt OCI_LANG_V6 = 0x0;
static const ShortInt OCI_LANG_NORM = 0x1;
static const ShortInt OCI_LANG_V7 = 0x2;
static const ShortInt SQLCS_IMPLICIT = 0x1;
static const ShortInt SQLCS_NCHAR = 0x2;
static const ShortInt SQLCS_EXPLICIT = 0x3;
static const ShortInt SQLCS_FLEXIBLE = 0x4;
static const ShortInt SQLCS_LIT_NULL = 0x5;
static const int SizeOfTCDAHead = 0x2c;
extern PACKAGE _obindps obindps;
extern PACKAGE _obndra obndra;
extern PACKAGE _obndrn obndrn;
extern PACKAGE _obndrv obndrv;
extern PACKAGE _obreak obreak;
extern PACKAGE _ocan ocan;
extern PACKAGE _oclose oclose;
extern PACKAGE _ocof ocof;
extern PACKAGE _ocom ocom;
extern PACKAGE _ocon ocon;
extern PACKAGE _odefin odefin;
extern PACKAGE _odefinps odefinps;
extern PACKAGE _odescr odescr;
extern PACKAGE _odessp odessp;
extern PACKAGE _oerhms oerhms;
extern PACKAGE _oermsg oermsg;
extern PACKAGE _oexec oexec;
extern PACKAGE _oexfet oexfet;
extern PACKAGE _oexn oexn;
extern PACKAGE _ofen ofen;
extern PACKAGE _ofetch ofetch;
extern PACKAGE _oflng oflng;
extern PACKAGE _ognfd ognfd;
extern PACKAGE _olog olog;
extern PACKAGE _ologof ologof;
extern PACKAGE _onbclr onbclr;
extern PACKAGE _onbset onbset;
extern PACKAGE _onbtst onbtst;
extern PACKAGE _oopt oopt;
extern PACKAGE _oopen oopen;
extern PACKAGE _oparse oparse;
extern PACKAGE _opinit opinit;
extern PACKAGE _orol orol;
extern PACKAGE _ogetpi ogetpi;
extern PACKAGE _osetpi osetpi;
extern PACKAGE _sqllda sqllda;
extern PACKAGE _sqlld2 sqlld2;
static const ShortInt OCI_DEFAULT = 0x0;
static const ShortInt OCI_THREADED = 0x1;
static const ShortInt OCI_OBJECT = 0x2;
static const ShortInt OCI_EVENTS = 0x4;
static const ShortInt OCI_SHARED = 0x10;
static const ShortInt OCI_NON_BLOCKING = 0x4;
static const ShortInt OCI_ENV_NO_MUTEX = 0x8;
static const Byte OCI_NO_MUTEX = 0x80;
static const Word OCI_UTF16 = 0x4000;
static const ShortInt OCI_SESSGET_SPOOL = 0x1;
static const ShortInt OCI_SESSGET_STMTCACHE = 0x4;
static const ShortInt OCI_SPC_REINITIALIZE = 0x1;
static const ShortInt OCI_SPC_HOMOGENEOUS = 0x2;
static const ShortInt OCI_SPC_STMTCACHE = 0x4;
static const ShortInt OCI_HTYPE_FIRST = 0x1;
static const ShortInt OCI_HTYPE_ENV = 0x1;
static const ShortInt OCI_HTYPE_ERROR = 0x2;
static const ShortInt OCI_HTYPE_SVCCTX = 0x3;
static const ShortInt OCI_HTYPE_STMT = 0x4;
static const ShortInt OCI_HTYPE_BIND = 0x5;
static const ShortInt OCI_HTYPE_DEFINE = 0x6;
static const ShortInt OCI_HTYPE_DESCRIBE = 0x7;
static const ShortInt OCI_HTYPE_SERVER = 0x8;
static const ShortInt OCI_HTYPE_SESSION = 0x9;
static const ShortInt OCI_HTYPE_AUTHINFO = 0x9;
static const ShortInt OCI_HTYPE_TRANS = 0xa;
static const ShortInt OCI_HTYPE_COMPLEXOBJECT = 0xb;
static const ShortInt OCI_HTYPE_SECURITY = 0xc;
static const ShortInt OCI_HTYPE_SUBSCRIPTION = 0xd;
static const ShortInt OCI_HTYPE_DIRPATH_CTX = 0xe;
static const ShortInt OCI_HTYPE_DIRPATH_COLUMN_ARRAY = 0xf;
static const ShortInt OCI_HTYPE_DIRPATH_STREAM = 0x10;
static const ShortInt OCI_HTYPE_PROC = 0x11;
static const ShortInt OCI_HTYPE_LAST = 0x11;
static const ShortInt OCI_HTYPE_SPOOL = 0x1b;
static const ShortInt OCI_DTYPE_FIRST = 0x32;
static const ShortInt OCI_DTYPE_LOB = 0x32;
static const ShortInt OCI_DTYPE_SNAP = 0x33;
static const ShortInt OCI_DTYPE_RSET = 0x34;
static const ShortInt OCI_DTYPE_PARAM = 0x35;
static const ShortInt OCI_DTYPE_ROWID = 0x36;
static const ShortInt OCI_DTYPE_COMPLEXOBJECTCOMP = 0x37;
static const ShortInt OCI_DTYPE_FILE = 0x38;
static const ShortInt OCI_DTYPE_AQENQ_OPTIONS = 0x39;
static const ShortInt OCI_DTYPE_AQDEQ_OPTIONS = 0x3a;
static const ShortInt OCI_DTYPE_AQMSG_PROPERTIES = 0x3b;
static const ShortInt OCI_DTYPE_AQAGENT = 0x3c;
static const ShortInt OCI_DTYPE_INTERVAL_YM = 0x3e;
static const ShortInt OCI_DTYPE_INTERVAL_DS = 0x3f;
static const ShortInt OCI_DTYPE_AQNFY_DESCRIPTOR = 0x40;
static const ShortInt OCI_DTYPE_DATE = 0x41;
static const ShortInt OCI_DTYPE_TIME = 0x42;
static const ShortInt OCI_DTYPE_TIME_TZ = 0x43;
static const ShortInt OCI_DTYPE_TIMESTAMP = 0x44;
static const ShortInt OCI_DTYPE_TIMESTAMP_TZ = 0x45;
static const ShortInt OCI_DTYPE_TIMESTAMP_LTZ = 0x46;
static const ShortInt OCI_DTYPE_UCB = 0x47;
static const ShortInt OCI_DTYPE_SRVDN = 0x48;
static const ShortInt OCI_DTYPE_SIGNATURE = 0x49;
static const ShortInt OCI_DTYPE_RESERVED_1 = 0x4a;
static const ShortInt OCI_DTYPE_AQLIS_OPTIONS = 0x4b;
static const ShortInt OCI_DTYPE_AQLIS_MSG_PROPERTIES = 0x4c;
static const ShortInt OCI_DTYPE_CHDES = 0x4d;
static const ShortInt OCI_DTYPE_TABLE_CHDES = 0x4e;
static const ShortInt OCI_DTYPE_ROW_CHDES = 0x4f;
static const ShortInt OCI_OTYPE_NAME = 0x1;
static const ShortInt OCI_OTYPE_REF = 0x2;
static const ShortInt OCI_OTYPE_PTR = 0x3;
static const ShortInt OCI_ATTR_FNCODE = 0x1;
static const ShortInt OCI_ATTR_OBJECT = 0x2;
static const ShortInt OCI_ATTR_NONBLOCKING_MODE = 0x3;
static const ShortInt OCI_ATTR_SQLCODE = 0x4;
static const ShortInt OCI_ATTR_ENV = 0x5;
static const ShortInt OCI_ATTR_SERVER = 0x6;
static const ShortInt OCI_ATTR_SESSION = 0x7;
static const ShortInt OCI_ATTR_TRANS = 0x8;
static const ShortInt OCI_ATTR_ROW_COUNT = 0x9;
static const ShortInt OCI_ATTR_SQLFNCODE = 0xa;
static const ShortInt OCI_ATTR_PREFETCH_ROWS = 0xb;
static const ShortInt OCI_ATTR_NESTED_PREFETCH_ROWS = 0xc;
static const ShortInt OCI_ATTR_PREFETCH_MEMORY = 0xd;
static const ShortInt OCI_ATTR_NESTED_PREFETCH_MEMORY = 0xe;
static const ShortInt OCI_ATTR_CHAR_COUNT = 0xf;
static const ShortInt OCI_ATTR_PDSCL = 0x10;
static const ShortInt OCI_ATTR_FSPRECISION = 0x10;
static const ShortInt OCI_ATTR_PDFMT = 0x11;
static const ShortInt OCI_ATTR_PARAM_COUNT = 0x12;
static const ShortInt OCI_ATTR_ROWID = 0x13;
static const ShortInt OCI_ATTR_CHARSET = 0x14;
static const ShortInt OCI_ATTR_NCHAR = 0x15;
static const ShortInt OCI_ATTR_USERNAME = 0x16;
static const ShortInt OCI_ATTR_PASSWORD = 0x17;
static const ShortInt OCI_ATTR_STMT_TYPE = 0x18;
static const ShortInt OCI_ATTR_INTERNAL_NAME = 0x19;
static const ShortInt OCI_ATTR_EXTERNAL_NAME = 0x1a;
static const ShortInt OCI_ATTR_XID = 0x1b;
static const ShortInt OCI_ATTR_TRANS_LOCK = 0x1c;
static const ShortInt OCI_ATTR_TRANS_NAME = 0x1d;
static const ShortInt OCI_ATTR_HEAPALLOC = 0x1e;
static const ShortInt OCI_ATTR_CHARSET_ID = 0x1f;
static const ShortInt OCI_ATTR_CHARSET_FORM = 0x20;
static const ShortInt OCI_ATTR_MAXDATA_SIZE = 0x21;
static const ShortInt OCI_ATTR_CACHE_OPT_SIZE = 0x22;
static const ShortInt OCI_ATTR_CACHE_MAX_SIZE = 0x23;
static const ShortInt OCI_ATTR_PINOPTION = 0x24;
static const ShortInt OCI_ATTR_ALLOC_DURATION = 0x25;
static const ShortInt OCI_ATTR_PIN_DURATION = 0x26;
static const ShortInt OCI_ATTR_FDO = 0x27;
static const ShortInt OCI_ATTR_POSTPROCESSING_CALLBACK = 0x28;
static const ShortInt OCI_ATTR_POSTPROCESSING_CONTEXT = 0x29;
static const ShortInt OCI_ATTR_ROWS_RETURNED = 0x2a;
static const ShortInt OCI_ATTR_FOCBK = 0x2b;
static const ShortInt OCI_ATTR_IN_V8_MODE = 0x2c;
static const ShortInt OCI_ATTR_LOBEMPTY = 0x2d;
static const ShortInt OCI_ATTR_SESSLANG = 0x2e;
static const ShortInt OCI_ATTR_VISIBILITY = 0x2f;
static const ShortInt OCI_ATTR_RELATIVE_MSGID = 0x30;
static const ShortInt OCI_ATTR_SEQUENCE_DEVIATION = 0x31;
static const ShortInt OCI_ATTR_CONSUMER_NAME = 0x32;
static const ShortInt OCI_ATTR_DEQ_MODE = 0x33;
static const ShortInt OCI_ATTR_NAVIGATION = 0x34;
static const ShortInt OCI_ATTR_WAIT = 0x35;
static const ShortInt OCI_ATTR_DEQ_MSGID = 0x36;
static const ShortInt OCI_ATTR_PRIORITY = 0x37;
static const ShortInt OCI_ATTR_DELAY = 0x38;
static const ShortInt OCI_ATTR_EXPIRATION = 0x39;
static const ShortInt OCI_ATTR_CORRELATION = 0x3a;
static const ShortInt OCI_ATTR_ATTEMPTS = 0x3b;
static const ShortInt OCI_ATTR_RECIPIENT_LIST = 0x3c;
static const ShortInt OCI_ATTR_EXCEPTION_QUEUE = 0x3d;
static const ShortInt OCI_ATTR_ENQ_TIME = 0x3e;
static const ShortInt OCI_ATTR_MSG_STATE = 0x3f;
static const ShortInt OCI_ATTR_AGENT_NAME = 0x40;
static const ShortInt OCI_ATTR_AGENT_ADDRESS = 0x41;
static const ShortInt OCI_ATTR_AGENT_PROTOCOL = 0x42;
static const ShortInt OCI_ATTR_SENDER_ID = 0x44;
static const ShortInt OCI_ATTR_ORIGINAL_MSGID = 0x45;
static const ShortInt OCI_ATTR_QUEUE_NAME = 0x46;
static const ShortInt OCI_ATTR_NFY_MSGID = 0x47;
static const ShortInt OCI_ATTR_MSG_PROP = 0x48;
static const ShortInt OCI_ATTR_NUM_DML_ERRORS = 0x49;
static const ShortInt OCI_ATTR_DML_ROW_OFFSET = 0x4a;
static const ShortInt OCI_ATTR_DATEFORMAT = 0x4b;
static const ShortInt OCI_ATTR_BUF_ADDR = 0x4c;
static const ShortInt OCI_ATTR_BUF_SIZE = 0x4d;
static const ShortInt OCI_ATTR_DIRPATH_MODE = 0x4e;
static const ShortInt OCI_ATTR_DIRPATH_NOLOG = 0x4f;
static const ShortInt OCI_ATTR_DIRPATH_PARALLEL = 0x50;
static const ShortInt OCI_ATTR_NUM_ROWS = 0x51;
static const ShortInt OCI_ATTR_COL_COUNT = 0x52;
static const ShortInt OCI_ATTR_STREAM_OFFSET = 0x53;
static const ShortInt OCI_ATTR_SHARED_HEAPALLOC = 0x54;
static const ShortInt OCI_ATTR_SERVER_GROUP = 0x55;
static const ShortInt OCI_ATTR_MIGSESSION = 0x56;
static const ShortInt OCI_ATTR_NOCACHE = 0x57;
static const ShortInt OCI_ATTR_MEMPOOL_SIZE = 0x58;
static const ShortInt OCI_ATTR_MEMPOOL_INSTNAME = 0x59;
static const ShortInt OCI_ATTR_MEMPOOL_APPNAME = 0x5a;
static const ShortInt OCI_ATTR_MEMPOOL_HOMENAME = 0x5b;
static const ShortInt OCI_ATTR_MEMPOOL_MODEL = 0x5c;
static const ShortInt OCI_ATTR_MODES = 0x5d;
static const ShortInt OCI_ATTR_SUBSCR_NAME = 0x5e;
static const ShortInt OCI_ATTR_SUBSCR_CALLBACK = 0x5f;
static const ShortInt OCI_ATTR_SUBSCR_CTX = 0x60;
static const ShortInt OCI_ATTR_SUBSCR_PAYLOAD = 0x61;
static const ShortInt OCI_ATTR_SUBSCR_NAMESPACE = 0x62;
static const ShortInt OCI_ATTR_PROXY_CREDENTIALS = 0x63;
static const ShortInt OCI_ATTR_INITIAL_CLIENT_ROLES = 0x64;
static const ShortInt OCI_ATTR_UNK = 0x65;
static const ShortInt OCI_ATTR_NUM_COLS = 0x66;
static const ShortInt OCI_ATTR_LIST_COLUMNS = 0x67;
static const ShortInt OCI_ATTR_RDBA = 0x68;
static const ShortInt OCI_ATTR_CLUSTERED = 0x69;
static const ShortInt OCI_ATTR_PARTITIONED = 0x6a;
static const ShortInt OCI_ATTR_INDEX_ONLY = 0x6b;
static const ShortInt OCI_ATTR_LIST_ARGUMENTS = 0x6c;
static const ShortInt OCI_ATTR_LIST_SUBPROGRAMS = 0x6d;
static const ShortInt OCI_ATTR_REF_TDO = 0x6e;
static const ShortInt OCI_ATTR_LINK = 0x6f;
static const ShortInt OCI_ATTR_MIN = 0x70;
static const ShortInt OCI_ATTR_MAX = 0x71;
static const ShortInt OCI_ATTR_INCR = 0x72;
static const ShortInt OCI_ATTR_CACHE = 0x73;
static const ShortInt OCI_ATTR_ORDER = 0x74;
static const ShortInt OCI_ATTR_HW_MARK = 0x75;
static const ShortInt OCI_ATTR_TYPE_SCHEMA = 0x76;
static const ShortInt OCI_ATTR_TIMESTAMP = 0x77;
static const ShortInt OCI_ATTR_NUM_ATTRS = 0x78;
static const ShortInt OCI_ATTR_NUM_PARAMS = 0x79;
static const ShortInt OCI_ATTR_OBJID = 0x7a;
static const ShortInt OCI_ATTR_PTYPE = 0x7b;
static const ShortInt OCI_ATTR_PARAM = 0x7c;
static const ShortInt OCI_ATTR_OVERLOAD_ID = 0x7d;
static const ShortInt OCI_ATTR_TABLESPACE = 0x7e;
static const ShortInt OCI_ATTR_TDO = 0x7f;
static const Byte OCI_ATTR_LTYPE = 0x80;
static const Byte OCI_ATTR_PARSE_ERROR_OFFSET = 0x81;
static const Byte OCI_ATTR_IS_TEMPORARY = 0x82;
static const Byte OCI_ATTR_IS_TYPED = 0x83;
static const Byte OCI_ATTR_DURATION = 0x84;
static const Byte OCI_ATTR_IS_INVOKER_RIGHTS = 0x85;
static const Byte OCI_ATTR_OBJ_NAME = 0x86;
static const Byte OCI_ATTR_OBJ_SCHEMA = 0x87;
static const Byte OCI_ATTR_OBJ_ID = 0x88;
static const Byte OCI_ATTR_MAXCHAR_SIZE = 0xa3;
static const Byte OCI_ATTR_CURRENT_POSITION = 0xa4;
static const Byte OCI_ATTR_STMTCACHESIZE = 0xb0;
static const Byte OCI_ATTR_STMT_STATE = 0xb6;
static const Byte OCI_ATTR_ENV_UTF16 = 0xd1;
static const Byte OCI_ATTR_SUBSCR_QOSFLAGS = 0xe1;
static const Byte OCI_ATTR_SUBSCR_PAYLOADCBK = 0xe2;
static const Byte OCI_ATTR_SUBSCR_TIMEOUT = 0xe3;
static const Byte OCI_ATTR_SUBSCR_NAMESPACE_CTX = 0xe4;
static const Word OCI_ATTR_CLIENT_IDENTIFIER = 0x116;
static const Word OCI_ATTR_IS_XMLTYPE = 0x13b;
static const Word OCI_ATTR_XMLSCHEMA_NAME = 0x13c;
static const Word OCI_ATTR_XMLELEMENT_NAME = 0x13d;
static const Word OCI_ATTR_XMLSQLTYPSCH_NAME = 0x13e;
static const Word OCI_ATTR_XMLSQLTYPE_NAME = 0x13f;
static const Word OCI_ATTR_XMLTYPE_STORED_OBJ = 0x140;
static const Word OCI_ATTR_TRANSACTION_NO = 0x16d;
static const Word OCI_ATTR_SUBSCR_PORTNO = 0x186;
static const Word OCI_ATTR_CHNF_TABLENAMES = 0x191;
static const Word OCI_ATTR_CHNF_ROWIDS = 0x192;
static const Word OCI_ATTR_CHNF_OPERATIONS = 0x193;
static const Word OCI_ATTR_CHNF_CHANGELAG = 0x194;
static const Word OCI_ATTR_CHDES_DBNAME = 0x195;
static const Word OCI_ATTR_CHDES_NFYTYPE = 0x196;
static const Word OCI_ATTR_CHDES_XID = 0x197;
static const Word OCI_ATTR_CHDES_TABLE_CHANGES = 0x198;
static const Word OCI_ATTR_CHDES_TABLE_NAME = 0x199;
static const Word OCI_ATTR_CHDES_TABLE_OPFLAGS = 0x19a;
static const Word OCI_ATTR_CHDES_TABLE_ROW_CHANGES = 0x19b;
static const Word OCI_ATTR_CHDES_ROW_ROWID = 0x19c;
static const Word OCI_ATTR_CHDES_ROW_OPFLAGS = 0x19d;
static const Word OCI_ATTR_CHNF_REGHANDLE = 0x19e;
static const Word OCI_ATTR_MSG_DELIVERY_MODE = 0x197;
static const Word OCI_ATTR_CONNECTION_TIMEOUT = 0x2711;
static const ShortInt OCI_EVENT_NONE = 0x0;
static const ShortInt OCI_EVENT_STARTUP = 0x1;
static const ShortInt OCI_EVENT_SHUTDOWN = 0x2;
static const ShortInt OCI_EVENT_SHUTDOWN_ANY = 0x3;
static const ShortInt OCI_EVENT_DROP_DB = 0x4;
static const ShortInt OCI_EVENT_DEREG = 0x5;
static const ShortInt OCI_EVENT_OBJCHANGE = 0x6;
static const ShortInt OCI_OPCODE_ALLROWS = 0x1;
static const ShortInt OCI_OPCODE_ALLOPS = 0x0;
static const ShortInt OCI_OPCODE_INSERT = 0x2;
static const ShortInt OCI_OPCODE_UPDATE = 0x4;
static const ShortInt OCI_OPCODE_DELETE = 0x8;
static const ShortInt OCI_OPCODE_ALTER = 0x10;
static const ShortInt OCI_OPCODE_DROP = 0x20;
static const ShortInt OCI_OPCODE_UNKNOWN = 0x40;
static const ShortInt OCI_SUBSCR_QOS_RELIABLE = 0x1;
static const ShortInt OCI_SUBSCR_QOS_PAYLOAD = 0x2;
static const ShortInt OCI_SUBSCR_QOS_REPLICATE = 0x4;
static const ShortInt OCI_SUBSCR_QOS_SECURE = 0x8;
static const ShortInt OCI_SUBSCR_QOS_PURGE_ON_NTFN = 0x10;
static const ShortInt OCI_SUBSCR_QOS_MULTICBK = 0x20;
static const Word OCI_UCS2ID = 0x3e8;
static const Word OCI_UTF16ID = 0x3e8;
static const ShortInt OCI_SUBSCR_NAMESPACE_ANONYMOUS = 0x0;
static const ShortInt OCI_SUBSCR_NAMESPACE_AQ = 0x1;
static const ShortInt OCI_SUBSCR_NAMESPACE_DBCHANGE = 0x2;
static const ShortInt OCI_CRED_RDBMS = 0x1;
static const ShortInt OCI_CRED_EXT = 0x2;
static const ShortInt OCI_CRED_PROXY = 0x3;
static const ShortInt OCI_SUCCESS = 0x0;
static const ShortInt OCI_SUCCESS_WITH_INFO = 0x1;
static const ShortInt OCI_NO_DATA = 0x64;
static const ShortInt OCI_ERROR = -1;
static const ShortInt OCI_INVALID_HANDLE = -2;
static const ShortInt OCI_NEED_DATA = 0x63;
static const short OCI_STILL_EXECUTING = -3123;
static const short OCI_CONTINUE = -24200;
static const ShortInt OCI_V7_SYNTAX = 0x2;
static const ShortInt OCI_V8_SYNTAX = 0x3;
static const ShortInt OCI_NTV_SYNTAX = 0x1;
static const ShortInt OCI_FETCH_NEXT = 0x2;
static const ShortInt OCI_FETCH_FIRST = 0x4;
static const ShortInt OCI_FETCH_LAST = 0x8;
static const ShortInt OCI_FETCH_PRIOR = 0x10;
static const ShortInt OCI_FETCH_ABSOLUTE = 0x20;
static const ShortInt OCI_FETCH_RELATIVE = 0x40;
static const ShortInt OCI_SB2_IND_PTR = 0x1;
static const ShortInt OCI_DATA_AT_EXEC = 0x2;
static const ShortInt OCI_DYNAMIC_FETCH = 0x2;
static const ShortInt OCI_PIECEWISE = 0x4;
static const ShortInt OCI_STMT_STATE_INITIALIZED = 0x1;
static const ShortInt OCI_STMT_STATE_EXECUTED = 0x2;
static const ShortInt OCI_STMT_STATE_END_OF_FETCH = 0x3;
static const ShortInt OCI_BATCH_MODE = 0x1;
static const ShortInt OCI_EXACT_FETCH = 0x2;
static const ShortInt OCI_KEEP_FETCH_STATE = 0x4;
static const ShortInt OCI_SCROLLABLE_CURSOR = 0x8;
static const ShortInt OCI_DESCRIBE_ONLY = 0x10;
static const ShortInt OCI_COMMIT_ON_SUCCESS = 0x20;
static const ShortInt OCI_MIGRATE = 0x1;
static const ShortInt OCI_SYSDBA = 0x2;
static const ShortInt OCI_SYSOPER = 0x4;
static const ShortInt OCI_PRELIM_AUTH = 0x8;
static const ShortInt OCI_STMT_CACHE = 0x40;
static const Word OCI_SYSASM = 0x8000;
static const ShortInt OCI_PARAM_IN = 0x1;
static const ShortInt OCI_PARAM_OUT = 0x2;
static const ShortInt OCI_TRANS_OLD = 0x0;
static const ShortInt OCI_TRANS_NEW = 0x1;
static const ShortInt OCI_TRANS_JOIN = 0x2;
static const ShortInt OCI_TRANS_RESUME = 0x4;
static const Byte OCI_TRANS_STARTMASK = 0xff;
static const Word OCI_TRANS_READONLY = 0x100;
static const Word OCI_TRANS_READWRITE = 0x200;
static const Word OCI_TRANS_SERIALIZABLE = 0x400;
static const Word OCI_TRANS_ISOLMASK = 0xff00;
static const int OCI_TRANS_LOOSE = 0x10000;
static const int OCI_TRANS_TIGHT = 0x20000;
static const int OCI_TRANS_TYPEMASK = 0xf0000;
static const int OCI_TRANS_NOMIGRATE = 0x100000;
static const int OCI_TRANS_TWOPHASE = 0x1000000;
static const ShortInt OCI_ENQ_IMMEDIATE = 0x1;
static const ShortInt OCI_ENQ_ON_COMMIT = 0x2;
static const ShortInt OCI_DEQ_BROWSE = 0x1;
static const ShortInt OCI_DEQ_LOCKED = 0x2;
static const ShortInt OCI_DEQ_REMOVE = 0x3;
static const ShortInt OCI_DEQ_FIRST_MSG = 0x1;
static const ShortInt OCI_DEQ_NEXT_MSG = 0x3;
static const ShortInt OCI_DEQ_NEXT_TRANSACTION = 0x2;
static const ShortInt OCI_MSG_WAITING = 0x1;
static const ShortInt OCI_MSG_READY = 0x0;
static const ShortInt OCI_MSG_PROCESSED = 0x2;
static const ShortInt OCI_MSG_EXPIRED = 0x3;
static const ShortInt OCI_ENQ_BEFORE = 0x2;
static const ShortInt OCI_ENQ_TOP = 0x3;
static const ShortInt OCI_DEQ_IMMEDIATE = 0x1;
static const ShortInt OCI_DEQ_ON_COMMIT = 0x2;
static const ShortInt OCI_DEQ_WAIT_FOREVER = -1;
static const ShortInt OCI_DEQ_NO_WAIT = 0x0;
static const ShortInt OCI_MSG_NO_DELAY = 0x0;
static const ShortInt OCI_MSG_NO_EXPIRATION = -1;
static const ShortInt OCI_MSG_PERSISTENT_OR_BUFFERED = 0x3;
static const ShortInt OCI_MSG_BUFFERED = 0x2;
static const ShortInt OCI_MSG_PERSISTENT = 0x1;
static const ShortInt OCI_OTYPE_UNK = 0x0;
static const ShortInt OCI_OTYPE_TABLE = 0x1;
static const ShortInt OCI_OTYPE_VIEW = 0x2;
static const ShortInt OCI_OTYPE_SYN = 0x3;
static const ShortInt OCI_OTYPE_PROC = 0x4;
static const ShortInt OCI_OTYPE_FUNC = 0x5;
static const ShortInt OCI_OTYPE_PKG = 0x6;
static const ShortInt OCI_OTYPE_STMT = 0x7;
static const Word OCI_ATTR_CHAR_USED = 0x11d;
static const Word OCI_ATTR_CHAR_SIZE = 0x11e;
static const ShortInt OCI_ATTR_DATA_SIZE = 0x1;
static const ShortInt OCI_ATTR_DATA_TYPE = 0x2;
static const ShortInt OCI_ATTR_DISP_SIZE = 0x3;
static const ShortInt OCI_ATTR_NAME = 0x4;
static const ShortInt OCI_ATTR_PRECISION = 0x5;
static const ShortInt OCI_ATTR_SCALE = 0x6;
static const ShortInt OCI_ATTR_IS_NULL = 0x7;
static const ShortInt OCI_ATTR_TYPE_NAME = 0x8;
static const ShortInt OCI_ATTR_SCHEMA_NAME = 0x9;
static const ShortInt OCI_ATTR_SUB_NAME = 0xa;
static const ShortInt OCI_ATTR_POSITION = 0xb;
static const ShortInt OCI_ATTR_COMPLEXOBJECTCOMP_TYPE = 0x32;
static const ShortInt OCI_ATTR_COMPLEXOBJECTCOMP_TYPE_LEVEL = 0x33;
static const ShortInt OCI_ATTR_COMPLEXOBJECT_LEVEL = 0x34;
static const ShortInt OCI_ATTR_COMPLEXOBJECT_COLL_OUTOFLINE = 0x35;
static const ShortInt OCI_ATTR_DISP_NAME = 0x64;
static const Byte OCI_ATTR_OVERLOAD = 0xd2;
static const Byte OCI_ATTR_LEVEL = 0xd3;
static const Byte OCI_ATTR_HAS_DEFAULT = 0xd4;
static const Byte OCI_ATTR_IOMODE = 0xd5;
static const Byte OCI_ATTR_RADIX = 0xd6;
static const Byte OCI_ATTR_NUM_ARGS = 0xd7;
static const Byte OCI_ATTR_TYPECODE = 0xd8;
static const Byte OCI_ATTR_COLLECTION_TYPECODE = 0xd9;
static const Byte OCI_ATTR_VERSION = 0xda;
static const Byte OCI_ATTR_IS_INCOMPLETE_TYPE = 0xdb;
static const Byte OCI_ATTR_IS_SYSTEM_TYPE = 0xdc;
static const Byte OCI_ATTR_IS_PREDEFINED_TYPE = 0xdd;
static const Byte OCI_ATTR_IS_TRANSIENT_TYPE = 0xde;
static const Byte OCI_ATTR_IS_SYSTEM_GENERATED_TYPE = 0xdf;
static const Byte OCI_ATTR_HAS_NESTED_TABLE = 0xe0;
static const Byte OCI_ATTR_HAS_LOB = 0xe1;
static const Byte OCI_ATTR_HAS_FILE = 0xe2;
static const Byte OCI_ATTR_COLLECTION_ELEMENT = 0xe3;
static const Byte OCI_ATTR_NUM_TYPE_ATTRS = 0xe4;
static const Byte OCI_ATTR_LIST_TYPE_ATTRS = 0xe5;
static const Byte OCI_ATTR_NUM_TYPE_METHODS = 0xe6;
static const Byte OCI_ATTR_LIST_TYPE_METHODS = 0xe7;
static const Byte OCI_ATTR_MAP_METHOD = 0xe8;
static const Byte OCI_ATTR_ORDER_METHOD = 0xe9;
static const Word OCI_ATTR_IS_FINAL_TYPE = 0x117;
static const Word OCI_ATTR_IS_INSTANTIABLE_TYPE = 0x118;
static const Word OCI_ATTR_IS_FINAL_METHOD = 0x119;
static const Word OCI_ATTR_IS_INSTANTIABLE_METHOD = 0x11a;
static const Word OCI_ATTR_IS_OVERRIDING_METHOD = 0x11b;
static const Byte OCI_ATTR_NUM_ELEMENTS = 0xea;
static const Byte OCI_ATTR_ENCAPSULATION = 0xeb;
static const Byte OCI_ATTR_IS_SELFISH = 0xec;
static const Byte OCI_ATTR_IS_VIRTUAL = 0xed;
static const Byte OCI_ATTR_IS_INLINE = 0xee;
static const Byte OCI_ATTR_IS_CONSTANT = 0xef;
static const Byte OCI_ATTR_HAS_RESULT = 0xf0;
static const Byte OCI_ATTR_IS_CONSTRUCTOR = 0xf1;
static const Byte OCI_ATTR_IS_DESTRUCTOR = 0xf2;
static const Byte OCI_ATTR_IS_OPERATOR = 0xf3;
static const Byte OCI_ATTR_IS_MAP = 0xf4;
static const Byte OCI_ATTR_IS_ORDER = 0xf5;
static const Byte OCI_ATTR_IS_RNDS = 0xf6;
static const Byte OCI_ATTR_IS_RNPS = 0xf7;
static const Byte OCI_ATTR_IS_WNDS = 0xf8;
static const Byte OCI_ATTR_IS_WNPS = 0xf9;
static const Byte OCI_ATTR_DESC_PUBLIC = 0xfa;
static const ShortInt OCI_AUTH = 0x8;
static const ShortInt OCI_MAX_FNS = 0x64;
static const ShortInt OCI_SQLSTATE_SIZE = 0x5;
static const Word OCI_ERROR_MAXMSG_SIZE = 0x400;
static const ShortInt OCI_ROWID_LEN = 0x17;
static const ShortInt OCI_FO_END = 0x1;
static const ShortInt OCI_FO_ABORT = 0x2;
static const ShortInt OCI_FO_REAUTH = 0x4;
static const ShortInt OCI_FO_BEGIN = 0x8;
static const ShortInt OCI_FO_ERROR = 0x10;
static const Word OCI_FO_RETRY = 0x6342;
static const ShortInt OCI_FO_NONE = 0x1;
static const ShortInt OCI_FO_SESSION = 0x2;
static const ShortInt OCI_FO_SELECT = 0x4;
static const ShortInt OCI_FO_TXNAL = 0x8;
static const ShortInt OCI_FILE_READONLY = 0x1;
static const ShortInt OCI_LOB_BUFFER_FREE = 0x1;
static const ShortInt OCI_LOB_BUFFER_NOFREE = 0x2;
static const ShortInt OCI_TEMP_BLOB = 0x1;
static const ShortInt OCI_TEMP_CLOB = 0x2;
static const ShortInt OCI_TEMP_NCLOB = 0x3;
static const ShortInt OCI_STMT_SELECT = 0x1;
static const ShortInt OCI_STMT_UPDATE = 0x2;
static const ShortInt OCI_STMT_DELETE = 0x3;
static const ShortInt OCI_STMT_INSERT = 0x4;
static const ShortInt OCI_STMT_CREATE = 0x5;
static const ShortInt OCI_STMT_DROP = 0x6;
static const ShortInt OCI_STMT_ALTER = 0x7;
static const ShortInt OCI_STMT_BEGIN = 0x8;
static const ShortInt OCI_STMT_DECLARE = 0x9;
static const ShortInt OCI_STMT_EXPLAIN = 0xa;
static const ShortInt OCI_PTYPE_UNK = 0x0;
static const ShortInt OCI_PTYPE_TABLE = 0x1;
static const ShortInt OCI_PTYPE_VIEW = 0x2;
static const ShortInt OCI_PTYPE_PROC = 0x3;
static const ShortInt OCI_PTYPE_FUNC = 0x4;
static const ShortInt OCI_PTYPE_PKG = 0x5;
static const ShortInt OCI_PTYPE_TYPE = 0x6;
static const ShortInt OCI_PTYPE_SYN = 0x7;
static const ShortInt OCI_PTYPE_SEQ = 0x8;
static const ShortInt OCI_PTYPE_COL = 0x9;
static const ShortInt OCI_PTYPE_ARG = 0xa;
static const ShortInt OCI_PTYPE_LIST = 0xb;
static const ShortInt OCI_PTYPE_TYPE_ATTR = 0xc;
static const ShortInt OCI_PTYPE_TYPE_COLL = 0xd;
static const ShortInt OCI_PTYPE_TYPE_METHOD = 0xe;
static const ShortInt OCI_PTYPE_TYPE_ARG = 0xf;
static const ShortInt OCI_PTYPE_TYPE_RESULT = 0x10;
static const ShortInt OCI_LTYPE_UNK = 0x0;
static const ShortInt OCI_LTYPE_COLUMN = 0x1;
static const ShortInt OCI_LTYPE_ARG_PROC = 0x2;
static const ShortInt OCI_LTYPE_ARG_FUNC = 0x3;
static const ShortInt OCI_LTYPE_SUBPRG = 0x4;
static const ShortInt OCI_LTYPE_TYPE_ATTR = 0x5;
static const ShortInt OCI_LTYPE_TYPE_METHOD = 0x6;
static const ShortInt OCI_LTYPE_TYPE_ARG_PROC = 0x7;
static const ShortInt OCI_LTYPE_TYPE_ARG_FUNC = 0x8;
static const ShortInt OCI_TYPECODE_REF = 0x6e;
static const ShortInt OCI_TYPECODE_DATE = 0xc;
static const ShortInt OCI_TYPECODE_SIGNED8 = 0x1b;
static const ShortInt OCI_TYPECODE_SIGNED16 = 0x1c;
static const ShortInt OCI_TYPECODE_SIGNED32 = 0x1d;
static const ShortInt OCI_TYPECODE_REAL = 0x15;
static const ShortInt OCI_TYPECODE_DOUBLE = 0x16;
static const ShortInt OCI_TYPECODE_FLOAT = 0x4;
static const ShortInt OCI_TYPECODE_NUMBER = 0x2;
static const ShortInt OCI_TYPECODE_DECIMAL = 0x7;
static const ShortInt OCI_TYPECODE_UNSIGNED8 = 0x17;
static const ShortInt OCI_TYPECODE_UNSIGNED16 = 0x19;
static const ShortInt OCI_TYPECODE_UNSIGNED32 = 0x1a;
static const Byte OCI_TYPECODE_OCTET = 0xf5;
static const Byte OCI_TYPECODE_SMALLINT = 0xf6;
static const ShortInt OCI_TYPECODE_INTEGER = 0x3;
static const ShortInt OCI_TYPECODE_RAW = 0x5f;
static const ShortInt OCI_TYPECODE_PTR = 0x20;
static const ShortInt OCI_TYPECODE_VARCHAR2 = 0x9;
static const ShortInt OCI_TYPECODE_CHAR = 0x60;
static const ShortInt OCI_TYPECODE_VARCHAR = 0x1;
static const ShortInt OCI_TYPECODE_MLSLABEL = 0x69;
static const Byte OCI_TYPECODE_VARRAY = 0xf7;
static const Byte OCI_TYPECODE_TABLE = 0xf8;
static const ShortInt OCI_TYPECODE_OBJECT = 0x6c;
static const ShortInt OCI_TYPECODE_NAMEDCOLLECTION = 0x7a;
static const ShortInt OCI_TYPECODE_BLOB = 0x71;
static const ShortInt OCI_TYPECODE_BFILE = 0x72;
static const ShortInt OCI_TYPECODE_CLOB = 0x70;
static const ShortInt OCI_TYPECODE_CFILE = 0x73;
static const ShortInt OCI_TYPECODE_OPAQUE = 0x3a;
static const Byte OCI_TYPECODE_OTMFIRST = 0xe4;
static const Word OCI_TYPECODE_OTMLAST = 0x140;
static const Byte OCI_TYPECODE_SYSFIRST = 0xe4;
static const Byte OCI_TYPECODE_SYSLAST = 0xeb;
static const Byte OCI_TYPECODE_ITABLE = 0xfb;
static const Byte OCI_TYPECODE_RECORD = 0xfa;
static const Byte OCI_TYPECODE_BOOLEAN = 0xfc;
static const ShortInt OCI_IND_NOTNULL = 0x0;
static const ShortInt OCI_IND_NULL = -1;
static const ShortInt OCI_IND_BADNULL = -2;
static const ShortInt OCI_IND_NOTNULLABLE = -3;
static const ShortInt OCI_PIN_DEFAULT = 0x1;
static const ShortInt OCI_PIN_ANY = 0x3;
static const ShortInt OCI_PIN_RECENT = 0x4;
static const ShortInt OCI_PIN_LATEST = 0x5;
static const ShortInt OCI_LOCK_NONE = 0x1;
static const ShortInt OCI_LOCK_X = 0x2;
static const ShortInt OCI_MARK_DEFAULT = 0x1;
static const ShortInt OCI_MARK_NONE = 0x1;
static const ShortInt OCI_MARK_UPDATE = 0x2;
static const Word OCI_DURATION_INVALID = 0xffff;
static const ShortInt OCI_DURATION_BEGIN = 0xa;
static const ShortInt OCI_DURATION_SESSION = 0xa;
static const ShortInt OCI_DURATION_TRANS = 0xb;
static const ShortInt OCI_DURATION_STATEMENT = 0xd;
static const ShortInt OCI_DURATION_CALLOUT = 0xe;
static const ShortInt OCI_DURATION_NULL = 0x9;
static const ShortInt OCI_DURATION_DEFAULT = 0x8;
static const ShortInt OCI_DURATION_USER_CALLBACK = 0x7;
static const ShortInt OCI_DURATION_NEXT = 0x6;
static const ShortInt OCI_DURATION_PROCESS = 0x5;
static const ShortInt OCI_DURATION_LAST = 0xe;
static const ShortInt OCI_OBJECTFREE_FORCE = 0x1;
static const ShortInt OCI_OBJECTFREE_NONULL = 0x2;
static const ShortInt OCI_OBJECT_PERSISTENT = 0x1;
static const ShortInt OCI_OBJECT_TRANSIENT = 0x2;
static const ShortInt OCI_OBJECT_VALUE = 0x3;
static const ShortInt OCI_OBJECT_NEW = 0x1;
static const ShortInt OCI_OBJECT_DELETED = 0x2;
static const ShortInt OCI_OBJECT_UPDATED = 0x4;
static const ShortInt OCI_TYPEGET_HEADER = 0x0;
static const ShortInt OCI_TYPEGET_ALL = 0x1;
static const ShortInt OCI_NUMBER_SIZE = 0x16;
static const ShortInt OCI_NUMBER_UNSIGNED = 0x0;
static const ShortInt OCI_NUMBER_SIGNED = 0x2;
static const ShortInt OCI_INTER_INVALID_DAY = 0x1;
static const ShortInt OCI_INTER_DAY_BELOW_VALID = 0x2;
static const ShortInt OCI_INTER_INVALID_MONTH = 0x4;
static const ShortInt OCI_INTER_MONTH_BELOW_VALID = 0x8;
static const ShortInt OCI_INTER_INVALID_YEAR = 0x10;
static const ShortInt OCI_INTER_YEAR_BELOW_VALID = 0x20;
static const ShortInt OCI_INTER_INVALID_HOUR = 0x40;
static const Byte OCI_INTER_HOUR_BELOW_VALID = 0x80;
static const Word OCI_INTER_INVALID_MINUTE = 0x100;
static const Word OCI_INTER_MINUTE_BELOW_VALID = 0x200;
static const Word OCI_INTER_INVALID_SECOND = 0x400;
static const Word OCI_INTER_SECOND_BELOW_VALID = 0x800;
static const Word OCI_INTER_INVALID_FRACSEC = 0x1000;
static const Word OCI_INTER_FRACSEC_BELOW_VALID = 0x2000;
static const ShortInt OCI_DT_INVALID_DAY = 0x1;
static const ShortInt OCI_DT_DAY_BELOW_VALID = 0x2;
static const ShortInt OCI_DT_INVALID_MONTH = 0x4;
static const ShortInt OCI_DT_MONTH_BELOW_VALID = 0x8;
static const ShortInt OCI_DT_INVALID_YEAR = 0x10;
static const ShortInt OCI_DT_YEAR_BELOW_VALID = 0x20;
static const ShortInt OCI_DT_INVALID_HOUR = 0x40;
static const Byte OCI_DT_HOUR_BELOW_VALID = 0x80;
static const Word OCI_DT_INVALID_MINUTE = 0x100;
static const Word OCI_DT_MINUTE_BELOW_VALID = 0x200;
static const Word OCI_DT_INVALID_SECOND = 0x400;
static const Word OCI_DT_SECOND_BELOW_VALID = 0x800;
static const Word OCI_DT_DAY_MISSING_FROM_1582 = 0x1000;
static const Word OCI_DT_YEAR_ZERO = 0x2000;
static const Word OCI_DT_INVALID_TIMEZONE = 0x4000;
static const Word OCI_DT_INVALID_FORMAT = 0x8000;
static const ShortInt ORAMTS_CFLG_ALLDEFAULT = 0x0;
static const ShortInt ORAMTS_CFLG_NOIMPLICIT = 0x1;
static const ShortInt ORAMTS_CFLG_UNIQUESRVR = 0x2;
static const ShortInt ORAMTS_CFLG_SYSDBALOGN = 0x4;
static const ShortInt ORAMTS_CFLG_SYSOPRLOGN = 0x10;
static const ShortInt ORAMTS_CFLG_PRELIMAUTH = 0x20;
static const ShortInt ORAMTS_ENFLG_DEFAULT = 0x0;
static const ShortInt ORAMTS_ENFLG_RESUMTX = 0x1;
static const ShortInt ORAMTS_ENFLG_DETCHTX = 0x2;
static const ShortInt ORAMTSERR_NOERROR = 0x0;
static const Word ORAMTSERR_NOMTXDISPEN = 0x3e9;
static const Word ORAMTSERR_DSPCREAFAIL = 0x3ea;
static const Word ORAMTSERR_DSPMAXSESSN = 0x3eb;
static const Word ORAMTSERR_DSPINVLSVCC = 0x3ec;
static const Word ORAMTSERR_DSPNODBIDEN = 0x3ed;
static const Word ORAMTSERR_NOSERVEROBJ = 0x7d1;
static const Word ORAMTSERR_INVALIDSRVR = 0xbb9;
static const Word ORAMTSERR_FAILEDATTCH = 0xbba;
static const Word ORAMTSERR_FAILEDDETCH = 0xbbb;
static const Word ORAMTSERR_FAILEDTRANS = 0xbbc;
static const Word ORAMTSERR_SETATTRIBUT = 0xbbd;
static const Word ORAMTSERR_CONNXBROKEN = 0xbbe;
static const Word ORAMTSERR_NOTATTACHED = 0xbbf;
static const Word ORAMTSERR_ALDYATTACHD = 0xbc0;
static const Word ORAMTSERR_INVALIDSESS = 0xfa1;
static const Word ORAMTSERR_FAILEDLOGON = 0xfa2;
static const Word ORAMTSERR_FAILEDLOGOF = 0xfa3;
static const Word ORAMTSERR_TRANSEXISTS = 0xfa4;
static const Word ORAMTSERR_LOGONEXISTS = 0xfa5;
static const Word ORAMTSERR_NOTLOGGEDON = 0xfa6;
static const Word ORAMTSERR_RPCINVLCTXT = 0x1389;
static const Word ORAMTSERR_RPCCOMMUERR = 0x138a;
static const Word ORAMTSERR_RPCALRDYCON = 0x138b;
static const Word ORAMTSERR_RPCNOTCONNE = 0x138c;
static const Word ORAMTSERR_RPCPROTVIOL = 0x138d;
static const Word ORAMTSERR_RPCACCPTIMO = 0x138e;
static const Word ORAMTSERR_RPCILLEGOPC = 0x138f;
static const Word ORAMTSERR_RPCBADINCNO = 0x1390;
static const Word ORAMTSERR_RPCCONNTIMO = 0x1391;
static const Word ORAMTSERR_RPCSENDTIMO = 0x1392;
static const Word ORAMTSERR_RPCRECVTIMO = 0x1393;
static const Word ORAMTSERR_RPCCONRESET = 0x1394;
static const Word ORAMTSERR_INVALIDARGU = 0x1771;
static const Word ORAMTSERR_INVALIDOBJE = 0x1772;
static const Word ORAMTSERR_ILLEGALOPER = 0x1773;
static const Word ORAMTSERR_ALLOCMEMORY = 0x1774;
static const Word ORAMTSERR_ERRORSYNCHR = 0x1775;
static const Word ORAMTSERR_NOORAPROXY = 0x1776;
static const Word ORAMTSERR_ALRDYENLIST = 0x1777;
static const Word ORAMTSERR_NOTENLISTED = 0x1778;
static const Word ORAMTSERR_TYPMANENLIS = 0x1779;
static const Word ORAMTSERR_TYPAUTENLIS = 0x177a;
static const Word ORAMTSERR_TRANSDETACH = 0x177b;
static const Word ORAMTSERR_OCIHNDLALLC = 0x177c;
static const Word ORAMTSERR_OCIHNDLRELS = 0x177d;
static const Word ORAMTSERR_TRANSEXPORT = 0x177e;
static const Word ORAMTSERR_OSCREDSFAIL = 0x17d9;
static const Word ORAMTSERR_ISONOSUPPORT = 0x17dc;
static const Word ORAMTSERR_MIXEDTXNISO = 0x17dd;
static const ShortInt OCI_DIRPATH_LOAD = 0x1;
static const ShortInt OCI_DIRPATH_UNLOAD = 0x2;
static const ShortInt OCI_DIRPATH_CONVERT = 0x3;
static const ShortInt OCI_DIRPATH_NORMAL = 0x1;
static const ShortInt OCI_DIRPATH_PARTIAL = 0x2;
static const ShortInt OCI_DIRPATH_NOT_PREPARED = 0x3;
static const ShortInt OCI_DIRPATH_COL_COMPLETE = 0x0;
static const ShortInt OCI_DIRPATH_COL_NULL = 0x1;
static const ShortInt OCI_DIRPATH_COL_PARTIAL = 0x2;
static const ShortInt sizeof_TRowId8 = 0xe;
static const ShortInt sizeof_TRowId81 = 0xd;
static const ShortInt sizeof_OCIRowid = 0x16;
static const ShortInt sizeof_OCIRowid81 = 0xc;
static const Byte XID_SIZE = 0x8c;
extern PACKAGE _OCIAttrGet1 OCIAttrGet1;
extern PACKAGE _OCIAttrGet2 OCIAttrGet2;
extern PACKAGE _OCIAttrSet1 OCIAttrSet1;
extern PACKAGE _OCIAttrSet2 OCIAttrSet2;
extern PACKAGE _OCIBindArrayOfStruct OCIBindArrayOfStruct;
extern PACKAGE _OCIBindByName OCIBindByName;
extern PACKAGE _OCIBindByPos OCIBindByPos;
extern PACKAGE _OCIBindDynamic OCIBindDynamic;
extern PACKAGE _OCIBindObject OCIBindObject;
extern PACKAGE _OCIBreak OCIBreak;
extern PACKAGE _OCIDefineArrayOfStruct OCIDefineArrayOfStruct;
extern PACKAGE _OCIDefineByPos OCIDefineByPos;
extern PACKAGE _OCIDefineDynamic OCIDefineDynamic;
extern PACKAGE _OCIDefineObject OCIDefineObject;
extern PACKAGE _OCIDescribeAny OCIDescribeAny;
extern PACKAGE _OCIDescriptorAlloc OCIDescriptorAlloc;
extern PACKAGE _OCIDescriptorFree OCIDescriptorFree;
extern PACKAGE _OCIEnvInit OCIEnvInit;
extern PACKAGE _OCIErrorGet OCIErrorGet;
extern PACKAGE _OCIHandleAlloc OCIHandleAlloc;
extern PACKAGE _OCIHandleFree OCIHandleFree;
extern PACKAGE _OCIInitialize OCIInitialize;
extern PACKAGE _OCILdaToSvcCtx OCILdaToSvcCtx;
extern PACKAGE _OCIParamGet OCIParamGet;
extern PACKAGE _OCIPasswordChange OCIPasswordChange;
extern PACKAGE _OCIServerAttach OCIServerAttach;
extern PACKAGE _OCIServerDetach OCIServerDetach;
extern PACKAGE _OCIServerVersion OCIServerVersion;
extern PACKAGE _OCISessionBegin OCISessionBegin;
extern PACKAGE _OCISessionEnd OCISessionEnd;
extern PACKAGE _OCISessionGet OCISessionGet;
extern PACKAGE _OCISessionRelease OCISessionRelease;
extern PACKAGE _OCISessionPoolCreate OCISessionPoolCreate;
extern PACKAGE _OCISessionPoolDestroy OCISessionPoolDestroy;
extern PACKAGE _OCITransStart OCITransStart;
extern PACKAGE _OCITransRollback OCITransRollback;
extern PACKAGE _OCITransCommit OCITransCommit;
extern PACKAGE _OCITransDetach OCITransDetach;
extern PACKAGE _OCITransPrepare OCITransPrepare;
extern PACKAGE _OCITransForget OCITransForget;
extern PACKAGE _OCIStmtExecute OCIStmtExecute;
extern PACKAGE _OCIStmtFetch OCIStmtFetch;
extern PACKAGE _OCIStmtFetch2 OCIStmtFetch2;
extern PACKAGE _OCIStmtGetPieceInfo OCIStmtGetPieceInfo;
extern PACKAGE _OCIStmtPrepare OCIStmtPrepare;
extern PACKAGE _OCIStmtPrepare2 OCIStmtPrepare2;
extern PACKAGE _OCIStmtRelease OCIStmtRelease;
extern PACKAGE _OCIStmtSetPieceInfo OCIStmtSetPieceInfo;
extern PACKAGE _OCISvcCtxToLda OCISvcCtxToLda;
extern PACKAGE _OCILobAppend OCILobAppend;
extern PACKAGE _OCILobAssign OCILobAssign;
extern PACKAGE _OCILobCharSetForm OCILobCharSetForm;
extern PACKAGE _OCILobCharSetId OCILobCharSetId;
extern PACKAGE _OCILobCopy OCILobCopy;
extern PACKAGE _OCILobCreateTemporary OCILobCreateTemporary;
extern PACKAGE _OCILobFreeTemporary OCILobFreeTemporary;
extern PACKAGE _OCILobIsTemporary OCILobIsTemporary;
extern PACKAGE _OCILobDisableBuffering OCILobDisableBuffering;
extern PACKAGE _OCILobEnableBuffering OCILobEnableBuffering;
extern PACKAGE _OCILobErase OCILobErase;
extern PACKAGE _OCILobFileClose OCILobFileClose;
extern PACKAGE _OCILobFileExists OCILobFileExists;
extern PACKAGE _OCILobFileGetName OCILobFileGetName;
extern PACKAGE _OCILobFileIsOpen OCILobFileIsOpen;
extern PACKAGE _OCILobFileOpen OCILobFileOpen;
extern PACKAGE _OCILobFileSetName OCILobFileSetName;
extern PACKAGE _OCILobFlushBuffer OCILobFlushBuffer;
extern PACKAGE _OCILobGetLength OCILobGetLength;
extern PACKAGE _OCILobIsEqual OCILobIsEqual;
extern PACKAGE _OCILobLoadFromFile OCILobLoadFromFile;
extern PACKAGE _OCILobLocatorIsInit OCILobLocatorIsInit;
extern PACKAGE _OCILobRead OCILobRead;
extern PACKAGE _OCILobRead2 OCILobRead2;
extern PACKAGE _OCILobTrim OCILobTrim;
extern PACKAGE _OCILobWrite OCILobWrite;
extern PACKAGE _OCICacheFlush OCICacheFlush;
extern PACKAGE _OCICacheFree OCICacheFree;
extern PACKAGE _OCICacheRefresh OCICacheRefresh;
extern PACKAGE _OCICacheUnmark OCICacheUnmark;
extern PACKAGE _OCICacheUnpin OCICacheUnpin;
extern PACKAGE _OCIObjectCopy OCIObjectCopy;
extern PACKAGE _OCIObjectExists OCIObjectExists;
extern PACKAGE _OCIObjectFlush OCIObjectFlush;
extern PACKAGE _OCIObjectFree OCIObjectFree;
extern PACKAGE _OCIObjectGetAttr OCIObjectGetAttr;
extern PACKAGE _OCIObjectGetInd OCIObjectGetInd;
extern PACKAGE _OCIObjectGetObjectRef OCIObjectGetObjectRef;
extern PACKAGE _OCIObjectGetProperty OCIObjectGetProperty;
extern PACKAGE _OCIObjectGetTypeRef OCIObjectGetTypeRef;
extern PACKAGE _OCIObjectIsDirty OCIObjectIsDirty;
extern PACKAGE _OCIObjectIsLocked OCIObjectIsLocked;
extern PACKAGE _OCIObjectLock OCIObjectLock;
extern PACKAGE _OCIObjectMarkDelete OCIObjectMarkDelete;
extern PACKAGE _OCIObjectMarkDeleteByRef OCIObjectMarkDeleteByRef;
extern PACKAGE _OCIObjectMarkUpdate OCIObjectMarkUpdate;
extern PACKAGE _OCIObjectNew OCIObjectNew;
extern PACKAGE _OCIObjectPin OCIObjectPin;
extern PACKAGE _OCIObjectPinCountReset OCIObjectPinCountReset;
extern PACKAGE _OCIObjectPinTable OCIObjectPinTable;
extern PACKAGE _OCIObjectRefresh OCIObjectRefresh;
extern PACKAGE _OCIObjectSetAttr OCIObjectSetAttr;
extern PACKAGE _OCIObjectUnmark OCIObjectUnmark;
extern PACKAGE _OCIObjectUnmarkByRef OCIObjectUnmarkByRef;
extern PACKAGE _OCIObjectUnpin OCIObjectUnpin;
extern PACKAGE _OCITypeByName OCITypeByName;
extern PACKAGE _OCITypeByRef OCITypeByRef;
extern PACKAGE _OCICollAppend OCICollAppend;
extern PACKAGE _OCICollAssign OCICollAssign;
extern PACKAGE _OCICollAssignElem OCICollAssignElem;
extern PACKAGE _OCICollGetElem OCICollGetElem;
extern PACKAGE _OCICollMax OCICollMax;
extern PACKAGE _OCICollSize OCICollSize;
extern PACKAGE _OCICollTrim OCICollTrim;
extern PACKAGE _OCIDateAssign OCIDateAssign;
extern PACKAGE _OCIDateFromText OCIDateFromText;
extern PACKAGE _OCIDateGetDate OCIDateGetDate;
extern PACKAGE _OCIDateGetTime OCIDateGetTime;
extern PACKAGE _OCIDateSetDate OCIDateSetDate;
extern PACKAGE _OCIDateSetTime OCIDateSetTime;
extern PACKAGE _OCIDateToText OCIDateToText;
extern PACKAGE _OCINumberAssign OCINumberAssign;
extern PACKAGE _OCINumberCmp OCINumberCmp;
extern PACKAGE _OCINumberFromInt OCINumberFromInt;
extern PACKAGE _OCINumberFromReal OCINumberFromReal;
extern PACKAGE _OCINumberFromText OCINumberFromText;
extern PACKAGE _OCINumberToInt OCINumberToInt;
extern PACKAGE _OCINumberToReal OCINumberToReal;
extern PACKAGE _OCINumberToText OCINumberToText;
extern PACKAGE _OCIRefAssign OCIRefAssign;
extern PACKAGE _OCIRefClear OCIRefClear;
extern PACKAGE _OCIRefIsEqual OCIRefIsEqual;
extern PACKAGE _OCIRefIsNull OCIRefIsNull;
extern PACKAGE _OCIRefToHex OCIRefToHex;
extern PACKAGE _OCIStringAllocSize OCIStringAllocSize;
extern PACKAGE _OCIStringAssign OCIStringAssign;
extern PACKAGE _OCIStringAssignText OCIStringAssignText;
extern PACKAGE _OCIStringPtr OCIStringPtr;
extern PACKAGE _OCIStringResize OCIStringResize;
extern PACKAGE _OCIStringSize OCIStringSize;
extern PACKAGE _OCITableDelete OCITableDelete;
extern PACKAGE _OCITableExists OCITableExists;
extern PACKAGE _OCITableFirst OCITableFirst;
extern PACKAGE _OCITableLast OCITableLast;
extern PACKAGE _OCITableNext OCITableNext;
extern PACKAGE _OCITablePrev OCITablePrev;
extern PACKAGE _OCITableSize OCITableSize;
extern PACKAGE _OCIEnvCreate OCIEnvCreate;
extern PACKAGE _OCIDirPathAbort OCIDirPathAbort;
extern PACKAGE _OCIDirPathColArrayEntryGet OCIDirPathColArrayEntryGet;
extern PACKAGE _OCIDirPathColArrayEntrySet OCIDirPathColArrayEntrySet;
extern PACKAGE _OCIDirPathColArrayRowGet OCIDirPathColArrayRowGet;
extern PACKAGE _OCIDirPathColArrayReset OCIDirPathColArrayReset;
extern PACKAGE _OCIDirPathColArrayToStream OCIDirPathColArrayToStream;
extern PACKAGE _OCIDirPathFinish OCIDirPathFinish;
extern PACKAGE _OCIDirPathLoadStream OCIDirPathLoadStream;
extern PACKAGE _OCIDirPathPrepare OCIDirPathPrepare;
extern PACKAGE _OCIDirPathStreamReset OCIDirPathStreamReset;
extern PACKAGE _OCIDateTimeConstruct OCIDateTimeConstruct;
extern PACKAGE _OCIDateTimeCheck OCIDateTimeCheck;
extern PACKAGE _OCIDateTimeFromText OCIDateTimeFromText;
extern PACKAGE _OCIDateTimeToText OCIDateTimeToText;
extern PACKAGE _OCIDateTimeGetDate OCIDateTimeGetDate;
extern PACKAGE _OCIDateTimeGetTime OCIDateTimeGetTime;
extern PACKAGE _OCIDateTimeGetTimeZoneOffset OCIDateTimeGetTimeZoneOffset;
extern PACKAGE _OCIDateTimeGetTimeZoneName OCIDateTimeGetTimeZoneName;
extern PACKAGE _OCIDateTimeAssign OCIDateTimeAssign;
extern PACKAGE _OCIDateTimeCompare OCIDateTimeCompare;
extern PACKAGE _OCIIntervalFromText OCIIntervalFromText;
extern PACKAGE _OCIIntervalToText OCIIntervalToText;
extern PACKAGE _OCIIntervalCheck OCIIntervalCheck;
extern PACKAGE _OCIIntervalAssign OCIIntervalAssign;
extern PACKAGE _OCIIntervalCompare OCIIntervalCompare;
extern PACKAGE _OCIIntervalSetYearMonth OCIIntervalSetYearMonth;
extern PACKAGE _OCIIntervalGetYearMonth OCIIntervalGetYearMonth;
extern PACKAGE _OCIIntervalSetDaySecond OCIIntervalSetDaySecond;
extern PACKAGE _OCIIntervalGetDaySecond OCIIntervalGetDaySecond;
extern PACKAGE _OCIIntervalFromNumber OCIIntervalFromNumber;
extern PACKAGE _OCIPing OCIPing;
extern PACKAGE _OCIXMLTypeNew OCIXMLTypeNew;
extern PACKAGE _OCIXMLTypeCreateFromSrc OCIXMLTypeCreateFromSrc;
extern PACKAGE _OCIXMLTypeExtract OCIXMLTypeExtract;
extern PACKAGE _OCIXMLTypeTransform OCIXMLTypeTransform;
extern PACKAGE _OCIXMLTypeExists OCIXMLTypeExists;
extern PACKAGE _OCIXMLTypeIsSchemaBased OCIXMLTypeIsSchemaBased;
extern PACKAGE _OCIXMLTypeGetSchema OCIXMLTypeGetSchema;
extern PACKAGE _OCIXMLTypeValidate OCIXMLTypeValidate;
extern PACKAGE _OCIXMLTypeGetDOM OCIXMLTypeGetDOM;
extern PACKAGE _OCIXMLTypeGetFromDOM OCIXMLTypeGetFromDOM;
extern PACKAGE _OCIDOMFree OCIDOMFree;
extern PACKAGE _OCIPStreamFromXMLType OCIPStreamFromXMLType;
extern PACKAGE _OCIPStreamRead OCIPStreamRead;
extern PACKAGE _OCIPStreamClose OCIPStreamClose;
extern PACKAGE _OCIRowidToChar OCIRowidToChar;
extern PACKAGE _OCIExtProcGetEnv OCIExtProcGetEnv;
extern PACKAGE _OCIExtProcAllocCallMemory OCIExtProcAllocCallMemory;
extern PACKAGE _OCIExtProcRaiseExcpWithMsg OCIExtProcRaiseExcpWithMsg;
extern PACKAGE _OCISubscriptionRegister OCISubscriptionRegister;
extern PACKAGE _OCISubscriptionUnRegister OCISubscriptionUnRegister;
extern PACKAGE _OCISubscriptionEnable OCISubscriptionEnable;
extern PACKAGE _OCISubscriptionDisable OCISubscriptionDisable;
extern PACKAGE _OraMTSSvcGet OraMTSSvcGet;
extern PACKAGE _OraMTSSvcRel OraMTSSvcRel;
extern PACKAGE _OraMTSJoinTxn OraMTSJoinTxn;
extern PACKAGE _OraMTSEnlCtxGet OraMTSEnlCtxGet;
extern PACKAGE _OraMTSEnlCtxRel OraMTSEnlCtxRel;
extern PACKAGE _OraMTSSvcEnlist OraMTSSvcEnlist;
static const ShortInt MaxOracleHomes = 0xa;
extern PACKAGE System::UnicodeString OCIDLL;
extern PACKAGE System::UnicodeString OCIClientDLL;
extern PACKAGE System::UnicodeString OCIVersionSt;
extern PACKAGE System::Word OCIVersion;
extern PACKAGE TOCICallStyle OCICallStyle;
extern PACKAGE TOCICallStyleSet PossibleOCICallStyles;
extern PACKAGE bool ObjectVersion;
extern PACKAGE bool ThreadSafety;
extern PACKAGE bool OCIThreaded;
extern PACKAGE bool OCIMutexed;
extern PACKAGE bool OCIShared;
extern PACKAGE bool OCIEvents;
extern PACKAGE System::Word OCIEventsVersion;
extern PACKAGE bool OCIUnicode;
extern PACKAGE bool OCIInited;
extern PACKAGE void *hOCIEnv;
extern PACKAGE void *hOCIError;
extern PACKAGE bool OCILite;
extern PACKAGE System::UnicodeString OracleHomePath;
extern PACKAGE System::UnicodeString OracleHomeName;
extern PACKAGE int OracleHomeCount;
extern PACKAGE int DefaultOracleHome;
extern PACKAGE Oracall__2 OracleHomePaths;
extern PACKAGE Oracall__3 OracleHomeKeys;
extern PACKAGE Oracall__4 OracleHomeNames;
extern PACKAGE int OracleErrorMaxLength;
extern PACKAGE int SubscriptionPort;
#define DACProductName L"ODAC"
extern PACKAGE bool __fastcall IsUnicodeEnv(void * Env, void * hError = (void *)(0x0));
extern PACKAGE void * __fastcall StringToHGlobalOCI(const System::UnicodeString S, int &Size, bool UnicodeEnv);
extern PACKAGE void __fastcall FreeStringOCI(void * P, bool UnicodeEnv);
extern PACKAGE System::UnicodeString __fastcall PtrToStringOCI(void * P, bool UnicodeEnv)/* overload */;
extern PACKAGE System::UnicodeString __fastcall PtrToStringOCI(void * P, int Size, bool UnicodeEnv)/* overload */;
extern PACKAGE int __fastcall SizeOfCharOCI(bool UnicodeEnv);
extern PACKAGE void __fastcall OCINumberFromBCD(Sysutils::TBytes rnum, unsigned rnum_length, void * number);
extern PACKAGE void __fastcall OCINumberToBCD(void * Number, void *Bcd);
extern PACKAGE System::Word __fastcall VersionStrToWord(System::UnicodeString VersionSt);
extern PACKAGE void __fastcall DetectOCI(void);
extern PACKAGE void __fastcall LoadOCI(void);
extern PACKAGE void __fastcall FreeOCI(void);
extern PACKAGE bool __fastcall LoadedOCI(void);
extern PACKAGE void __fastcall InitOCI(void);
extern PACKAGE void __fastcall FinishOCI(void);
extern PACKAGE void __fastcall CheckOCI(void);
extern PACKAGE void __fastcall CheckOCI73(void);
extern PACKAGE void __fastcall CheckOCI80(void);
extern PACKAGE void __fastcall CheckOCI81(void);
extern PACKAGE void __fastcall CheckOCI90(void);
extern PACKAGE void __fastcall InitMTS(void);
extern PACKAGE void __fastcall FreeMTS(void);
extern PACKAGE void __fastcall OraError(int ErrorCode, bool UnicodeEnv, void * hError = (void *)(0x0));
extern PACKAGE int __fastcall GetOraError(int ErrorCode, bool UnicodeEnv, System::UnicodeString &ErrorMsg, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE int __fastcall GetOraError(int ErrorCode, bool UnicodeEnv, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE void __fastcall Check(int Status, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE void __fastcall Check(int Status, bool UnicodeEnv, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE void __fastcall MTSError(int ErrorCode, bool UnicodeEnv, void * hError = (void *)(0x0));
extern PACKAGE int __fastcall GetMTSError(int ErrorCode, bool UnicodeEnv, System::UnicodeString &ErrorMsg, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE int __fastcall GetMTSError(int ErrorCode, bool UnicodeEnv, void * hError = (void *)(0x0))/* overload */;
extern PACKAGE void __fastcall MTSCheck(int Status, bool UnicodeEnv, void * hError = (void *)(0x0));
extern PACKAGE int __fastcall GetHeapAlloc(void);
extern PACKAGE int __fastcall GetSharedHeapAlloc(void);
extern PACKAGE int __fastcall GetSubscriptionPort(void);
extern PACKAGE bool __fastcall GetThreadSafety(void);
extern PACKAGE void __fastcall SetThreadSafety(bool Value);

}	/* namespace Oracall */
using namespace Oracall;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OracallHPP
