// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Win32timer.pas' rev: 21.00

#ifndef Win32timerHPP
#define Win32timerHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Daconsts.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Win32timer
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TWin32Timer;
class PASCALIMPLEMENTATION TWin32Timer : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	unsigned FInterval;
	HWND FWindowHandle;
	Classes::TNotifyEvent FOnTimer;
	bool FEnabled;
	void __fastcall UpdateTimer(void);
	void __fastcall SetEnabled(bool Value);
	void __fastcall SetInterval(unsigned Value);
	void __fastcall SetOnTimer(Classes::TNotifyEvent Value);
	
protected:
	DYNAMIC void __fastcall Timer(void);
	
public:
	__fastcall virtual TWin32Timer(Classes::TComponent* AOwner);
	__fastcall virtual ~TWin32Timer(void);
	
__published:
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property unsigned Interval = {read=FInterval, write=SetInterval, default=1000};
	__property Classes::TNotifyEvent OnTimer = {read=FOnTimer, write=SetOnTimer};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Win32timer */
using namespace Win32timer;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Win32timerHPP
