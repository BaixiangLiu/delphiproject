// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Orasmart.pas' rev: 21.00

#ifndef OrasmartHPP
#define OrasmartHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Oraservices.hpp>	// Pascal unit
#include <Oraalerter.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Orasmart
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSmartState { dsState, dsView };
#pragma option pop

class DELPHICLASS TSmartQueryOptions;
class PASCALIMPLEMENTATION TSmartQueryOptions : public Ora::TOraDataSetOptions
{
	typedef Ora::TOraDataSetOptions inherited;
	
public:
	__fastcall TSmartQueryOptions(Dbaccess::TCustomDADataSet* Owner);
	
__published:
	__property QuoteNames = {default=0};
	__property SetFieldsReadOnly = {default=1};
	__property ExtendedFieldsInfo = {default=1};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TSmartQueryOptions(void) { }
	
};


class DELPHICLASS TSmartSQLGenerator;
class PASCALIMPLEMENTATION TSmartSQLGenerator : public Ora::TOraSQLGenerator
{
	typedef Ora::TOraSQLGenerator inherited;
	
protected:
	virtual bool __fastcall FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf)/* overload */;
	virtual bool __fastcall FieldModified(Craccess::TCRFieldDesc* FieldDesc, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf)/* overload */;
	virtual void __fastcall AddFieldToRefreshSQL(Craccess::TCRFieldDesc* FieldDesc);
	virtual void __fastcall GenerateConditions(Clrclasses::WideStringBuilder* SB, const Dbaccess::TStatementType StatementType, const bool ModifiedFieldsOnly, const Dbaccess::TKeyAndDataFields &KeyAndDataFields, const int Index = 0xffffffff);
public:
	/* TCustomOraSQLGenerator.Create */ inline __fastcall virtual TSmartSQLGenerator(Dbaccess::TDADataSetService* Owner) : Ora::TOraSQLGenerator(Owner) { }
	
public:
	/* TDASQLGenerator.Destroy */ inline __fastcall virtual ~TSmartSQLGenerator(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline bool __fastcall  FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue){ return Dbaccess::TDASQLGenerator::FieldIsNull(FieldDesc, OldValue); }
	inline bool __fastcall  FieldModified(Craccess::TCRFieldDesc* FieldDesc){ return Ora::TOraSQLGenerator::FieldModified(FieldDesc); }
	
};


class DELPHICLASS TSmartDataSetUpdater;
class DELPHICLASS TSmartDataSetService;
class DELPHICLASS TCustomSmartQuery;
class PASCALIMPLEMENTATION TSmartDataSetUpdater : public Ora::TOraDataSetUpdater
{
	typedef Ora::TOraDataSetUpdater inherited;
	
protected:
	TSmartDataSetService* FDataSetService;
	TCustomSmartQuery* FDataSet;
	virtual bool __fastcall PerformAppend(void);
	virtual bool __fastcall PerformUpdate(void);
	virtual bool __fastcall PerformDelete(void);
	virtual void __fastcall PrepareUpdate(void);
	
public:
	__fastcall virtual TSmartDataSetUpdater(Memds::TDataSetService* AOwner);
public:
	/* TDADataSetUpdater.Destroy */ inline __fastcall virtual ~TSmartDataSetUpdater(void) { }
	
};


class PASCALIMPLEMENTATION TSmartDataSetService : public Ora::TOraDataSetService
{
	typedef Ora::TOraDataSetService inherited;
	
protected:
	TSmartSQLGenerator* FSQLGenerator;
	TSmartDataSetUpdater* FUpdater;
	TCustomSmartQuery* FDataSet;
	virtual void __fastcall CreateSQLGenerator(void);
	virtual void __fastcall SetSQLGenerator(Dbaccess::TDASQLGenerator* Value);
	virtual void __fastcall CreateDataSetUpdater(void);
	virtual void __fastcall SetDataSetUpdater(Memds::TDataSetUpdater* Value);
	virtual void __fastcall SetFieldsReadOnly(void);
	virtual void __fastcall FillDataFieldDescs(/* out */ Dbaccess::TFieldDescArray &DataFieldDescs, bool ForceUseAllKeyFields);
	void __fastcall PrepareExpandDataSet(bool Empty, System::UnicodeString &SQL);
	__property bool IsAnyFieldCanBeModified = {read=FIsAnyFieldCanBeModified, write=FIsAnyFieldCanBeModified, nodefault};
	
public:
	__fastcall virtual TSmartDataSetService(Memds::TMemDataSet* AOwner);
public:
	/* TDADataSetService.Destroy */ inline __fastcall virtual ~TSmartDataSetService(void) { }
	
};


class PASCALIMPLEMENTATION TCustomSmartQuery : public Ora::TCustomOraQuery
{
	typedef Ora::TCustomOraQuery inherited;
	
private:
	bool FExpand;
	Db::TDataSetNotifyEvent FRefreshFields;
	bool FExpanded;
	System::Word FExpandFlagOfs;
	TSmartState FSmartState;
	Memdata::TFieldDescs* FExpandedFields;
	int FExpandedFieldCount;
	bool FSmartRefresh;
	System::UnicodeString FRefreshEvent;
	Db::TDataSetNotifyEvent FAfterSmartRefresh;
	bool FNeedSmartRefresh;
	System::UnicodeString FDependEvents;
	void __fastcall SetExpand(bool Value);
	void __fastcall SetSmartRefresh(bool Value);
	void __fastcall SetDependEvents(const System::UnicodeString Value);
	bool __fastcall GetCachedUpdates(void);
	HIDESBASE void __fastcall SetCachedUpdates(const bool Value);
	bool __fastcall GetFullRefresh(void);
	void __fastcall SetFullRefresh(bool Value);
	
protected:
	Oraclasses::TOCIRecordSet* FRecordData;
	void *FExpandRecBuf;
	void *FOldExpandRecBuf;
	TSmartDataSetService* FDataSetService;
	virtual Memds::TDataSetServiceClass __fastcall GetDataSetServiceClass(void);
	virtual void __fastcall SetDataSetService(Memds::TDataSetService* Value);
	virtual Dbaccess::TDADataSetOptions* __fastcall CreateOptions(void);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall CreateFieldDefs(void);
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual void __fastcall SetUpdatingTable(const System::UnicodeString Value);
	virtual System::PByte __fastcall AllocRecordBuffer(void);
	bool __fastcall GetExpandFlag(System::PByte RecBuf);
	void __fastcall SetExpandFlag(System::PByte RecBuf, bool Value);
	void __fastcall AllocExpandRecBufs(void);
	void __fastcall FreeExpandRecBufs(void);
	virtual void __fastcall InitRecord(System::PByte Buffer);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalCancel(void);
	virtual bool __fastcall CanRefreshField(Db::TField* Field);
	virtual bool __fastcall GetCanModify(void);
	void __fastcall DoSmartRefresh(void);
	void __fastcall SmartChanged(void);
	virtual void __fastcall SetName(const Classes::TComponentName NewName);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	HIDESBASE TSmartQueryOptions* __fastcall GetOptions(void);
	HIDESBASE void __fastcall SetOptions(TSmartQueryOptions* Value);
	
public:
	__fastcall virtual TCustomSmartQuery(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomSmartQuery(void);
	virtual Memdata::TFieldDesc* __fastcall GetFieldDesc(const Db::TField* Field)/* overload */;
	virtual Memdata::TFieldDesc* __fastcall GetFieldDesc(const int FieldNo)/* overload */;
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual void __fastcall Post(void);
	virtual void __fastcall Cancel(void);
	void __fastcall View(void);
	HIDESBASE bool __fastcall FindKey(System::Variant const *KeyValues, const int KeyValues_Size);
	HIDESBASE void __fastcall FindNearest(System::Variant const *KeyValues, const int KeyValues_Size);
	virtual int __fastcall GetDataType(const System::UnicodeString FieldName);
	__property bool Expand = {read=FExpand, write=SetExpand, default=0};
	__property TSmartState SmartState = {read=FSmartState, nodefault};
	__property bool FullRefresh = {read=GetFullRefresh, write=SetFullRefresh, default=0};
	__property bool SmartRefresh = {read=FSmartRefresh, write=SetSmartRefresh, default=0};
	__property System::UnicodeString RefreshEvent = {read=FRefreshEvent, write=FRefreshEvent};
	__property Db::TDataSetNotifyEvent AfterSmartRefresh = {read=FAfterSmartRefresh, write=FAfterSmartRefresh};
	__property System::UnicodeString DependEvents = {read=FDependEvents, write=SetDependEvents};
	__property Db::TDataSetNotifyEvent RefreshFields = {read=FRefreshFields, write=FRefreshFields};
	__property bool CachedUpdates = {read=GetCachedUpdates, write=SetCachedUpdates, default=0};
	__property TSmartQueryOptions* Options = {read=GetOptions, write=SetOptions};
	
/* Hoisted overloads: */
	
protected:
	inline void __fastcall  SetFieldData(Db::TField* Field, void * Buffer, bool NativeFormat){ Memds::TMemDataSet::SetFieldData(Field, Buffer, NativeFormat); }
	
public:
	inline Memdata::TFieldDesc* __fastcall  GetFieldDesc(const System::UnicodeString FieldName){ return Dbaccess::TCustomDADataSet::GetFieldDesc(FieldName); }
	inline bool __fastcall  GetFieldData(int FieldNo, void * Buffer){ return Memds::TMemDataSet::GetFieldData(FieldNo, Buffer); }
	inline bool __fastcall  GetFieldData(Db::TField* Field, void * Buffer, bool NativeFormat){ return Memds::TMemDataSet::GetFieldData(Field, Buffer, NativeFormat); }
	
};


class DELPHICLASS TSmartQuery;
class PASCALIMPLEMENTATION TSmartQuery : public TCustomSmartQuery
{
	typedef TCustomSmartQuery inherited;
	
__published:
	__property UpdatingTable;
	__property CheckMode = {default=0};
	__property Expand = {default=0};
	__property KeyFields;
	__property FullRefresh = {default=0};
	__property DMLRefresh = {default=0};
	__property SmartRefresh = {default=0};
	__property AfterSmartRefresh;
	__property KeySequence;
	__property SequenceMode = {default=1};
	__property RefreshFields;
	__property SQLInsert;
	__property SQLDelete;
	__property SQLUpdate;
	__property SQLRefresh;
	__property SQLLock;
	__property Session;
	__property SQL;
	__property MasterFields;
	__property DetailFields;
	__property MasterSource;
	__property Debug = {default=0};
	__property Macros;
	__property Params;
	__property FetchRows = {default=25};
	__property FetchAll = {default=0};
	__property NonBlocking = {default=0};
	__property ReadOnly = {default=0};
	__property UniDirectional = {default=0};
	__property CachedUpdates = {default=0};
	__property AutoCommit = {default=1};
	__property FilterSQL;
	__property LockMode = {default=1};
	__property RefreshOptions = {default=0};
	__property Options;
	__property ChangeNotification;
	__property ReturnParams;
	__property LocalConstraints = {default=1};
	__property RefreshMode;
	__property OptionsDS;
	__property AfterExecute;
	__property BeforeUpdateExecute;
	__property AfterUpdateExecute;
	__property OnUpdateError;
	__property OnUpdateRecord;
	__property UpdateObject;
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property ObjectView = {default=0};
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeFetch;
	__property AfterFetch;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property AfterRefresh;
	__property BeforeRefresh;
	__property Fields;
public:
	/* TCustomSmartQuery.Create */ inline __fastcall virtual TSmartQuery(Classes::TComponent* Owner) : TCustomSmartQuery(Owner) { }
	/* TCustomSmartQuery.Destroy */ inline __fastcall virtual ~TSmartQuery(void) { }
	
};


class DELPHICLASS TOraTableOptions;
class PASCALIMPLEMENTATION TOraTableOptions : public TSmartQueryOptions
{
	typedef TSmartQueryOptions inherited;
	
public:
	__fastcall TOraTableOptions(Dbaccess::TCustomDADataSet* Owner);
	
__published:
	__property SetFieldsReadOnly = {default=0};
	__property ExtendedFieldsInfo = {default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOraTableOptions(void) { }
	
};


class DELPHICLASS TOraTable;
class PASCALIMPLEMENTATION TOraTable : public TCustomSmartQuery
{
	typedef TCustomSmartQuery inherited;
	
private:
	System::UnicodeString FTableName;
	System::UnicodeString FOrderFields;
	void __fastcall SetTableName(const System::UnicodeString Value);
	void __fastcall SetOrderFields(const System::UnicodeString Value);
	bool __fastcall GetReadOnly(void);
	
protected:
	virtual System::UnicodeString __fastcall PSGetTableName(void);
	virtual void __fastcall PSSetParams(Db::TParams* AParams);
	virtual void __fastcall PSSetCommandText(const System::UnicodeString CommandText)/* overload */;
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual Dbaccess::TDADataSetOptions* __fastcall CreateOptions(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	HIDESBASE TOraTableOptions* __fastcall GetOptions(void);
	HIDESBASE void __fastcall SetOptions(TOraTableOptions* Value);
	virtual void __fastcall SetKeyFields(const System::UnicodeString Value);
	virtual bool __fastcall SQLAutoGenerated(void);
	virtual void __fastcall SetReadOnly(bool Value);
	virtual void __fastcall SetFilterSQL(const System::UnicodeString Value);
	
public:
	void __fastcall PrepareSQL(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall Execute(void);
	void __fastcall EmptyTable(void);
	
__published:
	__property System::UnicodeString TableName = {read=FTableName, write=SetTableName};
	__property System::UnicodeString OrderFields = {read=FOrderFields, write=SetOrderFields};
	__property MasterFields;
	__property DetailFields;
	__property MasterSource;
	__property bool ReadOnly = {read=GetReadOnly, write=SetReadOnly, default=0};
	__property CheckMode = {default=0};
	__property KeyFields;
	__property KeySequence;
	__property SequenceMode = {default=1};
	__property DMLRefresh = {default=0};
	__property SmartRefresh = {default=0};
	__property AfterSmartRefresh;
	__property RefreshFields;
	__property Session;
	__property FilterSQL;
	__property Debug = {default=0};
	__property Params;
	__property FetchRows = {default=25};
	__property FetchAll = {default=0};
	__property NonBlocking = {default=0};
	__property UniDirectional = {default=0};
	__property CachedUpdates = {default=0};
	__property AutoCommit = {default=1};
	__property LockMode = {default=1};
	__property RefreshOptions = {default=0};
	__property ChangeNotification;
	__property LocalConstraints = {default=1};
	__property RefreshMode;
	__property OptionsDS;
	__property OnUpdateError;
	__property OnUpdateRecord;
	__property UpdateObject;
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property ObjectView = {default=0};
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property AfterRefresh;
	__property BeforeRefresh;
	__property Fields;
	__property TOraTableOptions* Options = {read=GetOptions, write=SetOptions};
public:
	/* TCustomSmartQuery.Create */ inline __fastcall virtual TOraTable(Classes::TComponent* Owner) : TCustomSmartQuery(Owner) { }
	/* TCustomSmartQuery.Destroy */ inline __fastcall virtual ~TOraTable(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline void __fastcall  PSSetCommandText [[deprecated]](const System::WideString CommandText){ Db::TDataSet::PSSetCommandText(CommandText); }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int RefreshInterval;

}	/* namespace Orasmart */
using namespace Orasmart;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OrasmartHPP
