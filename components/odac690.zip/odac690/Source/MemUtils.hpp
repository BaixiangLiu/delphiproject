// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Memutils.pas' rev: 21.00

#ifndef MemutilsHPP
#define MemutilsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Zlib.hpp>	// Pascal unit
#include <Zlibconst.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Memutils
{
//-- type declarations -------------------------------------------------------
typedef char * TValueArr;

typedef char * PAChar;

typedef System::WideChar * PWChar;

typedef Classes::TList TDAList;

typedef int __fastcall (*TCompressProc)(void * dest, void * destLen, const void * source, int sourceLen);

typedef int __fastcall (*TUncompressProc)(void * dest, void * destlen, void * source, int sourceLne);

typedef Zlib::EZCompressionError ECompressionError;

typedef Zlib::EZDecompressionError EDecompressionError;

typedef System::UnicodeString _string;

typedef System::WideChar _char;

typedef System::WideChar * _PChar;

typedef Classes::TStrings _TStrings;

typedef Classes::TStringList _TStringList;

typedef Clrclasses::WideStringBuilder _StringBuilder;

//-- var, const, procedure ---------------------------------------------------
static const ShortInt MIN_COMPRESS_LENGTH = 0x32;
extern PACKAGE TCompressProc CompressProc;
extern PACKAGE TUncompressProc UncompressProc;
extern PACKAGE bool IsWin9x;
extern PACKAGE bool __fastcall CompareGuid(const GUID &g1, const GUID &g2);
extern PACKAGE System::TDateTime __fastcall TimeStampToDateTime(const Sysutils::TTimeStamp &ATimeStamp);
extern PACKAGE bool __fastcall VarEqual(const System::Variant &Value1, const System::Variant &Value2);
extern PACKAGE void __fastcall CopyBuffer(void * Source, void * Dest, unsigned Count);
extern PACKAGE void __fastcall CopyBufferAnsi(const System::AnsiString Source, void * Dest, unsigned Count);
extern PACKAGE void __fastcall CopyBufferUni(const System::WideString Source, void * Dest, unsigned Count);
extern PACKAGE void __fastcall FillChar(void * X, int Count, System::Byte Value);
extern PACKAGE void __fastcall ArrayCopy(Sysutils::TBytes sourceArray, int sourceIndex, Sysutils::TBytes destinationArray, int destinationIndex, int length);
extern PACKAGE void * __fastcall AllocGCHandle(void * Obj, bool Pinned = false);
extern PACKAGE System::TObject* __fastcall GetGCHandleTarget(void * Handle);
extern PACKAGE void * __fastcall GetAddrOfPinnedObject(void * Handle);
extern PACKAGE void __fastcall FreeGCHandle(void * Handle);
extern PACKAGE void __fastcall FreeString(void * P);
extern PACKAGE void * __fastcall AllocOrdinal(System::ShortInt &Obj)/* overload */;
extern PACKAGE void * __fastcall AllocOrdinal(System::Byte &Obj)/* overload */;
extern PACKAGE void * __fastcall AllocOrdinal(System::Word &Obj)/* overload */;
extern PACKAGE void * __fastcall AllocOrdinal(int &Obj)/* overload */;
extern PACKAGE void * __fastcall AllocOrdinal(unsigned &Obj)/* overload */;
extern PACKAGE void * __fastcall AllocOrdinal(void * &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(double &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(System::Byte &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(short &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(int &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(__int64 &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(unsigned &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(System::Word &Obj)/* overload */;
extern PACKAGE void * __fastcall OrdinalToPtr(void * &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, System::ShortInt &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, System::Byte &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, short &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, System::Word &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, int &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, __int64 &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, double &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, unsigned &Obj)/* overload */;
extern PACKAGE void __fastcall PtrToOrdinal(void * P, void * &Obj)/* overload */;
extern PACKAGE void __fastcall FreeOrdinal(void * P);
extern PACKAGE void * __fastcall StrCopyW(System::WideChar * Dest, const System::WideChar * Source);
extern PACKAGE void __fastcall StrLCopyW(System::WideChar * Dest, const System::WideChar * Source, unsigned MaxLen);
extern PACKAGE unsigned __fastcall StrLenW(const System::WideChar * Str);
extern PACKAGE void __fastcall StrTrim(const char * Str, int Len = 0xffffffff);
extern PACKAGE void __fastcall StrTrimW(const System::WideChar * Str, int Len = 0xffffffff);
extern PACKAGE int __fastcall AnsiStrLCompWS(const System::WideString S1, const System::WideString S2, unsigned MaxLen);
extern PACKAGE int __fastcall AnsiStrLICompWS(const System::WideString S1, const System::WideString S2, unsigned MaxLen);
extern PACKAGE int __fastcall AnsiStrCompWS(const System::WideString S1, const System::WideString S2);
extern PACKAGE int __fastcall AnsiStrICompWS(const System::WideString S1, const System::WideString S2);
extern PACKAGE bool __fastcall IsClass(System::TObject* Obj, System::TClass AClass);
extern PACKAGE int __fastcall AnsiStrCompS(char * S1, char * S2);
extern PACKAGE int __fastcall AnsiStrICompS(char * S1, char * S2);
extern PACKAGE int __fastcall AnsiCompareTextS(const System::AnsiString S1, const System::AnsiString S2);
extern PACKAGE int __fastcall AnsiCompareStrS(const System::AnsiString S1, const System::AnsiString S2);
extern PACKAGE void __fastcall OleVarClear(System::POleVariant pValue);
extern PACKAGE System::OleVariant __fastcall GetOleVariant(System::POleVariant pValue);
extern PACKAGE void __fastcall SetOleVariant(System::POleVariant pValue, const System::OleVariant &Value);
extern PACKAGE bool __fastcall TryEncodeDate(System::Word Year, System::Word Month, System::Word Day, System::TDateTime &Date);
extern PACKAGE bool __fastcall TryEncodeTime(System::Word Hour, System::Word Min, System::Word Sec, System::Word MSec, System::TDateTime &Time);
extern PACKAGE bool __fastcall TryEncodeDateTime(const System::Word AYear, const System::Word AMonth, const System::Word ADay, const System::Word AHour, const System::Word AMinute, const System::Word ASecond, const System::Word AMilliSecond, /* out */ System::TDateTime &AValue);
extern PACKAGE System::TDateTime __fastcall EncodeDateTime(const System::Word AYear, const System::Word AMonth, const System::Word ADay, const System::Word AHour, const System::Word AMinute, const System::Word ASecond, const System::Word AMilliSecond);
extern PACKAGE unsigned __fastcall Reverse4(unsigned Value);
extern PACKAGE void __fastcall Reverse8(void * pValue);
extern PACKAGE void __fastcall CheckZLib(void);
extern PACKAGE void __fastcall DoCompress(void * dest, void * destLen, const void * source, int sourceLen);
extern PACKAGE void __fastcall DoUncompress(void * dest, void * destlen, void * source, int sourceLne);
extern PACKAGE System::UnicodeString __fastcall _LowerCase(const System::UnicodeString S);
extern PACKAGE System::UnicodeString __fastcall _UpperCase(const System::UnicodeString S);
extern PACKAGE int __fastcall _CompareText(const System::UnicodeString S1, const System::UnicodeString S2);
extern PACKAGE bool __fastcall _SameText(const System::UnicodeString S1, const System::UnicodeString S2);
extern PACKAGE System::UnicodeString __fastcall _QuotedStr(const System::UnicodeString S, System::WideChar AQuote);
extern PACKAGE System::UnicodeString __fastcall _DequotedStr(const System::UnicodeString S, System::WideChar AQuote);
extern PACKAGE System::UnicodeString __fastcall _VarToStr(const System::Variant &V);
extern PACKAGE System::UnicodeString __fastcall _Format(const System::UnicodeString AFormat, System::TVarRec const *Args, const int Args_Size);
extern PACKAGE void __fastcall AssignStrings(Classes::TStrings* Source, Classes::TStrings* Dest)/* overload */;

}	/* namespace Memutils */
using namespace Memutils;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MemutilsHPP
