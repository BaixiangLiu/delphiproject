// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dascript.pas' rev: 21.00

#ifndef DascriptHPP
#define DascriptHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dascript
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDAStatement;
class DELPHICLASS TDAScript;
class PASCALIMPLEMENTATION TDAStatement : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
protected:
	bool FOmit;
	int FStatementType;
	int FStartPos;
	int FEndPos;
	int FStartLine;
	int FEndLine;
	int FStartOffset;
	int FEndOffset;
	Dbaccess::TDAParams* FParams;
	System::UnicodeString __fastcall GetSQL(void);
	TDAScript* __fastcall GetScript(void);
	Dbaccess::TDAParams* __fastcall GetParams(void);
	Dbaccess::TDAParams* __fastcall CreateParams(void);
	
public:
	__fastcall virtual ~TDAStatement(void);
	__property TDAScript* Script = {read=GetScript};
	__property System::UnicodeString SQL = {read=GetSQL};
	__property bool Omit = {read=FOmit, write=FOmit, nodefault};
	__property int StartPos = {read=FStartPos, nodefault};
	__property int EndPos = {read=FEndPos, nodefault};
	__property int StartLine = {read=FStartLine, nodefault};
	__property int EndLine = {read=FEndLine, nodefault};
	__property int StartOffset = {read=FStartOffset, nodefault};
	__property int EndOffset = {read=FEndOffset, nodefault};
	__property Dbaccess::TDAParams* Params = {read=GetParams};
	void __fastcall Execute(void);
public:
	/* TCollectionItem.Create */ inline __fastcall virtual TDAStatement(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	
};


typedef TMetaClass* TDAStatementClass;

class DELPHICLASS TDAStatements;
class PASCALIMPLEMENTATION TDAStatements : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
public:
	TDAStatement* operator[](int Index) { return Items[Index]; }
	
protected:
	TDAScript* FScript;
	HIDESBASE TDAStatement* __fastcall GetItem(int Index);
	TDAStatement* __fastcall CreateStatement(int StatementType, bool Omit, int StartPos, int EndPos, int StartLine, int EndLine, int StartOffset, int EndOffset);
	
public:
	__fastcall TDAStatements(Classes::TCollectionItemClass ItemClass, TDAScript* Script);
	__property TDAStatement* Items[int Index] = {read=GetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TDAStatements(void) { }
	
};


typedef TMetaClass* TDAStatementsClass;

#pragma option push -b-
enum TDelimiterState { dsNone, dsDelimiter, dsBlank, dsValue, dsSet };
#pragma option pop

class DELPHICLASS TDAScriptProcessor;
class PASCALIMPLEMENTATION TDAScriptProcessor : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TDAScript* FOwner;
	Crparser::TSQLParser* FParser;
	Crparser::TSQLParser* FSQLParser;
	System::UnicodeString FCurrDelimiter;
	TDelimiterState FDelimiterState;
	System::UnicodeString FSt;
	int FCurrentStatementIdx;
	bool FStatementsPopulating;
	Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	Dbaccess::TCustomDASQL* __fastcall GetCommand(void);
	virtual Crparser::TSQLParserClass __fastcall GetParserClass(void);
	Crparser::TSQLParser* __fastcall CreateParser(const System::UnicodeString Text)/* overload */;
	Crparser::TSQLParser* __fastcall CreateParser(Classes::TStream* Stream)/* overload */;
	Crparser::TSQLParser* __fastcall GetSQLParser(const System::UnicodeString Text);
	virtual bool __fastcall ExecuteNext(void);
	virtual void __fastcall ExecuteStatement(const System::UnicodeString SQL, int StatementType, bool &Omit, /* out */ bool &BreakExec, Dbaccess::TDAParams* Params = (Dbaccess::TDAParams*)(0x0));
	virtual void __fastcall CreateStatement(int StatementType, bool Omit, int StartPos, int EndPos, int StartLine, int EndLine, int StartOffset, int EndOffset);
	virtual void __fastcall BreakExec(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall CheckLexem(int Code, int &StatementType, bool &Omit);
	virtual bool __fastcall GetReady(int Code);
	virtual bool __fastcall IsSpecificSQL(int StatementType);
	virtual bool __fastcall CanOptimize(const System::UnicodeString SQL, const int StatementType);
	virtual bool __fastcall IsBlankEndsDelimeter(void);
	virtual void __fastcall DoBeforeStatementExecute(System::UnicodeString &SQL, int StatementType, bool &Omit);
	virtual void __fastcall DoAfterStatementExecute(System::UnicodeString &SQL, int StatementType);
	
public:
	__fastcall virtual TDAScriptProcessor(TDAScript* Owner);
	__fastcall virtual ~TDAScriptProcessor(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
};


typedef TMetaClass* TDAScriptProcessorClass;

typedef void __fastcall (__closure *TBeforeStatementExecuteEvent)(System::TObject* Sender, System::UnicodeString &SQL, bool &Omit);

typedef void __fastcall (__closure *TAfterStatementExecuteEvent)(System::TObject* Sender, System::UnicodeString SQL);

#pragma option push -b-
enum TErrorAction { eaAbort, eaFail, eaException, eaContinue };
#pragma option pop

typedef void __fastcall (__closure *TOnErrorEvent)(System::TObject* Sender, Sysutils::Exception* E, System::UnicodeString SQL, TErrorAction &Action);

class PASCALIMPLEMENTATION TDAScript : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	TDAScriptProcessor* FProcessor;
	Classes::TStrings* FSQL;
	bool FSQLActual;
	Classes::TStream* FStream;
	Dbaccess::TCustomDASQL* FCommand;
	Dbaccess::TMacros* FMacros;
	__int64 FErrorOffset;
	__int64 FStartPos;
	__int64 FEndPos;
	__int64 FStartLine;
	__int64 FEndLine;
	__int64 FStartOffset;
	__int64 FEndOffset;
	Db::TDataSource* FDataSource;
	TBeforeStatementExecuteEvent FBeforeExecute;
	TAfterStatementExecuteEvent FAfterExecute;
	TOnErrorEvent FOnError;
	__int64 FStmtOffset;
	bool FDesignCreate;
	System::UnicodeString FDelimiter;
	TDAStatements* FStatements;
	bool FUseOptimization;
	bool FAllowOptimization;
	Clrclasses::WideStringBuilder* FBuffer;
	bool FAutoCommit;
	bool FBreakExecution;
	Syncobjs::TCriticalSection* FcsBreakMultiThread;
	bool FNoPreconnect;
	Dbaccess::TCustomDAConnection* __fastcall GetConnection(void);
	void __fastcall SetConnection(Dbaccess::TCustomDAConnection* Value);
	Dbaccess::TDATransaction* __fastcall GetTransaction(void);
	void __fastcall SetTransaction(Dbaccess::TDATransaction* Value);
	bool __fastcall IsTransactionStored(void);
	virtual TDAScriptProcessorClass __fastcall GetProcessorClass(void);
	virtual void __fastcall SetProcessor(TDAScriptProcessor* Value);
	void __fastcall CreateProcessor(void);
	void __fastcall FreeProcessor(void);
	void __fastcall CheckProcessor(void);
	virtual Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	Dbaccess::TDATransaction* __fastcall UsedTransaction(void);
	System::UnicodeString __fastcall GetSQLText(int StartLine, int EndLine, int StartOffset, int EndOffset, int Length);
	void __fastcall SetSQL(Classes::TStrings* Value);
	void __fastcall SQLChanged(System::TObject* Sender);
	bool __fastcall GetDebug(void);
	void __fastcall SetDebug(bool Value);
	void __fastcall SetMacros(Dbaccess::TMacros* Value);
	Dbaccess::TCustomDADataSet* __fastcall GetDataSet(void);
	void __fastcall SetDataSet(Dbaccess::TCustomDADataSet* Value);
	Dbaccess::TDAParams* __fastcall GetParams(void);
	void __fastcall SetAutoCommit(bool Value);
	void __fastcall SetDelimiter(const System::UnicodeString Value);
	bool __fastcall IsDelimiterStored(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadMacroData(Classes::TReader* Reader);
	void __fastcall WriteMacroData(Classes::TWriter* Writer);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual Dbaccess::TCustomDASQL* __fastcall CreateCommand(void);
	virtual void __fastcall CalculateErrorOffset(Sysutils::Exception* E);
	virtual TDAStatements* __fastcall CreateStatementsObject(void);
	TDAStatements* __fastcall GetStatements(void);
	void __fastcall Open(Classes::TStream* Stream);
	void __fastcall Close(void);
	void __fastcall InternalExecute(const System::UnicodeString SQL, /* out */ bool &BreakExec, Dbaccess::TDAParams* Params = (Dbaccess::TDAParams*)(0x0));
	void __fastcall Flush(/* out */ bool &BreakExec);
	__property Dbaccess::TDATransaction* Transaction = {read=GetTransaction, write=SetTransaction, stored=IsTransactionStored};
	
public:
	__fastcall virtual TDAScript(Classes::TComponent* Owner);
	__fastcall virtual ~TDAScript(void);
	virtual void __fastcall Execute(void);
	void __fastcall ExecuteStream(Classes::TStream* Stream);
	void __fastcall ExecuteFile(const System::UnicodeString FileName);
	virtual bool __fastcall ExecuteNext(void);
	virtual void __fastcall BreakExec(void);
	Dbaccess::TMacro* __fastcall FindMacro(System::UnicodeString Name);
	Dbaccess::TMacro* __fastcall MacroByName(System::UnicodeString Name);
	__int64 __fastcall ErrorOffset(void);
	__property Dbaccess::TDAParams* Params = {read=GetParams};
	__property bool UseOptimization = {read=FUseOptimization, write=FUseOptimization, default=0};
	__property bool AutoCommit = {read=FAutoCommit, write=SetAutoCommit, default=0};
	__property Dbaccess::TCustomDAConnection* Connection = {read=GetConnection, write=SetConnection};
	__property Dbaccess::TCustomDADataSet* DataSet = {read=GetDataSet, write=SetDataSet};
	__property __int64 StartPos = {read=FStartPos};
	__property __int64 EndPos = {read=FEndPos};
	__property __int64 StartLine = {read=FStartLine};
	__property __int64 EndLine = {read=FEndLine};
	__property __int64 StartOffset = {read=FStartOffset};
	__property __int64 EndOffset = {read=FEndOffset};
	__property TDAStatements* Statements = {read=GetStatements};
	
__published:
	__property Classes::TStrings* SQL = {read=FSQL, write=SetSQL};
	__property bool Debug = {read=GetDebug, write=SetDebug, default=0};
	__property System::UnicodeString Delimiter = {read=FDelimiter, write=FDelimiter, stored=IsDelimiterStored};
	__property Dbaccess::TMacros* Macros = {read=FMacros, write=SetMacros, stored=false};
	__property bool NoPreconnect = {read=FNoPreconnect, write=FNoPreconnect, default=0};
	__property TBeforeStatementExecuteEvent BeforeExecute = {read=FBeforeExecute, write=FBeforeExecute};
	__property TAfterStatementExecuteEvent AfterExecute = {read=FAfterExecute, write=FAfterExecute};
	__property TOnErrorEvent OnError = {read=FOnError, write=FOnError};
};


class DELPHICLASS TDAScriptUtils;
class PASCALIMPLEMENTATION TDAScriptUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TDAScript* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TDAScript* Obj);
	__classmethod void __fastcall SetCommand(TDAScript* Obj, Dbaccess::TCustomDASQL* Command);
	__classmethod Dbaccess::TCustomDASQL* __fastcall GetCommand(TDAScript* Obj);
	__classmethod void __fastcall Open(TDAScript* Obj, Classes::TStream* Stream);
	__classmethod void __fastcall Close(TDAScript* Obj);
	__classmethod Dbaccess::TCustomDAConnection* __fastcall UsedConnection(TDAScript* Obj);
	__classmethod Dbaccess::TDATransaction* __fastcall UsedTransaction(TDAScript* Obj);
	__classmethod Dbaccess::TDATransaction* __fastcall GetTransaction(TDAScript* Obj);
	__classmethod void __fastcall SetTransaction(TDAScript* Obj, Dbaccess::TDATransaction* Value);
public:
	/* TObject.Create */ inline __fastcall TDAScriptUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TDAScriptUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt ST_UNKNOWN = 0x0;
static const ShortInt ST_DELIMETER = 0x1;
static const ShortInt ST_COMMENT = 0x2;
static const Word ST_SPECIFIC_SQL = 0x8000;

}	/* namespace Dascript */
using namespace Dascript;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DascriptHPP
