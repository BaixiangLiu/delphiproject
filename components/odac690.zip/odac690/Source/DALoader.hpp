// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Daloader.pas' rev: 21.00

#ifndef DaloaderHPP
#define DaloaderHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Daloader
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TDAColumnDataType { ctString, ctDate, ctInteger, ctUInteger, ctFloat };
#pragma option pop

typedef TMetaClass* TDAColumnClass;

class DELPHICLASS TDAColumn;
class PASCALIMPLEMENTATION TDAColumn : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	System::UnicodeString FName;
	Db::TFieldType FFieldType;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual TDAColumnDataType __fastcall GetDataType(void);
	virtual void __fastcall SetDataType(TDAColumnDataType Value);
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	virtual System::UnicodeString __fastcall GetDisplayName(void);
	__property TDAColumnDataType DataType = {read=GetDataType, write=SetDataType, nodefault};
	
public:
	__fastcall virtual TDAColumn(Classes::TCollection* Collection);
	
__published:
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property Db::TFieldType FieldType = {read=FFieldType, write=SetFieldType, default=1};
public:
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TDAColumn(void) { }
	
};


class DELPHICLASS TDAColumns;
class PASCALIMPLEMENTATION TDAColumns : public Classes::TOwnedCollection
{
	typedef Classes::TOwnedCollection inherited;
	
public:
	TDAColumn* operator[](int Index) { return Items[Index]; }
	
private:
	TDAColumn* __fastcall GetColumn(int Index);
	void __fastcall SetColumn(int Index, TDAColumn* Value);
	
public:
	__property TDAColumn* Items[int Index] = {read=GetColumn, write=SetColumn/*, default*/};
public:
	/* TOwnedCollection.Create */ inline __fastcall TDAColumns(Classes::TPersistent* AOwner, Classes::TCollectionItemClass ItemClass) : Classes::TOwnedCollection(AOwner, ItemClass) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TDAColumns(void) { }
	
};


class DELPHICLASS TDALoader;
typedef void __fastcall (__closure *TDAPutDataEvent)(TDALoader* Sender);

typedef void __fastcall (__closure *TGetColumnDataEvent)(System::TObject* Sender, TDAColumn* Column, int Row, System::Variant &Value, bool &IsEOF);

typedef void __fastcall (__closure *TLoaderProgressEvent)(System::TObject* Sender, int Percent);

class PASCALIMPLEMENTATION TDALoader : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	System::UnicodeString FTableName;
	TDAPutDataEvent FOnPutData;
	TGetColumnDataEvent FOnGetColumnData;
	void __fastcall SetConnection(Dbaccess::TCustomDAConnection* Value);
	void __fastcall SetColumns(TDAColumns* Value);
	bool __fastcall IsColumnsStored(void);
	void __fastcall CreateColumnsByFields(Db::TFields* Fields);
	
protected:
	Craccess::TCRLoader* FILoader;
	TDAColumns* FColumns;
	Dbaccess::TCustomDAConnection* FConnection;
	Dbaccess::TDATransaction* FTransaction;
	bool FAutoCommit;
	bool FDesignCreate;
	TLoaderProgressEvent FOnLoaderProgress;
	virtual Craccess::TCRLoaderClass __fastcall GetInternalLoaderClass(void);
	virtual void __fastcall SetInternalLoader(Craccess::TCRLoader* Value);
	void __fastcall CreateInternalLoader(void);
	void __fastcall FreeInternalLoader(void);
	void __fastcall CheckInternalLoader(void);
	void __fastcall DoLoaderProgress(int Percent);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall Notification(Classes::TComponent* Component, Classes::TOperation Operation);
	virtual void __fastcall BeginConnection(void);
	virtual void __fastcall EndConnection(void);
	void __fastcall CommitData(void);
	virtual void __fastcall InternalPutData(void);
	virtual void __fastcall PutData(void);
	virtual void __fastcall SetTableName(const System::UnicodeString Value);
	__classmethod virtual TDAColumnClass __fastcall GetColumnClass();
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMapClass(void);
	bool __fastcall IsTransactionStored(void);
	virtual Dbaccess::TDATransaction* __fastcall GetTransaction(void);
	virtual void __fastcall SetTransaction(Dbaccess::TDATransaction* Value);
	virtual Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	virtual Dbaccess::TDATransaction* __fastcall UsedTransaction(void);
	virtual void __fastcall ReadColumn(TDAColumn* Column, Craccess::TCRLoaderColumn* CRColumn);
	virtual void __fastcall WriteColumn(TDAColumn* Column, Craccess::TCRLoaderColumn* CRColumn);
	void __fastcall ReadColumns(void);
	void __fastcall WriteColumns(void);
	__property Dbaccess::TDATransaction* Transaction = {read=GetTransaction, write=SetTransaction, stored=IsTransactionStored};
	__property bool AutoCommit = {read=FAutoCommit, write=FAutoCommit, default=1};
	
public:
	__fastcall virtual TDALoader(Classes::TComponent* Owner);
	__fastcall virtual ~TDALoader(void);
	virtual void __fastcall PutColumnData(int Col, int Row, const System::Variant &Value)/* overload */;
	void __fastcall PutColumnData(const System::UnicodeString ColName, int Row, const System::Variant &Value)/* overload */;
	virtual void __fastcall Load(void);
	void __fastcall CreateColumns(void);
	void __fastcall LoadFromDataSet(Db::TDataSet* DataSet);
	__property Dbaccess::TCustomDAConnection* Connection = {read=FConnection, write=SetConnection};
	__property System::UnicodeString TableName = {read=FTableName, write=SetTableName};
	__property TDAColumns* Columns = {read=FColumns, write=SetColumns, stored=IsColumnsStored};
	__property TDAPutDataEvent OnPutData = {read=FOnPutData, write=FOnPutData};
	__property TGetColumnDataEvent OnGetColumnData = {read=FOnGetColumnData, write=FOnGetColumnData};
	__property TLoaderProgressEvent OnProgress = {read=FOnLoaderProgress, write=FOnLoaderProgress};
};


class DELPHICLASS TDALoaderUtils;
class PASCALIMPLEMENTATION TDALoaderUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TDALoader* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TDALoader* Obj);
	__classmethod Dbaccess::TCustomDAConnection* __fastcall UsedConnection(TDALoader* Obj);
	__classmethod Dbaccess::TDATransaction* __fastcall GetTransaction(TDALoader* Obj);
	__classmethod void __fastcall SetTransaction(TDALoader* Obj, Dbaccess::TDATransaction* Value);
	__classmethod Dbaccess::TDATransaction* __fastcall GetFTransaction(TDALoader* Obj);
public:
	/* TObject.Create */ inline __fastcall TDALoaderUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TDALoaderUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Daloader */
using namespace Daloader;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DaloaderHPP
