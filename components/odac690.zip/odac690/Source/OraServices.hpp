// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraservices.pas' rev: 21.00

#ifndef OraservicesHPP
#define OraservicesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Crxml.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Dadump.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraservices
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum _TSequenceMode { _smInsert, _smPost };
#pragma option pop

class DELPHICLASS TCustomOraDataTypesMap;
class PASCALIMPLEMENTATION TCustomOraDataTypesMap : public Memds::TDataTypesMap
{
	typedef Memds::TDataTypesMap inherited;
	
public:
	__classmethod virtual int __fastcall GetDataType(Db::TFieldType FieldType);
	__classmethod virtual Db::TFieldType __fastcall GetFieldType(System::Word DataType);
public:
	/* TObject.Create */ inline __fastcall TCustomOraDataTypesMap(void) : Memds::TDataTypesMap() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCustomOraDataTypesMap(void) { }
	
};


class DELPHICLASS TCustomOraSQLGenerator;
class DELPHICLASS TCustomOraDataSetService;
class PASCALIMPLEMENTATION TCustomOraSQLGenerator : public Dbaccess::TDASQLGenerator
{
	typedef Dbaccess::TDASQLGenerator inherited;
	
protected:
	TCustomOraDataSetService* FDataSetService;
	bool FSeqReturning;
	Craccess::TCRFieldDesc* FSeqFieldDesc;
	Clrclasses::WideStringBuilder* FReturnSB;
	Clrclasses::WideStringBuilder* FIntoSB;
	virtual bool __fastcall IsBlobDataType(System::Word DataType);
	virtual bool __fastcall IsObjectDataType(System::Word DataType);
	virtual bool __fastcall FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf)/* overload */;
	virtual System::UnicodeString __fastcall GenerateIndexName(System::UnicodeString Name);
	virtual int __fastcall MaxIdentLength(void);
	virtual bool __fastcall IsSubstituteParamName(void);
	virtual void __fastcall AddParam(Clrclasses::WideStringBuilder* SB, Memdata::TFieldDesc* FieldDesc, const Dbaccess::TStatementType StatementType, const Db::TParamType ParamType, int Index = 0xffffffff, bool Old = false)/* overload */;
	virtual void __fastcall AddFieldToInsertSQL(Craccess::TCRFieldDesc* FieldDesc, const int Index = 0xffffffff);
	virtual void __fastcall AddFieldToUpdateSQL(Craccess::TCRFieldDesc* FieldDesc, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateInsertSQL(const Dbaccess::TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateUpdateSQL(const Dbaccess::TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateRefreshSQL(const Dbaccess::TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly);
	virtual void __fastcall GenerateLockSQL(const Dbaccess::TKeyAndDataFields &KeyAndDataFields, const int Index = 0xffffffff);
	
public:
	__fastcall virtual TCustomOraSQLGenerator(Dbaccess::TDADataSetService* Owner);
	virtual System::UnicodeString __fastcall GenerateSQL(const Dbaccess::TStatementType StatementType, const bool ModifiedFieldsOnly, Dbaccess::TDAParams* Params, const int Index = 0xffffffff);
	virtual System::UnicodeString __fastcall GenerateTableSQL(const System::UnicodeString TableName, const System::UnicodeString OrderFields);
	virtual System::UnicodeString __fastcall GenerateSelectValues(const System::UnicodeString ValuesList);
public:
	/* TDASQLGenerator.Destroy */ inline __fastcall virtual ~TCustomOraSQLGenerator(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline bool __fastcall  FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue){ return Dbaccess::TDASQLGenerator::FieldIsNull(FieldDesc, OldValue); }
	inline void __fastcall  AddParam(Clrclasses::WideStringBuilder* SB, Memdata::TFieldDesc* FieldDesc, const Dbaccess::TStatementType StatementType, int Index = 0xffffffff, bool Old = false){ Dbaccess::TDASQLGenerator::AddParam(SB, FieldDesc, StatementType, Index, Old); }
	
};


class DELPHICLASS TCustomOraDataSetUpdater;
class PASCALIMPLEMENTATION TCustomOraDataSetUpdater : public Dbaccess::TDADataSetUpdater
{
	typedef Dbaccess::TDADataSetUpdater inherited;
	
protected:
	TCustomOraDataSetService* FDataSetService;
	void __fastcall GetSequenceNextVal(void);
	virtual bool __fastcall GetIdentityFieldValue(System::Variant &Value);
	virtual bool __fastcall IsNeedInsertPreconnect(void);
	virtual bool __fastcall IsNeedEditPreconnect(void);
	virtual bool __fastcall IsPreconnected(void);
	virtual System::UnicodeString __fastcall PrepareBatch(System::UnicodeString SQL);
	virtual void __fastcall CheckUpdateQuery(const Dbaccess::TStatementType StatementType);
	virtual void __fastcall SetUpdateQueryOptions(const Dbaccess::TStatementType StatementType);
	virtual void __fastcall UpdateExecute(const Dbaccess::TStatementTypes StatementTypes);
	virtual void __fastcall PrepareAppend(void);
	virtual bool __fastcall PerformAppend(void);
	__property Classes::TComponent* UpdateQuery = {read=FUpdateQuery};
	
public:
	__fastcall virtual TCustomOraDataSetUpdater(Memds::TDataSetService* AOwner);
	virtual bool __fastcall PerformSQL(const System::UnicodeString SQL, const Dbaccess::TStatementTypes StatementTypes);
	virtual bool __fastcall GetDefaultExpressionValue(System::UnicodeString DefExpr, System::Variant &Value);
public:
	/* TDADataSetUpdater.Destroy */ inline __fastcall virtual ~TCustomOraDataSetUpdater(void) { }
	
};


class PASCALIMPLEMENTATION TCustomOraDataSetService : public Dbaccess::TDADataSetService
{
	typedef Dbaccess::TDADataSetService inherited;
	
protected:
	TCustomOraDataSetUpdater* FUpdater;
	System::UnicodeString FKeySequence;
	_TSequenceMode FSequenceMode;
	bool FScrollableCursor;
	bool __fastcall GetTemporaryLobUpdate(void);
	virtual void __fastcall CreateDataSetUpdater(void);
	virtual void __fastcall SetDataSetUpdater(Memds::TDataSetUpdater* Value);
	virtual void __fastcall CreateSQLGenerator(void);
	virtual Craccess::TCRFieldDesc* __fastcall DetectIdentityField(void);
	virtual Db::TField* __fastcall DetectKeyGeneratorField(void);
	virtual Dbaccess::TFieldArray __fastcall DetectHiddenFields(void);
	virtual bool __fastcall DetectCanModify(void);
	virtual bool __fastcall ExtFieldsInfoIsInternal(void);
	virtual void __fastcall RequestFieldsInfo(Craccess::TExtTablesInfo Tables, Craccess::TColumnsInfo* Columns);
	virtual int __fastcall GetRecCount(void);
	HIDESBASE Craccess::TCRCommand* __fastcall GetICommand(void);
	HIDESBASE void __fastcall CheckIRecordSet(void);
	HIDESBASE Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	HIDESBASE bool __fastcall IsFullRefresh(void);
	HIDESBASE bool __fastcall IsDMLRefresh(void);
	HIDESBASE bool __fastcall IsInCacheProcessing(void);
	HIDESBASE System::UnicodeString __fastcall GetKeyFields(void);
	HIDESBASE bool __fastcall IsAutoCommit(void);
	virtual bool __fastcall CompatibilityMode(void);
	virtual Db::TFieldClass __fastcall GetFieldClass(Db::TFieldType FieldType);
	virtual bool __fastcall PreventPSKeyFields(System::UnicodeString &PSKeyFields);
	virtual System::UnicodeString __fastcall GetCurrentSchema(void);
	virtual void __fastcall WriteFieldXMLDataType(Db::TField* Field, Memdata::TFieldDesc* FieldDesc, const System::UnicodeString FieldAlias, Crxml::XmlTextWriter* XMLWriter);
	virtual System::WideString __fastcall GetFieldXMLValue(Db::TField* Field, Memdata::TFieldDesc* FieldDesc);
	__property Db::TField* KeyGeneratorField = {read=FKeyGeneratorField};
	
public:
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall OpenNext(void);
	virtual bool __fastcall NeedParamValuesOnPrepare(void);
public:
	/* TDADataSetService.Create */ inline __fastcall virtual TCustomOraDataSetService(Memds::TMemDataSet* AOwner) : Dbaccess::TDADataSetService(AOwner) { }
	/* TDADataSetService.Destroy */ inline __fastcall virtual ~TCustomOraDataSetService(void) { }
	
};


class DELPHICLASS TOraServerEnumerator;
class PASCALIMPLEMENTATION TOraServerEnumerator : public Dbaccess::TCRServerEnumerator
{
	typedef Dbaccess::TCRServerEnumerator inherited;
	
private:
	bool FDirect;
	System::UnicodeString FHomeName;
	System::UnicodeString FTNSPath;
	
public:
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	System::UnicodeString __fastcall GetTNSFileName(void);
	virtual void __fastcall GetServerList(Classes::TStrings* List);
public:
	/* TCRServerEnumerator.Create */ inline __fastcall virtual TOraServerEnumerator(void) : Dbaccess::TCRServerEnumerator() { }
	
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TOraServerEnumerator(void) { }
	
};


class DELPHICLASS TCustomOraDumpProcessor;
class PASCALIMPLEMENTATION TCustomOraDumpProcessor : public Dadump::TDADumpProcessor
{
	typedef Dadump::TDADumpProcessor inherited;
	
public:
	/* TDADumpProcessor.Create */ inline __fastcall virtual TCustomOraDumpProcessor(Dadump::TDADump* Owner) : Dadump::TDADumpProcessor(Owner) { }
	/* TDADumpProcessor.Destroy */ inline __fastcall virtual ~TCustomOraDumpProcessor(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt prKeySequence = 0x65;
static const ShortInt prSequenceMode = 0x66;
static const ShortInt prTNSPath = 0x68;

}	/* namespace Oraservices */
using namespace Oraservices;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraservicesHPP
