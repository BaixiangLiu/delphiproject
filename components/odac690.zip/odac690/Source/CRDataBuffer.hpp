// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crdatabuffer.pas' rev: 21.00

#ifndef CrdatabufferHPP
#define CrdatabufferHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crdatabuffer
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDataBuffer;
class PASCALIMPLEMENTATION TDataBuffer : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FReceiveBuffer;
	void *FReadBuffer;
	void *FWriteBuffer;
	int FReadPos;
	int FWritePos;
	int FChunkSize;
	int __fastcall GetDataLength(void);
	
public:
	__fastcall TDataBuffer(int Size, int ChunkSize);
	__fastcall virtual ~TDataBuffer(void);
	void __fastcall Read(const Sysutils::TBytes data, int offset, int count);
	void __fastcall Write(const Sysutils::TBytes data, int offset, int count);
	int __fastcall SearchFromIndex(const System::Byte SearchByte, const int Index);
	__property int DataLength = {read=GetDataLength, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Crdatabuffer */
using namespace Crdatabuffer;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrdatabufferHPP
