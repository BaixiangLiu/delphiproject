// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crxml.pas' rev: 21.00

#ifndef CrxmlHPP
#define CrxmlHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Contnrs.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crxml
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS StreamWriter;
class PASCALIMPLEMENTATION StreamWriter : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Classes::TStream* FStream;
	bool FReleaseStream;
	Clrclasses::Encoding* FEncoding;
	
public:
	__fastcall StreamWriter(const System::UnicodeString path, bool Append)/* overload */;
	__fastcall StreamWriter(Classes::TStream* output, Clrclasses::Encoding* aEncoding)/* overload */;
	__fastcall virtual ~StreamWriter(void);
	void __fastcall Close(void);
	void __fastcall Flush(void);
	void __fastcall Write(const System::WideString value);
	void __fastcall WriteLine(const System::WideString value);
};


class DELPHICLASS XmlException;
class PASCALIMPLEMENTATION XmlException : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall XmlException(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall XmlException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall XmlException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall XmlException(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall XmlException(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall XmlException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall XmlException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall XmlException(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~XmlException(void) { }
	
};


#pragma option push -b-
enum XmlNodeType { ntNone, ntElement, ntAttribute, ntEndElement, ntComment, ntDeclaration, ntDocumentType, ntText };
#pragma option pop

#pragma option push -b-
enum XmlReadState { Initial, Interactive, Error, EndOfFile, Closed };
#pragma option pop

class DELPHICLASS XmlTextReader;
class PASCALIMPLEMENTATION XmlTextReader : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FBlocks;
	Classes::TStream* FStream;
	__int64 FStreamPosition;
	int FBlockSize;
	__int64 FFullSize;
	int FMaxNumBlock;
	int FCurPosition;
	int FActualPosition;
	int FActualBlockSize;
	System::UnicodeString FPrefix;
	System::UnicodeString FValue;
	System::UnicodeString FName;
	XmlNodeType FNodeType;
	Classes::TStringList* FAttrNames;
	Classes::TStringList* FAttrPrefix;
	Classes::TStringList* FAttrValues;
	int FOffset;
	XmlReadState FState;
	System::UnicodeString FCurrElementName;
	bool __fastcall GetHasAttributes(void);
	int __fastcall GetDepth(void);
	int __fastcall GetAttributeCount(void);
	void __fastcall GetXMLNodeAttributes(const System::UnicodeString Node, Classes::TStrings* AttrNames, Classes::TStrings* AttrValues);
	HIDESBASE void __fastcall InitInstance(void);
	bool __fastcall GetEof(void);
	bool __fastcall LoadNextBlock(bool ReplaceBuffer = true);
	bool __fastcall ReadTo(const System::AnsiString SubStr, /* out */ System::AnsiString &ResultStr, const int AdvLenth = 0x0)/* overload */;
	bool __fastcall IsToken(const System::AnsiString SubStr);
	char __fastcall GetNextSymbol(void);
	bool __fastcall MoveTo(const System::AnsiString Lexem);
	void __fastcall FreeOldBlocks(void);
	
public:
	__fastcall XmlTextReader(Classes::TStream* Stream)/* overload */;
	__fastcall XmlTextReader(const System::AnsiString Str)/* overload */;
	__fastcall virtual ~XmlTextReader(void);
	void __fastcall MoveToAttribute(int i)/* overload */;
	bool __fastcall MoveToAttribute(System::UnicodeString name)/* overload */;
	bool __fastcall Read(void);
	System::UnicodeString __fastcall Items(const int Index)/* overload */;
	System::UnicodeString __fastcall Items(const System::UnicodeString AttrName)/* overload */;
	__property System::UnicodeString Name = {read=FName};
	__property System::UnicodeString Prefix = {read=FPrefix};
	__property System::UnicodeString Value = {read=FValue};
	__property XmlNodeType NodeType = {read=FNodeType, nodefault};
	__property int AttributeCount = {read=GetAttributeCount, nodefault};
	__property int Depth = {read=GetDepth, nodefault};
	__property XmlReadState ReadState = {read=FState, nodefault};
	__property bool Eof = {read=GetEof, nodefault};
	__property bool HasAttributes = {read=GetHasAttributes, nodefault};
};


#pragma option push -b-
enum XmlFormatting { fmtNone, fmtIndented };
#pragma option pop

#pragma option push -b-
enum XmlWriteState { wsAttribute, wsClosed, wsContent, wsElement, wsStart };
#pragma option pop

class DELPHICLASS XmlTextWriter;
class PASCALIMPLEMENTATION XmlTextWriter : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::WideString FText;
	XmlFormatting FFormatting;
	int FIndentation;
	System::WideChar FIndentChar;
	System::WideChar FQuoteChar;
	XmlWriteState FWriteState;
	int FDepth;
	Contnrs::TStack* FPosStack;
	Classes::TStringList* FTagStack;
	StreamWriter* FWriter;
	System::WideString __fastcall IndentStr(void);
	System::UnicodeString __fastcall PopTagName(void);
	void __fastcall PushTagName(const System::UnicodeString TagName);
	void __fastcall InternalCloseStartTag(void);
	
protected:
	void __fastcall InternalWriteStartElement(const System::UnicodeString Prefix, const System::UnicodeString LocalName, const System::UnicodeString ns);
	void __fastcall InternalWriteElementString(const System::UnicodeString LocalName, const System::UnicodeString ns, System::WideString Value);
	void __fastcall InternalWriteAttributeString(const System::UnicodeString Prefix, const System::UnicodeString LocalName, const System::UnicodeString ns, System::WideString Value);
	void __fastcall InternalWriteEndElement(void);
	void __fastcall FlushData(void);
	
public:
	__fastcall XmlTextWriter(StreamWriter* w);
	__fastcall virtual ~XmlTextWriter(void);
	void __fastcall WriteStartElement(const System::UnicodeString LocalName)/* overload */;
	void __fastcall WriteStartElement(const System::UnicodeString Prefix, const System::UnicodeString LocalName, const System::UnicodeString ns)/* overload */;
	void __fastcall WriteStartElement(const System::UnicodeString LocalName, const System::UnicodeString ns)/* overload */;
	void __fastcall WriteEndElement(void);
	void __fastcall WriteFullEndElement(void);
	void __fastcall WriteString(const System::WideString Text);
	void __fastcall WriteElementString(const System::UnicodeString LocalName, const System::UnicodeString ns, System::WideString Value)/* overload */;
	void __fastcall WriteElementString(const System::UnicodeString LocalName, System::WideString Value)/* overload */;
	void __fastcall WriteAttributeString(const System::UnicodeString LocalName, System::WideString Value)/* overload */;
	void __fastcall WriteAttributeString(const System::UnicodeString Prefix, const System::UnicodeString LocalName, const System::UnicodeString ns, System::WideString Value)/* overload */;
	void __fastcall Close(void);
	__property XmlFormatting Formatting = {read=FFormatting, write=FFormatting, nodefault};
	__property int Indentation = {read=FIndentation, write=FIndentation, nodefault};
	__property System::WideChar IndentChar = {read=FIndentChar, write=FIndentChar, nodefault};
	__property System::WideChar QuoteChar = {read=FQuoteChar, write=FQuoteChar, nodefault};
	__property XmlWriteState WriteState = {read=FWriteState, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::WideString __fastcall XMLEncode(const System::WideString AStr);
extern PACKAGE System::UnicodeString __fastcall XMLDecode(const System::UnicodeString AStr);

}	/* namespace Crxml */
using namespace Crxml;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrxmlHPP
