// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dasqlmonitor.pas' rev: 21.00

#ifndef DasqlmonitorHPP
#define DasqlmonitorHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Activex.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Dbmonitorclient.hpp>	// Pascal unit
#include <Dbmonitorintf.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dasqlmonitor
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TDATraceFlag { tfQPrepare, tfQExecute, tfQFetch, tfError, tfStmt, tfConnect, tfTransact, tfBlob, tfService, tfMisc, tfParams };
#pragma option pop

typedef Set<TDATraceFlag, tfQPrepare, tfParams>  TDATraceFlags;

#pragma option push -b-
enum TMonitorOption { moDialog, moSQLMonitor, moDBMonitor, moCustom, moHandled };
#pragma option pop

typedef Set<TMonitorOption, moDialog, moHandled>  TMonitorOptions;

typedef void __fastcall (__closure *TOnSQLEvent)(System::TObject* Sender, System::UnicodeString Text, TDATraceFlag Flag);

typedef TMetaClass* TDASQLMonitorClass;

class DELPHICLASS TCustomDASQLMonitor;
class PASCALIMPLEMENTATION TCustomDASQLMonitor : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	bool FActive;
	TDATraceFlags FTraceFlags;
	TMonitorOptions FOptions;
	bool FStreamedActive;
	bool FRegistered;
	System::_di_IInterface FSMClient;
	bool NeedUninitialize;
	Dbmonitorintf::_di_IDBMonitor FDBMonitor;
	void __fastcall SetActive(bool Value);
	void __fastcall SetOptions(TMonitorOptions Value);
	
protected:
	TOnSQLEvent FOnSQLEvent;
	virtual void __fastcall Loaded(void);
	void __fastcall CheckActive(void);
	virtual void __fastcall RegisterClient(void);
	virtual void __fastcall UnRegisterClient(void);
	void __fastcall AddStatement(const System::AnsiString St);
	void __fastcall SMClientSignal(System::TObject* Sender, int Data);
	void __fastcall OnConnect(const System::AnsiString Username, const System::AnsiString Server, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnDisconnect(const System::AnsiString Username, const System::AnsiString Server, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnTransact(const System::AnsiString St, Classes::TComponent* Component, int TransactEvent, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnPrepare(const System::AnsiString SQL, Dbmonitorintf::TSQLParams &Params, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnUnprepare(const System::AnsiString SQL, Dbmonitorintf::TSQLParams &Params, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnExecute(const System::AnsiString SQL, Dbmonitorintf::TSQLParams &Params, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall OnError(const System::AnsiString ErrorStr);
	void __fastcall OnCustomMessage(const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &AMessageID);
	void __fastcall PrepareExecuteMessage(const System::AnsiString SQL, Dbmonitorintf::TSQLParams &Params, const System::AnsiString St, Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, Dbmonitorintf::TEventType EventType, unsigned &AMessageID);
	System::UnicodeString __fastcall GetCompHandle(Classes::TComponent* Comp);
	virtual Classes::TComponent* __fastcall GetParent(Classes::TComponent* Component, int Index);
	virtual int __fastcall GetParentCount(Classes::TComponent* Component);
	void __fastcall InternalSQLPrepare(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalSQLUnprepare(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	virtual void __fastcall InternalSQLExecute(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, const System::UnicodeString Caption, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalDBConnect(Dbaccess::TCustomDAConnection* Connection, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalDBDisconnect(Dbaccess::TCustomDAConnection* Connection, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	virtual void __fastcall InternalTRStart(Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	virtual void __fastcall InternalTRCommit(Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	virtual void __fastcall InternalTRRollback(Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalTRSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	void __fastcall InternalTRRollbackToSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	void __fastcall InternalTRReleaseSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	void __fastcall InternalTRCommitRetaining(Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalTRRollbackRetaining(Classes::TComponent* Component, Dbmonitorintf::TTracePoint ATracePoint, unsigned &MessageID);
	void __fastcall InternalDBError(Dbaccess::EDAError* Exception);
	void __fastcall InternalCustomMessage(Dbaccess::TCustomDAConnection* Connection, const System::UnicodeString Msg, unsigned &AMessageID);
	__classmethod virtual TCustomDASQLMonitor* __fastcall GetMonitor();
	
public:
	__classmethod void __fastcall SQLPrepare(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall SQLUnprepare(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall SQLExecute(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, const System::UnicodeString Caption, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall DBConnect(Dbaccess::TCustomDAConnection* Connection, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall DBDisconnect(Dbaccess::TCustomDAConnection* Connection, unsigned &MessageID, bool BeforeEvent);
	__classmethod virtual void __fastcall TRStart(Classes::TComponent* Component, unsigned &MessageID, bool BeforeEvent);
	__classmethod virtual void __fastcall TRCommit(Classes::TComponent* Component, unsigned &MessageID, bool BeforeEvent);
	__classmethod virtual void __fastcall TRRollback(Classes::TComponent* Component, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall TRSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	__classmethod void __fastcall TRRollbackToSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	__classmethod void __fastcall TRReleaseSavepoint(Classes::TComponent* Component, const System::UnicodeString Savepoint);
	__classmethod void __fastcall TRCommitRetaining(Classes::TComponent* Component, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall TRRollbackRetaining(Classes::TComponent* Component, unsigned &MessageID, bool BeforeEvent);
	__classmethod void __fastcall DBError(Dbaccess::EDAError* Exception);
	__classmethod void __fastcall CustomMessage(Dbaccess::TCustomDAConnection* Connection, const System::UnicodeString Msg, unsigned &MessageID);
	__classmethod bool __fastcall HasMonitor();
	__classmethod virtual System::UnicodeString __fastcall GetParamDataType(Dbaccess::TDAParam* Param);
	__classmethod virtual System::UnicodeString __fastcall GetParamParamType(Dbaccess::TDAParam* Param);
	__classmethod virtual System::UnicodeString __fastcall GetParamValue(Dbaccess::TDAParam* Param);
	__classmethod System::UnicodeString __fastcall GetParam(Dbaccess::TDAParam* Param, Dbmonitorintf::TSQLParam &SQLParam);
	__classmethod System::UnicodeString __fastcall GetParams(Dbaccess::TDAParams* Params, Dbmonitorintf::TSQLParams &SQLParams)/* overload */;
	__classmethod System::UnicodeString __fastcall GetParams(Dbaccess::TDAParams* Params)/* overload */;
	__classmethod virtual System::AnsiString __fastcall GetCaption();
	__classmethod void __fastcall ShowDebug(Classes::TComponent* Component, const System::UnicodeString SQL, Dbaccess::TDAParams* Params, const System::UnicodeString Caption);
	__fastcall virtual TCustomDASQLMonitor(Classes::TComponent* AOwner);
	__fastcall virtual ~TCustomDASQLMonitor(void);
	__property bool Active = {read=FActive, write=SetActive, default=1};
	__property TDATraceFlags TraceFlags = {read=FTraceFlags, write=FTraceFlags, default=1643};
	__property TMonitorOptions Options = {read=FOptions, write=SetOptions, default=15};
	__property TOnSQLEvent OnSQL = {read=FOnSQLEvent, write=FOnSQLEvent};
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt teStart = 0x1;
static const ShortInt teCommit = 0x2;
static const ShortInt teRollback = 0x3;
extern PACKAGE void __fastcall (*ShowDebugFormProc)(TDASQLMonitorClass DASQLMonitorClass, Classes::TComponent* Component, System::UnicodeString SQL, Dbaccess::TDAParams* Params, System::UnicodeString Caption);
extern PACKAGE unsigned __fastcall GetComponentID(Classes::TComponent* Component);
extern PACKAGE System::AnsiString __fastcall GetComponentName(Classes::TComponent* Component);

}	/* namespace Dasqlmonitor */
using namespace Dasqlmonitor;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DasqlmonitorHPP
