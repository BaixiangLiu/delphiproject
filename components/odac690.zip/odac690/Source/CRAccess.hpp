// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Craccess.pas' rev: 21.00

#ifndef CraccessHPP
#define CraccessHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Mtscall.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Craccess
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TCRConnectionClass;

typedef TMetaClass* TCRTransactionClass;

typedef TMetaClass* TCRCommandClass;

typedef TMetaClass* TCRRecordSetClass;

typedef TMetaClass* TParamDescClass;

typedef TMetaClass* TTableInfoClass;

typedef TMetaClass* TSQLInfoClass;

typedef TMetaClass* TCRMetaDataClass;

typedef TMetaClass* TCRLoaderColumnClass;

typedef TMetaClass* TCRLoaderClass;

#pragma option push -b-
enum TCommandType { ctUnknown, ctStatement, ctCursor };
#pragma option pop

#pragma option push -b-
enum TCursorState { csInactive, csOpen, csParsed, csPrepared, csBound, csExecuteFetchAll, csExecuting, csExecuted, csFetching, csFetchingAll, csFetched };
#pragma option pop

typedef void __fastcall (__closure *TErrorProc)(Sysutils::Exception* E, bool &Fail, bool &Reconnect, bool &Reexecute, int ReconnectAttempt, Memdata::TConnLostCause &ConnLostCause);

typedef void __fastcall (__closure *TReconnectProc)(void);

typedef void __fastcall (__closure *TBoolProc)(bool Value);

typedef void __fastcall (__closure *TBeforeFetchProc)(/* out */ bool &Cancel);

typedef void __fastcall (__closure *TAfterFetchProc)(void);

typedef void __fastcall (__closure *TDataChangeProc)(void);

typedef void __fastcall (__closure *TReadParamsProc)(void);

class DELPHICLASS EFailOver;
class PASCALIMPLEMENTATION EFailOver : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	Memdata::TConnLostCause FConnLostCause;
	__fastcall EFailOver(Memdata::TConnLostCause ConnLostCause);
public:
	/* Exception.CreateFmt */ inline __fastcall EFailOver(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EFailOver(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EFailOver(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EFailOver(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EFailOver(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EFailOver(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EFailOver(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EFailOver(void) { }
	
};


class DELPHICLASS TCRConnection;
class DELPHICLASS TCRTransaction;
class DELPHICLASS TMTSTransaction;
class PASCALIMPLEMENTATION TCRConnection : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TErrorProc FOnError;
	TReconnectProc FOnReconnectError;
	TReconnectProc FOnReconnectSuccess;
	unsigned FConnectionTime;
	
protected:
	TCRTransaction* FInternalTransaction;
	bool FConnected;
	bool FNativeConnection;
	System::UnicodeString FUsername;
	System::UnicodeString FPassword;
	System::UnicodeString FServer;
	bool FAutoCommit;
	bool FConvertEOL;
	bool FIsValid;
	System::TObject* FPool;
	int FPoolVersion;
	System::TObject* FComponent;
	bool FDisconnectedMode;
	bool FEnableBCD;
	bool FEnableFMTBCD;
	bool FInProcessError;
	bool FReconnected;
	Memdata::TSortType FDefaultSortType;
	Crvio::TCRIOHandler* FIOHandler;
	Crvio::THttpOptions* FHttpOptions;
	void __fastcall SetHttpOptions(Crvio::THttpOptions* Value);
	virtual void __fastcall Enlist(TMTSTransaction* MTSTransaction);
	virtual void __fastcall UnEnlist(TMTSTransaction* MTSTransaction);
	virtual void __fastcall DoError(Sysutils::Exception* E, bool &Fail);
	virtual TCRTransactionClass __fastcall GetTransactionClass(void) = 0 ;
	__property bool AutoCommit = {read=FAutoCommit, write=FAutoCommit, nodefault};
	__property bool EnableBCD = {read=FEnableBCD, write=FEnableBCD, nodefault};
	__property bool EnableFMTBCD = {read=FEnableFMTBCD, write=FEnableFMTBCD, nodefault};
	
public:
	__fastcall virtual TCRConnection(void);
	__fastcall virtual ~TCRConnection(void);
	virtual void __fastcall Connect(const System::UnicodeString ConnectString);
	virtual void __fastcall Disconnect(void) = 0 ;
	virtual void __fastcall AssignConnect(TCRConnection* Source) = 0 ;
	bool __fastcall GetConnected(void);
	void __fastcall SetConnected(bool Value);
	TCRTransaction* __fastcall GetInternalTransaction(void);
	virtual void __fastcall SetUsername(const System::UnicodeString Value);
	virtual void __fastcall SetPassword(const System::UnicodeString Value);
	void __fastcall SetServer(const System::UnicodeString Value);
	virtual bool __fastcall CheckIsValid(void) = 0 ;
	virtual void __fastcall ReturnToPool(void);
	virtual System::UnicodeString __fastcall GetServerVersion(void) = 0 ;
	virtual System::UnicodeString __fastcall GetServerVersionFull(void) = 0 ;
	virtual System::UnicodeString __fastcall GetClientVersion(void) = 0 ;
	virtual bool __fastcall CanChangeDatabase(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	__property TErrorProc OnError = {read=FOnError, write=FOnError};
	__property TReconnectProc OnReconnectError = {read=FOnReconnectError, write=FOnReconnectError};
	__property TReconnectProc OnReconnectSuccess = {read=FOnReconnectSuccess, write=FOnReconnectSuccess};
	__property unsigned ConnectionTime = {read=FConnectionTime, nodefault};
	__property bool IsValid = {read=FIsValid, write=FIsValid, nodefault};
	__property System::TObject* Pool = {read=FPool, write=FPool};
	__property int PoolVersion = {read=FPoolVersion, write=FPoolVersion, nodefault};
	__property System::TObject* Component = {read=FComponent, write=FComponent};
	__property bool DisconnectedMode = {read=FDisconnectedMode, write=FDisconnectedMode, nodefault};
	__property bool NativeConnection = {read=FNativeConnection, nodefault};
	__property Crvio::TCRIOHandler* IOHandler = {read=FIOHandler, write=FIOHandler};
	__property Crvio::THttpOptions* HttpOptions = {read=FHttpOptions, write=SetHttpOptions};
};


class DELPHICLASS TColumnInfo;
class PASCALIMPLEMENTATION TColumnInfo : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	System::UnicodeString Name;
	System::UnicodeString Table;
	int TableIndex;
	System::UnicodeString Expr;
	System::UnicodeString Alias;
	bool Used;
	bool Described;
	bool Required;
public:
	/* TObject.Create */ inline __fastcall TColumnInfo(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TColumnInfo(void) { }
	
};


class DELPHICLASS TColumnsInfo;
class PASCALIMPLEMENTATION TColumnsInfo : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TColumnInfo* operator[](int Index) { return Items[Index]; }
	
private:
	TColumnInfo* __fastcall GetItem(int Index);
	
public:
	virtual void __fastcall Clear(void);
	__property TColumnInfo* Items[int Index] = {read=GetItem/*, default*/};
public:
	/* TList.Destroy */ inline __fastcall virtual ~TColumnsInfo(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TColumnsInfo(void) : Classes::TList() { }
	
};


class DELPHICLASS TCRCommand;
class DELPHICLASS TParamDescs;
class DELPHICLASS TSQLInfo;
class DELPHICLASS TParamDesc;
class DELPHICLASS TCRCursor;
class PASCALIMPLEMENTATION TCRCommand : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	System::TObject* FComponent;
	TCRConnection* FConnection;
	TCRTransaction* FTransaction;
	System::UnicodeString FSQL;
	System::UnicodeString FUserSQL;
	TParamDescs* FParams;
	bool FAutoCommit;
	TBoolProc FAfterExecute;
	bool FExecuting;
	bool FScanParams;
	bool FDisableParamScan;
	bool FQuoteNames;
	Memdata::TCompressBlobMode FCompressBlob;
	bool FEnableBCD;
	bool FEnableFMTBCD;
	TReadParamsProc FReadParams;
	TSQLInfo* FSQLInfo;
	virtual void __fastcall ParseSQLParam(Clrclasses::WideStringBuilder* ParsedSQL, Crparser::TSQLParser* Parser, TParamDescs* Params, System::WideChar LeftQuote, System::WideChar RightQuote, const System::UnicodeString RenamePrefix);
	__property bool Executing = {read=FExecuting, write=FExecuting, nodefault};
	__property bool EnableBCD = {read=FEnableBCD, write=FEnableBCD, nodefault};
	__property bool EnableFMTBCD = {read=FEnableFMTBCD, write=FEnableFMTBCD, nodefault};
	
public:
	__fastcall virtual TCRCommand(void);
	__fastcall virtual ~TCRCommand(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall Unprepare(void);
	virtual bool __fastcall GetPrepared(void) = 0 ;
	virtual void __fastcall Execute(int Iters = 0x1) = 0 ;
	virtual void __fastcall SetConnection(TCRConnection* Value);
	TCRConnection* __fastcall GetConnection(void);
	virtual void __fastcall SetTransaction(TCRTransaction* Value);
	TCRTransaction* __fastcall GetTransaction(void);
	virtual TCursorState __fastcall GetCursorState(void) = 0 ;
	virtual void __fastcall SetCursorState(TCursorState Value) = 0 ;
	__classmethod virtual TTableInfoClass __fastcall GetTableInfoClass();
	__classmethod virtual TSQLInfoClass __fastcall GetSQLInfoClass();
	__classmethod virtual Crparser::TSQLParserClass __fastcall GetParserClass();
	virtual void __fastcall SetSQL(const System::UnicodeString Value);
	virtual System::UnicodeString __fastcall ParseSQL(const System::UnicodeString SQL, TParamDescs* Params, bool ReplaceAll = true, const System::UnicodeString RenamePrefix = L"")/* overload */;
	void __fastcall ParseSQL(bool ReplaceAll = true)/* overload */;
	virtual System::UnicodeString __fastcall CreateProcCall(const System::UnicodeString Name, bool NeedDescribe, bool IsQuery) = 0 ;
	virtual TParamDescClass __fastcall GetParamDescType(void);
	void __fastcall ClearParams(void);
	virtual TParamDesc* __fastcall AddParam(void);
	void __fastcall DeleteParam(int Index);
	int __fastcall GetParamCount(void);
	TParamDesc* __fastcall GetParam(int Index);
	TParamDesc* __fastcall FindParam(System::UnicodeString Name);
	virtual TCRCursor* __fastcall GetCursor(void);
	virtual void __fastcall SetCursor(TCRCursor* Value);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	__property System::UnicodeString SQL = {read=FSQL, write=SetSQL};
	__property System::TObject* Component = {read=FComponent, write=FComponent};
	__property TBoolProc AfterExecute = {read=FAfterExecute, write=FAfterExecute};
	__property TReadParamsProc ReadParams = {read=FReadParams, write=FReadParams};
	__property TParamDescs* Params = {read=FParams, write=FParams};
	__property TSQLInfo* SQLInfo = {read=FSQLInfo};
};


class DELPHICLASS TCRTableInfo;
class DELPHICLASS TCRTablesInfo;
class PASCALIMPLEMENTATION TCRTableInfo : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TCRTablesInfo* FOwner;
	int FIndex;
	System::UnicodeString FTableName;
	System::UnicodeString FTableAlias;
	bool FIsView;
	void __fastcall SetTableName(const System::UnicodeString Value);
	void __fastcall SetTableAlias(const System::UnicodeString Value);
	virtual System::UnicodeString __fastcall GetTableNameFull(void);
	virtual void __fastcall SetTableNameFull(const System::UnicodeString Value);
	
public:
	__fastcall virtual TCRTableInfo(TCRTablesInfo* Owner);
	__property System::UnicodeString TableName = {read=FTableName, write=SetTableName};
	__property System::UnicodeString TableAlias = {read=FTableAlias, write=SetTableAlias};
	__property System::UnicodeString TableNameFull = {read=GetTableNameFull, write=SetTableNameFull};
	__property bool IsView = {read=FIsView, write=FIsView, nodefault};
	__property int Index = {read=FIndex, write=FIndex, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRTableInfo(void) { }
	
};


class PASCALIMPLEMENTATION TCRTablesInfo : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	typedef DynamicArray<TCRTableInfo*> _TCRTablesInfo__1;
	
	
public:
	TCRTableInfo* operator[](int Index) { return Items[Index]; }
	
private:
	TCRTableInfo* __fastcall GetItem(int Index);
	void __fastcall SetItem(int Index, const TCRTableInfo* Value);
	
protected:
	bool FCaseSensitive;
	_TCRTablesInfo__1 FList;
	int FUpdateCount;
	TTableInfoClass FTableInfoClass;
	Classes::TStringList* FTableNameList;
	Classes::TStringList* FTableAliasList;
	void __fastcall InternalAdd(TCRTableInfo* TableInfo);
	void __fastcall Changed(void);
	void __fastcall TableNameChanged(void);
	void __fastcall TableAliasChanged(void);
	int __fastcall GetCount(void);
	void __fastcall SetCaseSensitive(bool Value);
	
public:
	__fastcall TCRTablesInfo(TTableInfoClass TableInfoClass);
	__fastcall virtual ~TCRTablesInfo(void);
	TCRTableInfo* __fastcall Add(void);
	void __fastcall Clear(void);
	virtual void __fastcall BeginUpdate(void);
	virtual void __fastcall EndUpdate(void);
	TCRTableInfo* __fastcall FindByName(System::UnicodeString TableName);
	int __fastcall IndexOf(TCRTableInfo* TableInfo);
	int __fastcall IndexByName(System::UnicodeString TableName);
	int __fastcall IndexByAlias(System::UnicodeString TableAlias);
	__property TCRTableInfo* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
	__property int Count = {read=GetCount, nodefault};
	__property TTableInfoClass TableInfoClass = {read=FTableInfoClass};
	__property bool CaseSensitive = {read=FCaseSensitive, write=SetCaseSensitive, nodefault};
};


#pragma option push -b-
enum TIdentCase { icUpper, icLower, icMixed, icMixedCaseSensitive };
#pragma option pop

struct TExtTableInfo
{
	
public:
	System::UnicodeString Table;
	System::UnicodeString Schema;
	System::UnicodeString Catalog;
	System::UnicodeString DBLink;
	System::UnicodeString Synonym;
	System::Byte Flag;
};


typedef DynamicArray<TExtTableInfo> TExtTablesInfo;

class PASCALIMPLEMENTATION TSQLInfo : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TCRCommand* FCommand;
	virtual void __fastcall ParseExtColumnName(Crparser::TSQLParser* Parser, int &Code, System::UnicodeString &Str);
	
public:
	__fastcall virtual TSQLInfo(void);
	TCRCommand* __fastcall GetCommand(void);
	void __fastcall SetCommand(TCRCommand* Value);
	virtual System::WideChar __fastcall LeftQuote(void);
	virtual System::WideChar __fastcall RightQuote(void);
	virtual TIdentCase __fastcall IdentCase(void);
	System::UnicodeString __fastcall Quote(const System::UnicodeString Value)/* overload */;
	virtual System::UnicodeString __fastcall Quote(const System::UnicodeString Value, const System::WideChar LeftQ, const System::WideChar RightQ)/* overload */;
	virtual System::UnicodeString __fastcall UnQuote(const System::UnicodeString Value);
	virtual bool __fastcall IsQuoted(const System::UnicodeString Value);
	virtual bool __fastcall QuotesNeeded(const System::UnicodeString Value);
	System::UnicodeString __fastcall QuoteIfNeed(const System::UnicodeString Value);
	virtual System::UnicodeString __fastcall NormalizeName(const System::UnicodeString Value, bool QuoteNames = false, bool UnQuoteNames = false)/* overload */;
	virtual System::UnicodeString __fastcall NormalizeName(const System::UnicodeString Value, const System::WideChar LeftQ, const System::WideChar RightQ, bool QuoteNames = false, bool UnQuoteNames = false)/* overload */;
	virtual void __fastcall SplitObjectName(const System::UnicodeString Name, TExtTableInfo &Info);
	virtual void __fastcall ParseTablesInfo(const System::UnicodeString SQL, TCRTablesInfo* TablesInfo);
	virtual void __fastcall ParseColumnsInfo(const System::UnicodeString SQL, TColumnsInfo* ColumnsInfo);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TSQLInfo(void) { }
	
};


class DELPHICLASS TCRFieldDesc;
class PASCALIMPLEMENTATION TCRFieldDesc : public Memdata::TFieldDesc
{
	typedef Memdata::TFieldDesc inherited;
	
private:
	typedef StaticArray<System::UnicodeString, 2> _TCRFieldDesc__1;
	
	
protected:
	TCRTableInfo* FTableInfo;
	_TCRFieldDesc__1 FActualNameQuoted;
	System::UnicodeString FDefaultExpr;
	bool FIsAutoIncrement;
	
public:
	virtual System::UnicodeString __fastcall ActualNameQuoted(TSQLInfo* SQLInfo, bool QuoteNames);
	virtual bool __fastcall IsNational(void);
	__property TCRTableInfo* TableInfo = {read=FTableInfo, write=FTableInfo};
	__property System::UnicodeString DefaultExpr = {read=FDefaultExpr, write=FDefaultExpr};
	__property bool IsAutoIncrement = {read=FIsAutoIncrement, write=FIsAutoIncrement, nodefault};
public:
	/* TFieldDesc.Create */ inline __fastcall virtual TCRFieldDesc(void) : Memdata::TFieldDesc() { }
	/* TFieldDesc.Destroy */ inline __fastcall virtual ~TCRFieldDesc(void) { }
	
};


class DELPHICLASS TCRRecordSet;
class PASCALIMPLEMENTATION TCRRecordSet : public Memdata::TMemData
{
	typedef Memdata::TMemData inherited;
	
protected:
	TCRCommand* FCommand;
	bool FUniDirectional;
	int FFetchRows;
	bool FFetchAll;
	bool FLockFetchAll;
	bool FLongStrings;
	bool FFlatBuffers;
	bool FExtendedFieldsInfo;
	bool FDefaultValues;
	bool FFieldsOrigin;
	TBoolProc FAfterExecFetch;
	TBoolProc FAfterFetchAll;
	TBeforeFetchProc FOnBeforeFetch;
	TAfterFetchProc FOnAfterFetch;
	TDataChangeProc FOnDataChanged;
	bool FWaitForFetchBreak;
	TCommandType FCommandType;
	TCRTablesInfo* FTablesInfo;
	virtual void __fastcall CreateCommand(void) = 0 ;
	void __fastcall FreeCommand(void);
	virtual void __fastcall SetCommand(TCRCommand* Value);
	virtual bool __fastcall CanFetchBack(void);
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalUnPrepare(void);
	virtual void __fastcall InternalOpen(bool DisableInitFields = false);
	virtual bool __fastcall NeedInitFields(void);
	virtual void __fastcall ExecFetch(bool DisableInitFields);
	void __fastcall CreateBlockStruct(Memdata::PBlockHeader Block, int RowsObtained, bool FetchBack = false);
	virtual void __fastcall DoBeforeFetch(/* out */ bool &Cancel);
	virtual void __fastcall DoAfterFetch(void);
	virtual bool __fastcall NeedConvertEOL(void);
	TTableInfoClass __fastcall GetTableInfoClass(void);
	virtual void __fastcall SetSortDefaults(Memdata::TSortColumn* SortColumn);
	System::TObject* __fastcall GetComponent(void);
	void __fastcall SetComponent(System::TObject* Value);
	
public:
	__fastcall virtual TCRRecordSet(void);
	__fastcall virtual ~TCRRecordSet(void);
	virtual Memdata::TFieldDescClass __fastcall GetFieldDescType(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall UnPrepare(void);
	virtual void __fastcall Disconnect(void);
	virtual void __fastcall Open(void);
	virtual void __fastcall Close(void);
	virtual void __fastcall ExecCommand(void);
	virtual void __fastcall GetNextRecord(void * RecBuf);
	virtual void __fastcall GetPriorRecord(void * RecBuf);
	virtual void __fastcall FetchAll(void);
	virtual void __fastcall BreakFetch(void);
	virtual bool __fastcall CanDisconnect(void);
	virtual bool __fastcall RowsReturn(void);
	TCRCommand* __fastcall GetCommand(void);
	virtual void __fastcall SetConnection(TCRConnection* Value);
	virtual void __fastcall SetTransaction(TCRTransaction* Value);
	virtual void __fastcall SetSQL(const System::UnicodeString Value);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	virtual bool __fastcall IsCaseSensitive(void);
	virtual void __fastcall FilterUpdated(void);
	__property TCommandType CommandType = {read=FCommandType, write=FCommandType, nodefault};
	__property TBoolProc AfterExecFetch = {read=FAfterExecFetch, write=FAfterExecFetch};
	__property TBoolProc AfterFetchAll = {read=FAfterFetchAll, write=FAfterFetchAll};
	__property TBeforeFetchProc OnBeforeFetch = {read=FOnBeforeFetch, write=FOnBeforeFetch};
	__property TAfterFetchProc OnAfterFetch = {read=FOnAfterFetch, write=FOnAfterFetch};
	__property TDataChangeProc OnDataChanged = {read=FOnDataChanged, write=FOnDataChanged};
	virtual void __fastcall SortItems(void);
	__property TCRTablesInfo* TablesInfo = {read=FTablesInfo};
	__property System::TObject* Component = {read=GetComponent, write=SetComponent};
};


#pragma option push -b-
enum TParamDirection { pdUnknown, pdInput, pdOutput, pdInputOutput, pdResult };
#pragma option pop

class PASCALIMPLEMENTATION TParamDesc : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	System::UnicodeString FName;
	System::Word FDataType;
	System::Word FSubDataType;
	TParamDirection FParamType;
	int FSize;
	System::Variant FData;
	bool FIsNull;
	bool FIsBound;
	bool FConvertEOL;
	bool FNational;
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::Word DataType = {read=FDataType, write=FDataType, nodefault};
	__property System::Word SubDataType = {read=FSubDataType, write=FSubDataType, nodefault};
	__property TParamDirection ParamType = {read=FParamType, write=FParamType, nodefault};
	__property int Size = {read=FSize, write=FSize, nodefault};
	
public:
	__fastcall virtual TParamDesc(void);
	__fastcall virtual ~TParamDesc(void);
	void __fastcall Clear(void);
	System::UnicodeString __fastcall GetName(void);
	void __fastcall SetName(System::UnicodeString Value);
	System::Word __fastcall GetDataType(void);
	virtual void __fastcall SetDataType(System::Word Value);
	System::Word __fastcall GetSubDataType(void);
	virtual void __fastcall SetSubDataType(System::Word Value);
	TParamDirection __fastcall GetParamType(void);
	virtual void __fastcall SetParamType(TParamDirection Value);
	int __fastcall GetSize(void);
	virtual void __fastcall SetSize(int Value);
	virtual System::Variant __fastcall GetValue(void);
	virtual void __fastcall SetValue(const System::Variant &Value);
	virtual Memdata::TSharedObject* __fastcall GetObject(void);
	virtual void __fastcall SetObject(Memdata::TSharedObject* Value);
	virtual bool __fastcall GetNull(void);
	virtual void __fastcall SetNull(const bool Value);
	bool __fastcall GetIsBound(void);
	virtual void __fastcall SetIsBound(bool Value);
	virtual bool __fastcall GetNational(void);
	virtual void __fastcall SetNational(bool Value);
	void __fastcall SetConvertEOL(const bool Value);
	__property System::Variant Value = {read=FData, write=SetValue};
};


class PASCALIMPLEMENTATION TParamDescs : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TParamDesc* operator[](int Index) { return Items[Index]; }
	
private:
	TParamDesc* __fastcall GetItems(int Index);
	
public:
	__fastcall virtual ~TParamDescs(void);
	virtual void __fastcall Clear(void);
	TParamDesc* __fastcall FindParam(System::UnicodeString Name);
	TParamDesc* __fastcall ParamByName(System::UnicodeString Name);
	__property TParamDesc* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TObject.Create */ inline __fastcall TParamDescs(void) : Classes::TList() { }
	
};


class DELPHICLASS TCRConnections;
class PASCALIMPLEMENTATION TCRConnections : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TCRConnection* operator[](int Index) { return Items[Index]; }
	
private:
	TCRConnection* __fastcall GetItems(int Index);
	
public:
	__property TCRConnection* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TList.Destroy */ inline __fastcall virtual ~TCRConnections(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TCRConnections(void) : Classes::TList() { }
	
};


typedef void __fastcall (__closure *TCRErrorProc)(Sysutils::Exception* E, bool &Fail);

#pragma option push -b-
enum TCRIsolationLevel { ilReadCommitted, ilReadUnCommitted, ilRepeatableRead, ilIsolated, ilSnapshot, ilCustom };
#pragma option pop

#pragma option push -b-
enum TCRTransactionAction { taCommit, taRollback };
#pragma option pop

class PASCALIMPLEMENTATION TCRTransaction : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	bool FActive;
	System::TObject* FComponent;
	TCRErrorProc FOnError;
	TCRConnections* FConnections;
	TCRIsolationLevel FIsolationLevel;
	bool FReadOnly;
	bool FNativeTransaction;
	
public:
	__fastcall virtual TCRTransaction(void);
	__fastcall virtual ~TCRTransaction(void);
	void __fastcall CheckInactive(void);
	void __fastcall CheckActive(void);
	virtual bool __fastcall AddConnection(TCRConnection* Connection);
	virtual bool __fastcall RemoveConnection(TCRConnection* Connection);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	virtual bool __fastcall GetInTransaction(void);
	virtual bool __fastcall DetectInTransaction(bool CanActivate);
	virtual void __fastcall AssignConnect(TCRTransaction* Source);
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual void __fastcall CommitRetaining(void);
	virtual void __fastcall RollbackRetaining(void);
	virtual void __fastcall Savepoint(const System::UnicodeString Name);
	virtual void __fastcall ReleaseSavepoint(const System::UnicodeString Name);
	virtual void __fastcall RollbackToSavepoint(const System::UnicodeString Name);
	virtual void __fastcall Reset(void);
	virtual bool __fastcall CanRestoreAfterFailover(void);
	__property System::TObject* Component = {read=FComponent, write=FComponent};
	__property TCRErrorProc OnError = {read=FOnError, write=FOnError};
};


class PASCALIMPLEMENTATION TMTSTransaction : public TCRTransaction
{
	typedef TCRTransaction inherited;
	
private:
	Mtscall::_di_ICRTransactionDispenserSC FMTSGC;
	Mtscall::_di_ICRTransactionSC FMTSTrans;
	
protected:
	virtual void __fastcall StartMTSTransaction(void);
	virtual void __fastcall CompleteMTSTransaction(bool Commit);
	virtual void __fastcall EnlistLink(TCRConnection* Connection);
	virtual void __fastcall UnEnlistLink(TCRConnection* Connection);
	
public:
	__fastcall virtual ~TMTSTransaction(void);
	virtual bool __fastcall AddConnection(TCRConnection* Connection);
	virtual bool __fastcall RemoveConnection(TCRConnection* Connection);
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual void __fastcall Savepoint(const System::UnicodeString Name);
	virtual void __fastcall ReleaseSavepoint(const System::UnicodeString Name);
	virtual void __fastcall RollbackToSavepoint(const System::UnicodeString Name);
	__property Mtscall::_di_ICRTransactionSC MTSTransaction = {read=FMTSTrans};
public:
	/* TCRTransaction.Create */ inline __fastcall virtual TMTSTransaction(void) : TCRTransaction() { }
	
};


class DELPHICLASS TDataHelper;
class PASCALIMPLEMENTATION TDataHelper : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Memdata::TData* FData;
	void *FRecBuf;
	void __fastcall FreeBuffer(void);
	System::Variant __fastcall GetFieldValue(int Index);
	void __fastcall SetFieldValue(int Index, const System::Variant &Value);
	
public:
	__fastcall TDataHelper(Memdata::TData* Data);
	__fastcall virtual ~TDataHelper(void);
	void __fastcall AllocBuffer(void);
	void __fastcall InitRecord(void);
	void __fastcall AppendRecord(void);
	bool __fastcall NextRecord(void);
	__property System::Variant FieldValues[int Index] = {read=GetFieldValue, write=SetFieldValue};
};


typedef DynamicArray<bool> TBooleanArray;

class DELPHICLASS TCRMetaData;
class PASCALIMPLEMENTATION TCRMetaData : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Memdata::TMemData* FMemData;
	TDataHelper* FMemDataHelper;
	TCRRecordSet* FRecordSet;
	TDataHelper* FRecordSetHelper;
	System::UnicodeString FOperator;
	virtual TCRRecordSet* __fastcall CreateRecordSet(void) = 0 ;
	void __fastcall AddField(const System::UnicodeString AName, int AType, int ALength = 0xffffffff);
	void __fastcall CopyRecord(int const *SourceIndices, const int SourceIndices_Size, int const *DestIndices, const int DestIndices_Size);
	TBooleanArray __fastcall ParseTypes(const System::UnicodeString ObjectTypes, System::UnicodeString *AllTypes, const int AllTypes_Size)/* overload */;
	void __fastcall ParseTypes(const System::UnicodeString ObjectTypes, Classes::TStringList* TypesList)/* overload */;
	void __fastcall AddWhere(System::UnicodeString &WhereClause, const System::UnicodeString Name, const System::UnicodeString Value, bool AddEmpty = false);
	virtual Memdata::TData* __fastcall InternalGetMetaData(const System::UnicodeString MetaDataKind, Classes::TStrings* Restrictions)/* overload */;
	virtual void __fastcall CreateMetaDataKindsFields(void);
	virtual void __fastcall InternalGetMetaDataKindsList(Classes::TStringList* List)/* overload */;
	virtual Memdata::TData* __fastcall GetMetaDataKinds(void);
	virtual void __fastcall CreateRestrictionsFields(void);
	virtual void __fastcall InternalGetRestrictionsList(Classes::TStringList* List, const System::UnicodeString MetaDataKind)/* overload */;
	virtual Memdata::TData* __fastcall GetRestrictions(Classes::TStrings* Restrictions);
	virtual void __fastcall CreateTablesFields(void);
	virtual Memdata::TData* __fastcall GetTables(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateColumnsFields(void);
	virtual Memdata::TData* __fastcall GetColumns(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateProceduresFields(void);
	virtual Memdata::TData* __fastcall GetProcedures(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateProcedureParametersFields(void);
	virtual Memdata::TData* __fastcall GetProcedureParameters(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateIndexesFields(void);
	virtual Memdata::TData* __fastcall GetIndexes(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateIndexColumnsFields(void);
	virtual Memdata::TData* __fastcall GetIndexColumns(Classes::TStrings* Restrictions) = 0 ;
	virtual void __fastcall CreateConstraintsFields(void);
	virtual Memdata::TData* __fastcall GetConstraints(Classes::TStrings* Restrictions) = 0 ;
	virtual Memdata::TData* __fastcall GetDatabases(Classes::TStrings* Restrictions);
	virtual void __fastcall CreateDatabasesFields(void);
	virtual Memdata::TData* __fastcall GetDataTypes(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetUsers(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetRoles(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetUDTs(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetPackages(Classes::TStrings* Restrictions);
	
public:
	__fastcall virtual TCRMetaData(void);
	__fastcall virtual ~TCRMetaData(void);
	virtual Memdata::TData* __fastcall GetMetaData(TCRConnection* Connection, TCRTransaction* Transaction, const System::UnicodeString MetaDataKind, Classes::TStrings* Restrictions);
	void __fastcall GetMetaDataKindsList(Classes::TStrings* List);
	void __fastcall GetRestrictionsList(Classes::TStrings* List, const System::UnicodeString MetaDataKind);
};


class PASCALIMPLEMENTATION TCRCursor : public Memdata::TSharedObject
{
	typedef Memdata::TSharedObject inherited;
	
public:
	virtual bool __fastcall CanFetch(void) = 0 ;
public:
	/* TSharedObject.Create */ inline __fastcall TCRCursor(void) : Memdata::TSharedObject() { }
	/* TSharedObject.Destroy */ inline __fastcall virtual ~TCRCursor(void) { }
	
};


class DELPHICLASS TCRLoaderColumn;
class PASCALIMPLEMENTATION TCRLoaderColumn : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	System::Word FDataType;
	int FSize;
	int FPrecision;
	int FScale;
	
public:
	__fastcall virtual TCRLoaderColumn(void);
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::Word DataType = {read=FDataType, write=FDataType, nodefault};
	__property int Size = {read=FSize, write=FSize, nodefault};
	__property int Precision = {read=FPrecision, write=FPrecision, nodefault};
	__property int Scale = {read=FScale, write=FScale, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRLoaderColumn(void) { }
	
};


class DELPHICLASS TCRLoaderColumns;
class PASCALIMPLEMENTATION TCRLoaderColumns : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TCRLoaderColumn* operator[](int Index) { return Items[Index]; }
	
private:
	TCRLoaderColumn* __fastcall GetColumn(int Index);
	void __fastcall SetColumn(int Index, TCRLoaderColumn* Value);
	
public:
	virtual void __fastcall Clear(void);
	__property TCRLoaderColumn* Items[int Index] = {read=GetColumn, write=SetColumn/*, default*/};
public:
	/* TList.Destroy */ inline __fastcall virtual ~TCRLoaderColumns(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TCRLoaderColumns(void) : Classes::TList() { }
	
};


class DELPHICLASS TCRLoader;
class PASCALIMPLEMENTATION TCRLoader : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TCRConnection* FConnection;
	TCRTransaction* FTransaction;
	System::UnicodeString FTableName;
	TCRLoaderColumns* FColumns;
	int FLastRow;
	int FLoadedRows;
	bool FSkipReadOnlyFieldDescs;
	__classmethod virtual TCRRecordSetClass __fastcall GetRecordSetClass();
	virtual void __fastcall SetConnection(TCRConnection* Value);
	virtual void __fastcall SetTransaction(TCRTransaction* Value);
	void __fastcall CheckTableName(void);
	virtual void __fastcall FillColumn(TCRLoaderColumn* Column, Memdata::TFieldDesc* FieldDesc);
	
public:
	__fastcall virtual TCRLoader(void);
	__fastcall virtual ~TCRLoader(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	__classmethod virtual TCRLoaderColumnClass __fastcall GetColumnClass();
	virtual void __fastcall Prepare(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall DoLoad(void);
	virtual void __fastcall Finish(void);
	virtual void __fastcall PutColumnData(int Col, int Row, const System::Variant &Value);
	void __fastcall CreateColumns(void);
	void __fastcall DiscardRow(void);
	__property TCRConnection* Connection = {read=FConnection, write=SetConnection};
	__property TCRTransaction* Transaction = {read=FTransaction, write=SetTransaction};
	__property System::UnicodeString TableName = {read=FTableName, write=FTableName};
	__property TCRLoaderColumns* Columns = {read=FColumns};
};


class DELPHICLASS TCRSimpleLoader;
class PASCALIMPLEMENTATION TCRSimpleLoader : public TCRLoader
{
	typedef TCRLoader inherited;
	
protected:
	TCRCommand* FCommand;
	void __fastcall LoadRow(void);
	virtual void __fastcall CreateCommand(void) = 0 ;
	
public:
	__fastcall virtual TCRSimpleLoader(void);
	__fastcall virtual ~TCRSimpleLoader(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall PutColumnData(int Col, int Row, const System::Variant &Value);
	virtual void __fastcall DoLoad(void);
	virtual void __fastcall Finish(void);
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt prUsername = 0x1;
static const ShortInt prPassword = 0x2;
static const ShortInt prServer = 0x4;
static const ShortInt prAutoCommit = 0x5;
static const ShortInt prSQL = 0xa;
static const ShortInt prScanParams = 0xb;
static const ShortInt prSQLType = 0xc;
static const ShortInt prRowsProcessed = 0xd;
static const ShortInt prUniDirectional = 0x14;
static const ShortInt prFetchRows = 0x15;
static const ShortInt prFetchAll = 0x16;
static const ShortInt prRowsFetched = 0x17;
static const ShortInt prExecuting = 0x18;
static const ShortInt prLongStrings = 0x19;
static const ShortInt prEnableEmptyStrings = 0x1a;
static const ShortInt prFlatBuffers = 0x1b;
static const ShortInt prConvertEOL = 0x1c;
static const ShortInt prIndexFieldNames = 0x1d;
static const ShortInt prCompressBlobMode = 0x1e;
static const ShortInt prDisconnectedMode = 0x1f;
static const ShortInt prDisableParamScan = 0x20;
static const ShortInt prStoredProcIsQuery = 0x21;
static const ShortInt prQuoteNames = 0x22;
static const ShortInt prIsolationLevel = 0x23;
static const ShortInt prTransactionReadOnly = 0x25;
static const ShortInt prDatabase = 0x26;
static const ShortInt prPort = 0x27;
static const ShortInt prMaxStringSize = 0x28;
static const ShortInt prEnableBCD = 0x29;
static const ShortInt prEnableFmtBCD = 0x2a;
static const ShortInt prCanReadParams = 0x2b;
static const ShortInt prReadOnly = 0x2c;
static const ShortInt prIsStoredProc = 0x2d;
static const ShortInt prIsSelectParams = 0x2e;
static const ShortInt prLockFetchAll = 0x2f;
static const ShortInt prDefaultSortType = 0x30;
static const ShortInt prLastInsertId = 0x31;
static const ShortInt prFieldsAsString = 0x32;
static const ShortInt prExtendedFieldsInfo = 0x33;
static const ShortInt prDefaultValues = 0x34;
static const ShortInt prFieldsOrigin = 0x35;
static const ShortInt prUseDescribeParams = 0x36;
static const ShortInt dtSingle = 0x1;
static const ShortInt dtUInt8 = 0x2;
extern PACKAGE System::UnicodeString __fastcall GenerateTableName(const Memdata::TFieldDesc* FieldDesc);

}	/* namespace Craccess */
using namespace Craccess;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CraccessHPP
