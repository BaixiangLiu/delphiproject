// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Ora.pas' rev: 21.00

#ifndef OraHPP
#define OraHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Crxml.hpp>	// Pascal unit
#include <Stdvcl.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Crconnectionpool.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Oraerror.hpp>	// Pascal unit
#include <Oraobjects.hpp>	// Pascal unit
#include <Oraconnectionpool.hpp>	// Pascal unit
#include <Oraservices.hpp>	// Pascal unit
#include <Dbcommontypes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------
#ifdef GetObject
#undef GetObject
#endif

namespace Ora
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TSubFieldType { stNone, stOraBlob, stOraClob };
#pragma option pop

typedef ShortInt TCharLength;

typedef void __fastcall (__closure *TConnectChangeEvent)(System::TObject* Sender, bool Connected);

#pragma option push -b-
enum TFailoverState { fsEnd, fsAbort, fsReauth, fsBegin, fsError };
#pragma option pop

#pragma option push -b-
enum TFailoverType { ftNone, ftSession, ftSelect, ftTransaction };
#pragma option pop

typedef void __fastcall (__closure *TFailoverEvent)(System::TObject* Sender, TFailoverState FailoverState, TFailoverType FailoverType, bool &Retry);

#pragma option push -b-
enum TOraIsolationLevel { ilReadCommitted, ilSerializable, ilReadOnly };
#pragma option pop

#pragma option push -b-
enum TSequenceMode { smInsert, smPost };
#pragma option pop

#pragma option push -b-
enum TCheckMode { cmNone, cmException, cmRefresh };
#pragma option pop

class DELPHICLASS TOraSessionOptions;
class PASCALIMPLEMENTATION TOraSessionOptions : public Dbaccess::TDAConnectionOptions
{
	typedef Dbaccess::TDAConnectionOptions inherited;
	
private:
	bool FUseOCI7;
	bool FDirect;
	bool FEnableIntegers;
	bool FIsDateLanguageStored;
	bool FIsDateFormatStored;
	bool FEnableNumbers;
	bool FEnableLargeint;
	bool FEnableOraTimestamp;
	TCharLength FCharLength;
	System::UnicodeString FCharset;
	bool FUseUnicode;
	System::UnicodeString FDateFormat;
	System::UnicodeString FDateLanguage;
	Oraclasses::TOptimizerMode FOptimizerMode;
	int FConnectionTimeout;
	bool FStatementCache;
	int FStatementCacheSize;
	System::UnicodeString FClientIdentifier;
	TCharLength __fastcall GetCharLength(void);
	void __fastcall SetCharLength(TCharLength Value);
	void __fastcall SetCharset(const System::UnicodeString Value);
	void __fastcall SetUseUnicode(bool Value);
	System::UnicodeString __fastcall GetDateLanguage(void);
	void __fastcall SetDateLanguage(const System::UnicodeString Value);
	System::UnicodeString __fastcall GetDateFormat(void);
	void __fastcall SetDateFormat(const System::UnicodeString Value);
	void __fastcall SetEnableIntegers(bool Value);
	void __fastcall SetEnableLargeint(bool Value);
	void __fastcall SetEnableNumbers(bool Value);
	void __fastcall SetEnableOraTimestamp(bool Value);
	bool __fastcall GetConvertEOL(void);
	void __fastcall SetConvertEOL(bool Value);
	void __fastcall SetNeverConnect(bool Value);
	bool __fastcall GetNeverConnect(void);
	void __fastcall SetUseOCI7(bool Value);
	bool __fastcall GetNet(void);
	void __fastcall SetNet(bool Value);
	void __fastcall SetDirect(bool Value);
	void __fastcall SetOptimizerMode(Oraclasses::TOptimizerMode Value);
	void __fastcall SetConnectionTimeout(int Value);
	void __fastcall SetStatementCache(bool Value);
	void __fastcall SetStatementCacheSize(int Value);
	void __fastcall SetClientIdentifier(const System::UnicodeString Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TOraSessionOptions(Dbaccess::TCustomDAConnection* Owner);
	
__published:
	__property TCharLength CharLength = {read=GetCharLength, write=SetCharLength, default=1};
	__property System::UnicodeString Charset = {read=FCharset, write=SetCharset};
	__property bool UseUnicode = {read=FUseUnicode, write=SetUseUnicode, default=0};
	__property bool ConvertEOL = {read=GetConvertEOL, write=SetConvertEOL, default=0};
	__property System::UnicodeString DateFormat = {read=GetDateFormat, write=SetDateFormat, stored=FIsDateFormatStored};
	__property System::UnicodeString DateLanguage = {read=GetDateLanguage, write=SetDateLanguage, stored=FIsDateLanguageStored};
	__property bool EnableIntegers = {read=FEnableIntegers, write=SetEnableIntegers, default=1};
	__property bool EnableLargeint = {read=FEnableLargeint, write=SetEnableLargeint, default=0};
	__property bool EnableNumbers = {read=FEnableNumbers, write=SetEnableNumbers, default=0};
	__property bool EnableOraTimestamp = {read=FEnableOraTimestamp, write=SetEnableOraTimestamp, default=1};
	__property bool NeverConnect = {read=GetNeverConnect, write=SetNeverConnect, stored=false, default=0};
	__property bool UseOCI7 = {read=FUseOCI7, write=SetUseOCI7, default=0};
	__property Oraclasses::TOptimizerMode OptimizerMode = {read=FOptimizerMode, write=SetOptimizerMode, default=0};
	__property int ConnectionTimeout = {read=FConnectionTimeout, write=SetConnectionTimeout, default=0};
	__property bool StatementCache = {read=FStatementCache, write=SetStatementCache, default=0};
	__property int StatementCacheSize = {read=FStatementCacheSize, write=SetStatementCacheSize, default=20};
	__property System::UnicodeString ClientIdentifier = {read=FClientIdentifier, write=SetClientIdentifier};
	__property bool Net = {read=GetNet, write=SetNet, stored=false, default=0};
	__property bool Direct = {read=FDirect, write=SetDirect, default=0};
	__property DisconnectedMode = {default=0};
	__property KeepDesignConnected = {default=1};
	__property LocalFailover = {default=0};
	__property DefaultSortType = {default=2};
	__property EnableBCD = {default=0};
	__property EnableFMTBCD = {default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOraSessionOptions(void) { }
	
};


class DELPHICLASS TOraPoolingOptions;
class PASCALIMPLEMENTATION TOraPoolingOptions : public Dbaccess::TPoolingOptions
{
	typedef Dbaccess::TPoolingOptions inherited;
	
private:
	Oraconnectionpool::TOraPoolingType FPoolingType;
	System::UnicodeString FProxyUsername;
	System::UnicodeString FProxyPassword;
	void __fastcall SetPoolingType(Oraconnectionpool::TOraPoolingType Value);
	void __fastcall SetProxyUsername(System::UnicodeString Value);
	void __fastcall SetProxyPassword(System::UnicodeString Value);
	
public:
	__fastcall virtual TOraPoolingOptions(Dbaccess::TCustomDAConnection* Owner);
	
__published:
	__property Oraconnectionpool::TOraPoolingType PoolType = {read=FPoolingType, write=SetPoolingType, default=0};
	__property System::UnicodeString ProxyUsername = {read=FProxyUsername, write=SetProxyUsername};
	__property System::UnicodeString ProxyPassword = {read=FProxyPassword, write=SetProxyPassword};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOraPoolingOptions(void) { }
	
};


#pragma option push -b-
enum Ora__3 { smBasicStatistics, smTypicalStatistics, smAllStatistics, smBindVariables, smWaitEvents, smTimedStatistics };
#pragma option pop

typedef Set<Ora__3, smBasicStatistics, smTimedStatistics>  TSqlTraceMode;

#pragma option push -b-
enum Ora__4 { pmAllCalls, pmEnabledCalls, pmAllExceptions, pmEnabledExceptions, pmAllSql, pmEnabledSql, pmAllLines, pmEnabledLines };
#pragma option pop

typedef Set<Ora__4, pmAllCalls, pmEnabledLines>  TPlSqlTraceMode;

#pragma option push -b-
enum Ora__5 { tsSqlTrace, tsPlSqlTrace };
#pragma option pop

typedef Set<Ora__5, tsSqlTrace, tsPlSqlTrace>  TTraceState;

class DELPHICLASS TOraTrace;
class DELPHICLASS TOraSession;
class PASCALIMPLEMENTATION TOraTrace : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	TOraSession* FSession;
	bool FEnabled;
	TPlSqlTraceMode FPlSqlTraceMode;
	TSqlTraceMode FSqlTraceMode;
	bool FPlSqlTraceActive;
	bool FSqlTraceActive;
	System::UnicodeString FTraceFileIdentifier;
	int FMaxTraceFileSize;
	TTraceState __fastcall GetState(void);
	void __fastcall SetSession(TOraSession* Value);
	void __fastcall SetEnabled(bool Value);
	void __fastcall SetTraceFileIdentifier(const System::UnicodeString Value);
	void __fastcall SetMaxTraceFileSize(int Value);
	void __fastcall SetSqlTraceMode(TSqlTraceMode Value);
	
protected:
	bool FDesignCreate;
	virtual void __fastcall Loaded(void);
	void __fastcall InternalSetTraceFileIdentifier(void);
	void __fastcall InternalSetMaxTraceFileSize(void);
	void __fastcall InternalSetSqlTraceMode(void);
	void __fastcall StartTrace(void);
	void __fastcall StopTrace(void);
	
public:
	__fastcall virtual TOraTrace(Classes::TComponent* AOwner);
	__fastcall virtual ~TOraTrace(void);
	void __fastcall PlSqlTraceStart(void);
	void __fastcall PlSqlTraceStop(void);
	void __fastcall PlSqlTracePause(void);
	void __fastcall PlSqlTraceResume(void);
	void __fastcall PlSqlTraceComment(const System::UnicodeString Comment);
	void __fastcall PlSqlTraceLimit(int Limit = 0x2000);
	int __fastcall PlSqlTraceRunNumber(void);
	void __fastcall SqlTraceStart(void);
	void __fastcall SqlTraceStop(void);
	System::UnicodeString __fastcall GetTraceFileName(void);
	int __fastcall GetSessionPID(void);
	__property TTraceState State = {read=GetState, nodefault};
	
__published:
	__property TOraSession* Session = {read=FSession, write=SetSession};
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property TSqlTraceMode SqlTraceMode = {read=FSqlTraceMode, write=SetSqlTraceMode, default=34};
	__property TPlSqlTraceMode PlSqlTraceMode = {read=FPlSqlTraceMode, write=FPlSqlTraceMode, default=0};
	__property System::UnicodeString TraceFileIdentifier = {read=FTraceFileIdentifier, write=SetTraceFileIdentifier};
	__property int MaxTraceFileSize = {read=FMaxTraceFileSize, write=SetMaxTraceFileSize, default=0};
};


class DELPHICLASS TOraSQL;
class DELPHICLASS TOraParam;
class PASCALIMPLEMENTATION TOraSession : public Dbaccess::TCustomDAConnection
{
	typedef Dbaccess::TCustomDAConnection inherited;
	
private:
	TOraSessionOptions* FOptions;
	TOraPoolingOptions* FPoolingOptions;
	System::UnicodeString FHomeName;
	bool FThreadSafety;
	Oraclasses::TConnectMode FConnectMode;
	Oracall::TOCICallStyle FOCICallStyle;
	TConnectChangeEvent FOnConnectChange;
	System::UnicodeString FInternalName;
	TFailoverEvent FFailoverEvent;
	System::UnicodeString FSchema;
	TOraSession* FProxySession;
	TOraTrace* FTrace;
	void __fastcall SetThreadSafety(bool Value);
	System::UnicodeString __fastcall GetOracleVersion(void);
	TOraSQL* __fastcall GetSQL(void);
	Oracall::PCDA __fastcall GetLDA(void);
	void * __fastcall GetOCISvcCtx(void);
	void __fastcall SetOCISvcCtx(void * Value);
	Oracall::TOCICallStyle __fastcall GetOCICallStyle(void);
	void __fastcall SetOCICallStyle(Oracall::TOCICallStyle Value);
	HIDESBASE void __fastcall SetOptions(TOraSessionOptions* Value);
	HIDESBASE void __fastcall SetPoolingOptions(TOraPoolingOptions* Value);
	int __fastcall GetLastError(void);
	void __fastcall SetLastError(int Value);
	void __fastcall SetHomeName(System::UnicodeString Value);
	Oracall::TOracleHome __fastcall GetHome(void);
	void __fastcall SetHome(Oracall::TOracleHome Value);
	bool __fastcall GetConnectPrompt(void);
	void __fastcall SetConnectPrompt(bool Value);
	void __fastcall SetConnectMode(Oraclasses::TConnectMode Value);
	System::UnicodeString __fastcall GetSchema(void);
	void __fastcall SetSchema(System::UnicodeString Value);
	bool __fastcall IsSchemaStored(void);
	TOraSession* __fastcall GetProxySession(void);
	void __fastcall SetProxySession(TOraSession* Value);
	void __fastcall SetInternalName(const System::UnicodeString AValue);
	void __fastcall GetObjectList(Classes::TStrings* List, System::UnicodeString SQL);
	void __fastcall CheckDirect(void);
	void __fastcall SetTrace(TOraTrace* Value);
	
protected:
	Oraclasses::TOCIConnection* FIConnection;
	Classes::TList* FChangeNotifications;
	virtual void __fastcall CreateIConnection(void);
	virtual Craccess::TCRConnectionClass __fastcall GetIConnectionClass(void);
	virtual Craccess::TCRCommandClass __fastcall GetICommandClass(void);
	virtual Craccess::TCRRecordSetClass __fastcall GetIRecordSetClass(void);
	virtual Craccess::TCRMetaDataClass __fastcall GetIMetaDataClass(void);
	Oraclasses::TOCIConnection* __fastcall GetOCIConnection(void);
	virtual void __fastcall SetIConnection(Craccess::TCRConnection* Value);
	virtual void __fastcall DoConnect(void);
	virtual void __fastcall DoDisconnect(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	System::UnicodeString __fastcall GetCompilationError(System::UnicodeString SQL);
	virtual System::TClass __fastcall SQLMonitorClass(void);
	virtual Dbaccess::TConnectDialogClass __fastcall ConnectDialogClass(void);
	virtual Dbaccess::TDAConnectionOptions* __fastcall CreateOptions(void);
	virtual Dbaccess::TPoolingOptions* __fastcall CreatePoolingOptions(void);
	virtual void __fastcall SetConnected(bool Value);
	virtual System::UnicodeString __fastcall GetConnectString(void);
	virtual void __fastcall SetConnectString(System::UnicodeString Value);
	void __fastcall DoOnFailover(unsigned FailoverState, unsigned FailoverType, bool &Retry);
	System::UnicodeString __fastcall GetCachedSchema(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual void __fastcall AssignConnectOptions(Dbaccess::TCustomDAConnection* Source);
	__property TOraTrace* Trace = {read=FTrace, write=SetTrace};
	
public:
	__fastcall virtual TOraSession(Classes::TComponent* Owner);
	__fastcall virtual ~TOraSession(void);
	virtual void __fastcall StartTransaction(void)/* overload */;
	HIDESBASE void __fastcall StartTransaction(TOraIsolationLevel IsolationLevel, const System::UnicodeString RollbackSegment = L"", const System::UnicodeString Name = L"")/* overload */;
	void __fastcall Savepoint(const System::UnicodeString Savepoint);
	void __fastcall RollbackToSavepoint(const System::UnicodeString Savepoint);
	HIDESBASE TOraParam* __fastcall ParamByName(System::UnicodeString Name);
	void __fastcall Ping(void);
	void __fastcall ClearStatementCache(void);
	HIDESBASE void __fastcall AssignConnect(TOraSession* Source);
	virtual Dbaccess::TCustomDADataSet* __fastcall CreateDataSet(void);
	virtual Dbaccess::TCustomDASQL* __fastcall CreateSQL(void);
	virtual Dbaccess::TDATransaction* __fastcall CreateTransaction(void);
	virtual Dbaccess::TDAMetaData* __fastcall CreateMetaData(void);
	void __fastcall ChangePassword(System::UnicodeString NewPassword);
	void __fastcall GetSequenceNames(Classes::TStrings* List, bool AllSequences = false);
	__property Oracall::PCDA LDA = {read=GetLDA};
	__property void * OCISvcCtx = {read=GetOCISvcCtx, write=SetOCISvcCtx};
	__property Oracall::TOCICallStyle OCICallStyle = {read=GetOCICallStyle, write=SetOCICallStyle, nodefault};
	__property int LastError = {read=GetLastError, write=SetLastError, nodefault};
	__property System::UnicodeString OracleVersion = {read=GetOracleVersion};
	__property TOraSQL* SQL = {read=GetSQL};
	__property TOraSQL* OraSQL = {read=GetSQL};
	__property System::UnicodeString InternalName = {read=FInternalName, write=SetInternalName};
	__property TOraSession* ProxySession = {read=GetProxySession, write=SetProxySession};
	
__published:
	__property bool ThreadSafety = {read=FThreadSafety, write=SetThreadSafety, default=1};
	__property bool ConnectPrompt = {read=GetConnectPrompt, write=SetConnectPrompt, stored=false, default=1};
	__property Oraclasses::TConnectMode ConnectMode = {read=FConnectMode, write=SetConnectMode, default=0};
	__property TOraSessionOptions* Options = {read=FOptions, write=SetOptions};
	__property TOraPoolingOptions* PoolingOptions = {read=FPoolingOptions, write=SetPoolingOptions};
	__property Pooling = {default=0};
	__property Debug = {default=0};
	__property Username;
	__property Password;
	__property Server;
	__property ConnectString;
	__property AutoCommit = {default=1};
	__property Connected = {stored=IsConnectedStored, default=0};
	__property ConnectDialog;
	__property LoginPrompt = {default=1};
	__property AfterConnect;
	__property BeforeConnect;
	__property AfterDisconnect;
	__property BeforeDisconnect;
	__property OnLogin;
	__property OnError;
	__property OnConnectionLost;
	__property TConnectChangeEvent OnConnectChange = {read=FOnConnectChange, write=FOnConnectChange};
	__property TFailoverEvent OnFailover = {read=FFailoverEvent, write=FFailoverEvent};
	__property Oracall::TOracleHome Home = {read=GetHome, write=SetHome, stored=false, default=0};
	__property System::UnicodeString HomeName = {read=FHomeName, write=SetHomeName};
	__property System::UnicodeString Schema = {read=GetSchema, write=SetSchema, stored=IsSchemaStored};
};


class DELPHICLASS TSessionList;
class PASCALIMPLEMENTATION TSessionList : public Classes::TThreadList
{
	typedef Classes::TThreadList inherited;
	
public:
	TOraSession* operator[](int i) { return Items[i]; }
	
private:
	int __fastcall GetCount(void);
	TOraSession* __fastcall GetSession(int i);
	
public:
	__property int Count = {read=GetCount, nodefault};
	__property TOraSession* Items[int i] = {read=GetSession/*, default*/};
public:
	/* TThreadList.Create */ inline __fastcall TSessionList(void) : Classes::TThreadList() { }
	/* TThreadList.Destroy */ inline __fastcall virtual ~TSessionList(void) { }
	
};


typedef System::Variant *VariantPtr;

class PASCALIMPLEMENTATION TOraParam : public Dbaccess::TDAParam
{
	typedef Dbaccess::TDAParam inherited;
	
private:
	bool FTable;
	bool FHasDefault;
	bool FIsResult;
	System::Variant FDataPtr;
	Oraclasses::TOraParamDesc* FParamDescRef;
	VariantPtr __fastcall GetVarArrayPtr(void);
	void __fastcall CheckIndex(int Index);
	bool __fastcall GetTable(void);
	void __fastcall SetTable(bool Value);
	int __fastcall GetTableLength(void);
	void __fastcall SetTableLength(int Value);
	HIDESBASE Oraclasses::TOraCursor* __fastcall GetAsCursor(void);
	HIDESBASE void __fastcall SetAsCursor(Oraclasses::TOraCursor* Value);
	Oraclasses::TOraLob* __fastcall GetAsOraBlob(void);
	void __fastcall SetAsOraBlob(Oraclasses::TOraLob* Value);
	Oraclasses::TOraLob* __fastcall GetAsOraClob(void);
	void __fastcall SetAsOraClob(Oraclasses::TOraLob* Value);
	Oraclasses::TOraFile* __fastcall GetAsBFile(void);
	void __fastcall SetAsBFile(Oraclasses::TOraFile* Value);
	HIDESBASE Oraobjects::TOraObject* __fastcall GetAsObject(void);
	HIDESBASE void __fastcall SetAsObject(Oraobjects::TOraObject* Value);
	Oraobjects::TOraXML* __fastcall GetAsXML(void);
	void __fastcall SetAsXML(Oraobjects::TOraXML* Value);
	Oraobjects::TOraRef* __fastcall GetAsRef(void);
	void __fastcall SetAsRef(Oraobjects::TOraRef* Value);
	Oraobjects::TOraArray* __fastcall GetAsArray(void);
	void __fastcall SetAsArray(Oraobjects::TOraArray* Value);
	Oraobjects::TOraNestTable* __fastcall GetAsTable(void);
	void __fastcall SetAsTable(Oraobjects::TOraNestTable* Value);
	Oraclasses::TOraTimeStamp* __fastcall GetAsTimeStamp(void);
	void __fastcall SetAsTimeStamp(Oraclasses::TOraTimeStamp* Value);
	Oraclasses::TOraInterval* __fastcall GetAsInterval(void);
	void __fastcall SetAsInterval(Oraclasses::TOraInterval* Value);
	Oraclasses::TOraNumber* __fastcall GetAsNumber(void);
	void __fastcall SetAsNumber(Oraclasses::TOraNumber* Value);
	System::TDateTime __fastcall GetItemAsDateTime(int Index);
	void __fastcall SetItemAsDateTime(int Index, System::TDateTime Value);
	double __fastcall GetItemAsFloat(int Index);
	void __fastcall SetItemAsFloat(int Index, double Value);
	int __fastcall GetItemAsInteger(int Index);
	void __fastcall SetItemAsInteger(int Index, int Value);
	System::UnicodeString __fastcall GetItemAsString(int Index);
	void __fastcall SetItemAsString(int Index, System::UnicodeString Value);
	Oraclasses::TOraTimeStamp* __fastcall GetItemAsTimeStamp(int Index);
	void __fastcall SetItemAsTimeStamp(int Index, Oraclasses::TOraTimeStamp* Value);
	Oraclasses::TOraInterval* __fastcall GetItemAsInterval(int Index);
	void __fastcall SetItemAsInterval(int Index, Oraclasses::TOraInterval* Value);
	System::Variant __fastcall GetItemAsVariant(int Index);
	void __fastcall SetItemAsVariant(int Index, const System::Variant &Value);
	Memdata::TSharedObject* __fastcall GetItemAsObject(int Index);
	void __fastcall SetItemAsObject(int Index, Memdata::TSharedObject* Value);
	bool __fastcall GetItemIsNull(int Index);
	void __fastcall SetItemText(int Index, System::UnicodeString Value);
	void __fastcall ReadHasDefault(Classes::TReader* Reader);
	void __fastcall WriteHasDefault(Classes::TWriter* Writer);
	void __fastcall ReadIsResult(Classes::TReader* Reader);
	void __fastcall WriteIsResult(Classes::TWriter* Writer);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual bool __fastcall IsObjectDataType(Db::TFieldType DataType)/* overload */;
	HIDESBASE bool __fastcall IsObjectDataType(void)/* overload */;
	virtual bool __fastcall IsBlobDataType(Db::TFieldType DataType)/* overload */;
	virtual bool __fastcall IsArray(void);
	virtual void __fastcall SetDataType(Db::TFieldType Value);
	virtual int __fastcall GetSize(void);
	virtual System::UnicodeString __fastcall GetAsString(void);
	virtual void __fastcall SetAsString(const System::UnicodeString Value);
	virtual int __fastcall GetAsInteger(void);
	virtual void __fastcall SetAsInteger(int Value);
	virtual void __fastcall SetAsSmallInt(int Value);
	virtual void __fastcall SetAsWord(int Value);
	virtual double __fastcall GetAsFloat(void);
	virtual void __fastcall SetAsFloat(double Value);
	virtual __int64 __fastcall GetAsLargeInt(void);
	virtual void __fastcall SetAsLargeInt(const __int64 Value);
	virtual void __fastcall SetAsShortInt(int Value);
	virtual void __fastcall SetAsByte(int Value);
	virtual System::Variant __fastcall GetAsVariant(void);
	virtual void __fastcall SetAsVariant(const System::Variant &Value);
	virtual Sqltimst::TSQLTimeStamp __fastcall GetAsSQLTimeStamp(void);
	virtual void __fastcall SetAsSQLTimeStamp(const Sqltimst::TSQLTimeStamp &Value);
	virtual bool __fastcall GetIsNull(void);
	virtual void __fastcall SetNational(bool Value);
	virtual void __fastcall CreateObject(void);
	void __fastcall FreeItems(void);
	__property ParamObject;
	
public:
	__fastcall virtual TOraParam(Classes::TCollection* Collection)/* overload */;
	__fastcall virtual ~TOraParam(void);
	virtual void __fastcall Clear(void);
	void __fastcall ItemClear(int Index);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	virtual void __fastcall AssignFieldValue(Db::TField* Field, const System::Variant &Value);
	HIDESBASE void __fastcall SetBlobData(void * Buffer, int Size);
	__property Oraclasses::TOraCursor* AsCursor = {read=GetAsCursor, write=SetAsCursor};
	__property Oraclasses::TOraLob* AsOraBlob = {read=GetAsOraBlob, write=SetAsOraBlob};
	__property Oraclasses::TOraLob* AsOraClob = {read=GetAsOraClob, write=SetAsOraClob};
	__property Oraclasses::TOraFile* AsBFile = {read=GetAsBFile, write=SetAsBFile};
	__property Oraobjects::TOraObject* AsObject = {read=GetAsObject, write=SetAsObject};
	__property Oraobjects::TOraXML* AsXML = {read=GetAsXML, write=SetAsXML};
	__property Oraobjects::TOraRef* AsRef = {read=GetAsRef, write=SetAsRef};
	__property Oraobjects::TOraArray* AsArray = {read=GetAsArray, write=SetAsArray};
	__property Oraobjects::TOraNestTable* AsTable = {read=GetAsTable, write=SetAsTable};
	__property Oraclasses::TOraTimeStamp* AsTimeStamp = {read=GetAsTimeStamp, write=SetAsTimeStamp};
	__property Oraclasses::TOraInterval* AsInterval = {read=GetAsInterval, write=SetAsInterval};
	__property Oraclasses::TOraNumber* AsNumber = {read=GetAsNumber, write=SetAsNumber};
	__property System::TDateTime ItemAsDateTime[int Index] = {read=GetItemAsDateTime, write=SetItemAsDateTime};
	__property double ItemAsFloat[int Index] = {read=GetItemAsFloat, write=SetItemAsFloat};
	__property int ItemAsInteger[int Index] = {read=GetItemAsInteger, write=SetItemAsInteger};
	__property System::UnicodeString ItemAsString[int Index] = {read=GetItemAsString, write=SetItemAsString};
	__property System::Variant ItemValue[int Index] = {read=GetItemAsVariant, write=SetItemAsVariant};
	__property bool ItemIsNull[int Index] = {read=GetItemIsNull};
	__property System::UnicodeString ItemText[int Index] = {read=GetItemAsString, write=SetItemText};
	__property Oraclasses::TOraTimeStamp* ItemAsTimeStamp[int Index] = {read=GetItemAsTimeStamp, write=SetItemAsTimeStamp};
	__property Oraclasses::TOraInterval* ItemAsInterval[int Index] = {read=GetItemAsInterval, write=SetItemAsInterval};
	__property Oraclasses::TOraLob* AsBLOBLocator = {read=GetAsOraBlob, write=SetAsOraBlob};
	__property Oraclasses::TOraLob* AsCLOBLocator = {read=GetAsOraClob, write=SetAsOraClob};
	
__published:
	__property National = {default=0};
	__property bool Table = {read=GetTable, write=SetTable, default=0};
	__property int Length = {read=GetTableLength, write=SetTableLength, default=1};
	
/* Hoisted overloads: */
	
protected:
	inline bool __fastcall  IsBlobDataType(void){ return Dbaccess::TDAParam::IsBlobDataType(); }
	
};


class DELPHICLASS TOraParams;
class PASCALIMPLEMENTATION TOraParams : public Dbaccess::TDAParams
{
	typedef Dbaccess::TDAParams inherited;
	
public:
	TOraParam* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE void __fastcall ReadBinaryData(Classes::TStream* Stream);
	HIDESBASE TOraParam* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TOraParam* Value);
	
protected:
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	
public:
	__fastcall TOraParams(Classes::TPersistent* Owner);
	HIDESBASE TOraParam* __fastcall ParamByName(const System::UnicodeString Value);
	HIDESBASE TOraParam* __fastcall FindParam(const System::UnicodeString Value);
	__property TOraParam* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TOraParams(void) { }
	
};


class DELPHICLASS TCursorField;
class PASCALIMPLEMENTATION TCursorField : public Dbaccess::TDACursorField
{
	typedef Dbaccess::TDACursorField inherited;
	
private:
	HIDESBASE Oraclasses::TOraCursor* __fastcall GetAsCursor(void);
	
public:
	__property Oraclasses::TOraCursor* AsCursor = {read=GetAsCursor};
public:
	/* TDACursorField.Create */ inline __fastcall virtual TCursorField(Classes::TComponent* Owner) : Dbaccess::TDACursorField(Owner) { }
	
public:
	/* TField.Destroy */ inline __fastcall virtual ~TCursorField(void) { }
	
};


class DELPHICLASS TBFileField;
class PASCALIMPLEMENTATION TBFileField : public Db::TBlobField
{
	typedef Db::TBlobField inherited;
	
private:
	bool FAutoRefresh;
	Oraclasses::TOraFile* __fastcall GetAsFile(void);
	HIDESBASE Db::TBlobType __fastcall GetBlobType(void);
	HIDESBASE void __fastcall SetBlobType(Db::TBlobType Value);
	System::UnicodeString __fastcall GetFileDir(void);
	void __fastcall SetFileDir(const System::UnicodeString Value);
	System::UnicodeString __fastcall GetFileName(void);
	void __fastcall SetFileName(const System::UnicodeString Value);
	bool __fastcall GetExists(void);
	
protected:
	virtual bool __fastcall GetCanModify(void);
	virtual System::UnicodeString __fastcall GetClassDesc(void);
	bool __fastcall GetValue(Oraclasses::TOraFile* &Value);
	virtual bool __fastcall GetIsNull(void);
	
public:
	__fastcall virtual TBFileField(Classes::TComponent* Owner);
	void __fastcall Refresh(void);
	__property System::UnicodeString FileDir = {read=GetFileDir, write=SetFileDir};
	__property System::UnicodeString FileName = {read=GetFileName, write=SetFileName};
	__property bool Exists = {read=GetExists, nodefault};
	__property Oraclasses::TOraFile* AsFile = {read=GetAsFile};
	
__published:
	__property Db::TBlobType BlobType = {read=GetBlobType, write=SetBlobType, nodefault};
	__property bool AutoRefresh = {read=FAutoRefresh, write=FAutoRefresh, default=1};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TBFileField(void) { }
	
};


class DELPHICLASS TOraDataSetField;
class PASCALIMPLEMENTATION TOraDataSetField : public Db::TDataSetField
{
	typedef Db::TDataSetField inherited;
	
private:
	bool FModified;
	
protected:
	virtual void __fastcall FreeBuffers(void);
	virtual System::UnicodeString __fastcall GetAsString(void);
	
public:
	__property bool Modified = {read=FModified, write=FModified, nodefault};
public:
	/* TDataSetField.Create */ inline __fastcall virtual TOraDataSetField(Classes::TComponent* AOwner) : Db::TDataSetField(AOwner) { }
	/* TDataSetField.Destroy */ inline __fastcall virtual ~TOraDataSetField(void) { }
	
};


class DELPHICLASS TOraReferenceField;
class PASCALIMPLEMENTATION TOraReferenceField : public Db::TReferenceField
{
	typedef Db::TReferenceField inherited;
	
private:
	bool FModified;
	
protected:
	virtual void __fastcall FreeBuffers(void);
	virtual System::UnicodeString __fastcall GetAsString(void);
	
public:
	__property bool Modified = {read=FModified, write=FModified, nodefault};
public:
	/* TReferenceField.Create */ inline __fastcall virtual TOraReferenceField(Classes::TComponent* AOwner) : Db::TReferenceField(AOwner) { }
	
public:
	/* TDataSetField.Destroy */ inline __fastcall virtual ~TOraReferenceField(void) { }
	
};


class DELPHICLASS TLabelField;
class PASCALIMPLEMENTATION TLabelField : public Db::TField
{
	typedef Db::TField inherited;
	
protected:
	virtual System::Variant __fastcall GetAsVariant(void);
	
public:
	__fastcall virtual TLabelField(Classes::TComponent* Owner);
public:
	/* TField.Destroy */ inline __fastcall virtual ~TLabelField(void) { }
	
};


class DELPHICLASS TOraTimeStampField;
class PASCALIMPLEMENTATION TOraTimeStampField : public Db::TField
{
	typedef Db::TField inherited;
	
private:
	System::UnicodeString FFormat;
	
protected:
	virtual System::TDateTime __fastcall GetAsDateTime(void);
	virtual void __fastcall SetAsDateTime(System::TDateTime Value);
	virtual System::UnicodeString __fastcall GetAsString(void);
	virtual void __fastcall SetAsString(const System::UnicodeString Value);
	virtual System::Variant __fastcall GetAsVariant(void);
	virtual void __fastcall SetVarValue(const System::Variant &Value);
	virtual Sqltimst::TSQLTimeStamp __fastcall GetAsSQLTimeStamp(void);
	virtual void __fastcall SetAsSQLTimeStamp(const Sqltimst::TSQLTimeStamp &Value);
	Oraclasses::TOraTimeStamp* __fastcall GetAsTimeStamp(void);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadDataType(Classes::TReader* Reader);
	void __fastcall WriteDataType(Classes::TWriter* Writer);
	virtual bool __fastcall GetIsNull(void);
	
public:
	__fastcall virtual TOraTimeStampField(Classes::TComponent* Owner);
	__property Oraclasses::TOraTimeStamp* AsTimeStamp = {read=GetAsTimeStamp};
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	
__published:
	__property System::UnicodeString Format = {read=FFormat, write=FFormat};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TOraTimeStampField(void) { }
	
};


class DELPHICLASS TOraIntervalField;
class PASCALIMPLEMENTATION TOraIntervalField : public Db::TField
{
	typedef Db::TField inherited;
	
private:
	int FLeadPrecision;
	int FFracPrecision;
	
protected:
	virtual System::UnicodeString __fastcall GetAsString(void);
	virtual void __fastcall SetAsString(const System::UnicodeString Value);
	virtual System::Variant __fastcall GetAsVariant(void);
	virtual void __fastcall SetVarValue(const System::Variant &Value);
	Oraclasses::TOraInterval* __fastcall GetAsInterval(void);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadDataType(Classes::TReader* Reader);
	void __fastcall WriteDataType(Classes::TWriter* Writer);
	virtual bool __fastcall GetIsNull(void);
	
public:
	__fastcall virtual TOraIntervalField(Classes::TComponent* Owner);
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	__property Oraclasses::TOraInterval* AsInterval = {read=GetAsInterval};
	
__published:
	__property int LeadPrecision = {read=FLeadPrecision, write=FLeadPrecision, default=2};
	__property int FracPrecision = {read=FFracPrecision, write=FFracPrecision, default=6};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TOraIntervalField(void) { }
	
};


class DELPHICLASS TOraNumberField;
class PASCALIMPLEMENTATION TOraNumberField : public Db::TNumericField
{
	typedef Db::TNumericField inherited;
	
private:
	Oraclasses::TOraNumber* __fastcall GetAsNumber(void);
	
protected:
	virtual System::Variant __fastcall GetAsVariant(void);
	virtual void __fastcall SetVarValue(const System::Variant &Value);
	virtual System::UnicodeString __fastcall GetAsString(void);
	virtual void __fastcall SetAsString(const System::UnicodeString Value);
	virtual int __fastcall GetAsInteger(void);
	virtual void __fastcall SetAsInteger(int Value);
	virtual __int64 __fastcall GetAsLargeInt(void);
	virtual void __fastcall SetAsLargeInt(__int64 Value);
	virtual double __fastcall GetAsFloat(void);
	virtual void __fastcall SetAsFloat(double Value);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadDataType(Classes::TReader* Reader);
	void __fastcall WriteDataType(Classes::TWriter* Writer);
	virtual bool __fastcall GetIsNull(void);
	
public:
	__fastcall virtual TOraNumberField(Classes::TComponent* Owner);
	virtual bool __fastcall IsValidChar(System::WideChar InputChar);
	__property Oraclasses::TOraNumber* AsNumber = {read=GetAsNumber};
	__property __int64 AsLargeInt = {read=GetAsLargeInt, write=SetAsLargeInt};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TOraNumberField(void) { }
	
};


class DELPHICLASS TOraXMLField;
class PASCALIMPLEMENTATION TOraXMLField : public Db::TField
{
	typedef Db::TField inherited;
	
protected:
	virtual System::UnicodeString __fastcall GetAsString(void);
	virtual void __fastcall SetAsString(const System::UnicodeString Value);
	virtual System::Variant __fastcall GetAsVariant(void);
	virtual void __fastcall SetVarValue(const System::Variant &Value);
	Oraobjects::TOraXML* __fastcall GetAsXML(void);
	virtual void __fastcall GetText(System::UnicodeString &Text, bool DisplayText);
	virtual void __fastcall SetText(const System::UnicodeString Value);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadDataType(Classes::TReader* Reader);
	void __fastcall WriteDataType(Classes::TWriter* Writer);
	virtual bool __fastcall GetIsNull(void);
	virtual System::UnicodeString __fastcall GetClassDesc(void);
	
public:
	__fastcall virtual TOraXMLField(Classes::TComponent* Owner);
	virtual void __fastcall Clear(void);
	__classmethod virtual bool __fastcall IsBlob();
	virtual void __fastcall SetFieldType(Db::TFieldType Value);
	__property Oraobjects::TOraXML* AsXML = {read=GetAsXML};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TOraXMLField(void) { }
	
};


#pragma option push -b-
enum TLockMode { lmNone, lmLockImmediate, lmLockDelayed };
#pragma option pop

#pragma option push -b-
enum TRefreshMode { rmNone, rmAfterInsert, rmAfterUpdate, rmAlways };
#pragma option pop

class DELPHICLASS TOraDataSetOptionsDS;
class PASCALIMPLEMENTATION TOraDataSetOptionsDS : public Dbaccess::TDADataSetOptions
{
	typedef Dbaccess::TDADataSetOptions inherited;
	
private:
	bool FAutoClose;
	bool FFieldsAsString;
	bool FDeferredLobRead;
	bool FCacheLobs;
	bool FScrollableCursor;
	bool FRawAsString;
	bool __fastcall GetKeepPrepared(void);
	void __fastcall SetKeepPrepared(bool Value);
	void __fastcall SetAutoClose(bool Value);
	void __fastcall SetFieldsAsString(bool Value);
	void __fastcall SetDeferredLobRead(bool Value);
	void __fastcall SetCacheLobs(bool Value);
	void __fastcall SetScrollableCursor(bool Value);
	void __fastcall SetRawAsString(bool Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TOraDataSetOptionsDS(Dbaccess::TCustomDADataSet* Owner);
	
__published:
	__property bool KeepPrepared = {read=GetKeepPrepared, write=SetKeepPrepared, stored=false, nodefault};
	__property bool AutoClose = {read=FAutoClose, write=SetAutoClose, stored=false, default=0};
	__property bool FieldsAsString = {read=FFieldsAsString, write=SetFieldsAsString, stored=false, default=0};
	__property bool DeferredLobRead = {read=FDeferredLobRead, write=SetDeferredLobRead, stored=false, default=0};
	__property bool CacheLobs = {read=FCacheLobs, write=SetCacheLobs, stored=false, default=1};
	__property bool ScrollableCursor = {read=FScrollableCursor, write=SetScrollableCursor, stored=false, default=0};
	__property bool RawAsString = {read=FRawAsString, write=SetRawAsString, stored=false, default=0};
	__property FieldsOrigin = {stored=false, default=0};
	__property DefaultValues = {stored=false, default=0};
	__property RequiredFields = {stored=false, default=1};
	__property StrictUpdate = {stored=false, default=1};
	__property NumberRange = {stored=false, default=0};
	__property QueryRecCount = {stored=false, default=0};
	__property AutoPrepare = {stored=false, default=0};
	__property ReturnParams = {stored=false, default=0};
	__property TrimFixedChar = {stored=false, default=1};
	__property LongStrings = {stored=false, default=1};
	__property RemoveOnRefresh = {stored=false, default=1};
	__property FlatBuffers = {stored=false, default=0};
	__property DetailDelay = {stored=false, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOraDataSetOptionsDS(void) { }
	
};


class DELPHICLASS TOraDataSetOptions;
class PASCALIMPLEMENTATION TOraDataSetOptions : public TOraDataSetOptionsDS
{
	typedef TOraDataSetOptionsDS inherited;
	
private:
	bool FTemporaryLobUpdate;
	bool FReflectChangeNotify;
	bool FStatementCache;
	int FPrefetchRows;
	void __fastcall SetTemporaryLobUpdate(bool Value);
	void __fastcall SetStatementCache(bool Value);
	void __fastcall SetPrefetchRows(int Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TOraDataSetOptions(Dbaccess::TCustomDADataSet* Owner);
	
__published:
	__property AutoClose = {stored=true, default=0};
	__property FieldsOrigin = {stored=true, default=0};
	__property DefaultValues = {stored=true, default=0};
	__property FieldsAsString = {stored=true, default=0};
	__property DeferredLobRead = {stored=true, default=0};
	__property CacheLobs = {stored=true, default=1};
	__property ScrollableCursor = {stored=true, default=0};
	__property RawAsString = {stored=true, default=0};
	__property RequiredFields = {stored=true, default=1};
	__property StrictUpdate = {stored=true, default=1};
	__property NumberRange = {stored=true, default=0};
	__property QueryRecCount = {stored=true, default=0};
	__property AutoPrepare = {stored=true, default=0};
	__property ReturnParams = {stored=true, default=0};
	__property TrimFixedChar = {stored=true, default=1};
	__property LongStrings = {stored=true, default=1};
	__property RemoveOnRefresh = {stored=true, default=1};
	__property FlatBuffers = {stored=true, default=0};
	__property DetailDelay = {stored=true, default=0};
	__property bool TemporaryLobUpdate = {read=FTemporaryLobUpdate, write=SetTemporaryLobUpdate, default=0};
	__property bool ReflectChangeNotify = {read=FReflectChangeNotify, write=FReflectChangeNotify, default=0};
	__property bool StatementCache = {read=FStatementCache, write=SetStatementCache, default=0};
	__property int PrefetchRows = {read=FPrefetchRows, write=SetPrefetchRows, default=1};
	__property SetFieldsReadOnly = {default=0};
	__property LocalMasterDetail = {default=0};
	__property CacheCalcFields = {default=0};
	__property FullRefresh = {default=0};
	__property CompressBlobMode = {default=0};
	__property UpdateBatchSize = {default=1};
	__property UpdateAllFields = {default=0};
	__property PrepareUpdateSQL = {default=0};
	__property ExtendedFieldsInfo = {default=0};
	__property EnableBCD = {default=0};
	__property EnableFMTBCD = {default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TOraDataSetOptions(void) { }
	
};


class DELPHICLASS TOraSQLGenerator;
class PASCALIMPLEMENTATION TOraSQLGenerator : public Oraservices::TCustomOraSQLGenerator
{
	typedef Oraservices::TCustomOraSQLGenerator inherited;
	
protected:
	virtual bool __fastcall FieldModified(Craccess::TCRFieldDesc* FieldDesc)/* overload */;
public:
	/* TCustomOraSQLGenerator.Create */ inline __fastcall virtual TOraSQLGenerator(Dbaccess::TDADataSetService* Owner) : Oraservices::TCustomOraSQLGenerator(Owner) { }
	
public:
	/* TDASQLGenerator.Destroy */ inline __fastcall virtual ~TOraSQLGenerator(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline bool __fastcall  FieldModified(Craccess::TCRFieldDesc* FieldDesc, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf){ return Dbaccess::TDASQLGenerator::FieldModified(FieldDesc, Data, OldRecBuf, NewRecBuf); }
	
};


class DELPHICLASS TOraDataSetUpdater;
class PASCALIMPLEMENTATION TOraDataSetUpdater : public Oraservices::TCustomOraDataSetUpdater
{
	typedef Oraservices::TCustomOraDataSetUpdater inherited;
	
protected:
	virtual void __fastcall SetUpdateQueryOptions(const Dbaccess::TStatementType StatementType);
	virtual bool __fastcall PerformRefreshRecord(void);
	virtual void __fastcall SetSavepoint(void);
	virtual bool __fastcall PerformUnLock(void);
public:
	/* TCustomOraDataSetUpdater.Create */ inline __fastcall virtual TOraDataSetUpdater(Memds::TDataSetService* AOwner) : Oraservices::TCustomOraDataSetUpdater(AOwner) { }
	
public:
	/* TDADataSetUpdater.Destroy */ inline __fastcall virtual ~TOraDataSetUpdater(void) { }
	
};


class DELPHICLASS TOraDataSetService;
class PASCALIMPLEMENTATION TOraDataSetService : public Oraservices::TCustomOraDataSetService
{
	typedef Oraservices::TCustomOraDataSetService inherited;
	
protected:
	virtual void __fastcall CreateDataSetUpdater(void);
	virtual void __fastcall CreateSQLGenerator(void);
	virtual void __fastcall SetDataSetUpdater(Memds::TDataSetUpdater* Value);
	virtual bool __fastcall CompatibilityMode(void);
	virtual Db::TFieldClass __fastcall GetFieldClass(Db::TFieldType FieldType);
public:
	/* TDADataSetService.Create */ inline __fastcall virtual TOraDataSetService(Memds::TMemDataSet* AOwner) : Oraservices::TCustomOraDataSetService(AOwner) { }
	/* TDADataSetService.Destroy */ inline __fastcall virtual ~TOraDataSetService(void) { }
	
};


typedef void __fastcall (__closure *TOraChangeNotificationEvent)(System::TObject* Sender, Oraclasses::TChangeNotifyEventType NotifyType, Oraclasses::TNotifyTableChanges* TableChanges);

class DELPHICLASS TOraChangeNotification;
class PASCALIMPLEMENTATION TOraChangeNotification : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	TOraSession* FSession;
	bool FEnabled;
	bool FPersistent;
	int FTimeOut;
	Oracall::TChangeNotifyDMLOperations FOperations;
	Classes::TList* FDatasets;
	TOraChangeNotificationEvent FOnChange;
	void __fastcall SetSession(TOraSession* Value);
	void __fastcall SetEnabled(bool Value);
	void __fastcall SetPersistent(bool Value);
	void __fastcall SetTimeOut(int Value);
	void __fastcall SetOperations(Oracall::TChangeNotifyDMLOperations Value);
	bool __fastcall GetActive(void);
	int __fastcall GetPort(void);
	void __fastcall SetPort(int Value);
	
protected:
	Oraclasses::TOCIChangeNotification* FIChangeNotification;
	TOraSession* __fastcall UsedConnection(TOraSession* Session);
	void __fastcall BeginConnection(TOraSession* Session);
	void __fastcall EndConnection(TOraSession* Session);
	void __fastcall DoOnChange(Oraclasses::TChangeNotifyEventType NotifyType, Oraclasses::TNotifyTableChanges* TableChanges);
	__property TOraSession* Session = {read=FSession, write=SetSession};
	
public:
	__fastcall virtual TOraChangeNotification(Classes::TComponent* AOwner);
	__fastcall virtual ~TOraChangeNotification(void);
	void __fastcall RemoveRegistration(TOraSession* Session);
	__property bool Active = {read=GetActive, nodefault};
	__property int Port = {read=GetPort, write=SetPort, nodefault};
	
__published:
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property bool Persistent = {read=FPersistent, write=SetPersistent, default=0};
	__property int TimeOut = {read=FTimeOut, write=SetTimeOut, default=0};
	__property Oracall::TChangeNotifyDMLOperations Operations = {read=FOperations, write=SetOperations, default=7};
	__property TOraChangeNotificationEvent OnChange = {read=FOnChange, write=FOnChange};
};


class DELPHICLASS TOraDataSet;
class DELPHICLASS TOraUpdateSQL;
class PASCALIMPLEMENTATION TOraDataSet : public Dbaccess::TCustomDADataSet
{
	typedef Dbaccess::TCustomDADataSet inherited;
	
private:
	TCheckMode FCheckMode;
	TSequenceMode FSequenceMode;
	System::UnicodeString FKeySequence;
	TOraChangeNotification* FChangeNotification;
	Stdvcl::_di_IProvider FProvIntf;
	TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(TOraSession* Value);
	HIDESBASE TOraParams* __fastcall GetParams(void);
	HIDESBASE void __fastcall SetParams(TOraParams* Value);
	void __fastcall SetNonBlocking(bool Value);
	int __fastcall GetRowsProcessed(void);
	bool __fastcall GetIsPLSQL(void);
	int __fastcall GetSQLType(void);
	HIDESBASE Oraclasses::TOraCursor* __fastcall GetCursor(void);
	TOraDataSetOptions* __fastcall GetOptions(void);
	void __fastcall SetCursor(Oraclasses::TOraCursor* Value);
	HIDESBASE void __fastcall SetOptions(TOraDataSetOptions* Value);
	void __fastcall SetKeySequence(System::UnicodeString Value);
	void __fastcall SetSequenceMode(TSequenceMode Value);
	void __fastcall SetCheckMode(TCheckMode Value);
	TLockMode __fastcall GetLockMode(void);
	void __fastcall SetLockMode(TLockMode Value);
	void __fastcall SetChangeNotification(TOraChangeNotification* Value);
	bool __fastcall GetStrictUpdate(void);
	void __fastcall SetStrictUpdate(bool Value);
	bool __fastcall GetReturnParams(void);
	void __fastcall SetReturnParams(bool Value);
	TRefreshMode __fastcall GetRefreshMode(void);
	void __fastcall SetRefreshMode(TRefreshMode Value);
	TOraDataSetOptionsDS* __fastcall GetOptionsDS(void);
	void __fastcall SetOptionsDS(TOraDataSetOptionsDS* Value);
	Stdvcl::_di_IProvider __fastcall GetProvider(void);
	
protected:
	virtual Db::TIndexDef* __fastcall PSGetDefaultOrder(void);
	Oraclasses::TOCIRecordSet* FIRecordSet;
	Oraclasses::TOCICommand* FICommand;
	TOraDataSetService* FDataSetService;
	virtual void __fastcall CreateIRecordSet(void);
	virtual void __fastcall SetIRecordSet(Memdata::TData* Value);
	virtual Memds::TDataSetServiceClass __fastcall GetDataSetServiceClass(void);
	virtual void __fastcall SetDataSetService(Memds::TDataSetService* Value);
	virtual void __fastcall CreateCommand(void);
	virtual Dbaccess::TDADataSetOptions* __fastcall CreateOptions(void);
	virtual Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	virtual void __fastcall CheckInactive(void);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall CloseCursor(void);
	virtual void __fastcall InternalExecute(void);
	virtual void __fastcall CheckFieldCompatibility(Db::TField* Field, Db::TFieldDef* FieldDef);
	virtual void __fastcall DoAfterOpen(void);
	virtual void __fastcall DoAfterScroll(void);
	virtual void __fastcall InitRecord(System::PByte Buffer);
	virtual void __fastcall AssignFieldValue(Dbaccess::TDAParam* Param, Db::TField* Field, bool Old)/* overload */;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual bool __fastcall NeedDetailRefresh(Dbaccess::TDAParam* Param, Memdata::TSharedObject* FieldValue);
	virtual void __fastcall CopyFieldValue(const System::Variant &Value, /* out */ void * &ValuePtr, /* out */ int &ValueType, Memdata::TFieldDesc* FieldDesc, bool UseFieldType = true);
	virtual void __fastcall InternalOpen(void);
	virtual System::UnicodeString __fastcall SQLAddWhere(System::UnicodeString SQLText, System::UnicodeString Condition);
	virtual System::UnicodeString __fastcall SQLDeleteWhere(System::UnicodeString SQLText);
	virtual System::UnicodeString __fastcall SQLSetOrderBy(System::UnicodeString SQLText, System::UnicodeString Fields);
	virtual System::UnicodeString __fastcall SQLGetOrderBy(System::UnicodeString SQLText);
	HIDESBASE void __fastcall SetModified(bool Value);
	HIDESBASE bool __fastcall GetActiveRecBuf(System::PByte &RecBuf);
	Memdata::TData* __fastcall GetData(void);
	void __fastcall ReflectChanges(Oraclasses::TNotifyTableChanges* TableChanges);
	TOraUpdateSQL* __fastcall GetUpdateObject(void);
	HIDESBASE void __fastcall SetUpdateObject(TOraUpdateSQL* Value);
	
public:
	__fastcall virtual TOraDataSet(Classes::TComponent* Owner);
	__fastcall virtual ~TOraDataSet(void);
	void __fastcall ExecSQL(void);
	void __fastcall BreakExec(void);
	virtual bool __fastcall Fetched(void);
	int __fastcall ErrorOffset(void);
	void __fastcall GetErrorPos(int &Row, int &Col);
	void __fastcall CreateProcCall(System::UnicodeString Name, int Overload = 0x0);
	System::UnicodeString __fastcall GetKeyList(System::UnicodeString TableName, Classes::TStrings* List);
	HIDESBASE TOraParam* __fastcall FindParam(const System::UnicodeString Value);
	HIDESBASE TOraParam* __fastcall ParamByName(const System::UnicodeString Value);
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
	Oraclasses::TOraLob* __fastcall GetLob(const System::UnicodeString FieldName);
	Oraclasses::TOraFile* __fastcall GetFile(const System::UnicodeString FieldName);
	Oraobjects::TOraObject* __fastcall GetObject(const System::UnicodeString FieldName);
	Oraobjects::TOraRef* __fastcall GetRef(const System::UnicodeString FieldName);
	Oraobjects::TOraArray* __fastcall GetArray(const System::UnicodeString FieldName);
	Oraobjects::TOraNestTable* __fastcall GetTable(const System::UnicodeString FieldName);
	Oraclasses::TOraTimeStamp* __fastcall GetTimeStamp(const System::UnicodeString FieldName);
	Oraclasses::TOraInterval* __fastcall GetInterval(const System::UnicodeString FieldName);
	Oraclasses::TOraNumber* __fastcall GetNumber(const System::UnicodeString FieldName);
	Oraclasses::TOraLob* __fastcall GetLobLocator(const System::UnicodeString FieldName);
	__property TOraSession* Session = {read=GetSession, write=SetSession};
	__property TOraParams* Params = {read=GetParams, write=SetParams, stored=false};
	__property bool NonBlocking = {read=FNonBlocking, write=SetNonBlocking, default=0};
	__property int RowsProcessed = {read=GetRowsProcessed, nodefault};
	__property bool IsQuery = {read=GetIsQuery, nodefault};
	__property bool IsPLSQL = {read=GetIsPLSQL, nodefault};
	__property int SQLType = {read=GetSQLType, nodefault};
	__property Oraclasses::TOraCursor* Cursor = {read=GetCursor, write=SetCursor};
	__property TLockMode LockMode = {read=GetLockMode, write=SetLockMode, nodefault};
	__property TCheckMode CheckMode = {read=FCheckMode, write=SetCheckMode, default=0};
	__property TOraDataSetOptions* Options = {read=GetOptions, write=SetOptions};
	__property System::UnicodeString KeySequence = {read=FKeySequence, write=SetKeySequence};
	__property TSequenceMode SequenceMode = {read=FSequenceMode, write=SetSequenceMode, default=1};
	__property TOraChangeNotification* ChangeNotification = {read=FChangeNotification, write=SetChangeNotification};
	__property TRefreshMode RefreshMode = {read=GetRefreshMode, write=SetRefreshMode, stored=false, nodefault};
	__property bool StrictUpdate = {read=GetStrictUpdate, write=SetStrictUpdate, stored=false, nodefault};
	__property LocalConstraints = {stored=false, default=1};
	__property bool ReturnParams = {read=GetReturnParams, write=SetReturnParams, stored=false, nodefault};
	__property TOraDataSetOptionsDS* OptionsDS = {read=GetOptionsDS, write=SetOptionsDS, stored=false};
	__property Stdvcl::_di_IProvider Provider = {read=GetProvider};
	__property TOraUpdateSQL* UpdateObject = {read=GetUpdateObject, write=SetUpdateObject};
	__property AutoCommit = {default=1};
	__property FetchAll = {default=0};
	__property KeyFields;
	__property DMLRefresh = {default=0};
	
/* Hoisted overloads: */
	
protected:
	inline void __fastcall  AssignFieldValue(Dbaccess::TDAParam* Param, Memdata::TFieldDesc* FieldDesc, bool Old){ Dbaccess::TCustomDADataSet::AssignFieldValue(Param, FieldDesc, Old); }
	
};


class DELPHICLASS TBFileStream;
class PASCALIMPLEMENTATION TBFileStream : public Memds::TBlobStream
{
	typedef Memds::TBlobStream inherited;
	
public:
	__fastcall TBFileStream(Db::TBlobField* Field, Db::TBlobStreamMode Mode);
	__fastcall virtual ~TBFileStream(void);
};


class DELPHICLASS TOraNestedTable;
class PASCALIMPLEMENTATION TOraNestedTable : public Memds::TMemDataSet
{
	typedef Memds::TMemDataSet inherited;
	
private:
	Oraobjects::TOraNestTable* __fastcall GetTable(void);
	void __fastcall SetTable(Oraobjects::TOraNestTable* Value);
	Oraobjects::TOraRef* __fastcall GetRef(void);
	void __fastcall SetRef(Oraobjects::TOraRef* Value);
	
protected:
	virtual void __fastcall CreateIRecordSet(void);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall CloseCursor(void);
	virtual void __fastcall CreateFieldDefs(void);
	virtual void __fastcall DoAfterPost(void);
	virtual void __fastcall DoBeforeInsert(void);
	virtual void __fastcall DoBeforeDelete(void);
	virtual bool __fastcall GetCanModify(void);
	virtual void __fastcall SetDataSetField(const Db::TDataSetField* Value);
	virtual void __fastcall DataEvent(Db::TDataEvent Event, int Info);
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMap(void);
	virtual Db::TFieldClass __fastcall GetFieldClass(Db::TFieldType FieldType)/* overload */;
	
public:
	__fastcall virtual TOraNestedTable(Classes::TComponent* Owner);
	Oraobjects::TOraObject* __fastcall GetObject(const System::UnicodeString FieldName);
	__property Oraobjects::TOraNestTable* Table = {read=GetTable, write=SetTable};
	__property Oraobjects::TOraRef* Ref = {read=GetRef, write=SetRef};
	
__published:
	__property DataSetField;
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property ObjectView = {default=1};
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property AfterRefresh;
	__property BeforeRefresh;
public:
	/* TMemDataSet.Destroy */ inline __fastcall virtual ~TOraNestedTable(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline Db::TFieldClass __fastcall  GetFieldClass(Db::TFieldDef* FieldDef){ return Db::TDataSet::GetFieldClass(FieldDef); }
	
};


class DELPHICLASS TCustomOraQuery;
class PASCALIMPLEMENTATION TCustomOraQuery : public TOraDataSet
{
	typedef TOraDataSet inherited;
	
public:
	/* TOraDataSet.Create */ inline __fastcall virtual TCustomOraQuery(Classes::TComponent* Owner) : TOraDataSet(Owner) { }
	/* TOraDataSet.Destroy */ inline __fastcall virtual ~TCustomOraQuery(void) { }
	
};


class DELPHICLASS TOraQuery;
class PASCALIMPLEMENTATION TOraQuery : public TCustomOraQuery
{
	typedef TCustomOraQuery inherited;
	
protected:
	virtual void __fastcall DoBeforeInsert(void);
	virtual void __fastcall DoBeforeDelete(void);
	virtual void __fastcall DoBeforeEdit(void);
	
__published:
	__property UpdatingTable;
	__property KeyFields;
	__property KeySequence;
	__property SequenceMode = {default=1};
	__property SQLInsert;
	__property SQLDelete;
	__property SQLUpdate;
	__property SQLLock;
	__property SQLRefresh;
	__property LocalUpdate = {default=0};
	__property Session;
	__property ParamCheck = {default=1};
	__property SQL;
	__property MasterSource;
	__property MasterFields;
	__property DetailFields;
	__property Debug = {default=0};
	__property Macros;
	__property Params;
	__property FetchRows = {default=25};
	__property FetchAll = {default=0};
	__property NonBlocking = {default=0};
	__property ReadOnly = {default=0};
	__property UniDirectional = {default=0};
	__property CachedUpdates = {default=0};
	__property AutoCommit = {default=1};
	__property FilterSQL;
	__property LockMode = {default=0};
	__property CheckMode = {default=0};
	__property DMLRefresh = {default=0};
	__property RefreshOptions = {default=0};
	__property Options;
	__property ChangeNotification;
	__property ReturnParams;
	__property LocalConstraints = {default=1};
	__property RefreshMode;
	__property OptionsDS;
	__property AfterExecute;
	__property BeforeUpdateExecute;
	__property AfterUpdateExecute;
	__property OnUpdateError;
	__property OnUpdateRecord;
	__property BeforeFetch;
	__property AfterFetch;
	__property UpdateObject;
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property ObjectView = {default=0};
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property AfterRefresh;
	__property BeforeRefresh;
	__property Fields;
public:
	/* TOraDataSet.Create */ inline __fastcall virtual TOraQuery(Classes::TComponent* Owner) : TCustomOraQuery(Owner) { }
	/* TOraDataSet.Destroy */ inline __fastcall virtual ~TOraQuery(void) { }
	
};


class DELPHICLASS TOraStoredProc;
class PASCALIMPLEMENTATION TOraStoredProc : public TCustomOraQuery
{
	typedef TCustomOraQuery inherited;
	
private:
	System::UnicodeString FStoredProcName;
	int FOverload;
	void __fastcall SetStoredProcName(System::UnicodeString Value);
	void __fastcall SetOverload(int Value);
	
protected:
	virtual void __fastcall PSSetCommandText(const System::UnicodeString CommandText)/* overload */;
	virtual void __fastcall DoBeforeInsert(void);
	virtual void __fastcall DoBeforeDelete(void);
	virtual void __fastcall DoBeforeEdit(void);
	virtual bool __fastcall SQLAutoGenerated(void);
	virtual void __fastcall BeforeOpenCursor(bool InfoQuery);
	virtual void __fastcall BeforeExecute(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	virtual void __fastcall Prepare(void);
	void __fastcall PrepareSQL(void);
	void __fastcall ExecProc(void);
	
__published:
	__property System::UnicodeString StoredProcName = {read=FStoredProcName, write=SetStoredProcName};
	__property int Overload = {read=FOverload, write=SetOverload, default=0};
	__property SQLInsert;
	__property SQLDelete;
	__property SQLUpdate;
	__property SQLLock;
	__property SQLRefresh;
	__property LocalUpdate = {default=0};
	__property Session;
	__property ParamCheck = {stored=false, default=1};
	__property SQL;
	__property Debug = {default=0};
	__property Params;
	__property FetchRows = {default=25};
	__property FetchAll = {default=0};
	__property NonBlocking = {default=0};
	__property ReadOnly = {default=0};
	__property UniDirectional = {default=0};
	__property CachedUpdates = {default=0};
	__property AutoCommit = {default=1};
	__property LockMode = {default=0};
	__property RefreshOptions = {default=0};
	__property Options;
	__property ChangeNotification;
	__property ReturnParams;
	__property LocalConstraints = {default=1};
	__property RefreshMode;
	__property OptionsDS;
	__property AfterExecute;
	__property BeforeUpdateExecute;
	__property AfterUpdateExecute;
	__property OnUpdateError;
	__property OnUpdateRecord;
	__property UpdateObject;
	__property Active = {default=0};
	__property AutoCalcFields = {default=1};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property ObjectView = {default=0};
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeInsert;
	__property AfterInsert;
	__property BeforeEdit;
	__property AfterEdit;
	__property BeforePost;
	__property AfterPost;
	__property BeforeCancel;
	__property AfterCancel;
	__property BeforeDelete;
	__property AfterDelete;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnCalcFields;
	__property OnDeleteError;
	__property OnEditError;
	__property OnFilterRecord;
	__property OnNewRecord;
	__property OnPostError;
	__property AfterRefresh;
	__property BeforeRefresh;
	__property Fields;
public:
	/* TOraDataSet.Create */ inline __fastcall virtual TOraStoredProc(Classes::TComponent* Owner) : TCustomOraQuery(Owner) { }
	/* TOraDataSet.Destroy */ inline __fastcall virtual ~TOraStoredProc(void) { }
	
	
/* Hoisted overloads: */
	
protected:
	inline void __fastcall  PSSetCommandText [[deprecated]](const System::WideString CommandText){ Db::TDataSet::PSSetCommandText(CommandText); }
	
};


class PASCALIMPLEMENTATION TOraSQL : public Dbaccess::TCustomDASQL
{
	typedef Dbaccess::TCustomDASQL inherited;
	
private:
	bool FStatementCache;
	bool FTemporaryLobUpdate;
	TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(TOraSession* Value);
	void __fastcall SetNonBlocking(bool Value);
	int __fastcall GetRowsProcessed(void);
	System::UnicodeString __fastcall GetText(void);
	void __fastcall SetText(System::UnicodeString Value);
	int __fastcall GetSQLType(void);
	void __fastcall SetArrayLength(int Value);
	void __fastcall SetStatementCache(bool Value);
	void __fastcall SetTemporaryLobUpdate(bool Value);
	TOraParams* __fastcall GetParams(void);
	HIDESBASE void __fastcall SetParams(TOraParams* Value);
	
protected:
	Oraclasses::TOCICommand* FICommand;
	virtual void __fastcall CreateICommand(void);
	virtual void __fastcall SetICommand(Craccess::TCRCommand* Value);
	virtual Dbaccess::TDAParams* __fastcall CreateParamsObject(void);
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMap(void);
	virtual Dbaccess::TCustomDAConnection* __fastcall UsedConnection(void);
	virtual void __fastcall AssignParam(Craccess::TParamDesc* ParamDesc, Dbaccess::TDAParam* Param);
	virtual void __fastcall AssignParamValue(Craccess::TParamDesc* ParamDesc, Dbaccess::TDAParam* Param);
	virtual void __fastcall AssignParamDesc(Dbaccess::TDAParam* Param, Craccess::TParamDesc* ParamDesc);
	virtual Dbaccess::TDAParam* __fastcall FindResultParam(void);
	virtual bool __fastcall NeedRecreateProcCall(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall InternalExecute(int Iters);
	
public:
	__fastcall virtual TOraSQL(Classes::TComponent* Owner);
	void __fastcall BreakExec(void);
	int __fastcall ErrorOffset(void);
	HIDESBASE TOraParam* __fastcall FindParam(const System::UnicodeString Value);
	HIDESBASE TOraParam* __fastcall ParamByName(const System::UnicodeString Value);
	void __fastcall CreateProcCall(System::UnicodeString Name, int Overload = 0x0);
	__property int RowsProcessed = {read=GetRowsProcessed, nodefault};
	__property int SQLType = {read=GetSQLType, nodefault};
	__property int ArrayLength = {write=SetArrayLength, nodefault};
	__property System::UnicodeString Text = {read=GetText, write=SetText};
	
__published:
	__property TOraSession* Session = {read=GetSession, write=SetSession};
	__property TOraParams* Params = {read=GetParams, write=SetParams, stored=false};
	__property bool NonBlocking = {read=FNonBlocking, write=SetNonBlocking, default=0};
	__property bool StatementCache = {read=FStatementCache, write=SetStatementCache, default=0};
	__property bool TemporaryLobUpdate = {read=FTemporaryLobUpdate, write=SetTemporaryLobUpdate, default=0};
	__property ParamCheck = {default=1};
	__property SQL;
	__property Macros;
	__property AutoCommit = {default=0};
	__property Debug = {default=0};
	__property AfterExecute;
public:
	/* TCustomDASQL.Destroy */ inline __fastcall virtual ~TOraSQL(void) { }
	
};


class PASCALIMPLEMENTATION TOraUpdateSQL : public Dbaccess::TCustomDAUpdateSQL
{
	typedef Dbaccess::TCustomDAUpdateSQL inherited;
	
protected:
	virtual Dbaccess::TCustomDADataSetClass __fastcall DataSetClass(void);
	virtual Dbaccess::TCustomDASQLClass __fastcall SQLClass(void);
public:
	/* TCustomDAUpdateSQL.Create */ inline __fastcall virtual TOraUpdateSQL(Classes::TComponent* Owner) : Dbaccess::TCustomDAUpdateSQL(Owner) { }
	/* TCustomDAUpdateSQL.Destroy */ inline __fastcall virtual ~TOraUpdateSQL(void) { }
	
};


class DELPHICLASS TOraMetaData;
class PASCALIMPLEMENTATION TOraMetaData : public Dbaccess::TDAMetaData
{
	typedef Dbaccess::TDAMetaData inherited;
	
private:
	TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(TOraSession* Value);
	
__published:
	__property Active = {default=0};
	__property Filtered = {default=0};
	__property Filter;
	__property FilterOptions = {default=0};
	__property IndexFieldNames;
	__property BeforeOpen;
	__property AfterOpen;
	__property BeforeClose;
	__property AfterClose;
	__property BeforeScroll;
	__property AfterScroll;
	__property OnFilterRecord;
	__property MetaDataKind;
	__property Restrictions;
	__property TOraSession* Session = {read=GetSession, write=SetSession};
public:
	/* TDAMetaData.Create */ inline __fastcall virtual TOraMetaData(Classes::TComponent* AOwner) : Dbaccess::TDAMetaData(AOwner) { }
	/* TDAMetaData.Destroy */ inline __fastcall virtual ~TOraMetaData(void) { }
	
};


class DELPHICLASS TOraDataSource;
class PASCALIMPLEMENTATION TOraDataSource : public Dbaccess::TCRDataSource
{
	typedef Dbaccess::TCRDataSource inherited;
	
public:
	/* TCRDataSource.Create */ inline __fastcall virtual TOraDataSource(Classes::TComponent* Owner) : Dbaccess::TCRDataSource(Owner) { }
	
public:
	/* TDataSource.Destroy */ inline __fastcall virtual ~TOraDataSource(void) { }
	
};


class DELPHICLASS TOraDataTypesMap;
class PASCALIMPLEMENTATION TOraDataTypesMap : public Oraservices::TCustomOraDataTypesMap
{
	typedef Oraservices::TCustomOraDataTypesMap inherited;
	
public:
	__classmethod virtual Db::TFieldType __fastcall GetFieldType(System::Word DataType);
	__classmethod virtual int __fastcall GetDataType(Db::TFieldType FieldType);
public:
	/* TObject.Create */ inline __fastcall TOraDataTypesMap(void) : Oraservices::TCustomOraDataTypesMap() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraDataTypesMap(void) { }
	
};


class DELPHICLASS TOraUtils;
class PASCALIMPLEMENTATION TOraUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod Oraclasses::TOCIConnection* __fastcall GetIConnection(TOraSession* Obj);
	__classmethod void __fastcall SetIConnection(TOraSession* Obj, Oraclasses::TOCIConnection* Value);
	__classmethod void __fastcall GetObjectList(TOraSession* Obj, Classes::TStrings* List, System::UnicodeString SQL);
	__classmethod System::UnicodeString __fastcall GetCachedSchema(TOraSession* Obj);
	__classmethod TOraSession* __fastcall FOwner(TOraSessionOptions* Obj);
	__classmethod Oraclasses::TOCICommand* __fastcall GetICommand(TOraDataSet* Obj);
	__classmethod System::UnicodeString __fastcall GetRowId(Classes::TComponent* Obj);
	__classmethod void __fastcall SetDesignCreate(TOraTrace* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TOraTrace* Obj)/* overload */;
public:
	/* TObject.Create */ inline __fastcall TOraUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
#define DACVersion L"6.90.0.57"
#define OdacVersion L"6.90.0.53"
static const Db::TFieldType ftObject = (Db::TFieldType)(26);
static const Db::TFieldType ftTable = (Db::TFieldType)(29);
static const ShortInt ftBFile = 0x64;
static const ShortInt ftLabel = 0x65;
static const ShortInt ftIntervalYM = 0x67;
static const ShortInt ftIntervalDS = 0x68;
static const ShortInt ftTimeStampTZ = 0x69;
static const ShortInt ftTimeStampLTZ = 0x6a;
static const ShortInt ftNumber = 0x6b;
static const ShortInt ftXML = 0x6c;
static const ShortInt DEFAULT_TRACE_FILE_SIZE = 0x0;
static const ShortInt UNLIMITED_TRACE_FILE_SIZE = -1;
extern PACKAGE TOraSession* DefSession;
extern PACKAGE bool UseDefSession;
extern PACKAGE TSessionList* Sessions;
extern PACKAGE System::TClass __fastcall (*DefConnectDialogClassProc)(void);
extern PACKAGE bool ShowRefId;
extern PACKAGE bool OraQueryCompatibilityMode;
extern PACKAGE bool UseLockInTransaction;
extern PACKAGE Stdvcl::_di_IProvider __fastcall (*CreateProviderProc)(TOraDataSet* DataSet);
extern PACKAGE TOraSession* __fastcall DefaultSession(void);
extern PACKAGE TOraSession* __fastcall SessionByName(System::UnicodeString Name);
extern PACKAGE System::UnicodeString __fastcall AddWhere(System::UnicodeString SQL, System::UnicodeString Condition);
extern PACKAGE System::UnicodeString __fastcall SetWhere(System::UnicodeString SQL, System::UnicodeString Condition);
extern PACKAGE System::UnicodeString __fastcall DeleteWhere(System::UnicodeString SQL);
extern PACKAGE System::UnicodeString __fastcall SetOrderBy(System::UnicodeString SQL, System::UnicodeString Fields);
extern PACKAGE System::UnicodeString __fastcall GetOrderBy(System::UnicodeString SQL);
extern PACKAGE System::UnicodeString __fastcall SetGroupBy(System::UnicodeString SQL, System::UnicodeString Fields);
extern PACKAGE System::UnicodeString __fastcall SetFieldList(System::UnicodeString SQL, System::UnicodeString Fields);
extern PACKAGE System::UnicodeString __fastcall SetTableList(System::UnicodeString SQL, System::UnicodeString Tables);
extern PACKAGE System::UnicodeString __fastcall GetTableList(System::UnicodeString SQL);
extern PACKAGE int __fastcall GetSubscriptionPort(void);
extern PACKAGE void __fastcall SetSubscriptionPort(int Value);
extern PACKAGE void __fastcall RegisterFieldClasses(void);

}	/* namespace Ora */
using namespace Ora;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraHPP
