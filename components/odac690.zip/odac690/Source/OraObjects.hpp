// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraobjects.pas' rev: 21.00

#ifndef OraobjectsHPP
#define OraobjectsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraobjects
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOraType;
class PASCALIMPLEMENTATION TOraType : public Memdata::TObjectType
{
	typedef Memdata::TObjectType inherited;
	
private:
	Craccess::TCRConnection* FConnection;
	System::Word FDataSize;
	System::Word FIndicatorSize;
	int FTypeCode;
	void *FSvcCtx;
	bool FFinal;
	bool FAlignNeaded;
	bool FValid;
	
protected:
	void *hType;
	HIDESBASE void __fastcall ClearAttributes(void);
	
public:
	__fastcall TOraType(Craccess::TCRConnection* Connection, System::UnicodeString Name)/* overload */;
	__fastcall TOraType(void * SvcCtx, System::UnicodeString Name)/* overload */;
	__fastcall virtual ~TOraType(void);
	void __fastcall Init(System::UnicodeString Name);
	void __fastcall Describe(void * SvcCtx, System::UnicodeString Name)/* overload */;
	void __fastcall Describe(void * SvcCtx)/* overload */;
	__property void * TDO = {read=hType};
	__property System::Word DataSize = {read=FDataSize, nodefault};
	__property System::Word IndicatorSize = {read=FIndicatorSize, nodefault};
	__property bool Final = {read=FFinal, nodefault};
	__property bool Valid = {read=FValid, nodefault};
};


class DELPHICLASS TObjectTypes;
class PASCALIMPLEMENTATION TObjectTypes : public Classes::TThreadList
{
	typedef Classes::TThreadList inherited;
	
public:
	Memdata::TObjectType* __fastcall FindType(void * SvcCtx, System::UnicodeString Name);
	void __fastcall ClearTypes(void * SvcCtx, bool LeaveTypes);
public:
	/* TThreadList.Create */ inline __fastcall TObjectTypes(void) : Classes::TThreadList() { }
	/* TThreadList.Destroy */ inline __fastcall virtual ~TObjectTypes(void) { }
	
};


class DELPHICLASS TOraObject;
class DELPHICLASS TOraArray;
class PASCALIMPLEMENTATION TOraObject : public Memdata::TDBObject
{
	typedef Memdata::TDBObject inherited;
	
private:
	TOraType* FObjectType;
	void *FSvcCtx;
	void *FOCIEnv;
	bool FUnicodeEnv;
	bool FNativeInstance;
	Classes::TList* FObjects;
	bool FAutoCreate;
	TOraObject* FOwner;
	void *FOCIError;
	void __fastcall SetOCISvcCtx(void * Value);
	HIDESBASE void __fastcall SetObjectType(TOraType* Value);
	void __fastcall SetInstance(void * Value);
	void * __fastcall GetFInstance(void);
	void __fastcall SetFInstance(void * Value);
	void * __fastcall GetFIndicator(void);
	void __fastcall SetFIndicator(void * Value);
	Oracall::OCIDate __fastcall GetAsOCIDate(System::UnicodeString Name);
	void __fastcall SetAsOCIDate(System::UnicodeString Name, const Oracall::OCIDate &Value);
	Oracall::OCINumber __fastcall GetAsOCINumber(System::UnicodeString Name);
	void __fastcall SetAsOCINumber(System::UnicodeString Name, const Oracall::OCINumber &Value);
	void * __fastcall GetAsOCIString(System::UnicodeString Name);
	void __fastcall SetAsOCIString(System::UnicodeString Name, void * Value);
	System::TDateTime __fastcall GetAsDateTime(System::UnicodeString Name);
	void __fastcall SetAsDateTime(System::UnicodeString Name, System::TDateTime Value);
	double __fastcall GetAsFloat(System::UnicodeString Name);
	void __fastcall SetAsFloat(System::UnicodeString Name, double Value);
	int __fastcall GetAsInteger(System::UnicodeString Name);
	void __fastcall SetAsInteger(System::UnicodeString Name, int Value);
	__int64 __fastcall GetAsLargeInt(System::UnicodeString Name);
	void __fastcall SetAsLargeInt(System::UnicodeString Name, __int64 Value);
	System::UnicodeString __fastcall GetAsString(System::UnicodeString Name);
	void __fastcall SetAsString(System::UnicodeString Name, const System::UnicodeString Value);
	System::AnsiString __fastcall GetAsAnsiString(System::UnicodeString Name);
	void __fastcall SetAsAnsiString(System::UnicodeString Name, const System::AnsiString Value);
	System::WideString __fastcall GetAsWideString(System::UnicodeString Name);
	void __fastcall SetAsWideString(System::UnicodeString Name, const System::WideString Value);
	Memdata::TSharedObject* __fastcall GetComplexAttribute(const System::UnicodeString Name);
	TOraObject* __fastcall GetAsObject(System::UnicodeString Name);
	TOraArray* __fastcall GetAsArray(System::UnicodeString Name);
	Oraclasses::TOraLob* __fastcall GetAsLob(System::UnicodeString Name);
	Oraclasses::TOraTimeStamp* __fastcall GetAsOraTimeStamp(System::UnicodeString Name);
	Oraclasses::TOraInterval* __fastcall GetAsOraInterval(System::UnicodeString Name);
	
protected:
	void *FInstancePtr;
	void *FIndicatorPtr;
	bool FCached;
	void __fastcall Check(int Status);
	virtual void __fastcall CheckType(void);
	void __fastcall CheckSession(void);
	void __fastcall CheckAlloc(bool RaiseException = true);
	void __fastcall CheckNotCached(void);
	void __fastcall AllocNewObject(void);
	void __fastcall FreeObjects(void);
	virtual void __fastcall GetAttributeValue(const System::UnicodeString Name, void * &AttrBuf, bool &IsBlank, bool &NativeBuffer);
	virtual void __fastcall SetAttributeValue(const System::UnicodeString Name, void * Source);
	virtual bool __fastcall GetAttrIsNull(const System::UnicodeString Name);
	void __fastcall SetAttrIsNull(const System::UnicodeString Name, bool Value);
	void __fastcall GetAttribute(System::UnicodeString Name, void * &Value, short &Ind, void * &Indicator, bool AutoAlloc = false, bool MakeNotNull = false);
	void __fastcall SetAttribute(System::UnicodeString Name, void * Value, short Ind);
	virtual bool __fastcall GetIsNull(void);
	virtual void __fastcall SetIsNull(bool Value);
	virtual void * __fastcall GetIndicatorPtr(void);
	Memdata::TSharedObject* __fastcall GetChildObject(Memdata::TAttribute* Attr);
	virtual void __fastcall ChildAlloc(TOraObject* Child);
	virtual void * __fastcall GetOCIRef(void);
	__property void * FInstance = {read=GetFInstance, write=SetFInstance};
	__property void * FIndicator = {read=GetFIndicator, write=SetFIndicator};
	
public:
	__fastcall TOraObject(TOraType* ObjectType);
	__fastcall virtual ~TOraObject(void);
	virtual void __fastcall AllocObject(void)/* overload */;
	void __fastcall AllocObject(void * SvcCtx)/* overload */;
	virtual void __fastcall AllocObject(System::UnicodeString TypeName)/* overload */;
	virtual void __fastcall AllocObject(void * SvcCtx, System::UnicodeString TypeName)/* overload */;
	virtual void __fastcall FreeObject(bool FreeChild = true);
	virtual void __fastcall Disconnect(void);
	void __fastcall CreateObject(void * SvcCtx, System::UnicodeString TypeName);
	void __fastcall CacheObject(void);
	virtual void __fastcall Pin(void);
	virtual void __fastcall Unpin(void);
	void __fastcall Lock(void);
	void __fastcall Flush(void);
	void __fastcall Refresh(void);
	void __fastcall MarkDelete(void);
	void __fastcall MarkUpdate(void);
	void __fastcall Unmark(void);
	void __fastcall WriteLobs(void);
	void __fastcall ResetInstance(void * NewInstance, void * NewIndicator);
	bool __fastcall Exists(void);
	bool __fastcall IsLocked(void);
	bool __fastcall IsDirty(void);
	virtual void __fastcall Assign(TOraObject* Source);
	void __fastcall OraObjectAssign(void * Source, void * Dest, TOraType* OType);
	void __fastcall NestTableAssign(void * Source, void * Dest, TOraType* OType);
	__property bool AttrIsNull[const System::UnicodeString Name] = {read=GetAttrIsNull, write=SetAttrIsNull};
	__property Oracall::OCIDate AttrAsOCIDate[System::UnicodeString Name] = {read=GetAsOCIDate, write=SetAsOCIDate};
	__property Oracall::OCINumber AttrAsOCINumber[System::UnicodeString Name] = {read=GetAsOCINumber, write=SetAsOCINumber};
	__property void * AttrAsOCIString[System::UnicodeString Name] = {read=GetAsOCIString, write=SetAsOCIString};
	__property System::TDateTime AttrAsDateTime[System::UnicodeString Name] = {read=GetAsDateTime, write=SetAsDateTime};
	__property double AttrAsFloat[System::UnicodeString Name] = {read=GetAsFloat, write=SetAsFloat};
	__property int AttrAsInteger[System::UnicodeString Name] = {read=GetAsInteger, write=SetAsInteger};
	__property __int64 AttrAsLargeInt[System::UnicodeString Name] = {read=GetAsLargeInt, write=SetAsLargeInt};
	__property System::UnicodeString AttrAsString[System::UnicodeString Name] = {read=GetAsString, write=SetAsString};
	__property System::AnsiString AttrAsAnsiString[System::UnicodeString Name] = {read=GetAsAnsiString, write=SetAsAnsiString};
	__property System::WideString AttrAsWideString[System::UnicodeString Name] = {read=GetAsWideString, write=SetAsWideString};
	__property TOraObject* AttrAsObject[System::UnicodeString Name] = {read=GetAsObject};
	__property TOraArray* AttrAsArray[System::UnicodeString Name] = {read=GetAsArray};
	__property Oraclasses::TOraLob* AttrAsLob[System::UnicodeString Name] = {read=GetAsLob};
	__property Oraclasses::TOraTimeStamp* AttrAsTimeStamp[System::UnicodeString Name] = {read=GetAsOraTimeStamp};
	__property Oraclasses::TOraInterval* AttrAsInterval[System::UnicodeString Name] = {read=GetAsOraInterval};
	__property TOraType* ObjectType = {read=FObjectType, write=SetObjectType};
	__property void * OCISvcCtx = {read=FSvcCtx, write=SetOCISvcCtx};
	__property void * OCIError = {read=FOCIError, write=FOCIError};
	__property void * Instance = {read=GetFInstance, write=SetInstance};
	__property void * Indicator = {read=GetFIndicator, write=SetFIndicator};
	__property void * InstancePtr = {read=FInstancePtr};
	__property void * IndicatorPtr = {read=GetIndicatorPtr};
	__property bool IsNull = {read=GetIsNull, write=SetIsNull, nodefault};
	__property bool AutoCreate = {read=FAutoCreate, write=FAutoCreate, nodefault};
	__property bool NativeInstance = {read=FNativeInstance, write=FNativeInstance, nodefault};
};


class DELPHICLASS TOraXML;
class PASCALIMPLEMENTATION TOraXML : public TOraObject
{
	typedef TOraObject inherited;
	
private:
	void *phOCIDescriptor;
	char *CacheValue;
	bool CacheIsNull;
	void *LocalIndicator;
	void *LocalIndicatorPtr;
	void __fastcall CreateXMLStream(void);
	void __fastcall FreeXMLStream(void);
	HIDESBASE System::UnicodeString __fastcall GetAsString(void);
	HIDESBASE void __fastcall SetAsString(System::UnicodeString Value);
	bool __fastcall ObjectIsNull(void);
	void __fastcall StartRead(void);
	unsigned __fastcall Read(unsigned Count, void * Dest);
	
protected:
	virtual bool __fastcall GetIsNull(void);
	virtual void __fastcall SetIsNull(bool Value);
	virtual void * __fastcall GetIndicatorPtr(void);
	virtual void __fastcall CheckType(void);
	
public:
	__fastcall TOraXML(TOraType* ObjectType);
	__fastcall virtual ~TOraXML(void);
	virtual void __fastcall AllocObject(void)/* overload */;
	virtual void __fastcall AllocObject(System::UnicodeString TypeName)/* overload */;
	virtual void __fastcall AllocObject(void * SvcCtx, System::UnicodeString TypeName)/* overload */;
	HIDESBASE void __fastcall AllocObject(void * SvcCtx, Oraclasses::TOraLob* OraLob)/* overload */;
	virtual void __fastcall FreeObject(bool FreeChild = true);
	virtual void __fastcall Assign(TOraObject* Source);
	void __fastcall ReadXML(void);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall SaveToStream(Classes::TStream* Stream);
	void __fastcall Extract(TOraXML* RetDoc, System::UnicodeString XPathExpr, System::UnicodeString NSmap = L"");
	HIDESBASE bool __fastcall Exists(System::UnicodeString XPathExpr, System::UnicodeString NSmap = L"");
	void __fastcall Transform(TOraXML* XSLDoc, TOraXML* RetDoc);
	void __fastcall GetSchema(TOraXML* SchemaDoc, System::UnicodeString &SchemaURL, System::UnicodeString &RootElem);
	bool __fastcall Validate(System::UnicodeString SchemaURL);
	bool __fastcall IsSchemaBased(void);
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	
/* Hoisted overloads: */
	
public:
	inline void __fastcall  AllocObject(void * SvcCtx){ TOraObject::AllocObject(SvcCtx); }
	
};


class DELPHICLASS TOraRef;
class PASCALIMPLEMENTATION TOraRef : public TOraObject
{
	typedef TOraObject inherited;
	
private:
	bool InvalidObject;
	void * __fastcall GethOCIRef(void);
	void __fastcall SethOCIRef(void * Value);
	void __fastcall SetOCIRef(void * Value);
	Oracall::ppOCIRef __fastcall GetOCIRefPtr(void);
	
protected:
	void * *FpOCIRef;
	virtual bool __fastcall GetIsNull(void);
	virtual void __fastcall SetIsNull(bool Value);
	System::UnicodeString __fastcall GetAsHex(void);
	__property void * FOCIRef = {read=GethOCIRef, write=SethOCIRef};
	
public:
	__fastcall TOraRef(TOraType* ObjectType);
	__fastcall virtual ~TOraRef(void);
	virtual void __fastcall Pin(void);
	virtual void __fastcall Unpin(void);
	bool __fastcall RefIsNull(void);
	void __fastcall Clear(void);
	virtual void __fastcall Assign(TOraObject* Source);
	__property void * OCIRef = {read=GethOCIRef, write=SetOCIRef};
	__property Oracall::ppOCIRef OCIRefPtr = {read=GetOCIRefPtr};
	__property System::UnicodeString AsHex = {read=GetAsHex};
};


class PASCALIMPLEMENTATION TOraArray : public TOraObject
{
	typedef TOraObject inherited;
	
private:
	void __fastcall SetSize(int Value);
	int __fastcall GetMaxSize(void);
	System::Word __fastcall GetItemType(void);
	System::Word __fastcall GetItemSubType(void);
	bool __fastcall GetItemExists(int Index);
	bool __fastcall GetItemIsNull(int Index);
	void __fastcall SetItemIsNull(int Index, bool Value);
	void * __fastcall GetItemAsOCIString(int Index);
	void __fastcall SetItemAsOCIString(int Index, void * Value);
	System::TDateTime __fastcall GetItemAsDateTime(int Index);
	void __fastcall SetItemAsDateTime(int Index, System::TDateTime Value);
	double __fastcall GetItemAsFloat(int Index);
	void __fastcall SetItemAsFloat(int Index, double Value);
	int __fastcall GetItemAsInteger(int Index);
	void __fastcall SetItemAsInteger(int Index, int Value);
	__int64 __fastcall GetItemAsLargeInt(int Index);
	void __fastcall SetItemAsLargeInt(int Index, __int64 Value);
	System::UnicodeString __fastcall GetItemAsString(int Index);
	void __fastcall SetItemAsString(int Index, const System::UnicodeString Value);
	System::AnsiString __fastcall GetItemAsAnsiString(int Index);
	void __fastcall SetItemAsAnsiString(int Index, const System::AnsiString Value);
	System::WideString __fastcall GetItemAsWideString(int Index);
	void __fastcall SetItemAsWideString(int Index, const System::WideString Value);
	TOraObject* __fastcall GetItemAsObject(int Index);
	void __fastcall SetItemAsObject(int Index, TOraObject* Value);
	TOraRef* __fastcall GetItemAsRef(int Index);
	void __fastcall SetItemAsRef(int Index, TOraRef* Value);
	
protected:
	virtual void __fastcall CheckType(void);
	void __fastcall CheckIndex(int Index);
	virtual void __fastcall ChildAlloc(TOraObject* Child);
	virtual int __fastcall GetSize(void);
	
public:
	void __fastcall Clear(void);
	int __fastcall AppendItem(void);
	void __fastcall InsertItem(int Index);
	virtual void __fastcall Assign(TOraObject* Source);
	__property int Size = {read=GetSize, write=SetSize, nodefault};
	__property int MaxSize = {read=GetMaxSize, nodefault};
	__property System::Word ItemType = {read=GetItemType, nodefault};
	__property System::Word ItemSubType = {read=GetItemSubType, nodefault};
	__property bool ItemExists[int Index] = {read=GetItemExists};
	__property bool ItemIsNull[int Index] = {read=GetItemIsNull, write=SetItemIsNull};
	__property void * ItemAsOCIString[int Index] = {read=GetItemAsOCIString, write=SetItemAsOCIString};
	__property System::TDateTime ItemAsDateTime[int Index] = {read=GetItemAsDateTime, write=SetItemAsDateTime};
	__property double ItemAsFloat[int Index] = {read=GetItemAsFloat, write=SetItemAsFloat};
	__property int ItemAsInteger[int Index] = {read=GetItemAsInteger, write=SetItemAsInteger};
	__property __int64 ItemAsLargeInt[int Index] = {read=GetItemAsLargeInt, write=SetItemAsLargeInt};
	__property System::UnicodeString ItemAsString[int Index] = {read=GetItemAsString, write=SetItemAsString};
	__property System::AnsiString ItemAsAnsiString[int Index] = {read=GetItemAsAnsiString, write=SetItemAsAnsiString};
	__property System::WideString ItemAsWideString[int Index] = {read=GetItemAsWideString, write=SetItemAsWideString};
	__property TOraObject* ItemAsObject[int Index] = {read=GetItemAsObject, write=SetItemAsObject};
	__property TOraRef* ItemAsRef[int Index] = {read=GetItemAsRef, write=SetItemAsRef};
public:
	/* TOraObject.Create */ inline __fastcall TOraArray(TOraType* ObjectType) : TOraObject(ObjectType) { }
	/* TOraObject.Destroy */ inline __fastcall virtual ~TOraArray(void) { }
	
};


class DELPHICLASS TOraNestTable;
class PASCALIMPLEMENTATION TOraNestTable : public TOraArray
{
	typedef TOraArray inherited;
	
protected:
	virtual void __fastcall CheckType(void);
	virtual int __fastcall GetSize(void);
	
public:
	virtual void __fastcall Assign(TOraObject* Source);
	void __fastcall DeleteItem(int Index);
	__property int Size = {read=GetSize, nodefault};
public:
	/* TOraObject.Create */ inline __fastcall TOraNestTable(TOraType* ObjectType) : TOraArray(ObjectType) { }
	/* TOraObject.Destroy */ inline __fastcall virtual ~TOraNestTable(void) { }
	
};


class DELPHICLASS TRefData;
class PASCALIMPLEMENTATION TRefData : public Memdata::TData
{
	typedef Memdata::TData inherited;
	
private:
	TOraRef* FRef;
	bool FIncludeObjectField;
	void __fastcall SetRef(TOraRef* Value);
	
protected:
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalOpen(bool DisableInitFields = false);
	virtual void __fastcall InternalInitFields(void);
	
public:
	__fastcall TRefData(void);
	__fastcall virtual ~TRefData(void);
	virtual void __fastcall Reopen(void);
	virtual void __fastcall GetRecord(void * RecBuf);
	virtual void __fastcall GetNextRecord(void * RecBuf);
	virtual void __fastcall GetPriorRecord(void * RecBuf);
	virtual void __fastcall PutRecord(void * RecBuf);
	virtual void __fastcall AppendRecord(void * RecBuf);
	virtual void __fastcall InsertRecord(void * RecBuf);
	virtual void __fastcall UpdateRecord(void * RecBuf);
	virtual void __fastcall DeleteRecord(void);
	__classmethod virtual bool __fastcall IsComplexFieldType(System::Word DataType);
	virtual void __fastcall CreateComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall FreeComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CopyComplexFields(void * Source, void * Dest, bool WithBlob);
	virtual void __fastcall GetBookmark(Memdata::PRecBookmark Bookmark);
	virtual void __fastcall SetToBookmark(Memdata::PRecBookmark Bookmark);
	__property TOraRef* Ref = {read=FRef, write=SetRef};
	__property bool IncludeObjectField = {read=FIncludeObjectField, write=FIncludeObjectField, nodefault};
};


class DELPHICLASS TTableData;
class PASCALIMPLEMENTATION TTableData : public Memdata::TMemData
{
	typedef Memdata::TMemData inherited;
	
private:
	TOraNestTable* FTable;
	System::Word FIndexOfs;
	bool FIncludeObjectField;
	void __fastcall SetTable(TOraNestTable* Value);
	
protected:
	int LastIndex;
	void __fastcall Check(int Status);
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalOpen(bool DisableInitFields = false);
	virtual void __fastcall InternalInitFields(void);
	virtual System::Word __fastcall GetIndicatorSize(void);
	virtual void __fastcall InternalAppend(void * RecBuf);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalUpdate(void * RecBuf);
	virtual bool __fastcall Fetch(bool FetchBack = false);
	virtual int __fastcall GetRecordCount(void);
	
public:
	__fastcall TTableData(void);
	__fastcall virtual ~TTableData(void);
	virtual void __fastcall Reopen(void);
	virtual void __fastcall InitFields(void);
	__classmethod virtual bool __fastcall IsBlobFieldType(System::Word DataType);
	virtual void __fastcall GetRecord(void * RecBuf);
	virtual void __fastcall GetNextRecord(void * RecBuf);
	virtual void __fastcall PutRecord(void * RecBuf);
	virtual void __fastcall CancelRecord(void * RecBuf);
	__classmethod virtual bool __fastcall IsComplexFieldType(System::Word DataType);
	void __fastcall FetchComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CreateComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall FreeComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CopyComplexFields(void * Source, void * Dest, bool WithBlob);
	__property TOraNestTable* Table = {read=FTable, write=SetTable};
	__property bool IncludeObjectField = {read=FIncludeObjectField, write=FIncludeObjectField, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TObjectTypes* ObjectTypes;
extern PACKAGE int __fastcall GetObjectCacheMaxSize(void);
extern PACKAGE void __fastcall SetObjectCacheMaxSize(int Value);
extern PACKAGE int __fastcall GetObjectCacheOptSize(void);
extern PACKAGE void __fastcall SetObjectCacheOptSize(int Value);
extern PACKAGE Memdata::TObjectType* __fastcall GetOraType(void * SvcCtx, System::UnicodeString Name);

}	/* namespace Oraobjects */
using namespace Oraobjects;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraobjectsHPP
