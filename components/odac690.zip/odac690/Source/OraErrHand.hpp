// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraerrhand.pas' rev: 21.00

#ifndef OraerrhandHPP
#define OraerrhandHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraerrhand
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TOnOraErrorEvent)(System::TObject* Sender, Sysutils::Exception* E, int ErrorCode, const System::UnicodeString ConstraintName, System::UnicodeString &Msg);

typedef void __fastcall (__closure *TOnError1Event)(System::TObject* Sender, Sysutils::Exception* E, int ErrorCode, const System::UnicodeString ConstraintName, System::UnicodeString &Msg, bool &Handled);

class DELPHICLASS TOraErrorHandler;
class PASCALIMPLEMENTATION TOraErrorHandler : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Ora::TOraQuery* FQuery;
	System::UnicodeString FTableName;
	bool FDebug;
	bool FStreamedActive;
	TOnOraErrorEvent FOnError;
	TOnError1Event FOnError1;
	Ora::TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(Ora::TOraSession* Value);
	bool __fastcall GetActive(void);
	void __fastcall SetActive(bool Value);
	void __fastcall SetTableName(System::UnicodeString Value);
	
protected:
	bool FDesignCreate;
	virtual void __fastcall Loaded(void);
	void __fastcall OnException(System::TObject* Sender, Sysutils::Exception* E);
	bool __fastcall FindError(System::UnicodeString SenderName, System::UnicodeString ErrorClass, int ErrorCode, const System::UnicodeString ConstraintName, const System::UnicodeString FullConstraintName, System::UnicodeString &Msg);
	
public:
	__fastcall virtual TOraErrorHandler(Classes::TComponent* Owner);
	__fastcall virtual ~TOraErrorHandler(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	__property Ora::TOraQuery* Query = {read=FQuery};
	__property TOnError1Event OnError1 = {read=FOnError1, write=FOnError1};
	
__published:
	__property Ora::TOraSession* Session = {read=GetSession, write=SetSession};
	__property System::UnicodeString TableName = {read=FTableName, write=SetTableName};
	__property bool Active = {read=GetActive, write=SetActive, default=0};
	__property bool Debug = {read=FDebug, write=FDebug, default=0};
	__property TOnOraErrorEvent OnError = {read=FOnError, write=FOnError};
};


class DELPHICLASS TOraErrorHandlerUtils;
class PASCALIMPLEMENTATION TOraErrorHandlerUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TOraErrorHandler* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TOraErrorHandler* Obj);
public:
	/* TObject.Create */ inline __fastcall TOraErrorHandlerUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraErrorHandlerUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Oraerrhand */
using namespace Oraerrhand;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraerrhandHPP
