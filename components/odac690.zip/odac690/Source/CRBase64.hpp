// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crbase64.pas' rev: 21.00

#ifndef Crbase64HPP
#define Crbase64HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crbase64
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TBase64;
class PASCALIMPLEMENTATION TBase64 : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod Sysutils::TBytes __fastcall Encode(const Sysutils::TBytes data)/* overload */;
	__classmethod Sysutils::TBytes __fastcall Encode(const Sysutils::TBytes data, int offset, int length)/* overload */;
	__classmethod Sysutils::TBytes __fastcall Decode(const Sysutils::TBytes data)/* overload */;
	__classmethod Sysutils::TBytes __fastcall Decode(const Sysutils::TBytes data, int offset, int length)/* overload */;
public:
	/* TObject.Create */ inline __fastcall TBase64(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TBase64(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Crbase64 */
using namespace Crbase64;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Crbase64HPP
