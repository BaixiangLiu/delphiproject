// CodeGear C++Builder
// Copyright (c) 1995, 2007 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oranetuni.pas' rev: 11.00

#ifndef OranetuniHPP
#define OranetuniHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Scktcomp.hpp>	// Pascal unit
#include <Winsock.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Rtlconsts.hpp>	// Pascal unit
#include <Oracalluni.hpp>	// Pascal unit
#include <Oracryptuni.hpp>	// Pascal unit
#include <Oraparseruni.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Dateutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oranetuni
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool UseDirectLobs;
extern PACKAGE int SDU;
extern PACKAGE int TDU;
extern PACKAGE void __fastcall InitNet(void);
extern PACKAGE void __fastcall LoadNet(void);
extern PACKAGE void __fastcall FreeNet(void);

}	/* namespace Oranetuni */
using namespace Oranetuni;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Oranetuni
