// Borland C++ Builder
// Copyright (c) 1995, 2005 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oracrypt.pas' rev: 10.00

#ifndef OracryptHPP
#define OracryptHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oracrypt
{
//-- type declarations -------------------------------------------------------
typedef DynamicArray<Byte >  TByteArr;

typedef DynamicArray<int >  TIntArr;

typedef DynamicArray<int >  TLongArr;

typedef DynamicArray<Shortint >  TShortArr;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall ByteArrayCopy(Clrclasses::TBytes Src, int SrcPos, Clrclasses::TBytes Dest, int DestPos, int Len);
extern PACKAGE Clrclasses::TBytes __fastcall encrypt(Clrclasses::TBytes key, Clrclasses::TBytes buffer, int buf_len);
extern PACKAGE Clrclasses::TBytes __fastcall decrypt(Clrclasses::TBytes key, Clrclasses::TBytes ebuf);
extern PACKAGE Clrclasses::TBytes __fastcall encryptAll8BytesBlocks(Clrclasses::TBytes value, bool only8bytes);
extern PACKAGE void __fastcall des_enc(Clrclasses::TBytes data, int blocks);
extern PACKAGE void __fastcall des_dec(Clrclasses::TBytes data, int blocks);
extern PACKAGE void __fastcall des_enc1(Clrclasses::TBytes key, Clrclasses::TBytes data, int blocks);
extern PACKAGE void __fastcall des_dec1(Clrclasses::TBytes key, Clrclasses::TBytes data, int blocks);
extern PACKAGE void __fastcall setKeys(Clrclasses::TBytes key);
extern PACKAGE Byte __fastcall nibbleToHex(Byte nibble);
extern PACKAGE Byte __fastcall asciiHexToNibble(Byte b);
extern PACKAGE void __fastcall bArray2nibbles(Clrclasses::TBytes arr, Clrclasses::TBytes nibbles);
extern PACKAGE Clrclasses::TBytes __fastcall nibbles2bArray(Clrclasses::TBytes nibbles);
extern PACKAGE Clrclasses::TBytes __fastcall normO(AnsiString user, AnsiString password);
extern PACKAGE Clrclasses::TBytes __fastcall wb_decrypt(Clrclasses::TBytes key, Clrclasses::TBytes evalue);
extern PACKAGE Clrclasses::TBytes __fastcall wb_encrypt(Clrclasses::TBytes key, Clrclasses::TBytes value);
extern PACKAGE Clrclasses::TBytes __fastcall normalizeUserPassword(AnsiString user, AnsiString password);
extern PACKAGE Clrclasses::TBytes __fastcall oneWayEncryption(Clrclasses::TBytes value);
extern PACKAGE Clrclasses::TBytes __fastcall StringToWorkbench(AnsiString value);
extern PACKAGE int __fastcall StringToWorkbench1(AnsiString value, Clrclasses::TBytes outArray, int offset);

}	/* namespace Oracrypt */
using namespace Oracrypt;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Oracrypt
