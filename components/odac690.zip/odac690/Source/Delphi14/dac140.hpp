// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dac140.pas' rev: 21.00

#ifndef Dac140HPP
#define Dac140HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Daloader.hpp>	// Pascal unit
#include <Dadump.hpp>	// Pascal unit
#include <Dascript.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Daconsts.hpp>	// Pascal unit
#include <Dbmonitorintf.hpp>	// Pascal unit
#include <Dbmonitorclient.hpp>	// Pascal unit
#include <Dasqlmonitor.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Virtualtable.hpp>	// Pascal unit
#include <Daversioninfo.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crbatchmove.hpp>	// Pascal unit
#include <Win32timer.hpp>	// Pascal unit
#include <Crconnectionpool.hpp>	// Pascal unit
#include <Crxml.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit
#include <Crviotcp.hpp>	// Pascal unit
#include <Crbase64.hpp>	// Pascal unit
#include <Crdatabuffer.hpp>	// Pascal unit
#include <Crhttp.hpp>	// Pascal unit
#include <Crviohttp.hpp>	// Pascal unit
#include <Crviotcpssl.hpp>	// Pascal unit
#include <Mtscall.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Varutils.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Timespan.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Comobj.hpp>	// Pascal unit
#include <Widestrings.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Ioutils.hpp>	// Pascal unit
#include <Inifiles.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dac140
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dac140 */
using namespace Dac140;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dac140HPP
