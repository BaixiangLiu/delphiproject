// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crbatchmove.pas' rev: 21.00

#ifndef CrbatchmoveHPP
#define CrbatchmoveHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crbatchmove
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TCRBatchMode { bmAppend, bmUpdate, bmAppendUpdate, bmDelete };
#pragma option pop

typedef void __fastcall (__closure *TCRBatchMoveProgressEvent)(System::TObject* Sender, int Percent);

typedef bool __fastcall (__closure *TDALocate)(void);

#pragma option push -b-
enum TCRFieldMappingMode { mmFieldIndex, mmFieldName };
#pragma option pop

class DELPHICLASS TCRBatchMove;
class PASCALIMPLEMENTATION TCRBatchMove : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	typedef DynamicArray<Db::TField*> _TCRBatchMove__1;
	
	typedef DynamicArray<bool> _TCRBatchMove__2;
	
	typedef DynamicArray<System::Variant> _TCRBatchMove__3;
	
	typedef DynamicArray<System::Word> _TCRBatchMove__4;
	
	
private:
	Dbaccess::TFieldArray FFldDestKeys;
	System::UnicodeString FStrDestKeys;
	_TCRBatchMove__1 FSrcKeyFields;
	_TCRBatchMove__2 FDestKeyFields;
	_TCRBatchMove__3 FKeyValues;
	_TCRBatchMove__4 FFieldMap;
	Db::_di_IProviderSupport FPSDestination;
	TDALocate Locate;
	void __fastcall SetMappings(Classes::TStrings* Value);
	void __fastcall SetSource(Db::TDataSet* Value);
	void __fastcall SetDestination(Db::TDataSet* Value);
	Db::_di_IProviderSupport __fastcall GetProviderSupport(Db::TDataSet* DataSet);
	bool __fastcall LocateForCustomDaDataSet(void);
	bool __fastcall LocateForDataSet(void);
	
protected:
	Db::TDataSet* FDestination;
	Db::TDataSet* FSource;
	TCRBatchMode FMode;
	bool FAbortOnKeyViol;
	bool FAbortOnProblem;
	int FRecordCount;
	int FMovedCount;
	int FKeyViolCount;
	int FProblemCount;
	int FChangedCount;
	Classes::TStrings* FMappings;
	TCRFieldMappingMode FFieldMappingMode;
	int FCommitCount;
	TCRBatchMoveProgressEvent FOnBatchMoveProgress;
	bool FTransactionNeeds;
	int FAppliedCount;
	System::Word FDestCountKeys;
	void __fastcall DoBatchMoveProgress(int Percent);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	System::Variant __fastcall GetKeyValues(void);
	void __fastcall SetFieldsValues(bool SetKeyFields);
	void __fastcall Append(void);
	void __fastcall Update(void);
	void __fastcall AppendUpdate(void);
	void __fastcall Delete(void);
	
public:
	__fastcall virtual TCRBatchMove(Classes::TComponent* AOwner);
	__fastcall virtual ~TCRBatchMove(void);
	void __fastcall Execute(void);
	__property int ChangedCount = {read=FChangedCount, nodefault};
	__property int KeyViolCount = {read=FKeyViolCount, nodefault};
	__property int MovedCount = {read=FMovedCount, nodefault};
	__property int ProblemCount = {read=FProblemCount, nodefault};
	
__published:
	__property bool AbortOnKeyViol = {read=FAbortOnKeyViol, write=FAbortOnKeyViol, default=1};
	__property bool AbortOnProblem = {read=FAbortOnProblem, write=FAbortOnProblem, default=1};
	__property int CommitCount = {read=FCommitCount, write=FCommitCount, default=0};
	__property Db::TDataSet* Destination = {read=FDestination, write=SetDestination};
	__property Classes::TStrings* Mappings = {read=FMappings, write=SetMappings};
	__property TCRFieldMappingMode FieldMappingMode = {read=FFieldMappingMode, write=FFieldMappingMode, default=0};
	__property TCRBatchMode Mode = {read=FMode, write=FMode, default=0};
	__property int RecordCount = {read=FRecordCount, write=FRecordCount, default=0};
	__property Db::TDataSet* Source = {read=FSource, write=SetSource};
	__property TCRBatchMoveProgressEvent OnBatchMoveProgress = {read=FOnBatchMoveProgress, write=FOnBatchMoveProgress};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Crbatchmove */
using namespace Crbatchmove;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrbatchmoveHPP
