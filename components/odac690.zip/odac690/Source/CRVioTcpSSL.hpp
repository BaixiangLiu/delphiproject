// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crviotcpssl.pas' rev: 21.00

#ifndef CrviotcpsslHPP
#define CrviotcpsslHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit
#include <Crviotcp.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crviotcpssl
{
//-- type declarations -------------------------------------------------------
#pragma pack(push,1)
struct st_VioSSLConnectorFd
{
	
public:
	void *ssl_context_;
	void *ssl_method_;
};
#pragma pack(pop)


class DELPHICLASS TCRVioTcpSSL;
class PASCALIMPLEMENTATION TCRVioTcpSSL : public Crviotcp::TCRVioTcp
{
	typedef Crviotcp::TCRVioTcp inherited;
	
protected:
	bool FisSecure;
	System::AnsiString FSSL_key;
	System::AnsiString FSSL_cert;
	System::AnsiString FSSL_ca;
	System::AnsiString FSSL_capath;
	System::AnsiString FSSL_cipher;
	st_VioSSLConnectorFd Fnewcon;
	void *Fssl_arg;
	void __fastcall new_VioSSLConnectorFd(void);
	void __fastcall SetisSecure(bool Value);
	
public:
	__fastcall TCRVioTcpSSL(const System::AnsiString hostname, const int port, const System::AnsiString SSL_key, const System::AnsiString SSL_cert, const System::AnsiString SSL_ca, const System::AnsiString SSL_capath, const System::AnsiString SSL_cipher);
	virtual int __fastcall ReadNoWait(char * buffer, int offset, int count);
	virtual int __fastcall WriteNoWait(const char * buffer, int offset, int count);
	__property bool isSecure = {read=FisSecure, write=SetisSecure, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRVioTcpSSL(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt SSL_VERIFY_NONE = 0x0;
static const ShortInt SSL_CTRL_SET_TMP_DH = 0x3;
extern PACKAGE int __cdecl (*SSL_write)(void * s, void * pBuf, int len);
extern PACKAGE int __cdecl (*SSL_read)(void * s, void * pBuf, int len);
extern PACKAGE int __cdecl (*SSL_get_error)(const void * s, int ret_code);
extern PACKAGE void __cdecl (*SSL_free)(void * s);
extern PACKAGE void __cdecl (*SSL_load_error_strings)(void);
extern PACKAGE void * __cdecl (*TLSv1_client_method)(void);
extern PACKAGE int __cdecl (*SSL_library_init)(void);
extern PACKAGE void * __cdecl (*SSL_CTX_new)(void * meth);
extern PACKAGE int __cdecl (*SSL_CTX_set_cipher_list)(void * actx, const char * str);
extern PACKAGE void * __cdecl (*SSL_new)(void * s);
extern PACKAGE int __cdecl (*SSL_clear)(void * s);
extern PACKAGE int __cdecl (*SSL_SESSION_set_timeout)(void * s, unsigned t);
extern PACKAGE void * __cdecl (*SSL_get_session)(void * s);
extern PACKAGE int __cdecl (*SSL_set_fd)(void * s, int fd);
extern PACKAGE void __cdecl (*SSL_set_connect_state)(void * s);
extern PACKAGE int __cdecl (*SSL_do_handshake)(void * s);
extern PACKAGE void __cdecl (*SSL_CTX_set_verify)(void * actx, int mode, void * acallback);
extern PACKAGE int __cdecl (*SSL_CTX_load_verify_locations)(void * actx, const char * CAfile, const char * CApath);
extern PACKAGE int __cdecl (*SSL_CTX_set_default_verify_paths)(void * actx);
extern PACKAGE int __cdecl (*SSL_CTX_use_certificate_file)(void * actx, const char * afile, int atype);
extern PACKAGE int __cdecl (*SSL_CTX_use_PrivateKey_file)(void * actx, const char * afile, int atype);
extern PACKAGE int __cdecl (*SSL_CTX_check_private_key)(const void * actx);
extern PACKAGE void * __cdecl (*DH_new)(void);
extern PACKAGE int __cdecl (*DH_free)(void * dh);
extern PACKAGE void __cdecl (*OPENSSL_add_all_algorithms_noconf)(void);
extern PACKAGE void * __cdecl (*BN_bin2bn)(const void * s, int len, void * ret);
extern PACKAGE void * __cdecl (*X509_get_subject_name)(void * a);
extern PACKAGE char * __cdecl (*X509_NAME_oneline)(void * a, char * buf, int size);
extern PACKAGE int __cdecl (*X509_STORE_CTX_get_error_depth)(void * actx);
extern PACKAGE int __cdecl (*X509_STORE_CTX_get_error)(void * actx);
extern PACKAGE void * __cdecl (*X509_STORE_CTX_get_current_cert)(void * actx);
extern PACKAGE int __cdecl (*SSL_CTX_ctrl)(void * actx, int a1, int a2, void * adh);
extern PACKAGE void * __cdecl (*X509_get_issuer_name)(void * a);
extern PACKAGE System::UnicodeString LIBEAY32DLL;
extern PACKAGE System::UnicodeString SSLEAY32DLL;
extern PACKAGE bool ssl_algorithms_added;
extern PACKAGE bool ssl_error_strings_loaded;
extern PACKAGE int __cdecl vio_verify_callback(int ok, void * ctx);
extern PACKAGE int __fastcall vio_set_cert_stuff(void * ctx, const System::AnsiString cert_file, System::AnsiString key_file);
extern PACKAGE void * __fastcall get_dh512(void);
extern PACKAGE void __fastcall LoadSSLLib(void);
extern PACKAGE void __fastcall InitSSLLib(void);

}	/* namespace Crviotcpssl */
using namespace Crviotcpssl;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrviotcpsslHPP
