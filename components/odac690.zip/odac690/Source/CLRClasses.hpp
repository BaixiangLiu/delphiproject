// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Clrclasses.pas' rev: 21.00

#ifndef ClrclassesHPP
#define ClrclassesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Clrclasses
{
//-- type declarations -------------------------------------------------------
typedef int Int;

typedef short Int16;

typedef int Int32;

typedef System::Word UInt16;

typedef unsigned UInt32;

typedef System::ShortInt sbyte;

typedef void * IntPtr;

typedef void * MulticastDelegate;

class DELPHICLASS BitConverter;
class PASCALIMPLEMENTATION BitConverter : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod Sysutils::TBytes __fastcall GetBytes(System::Word value)/* overload */;
	__classmethod Sysutils::TBytes __fastcall GetBytes(unsigned value)/* overload */;
	__classmethod Sysutils::TBytes __fastcall GetBytes(__int64 value)/* overload */;
	__classmethod Sysutils::TBytes __fastcall GetBytes(double value)/* overload */;
	__classmethod Sysutils::TBytes __fastcall GetBytes(float value)/* overload */;
	__classmethod double __fastcall Int64BitsToDouble(__int64 Value);
	__classmethod __int64 __fastcall DoubleToInt64Bits(double Value);
	__classmethod double __fastcall ToDouble(const Sysutils::TBytes value, int startIndex)/* overload */;
	__classmethod double __fastcall ToDouble(char * value, int startIndex)/* overload */;
	__classmethod float __fastcall ToSingle(const Sysutils::TBytes value, int startIndex);
	__classmethod __int64 __fastcall ToInt64(const Sysutils::TBytes value, int startIndex)/* overload */;
	__classmethod __int64 __fastcall ToInt64(char * value, int startIndex)/* overload */;
	__classmethod int __fastcall ToInt32(const Sysutils::TBytes value, int startIndex)/* overload */;
	__classmethod int __fastcall ToInt32(char * value, int startIndex)/* overload */;
	__classmethod short __fastcall ToInt16(const Sysutils::TBytes value, int startIndex);
	__classmethod unsigned __fastcall ToUInt32(const Sysutils::TBytes value, int startIndex);
	__classmethod System::Word __fastcall ToUInt16(const Sysutils::TBytes value, int startIndex)/* overload */;
	__classmethod System::Word __fastcall ToUInt16(char * value, int startIndex)/* overload */;
public:
	/* TObject.Create */ inline __fastcall BitConverter(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~BitConverter(void) { }
	
};


class DELPHICLASS Marshal;
class PASCALIMPLEMENTATION Marshal : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void * __fastcall AllocHGlobal(int cb);
	__classmethod void * __fastcall ReallocHGlobal(void * pv, void * cb);
	__classmethod void __fastcall FreeHGlobal(void * hglobal);
	__classmethod void __fastcall FreeCoTaskMem(void * ptr);
	__classmethod System::Byte __fastcall ReadByte(void * ptr, int ofs = 0x0);
	__classmethod void __fastcall WriteByte(void * ptr, System::Byte val)/* overload */;
	__classmethod void __fastcall WriteByte(void * ptr, int ofs, System::Byte val)/* overload */;
	__classmethod short __fastcall ReadInt16(void * ptr, int ofs = 0x0);
	__classmethod void __fastcall WriteInt16(void * ptr, short val)/* overload */;
	__classmethod void __fastcall WriteInt16(void * ptr, int ofs, short val)/* overload */;
	__classmethod int __fastcall ReadInt32(void * ptr, int ofs = 0x0);
	__classmethod void __fastcall WriteInt32(void * ptr, int val)/* overload */;
	__classmethod void __fastcall WriteInt32(void * ptr, int ofs, int val)/* overload */;
	__classmethod __int64 __fastcall ReadInt64(void * ptr, int ofs = 0x0);
	__classmethod void __fastcall WriteInt64(void * ptr, __int64 val)/* overload */;
	__classmethod void __fastcall WriteInt64(void * ptr, double val)/* overload */;
	__classmethod void __fastcall WriteInt64(void * ptr, int ofs, __int64 val)/* overload */;
	__classmethod void * __fastcall ReadIntPtr(void * ptr, int ofs = 0x0);
	__classmethod void __fastcall WriteIntPtr(void * ptr, void * val)/* overload */;
	__classmethod void __fastcall WriteIntPtr(void * ptr, int ofs, void * val)/* overload */;
	__classmethod System::AnsiString __fastcall PtrToStringAnsi(void * ptr, int len = 0x0);
	__classmethod System::WideString __fastcall PtrToStringUni(void * ptr, int len = 0x0);
	__classmethod void * __fastcall StringToHGlobalAnsi(const System::AnsiString s);
	__classmethod void * __fastcall StringToHGlobalUni(const System::WideString s);
	__classmethod void __fastcall Copy(const Sysutils::TBytes source, int startIndex, void * destination, int length)/* overload */;
	__classmethod void __fastcall Copy(void * source, const Sysutils::TBytes destination, int startIndex, int length)/* overload */;
	__classmethod void * __fastcall GetIUnknownForObject(System::TInterfacedObject* o);
	__classmethod int __fastcall AddRef(void * pUnk);
	__classmethod int __fastcall Release(void * pUnk);
public:
	/* TObject.Create */ inline __fastcall Marshal(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~Marshal(void) { }
	
};


class DELPHICLASS Encoding;
class PASCALIMPLEMENTATION Encoding : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod Encoding* __fastcall Default();
	__classmethod Encoding* __fastcall Unicode();
	__classmethod Encoding* __fastcall UTF8();
	__classmethod Encoding* __fastcall GetEncoding(int codepage);
	__classmethod Sysutils::TBytes __fastcall Convert(Encoding* srcEncoding, Encoding* dstEncoding, Sysutils::TBytes bytes)/* overload */;
	__classmethod Sysutils::TBytes __fastcall Convert(Encoding* srcEncoding, Encoding* dstEncoding, Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual Sysutils::TBytes __fastcall GetBytes(const System::AnsiString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::AnsiString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual Sysutils::TBytes __fastcall GetBytes(const System::WideString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::WideString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual int __fastcall GetMaxByteCount(int charCount);
public:
	/* TObject.Create */ inline __fastcall Encoding(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~Encoding(void) { }
	
};


class DELPHICLASS UnicodeEncoding;
class PASCALIMPLEMENTATION UnicodeEncoding : public Encoding
{
	typedef Encoding inherited;
	
public:
	virtual Sysutils::TBytes __fastcall GetBytes(const System::AnsiString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::AnsiString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual Sysutils::TBytes __fastcall GetBytes(const System::WideString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::WideString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual int __fastcall GetMaxByteCount(int charCount);
public:
	/* TObject.Create */ inline __fastcall UnicodeEncoding(void) : Encoding() { }
	/* TObject.Destroy */ inline __fastcall virtual ~UnicodeEncoding(void) { }
	
};


class DELPHICLASS UTF8Encoding;
class PASCALIMPLEMENTATION UTF8Encoding : public Encoding
{
	typedef Encoding inherited;
	
public:
	virtual Sysutils::TBytes __fastcall GetBytes(const System::AnsiString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::AnsiString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual Sysutils::TBytes __fastcall GetBytes(const System::WideString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::WideString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual int __fastcall GetMaxByteCount(int charCount);
public:
	/* TObject.Create */ inline __fastcall UTF8Encoding(void) : Encoding() { }
	/* TObject.Destroy */ inline __fastcall virtual ~UTF8Encoding(void) { }
	
};


class DELPHICLASS CodePageEncoding;
class PASCALIMPLEMENTATION CodePageEncoding : public Encoding
{
	typedef Encoding inherited;
	
private:
	int FCodePage;
	
public:
	__fastcall CodePageEncoding(int CodePage);
	virtual Sysutils::TBytes __fastcall GetBytes(const System::AnsiString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::AnsiString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual Sysutils::TBytes __fastcall GetBytes(const System::WideString chars)/* overload */;
	virtual int __fastcall GetBytes(const System::WideString chars, int charIndex, int charCount, Sysutils::TBytes &bytes, int byteIndex)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::AnsiString __fastcall GetString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes)/* overload */;
	virtual System::WideString __fastcall GetWideString(const Sysutils::TBytes bytes, int index, int count)/* overload */;
	virtual int __fastcall GetMaxByteCount(int charCount);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~CodePageEncoding(void) { }
	
};


typedef DynamicArray<char> TAnsiCharArray;

class DELPHICLASS AnsiStringBuilder;
class PASCALIMPLEMENTATION AnsiStringBuilder : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TAnsiCharArray FString;
	int FActualLength;
	void __fastcall SetActualLength(int Value);
	
public:
	__fastcall AnsiStringBuilder(int capacity)/* overload */;
	__fastcall AnsiStringBuilder(const System::AnsiString value, int capacity)/* overload */;
	void __fastcall Append(const System::AnsiString value)/* overload */;
	void __fastcall Append(const System::AnsiString value, const int startIndex, const int count)/* overload */;
	void __fastcall Append(char value)/* overload */;
	void __fastcall Append(char value, int repeatCount)/* overload */;
	void __fastcall Append(AnsiStringBuilder* value)/* overload */;
	void __fastcall Insert(int index, const System::AnsiString value)/* overload */;
	void __fastcall Replace(const System::AnsiString OldValue, const System::AnsiString NewValue);
	HIDESBASE System::AnsiString __fastcall ToString(void);
	__property int Length = {read=FActualLength, write=SetActualLength, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~AnsiStringBuilder(void) { }
	
};


typedef DynamicArray<System::WideChar> TWideCharArray;

typedef System::UnicodeString WString;

class DELPHICLASS WideStringBuilder;
class PASCALIMPLEMENTATION WideStringBuilder : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TWideCharArray FString;
	int FActualLength;
	void __fastcall SetActualLength(int Value);
	
public:
	__fastcall WideStringBuilder(int capacity)/* overload */;
	__fastcall WideStringBuilder(const System::UnicodeString value, int capacity)/* overload */;
	void __fastcall Append(const System::UnicodeString value)/* overload */;
	void __fastcall Append(const System::UnicodeString value, const int startIndex, const int count)/* overload */;
	void __fastcall Append(System::WideChar value)/* overload */;
	void __fastcall Append(System::WideChar value, int repeatCount)/* overload */;
	void __fastcall Append(WideStringBuilder* value)/* overload */;
	void __fastcall Insert(int index, const System::UnicodeString value)/* overload */;
	void __fastcall Replace(const System::UnicodeString OldValue, const System::UnicodeString NewValue);
	virtual System::UnicodeString __fastcall ToString(void);
	__property int Length = {read=FActualLength, write=SetActualLength, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~WideStringBuilder(void) { }
	
};


typedef WideStringBuilder StringBuilder;

class DELPHICLASS Buffer;
class PASCALIMPLEMENTATION Buffer : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall BlockCopy(const Sysutils::TBytes src, int srcOffset, const Sysutils::TBytes dst, int dstOffset, int count);
	__classmethod System::Byte __fastcall GetByte(const void * src, int Index);
	__classmethod void __fastcall SetByte(const void * src, int Index, System::Byte Value);
public:
	/* TObject.Create */ inline __fastcall Buffer(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~Buffer(void) { }
	
};


class DELPHICLASS MemoryStream;
class PASCALIMPLEMENTATION MemoryStream : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Sysutils::TBytes FData;
	int FPosition;
	int FLength;
	
protected:
	void __fastcall SetPosition(const int Pos);
	
public:
	__fastcall MemoryStream(int capacity);
	int __fastcall Seek(int Offset, System::Word Origin);
	int __fastcall Read(Sysutils::TBytes &Buffer, int Offset, int Count)/* overload */;
	int __fastcall Read(char * Buffer, int Offset, int Count)/* overload */;
	void __fastcall Write(const Sysutils::TBytes Buffer, int Offset, int Count)/* overload */;
	void __fastcall Write(char * Buffer, int Offset, int Count)/* overload */;
	void __fastcall WriteByte(System::Byte value);
	System::Byte __fastcall ReadByte(void);
	char * __fastcall GetBuffer(void);
	void __fastcall Close(void);
	void __fastcall SetLength(int Value);
	__property int Length = {read=FLength, write=SetLength, nodefault};
	__property int Position = {read=FPosition, write=SetPosition, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~MemoryStream(void) { }
	
};


class DELPHICLASS ArgumentException;
class PASCALIMPLEMENTATION ArgumentException : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	__fastcall ArgumentException(void)/* overload */;
	__fastcall ArgumentException(const System::UnicodeString Msg)/* overload */;
public:
	/* Exception.CreateFmt */ inline __fastcall ArgumentException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall ArgumentException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall ArgumentException(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall ArgumentException(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall ArgumentException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall ArgumentException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall ArgumentException(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~ArgumentException(void) { }
	
};


class DELPHICLASS NotSupportedException;
class PASCALIMPLEMENTATION NotSupportedException : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	__fastcall NotSupportedException(void)/* overload */;
	__fastcall NotSupportedException(const System::UnicodeString Msg)/* overload */;
public:
	/* Exception.CreateFmt */ inline __fastcall NotSupportedException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall NotSupportedException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall NotSupportedException(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall NotSupportedException(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall NotSupportedException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall NotSupportedException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall NotSupportedException(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~NotSupportedException(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Clrclasses */
using namespace Clrclasses;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ClrclassesHPP
