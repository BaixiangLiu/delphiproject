// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crviohttp.pas' rev: 21.00

#ifndef CrviohttpHPP
#define CrviohttpHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Win32timer.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit
#include <Crhttp.hpp>	// Pascal unit
#include <Crbase64.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crviohttp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCRVioHttp;
class PASCALIMPLEMENTATION TCRVioHttp : public Crvio::TCRVio
{
	typedef Crvio::TCRVio inherited;
	
private:
	Crvio::THttpOptions* FHttpOptions;
	System::UnicodeString FUrl;
	System::UnicodeString FConnectUrl;
	System::UnicodeString FTestUrl;
	int FPortID;
	bool FClosed;
	Crhttp::TCRHttp* FLastReadRequest;
	Sysutils::TBytes FLastReadBuffer;
	int FTimeout;
	int FScriptNotificationTime;
	Syncobjs::TCriticalSection* FSendingLock;
	Sysutils::Exception* FThreadException;
	Win32timer::TWin32Timer* FNotificationTimer;
	void __fastcall OnScriptNotification(System::TObject* Sender);
	void __fastcall StartNotificationTimer(void);
	void __fastcall StartHttpServerScript(void);
	Crhttp::TCRHttp* __fastcall CreateRequest(const System::UnicodeString Url, const System::WideChar Command, const System::UnicodeString Method);
	void __fastcall CloseRequest(Crhttp::TCRHttp* &Request, bool IsConnect = false);
	void __fastcall CheckConnectResponse(Crhttp::TCRHttp* Request);
	void __fastcall CheckResponseSuccess(Crhttp::TCRHttp* Request);
	void __fastcall CheckThreadException(void);
	Crhttp::TCRHttp* __fastcall ExecuteGetRequest(const System::UnicodeString Url, const System::WideChar Command)/* overload */;
	Crhttp::TCRHttp* __fastcall ExecuteGetRequest(const System::UnicodeString Url, const System::WideChar Command, bool CheckLeaseException)/* overload */;
	
protected:
	virtual int __fastcall GetTimeout(void);
	virtual void __fastcall SetTimeout(int Value);
	
public:
	__fastcall TCRVioHttp(Crvio::THttpOptions* HttpOptions, const System::AnsiString hostname, const int port);
	__fastcall virtual ~TCRVioHttp(void);
	virtual void __fastcall Connect(void);
	virtual void __fastcall Close(void);
	virtual int __fastcall ReadNoWait(char * buffer, int offset, int count);
	virtual int __fastcall WriteNoWait(const char * buffer, int offset, int count);
	virtual int __fastcall Write(const char * buffer, int offset, int count);
	virtual bool __fastcall WaitForData(int Timeout = 0xffffffff);
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Crviohttp */
using namespace Crviohttp;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrviohttpHPP
