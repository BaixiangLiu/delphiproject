// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dbaccess.pas' rev: 21.00

#ifndef DbaccessHPP
#define DbaccessHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Memds.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Win32timer.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Crxml.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dbaccess
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TCustomDASQLClass;

typedef TMetaClass* TCustomDADataSetClass;

typedef TMetaClass* TDADataSetServiceClass;

typedef TMetaClass* TDADataSetUpdaterClass;

typedef TMetaClass* TConnectDialogClass;

struct TLocalMDLink
{
	
public:
	bool IsNull;
	void *Buffer;
	int BufferType;
	bool NativeBuffer;
	int FieldNo;
};


typedef DynamicArray<TLocalMDLink> TLocalMDLinks;

class DELPHICLASS EDAError;
class PASCALIMPLEMENTATION EDAError : public Db::EDatabaseError
{
	typedef Db::EDatabaseError inherited;
	
protected:
	int FErrorCode;
	System::TObject* FComponent;
	
public:
	__fastcall EDAError(int ErrorCode, System::UnicodeString Msg);
	virtual bool __fastcall IsFatalError(void);
	virtual bool __fastcall IsKeyViolation(void);
	__property int ErrorCode = {read=FErrorCode, nodefault};
	__property System::TObject* Component = {read=FComponent, write=FComponent};
public:
	/* Exception.CreateFmt */ inline __fastcall EDAError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Db::EDatabaseError(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EDAError(int Ident)/* overload */ : Db::EDatabaseError(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EDAError(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Db::EDatabaseError(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EDAError(const System::UnicodeString Msg, int AHelpContext) : Db::EDatabaseError(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EDAError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Db::EDatabaseError(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EDAError(int Ident, int AHelpContext)/* overload */ : Db::EDatabaseError(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EDAError(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Db::EDatabaseError(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EDAError(void) { }
	
};


#pragma option push -b-
enum TRetryMode { rmRaise, rmReconnect, rmReconnectExecute };
#pragma option pop

struct TFailOverOperation
{
	
public:
	Memdata::TConnLostCause Operation;
	bool AllowFailOver;
};


typedef DynamicArray<TFailOverOperation> TOperationsStack;

typedef void __fastcall (__closure *TDAConnectionErrorEvent)(System::TObject* Sender, EDAError* E, bool &Fail);

typedef void __fastcall (__closure *TConnectionLostEvent)(System::TObject* Sender, Classes::TComponent* Component, Memdata::TConnLostCause ConnLostCause, TRetryMode &RetryMode);

class DELPHICLASS TDAConnectionOptions;
class DELPHICLASS TCustomDAConnection;
class PASCALIMPLEMENTATION TDAConnectionOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	bool FKeepDesignConnected;
	bool FDisconnectedMode;
	bool FLocalFailover;
	Memdata::TSortType FDefaultSortType;
	bool FEnableBCD;
	bool FEnableFMTBCD;
	void __fastcall SetDisconnectedMode(bool Value);
	void __fastcall SetDefaultSortType(Memdata::TSortType Value);
	void __fastcall SetEnableBCD(bool Value);
	void __fastcall SetEnableFMTBCD(bool Value);
	
protected:
	TCustomDAConnection* FOwner;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	__property bool EnableBCD = {read=FEnableBCD, write=SetEnableBCD, default=0};
	__property bool EnableFMTBCD = {read=FEnableFMTBCD, write=SetEnableFMTBCD, default=0};
	
public:
	__fastcall TDAConnectionOptions(TCustomDAConnection* Owner);
	__property bool DisconnectedMode = {read=FDisconnectedMode, write=SetDisconnectedMode, default=0};
	__property bool KeepDesignConnected = {read=FKeepDesignConnected, write=FKeepDesignConnected, default=1};
	__property bool LocalFailover = {read=FLocalFailover, write=FLocalFailover, default=0};
	__property Memdata::TSortType DefaultSortType = {read=FDefaultSortType, write=SetDefaultSortType, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TDAConnectionOptions(void) { }
	
};


class DELPHICLASS TPoolingOptions;
class PASCALIMPLEMENTATION TPoolingOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
protected:
	TCustomDAConnection* FOwner;
	int FMaxPoolSize;
	int FMinPoolSize;
	int FConnectionLifetime;
	bool FValidate;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall virtual TPoolingOptions(TCustomDAConnection* Owner);
	
__published:
	__property int MaxPoolSize = {read=FMaxPoolSize, write=FMaxPoolSize, default=100};
	__property int MinPoolSize = {read=FMinPoolSize, write=FMinPoolSize, default=0};
	__property int ConnectionLifetime = {read=FConnectionLifetime, write=FConnectionLifetime, default=0};
	__property bool Validate = {read=FValidate, write=FValidate, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TPoolingOptions(void) { }
	
};


class DELPHICLASS TDATransactions;
class DELPHICLASS TCustomConnectDialog;
class DELPHICLASS TDATransaction;
class DELPHICLASS TCustomDASQL;
class DELPHICLASS TDAParam;
class DELPHICLASS TCustomDADataSet;
class DELPHICLASS TDAMetaData;
class PASCALIMPLEMENTATION TCustomDAConnection : public Db::TCustomConnection
{
	typedef Db::TCustomConnection inherited;
	
private:
	TDATransactions* FTransactions;
	System::UnicodeString FUsername;
	bool FAutoCommit;
	bool FInProcessError;
	TCustomConnectDialog* FConnectDialog;
	bool FDebug;
	TDAConnectionErrorEvent FOnError;
	bool FConvertEOL;
	TDAConnectionOptions* FOptions;
	TPoolingOptions* FPoolingOptions;
	bool FPooling;
	TConnectionLostEvent FOnConnectionLost;
	Syncobjs::TCriticalSection* hRegisterClient;
	void __fastcall ClearRefs(void);
	void __fastcall SetDefaultTransaction(TDATransaction* Value);
	TDATransaction* __fastcall GetDefaultTransaction(void);
	TDATransaction* __fastcall GetTransaction(int Index);
	int __fastcall GetTransactionsCount(void);
	void __fastcall SetUsername(const System::UnicodeString Value);
	void __fastcall SetPassword(const System::UnicodeString Value);
	void __fastcall SetAutoCommit(bool Value);
	void __fastcall SetConnectDialog(TCustomConnectDialog* Value);
	void __fastcall SetPooling(bool Value);
	void __fastcall SetDebug(bool Value);
	void __fastcall DoAfterConnect(void);
	
protected:
	TDATransaction* FDefaultTransaction;
	TDATransaction* FInternalDefTransaction;
	int FConnectCount;
	Classes::TList* FSQLs;
	Craccess::TCRConnection* FIConnection;
	bool FStreamedConnected;
	System::UnicodeString FServer;
	System::UnicodeString FPassword;
	bool FShouldShowPrompt;
	TOperationsStack FOperationsStack;
	int FOperationsStackLen;
	TCustomDASQL* FCommand;
	bool FLockLoginPrompt;
	Crvio::TCRIOHandler* FIOHandler;
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall SetIOHandler(Crvio::TCRIOHandler* Value);
	virtual Craccess::TCRConnectionClass __fastcall GetIConnectionClass(void);
	virtual Craccess::TCRCommandClass __fastcall GetICommandClass(void);
	virtual Craccess::TCRRecordSetClass __fastcall GetIRecordSetClass(void);
	virtual Craccess::TCRMetaDataClass __fastcall GetIMetaDataClass(void);
	virtual bool __fastcall IsMultipleTransactionsSupported(void);
	virtual void __fastcall CreateIConnection(void);
	Craccess::TCRCommand* __fastcall CreateICommand(void);
	Craccess::TCRRecordSet* __fastcall CreateIRecordSet(void);
	void __fastcall FreeIConnection(void);
	virtual void __fastcall SetIConnection(Craccess::TCRConnection* Value);
	void __fastcall ClearTransactionRefs(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall RegisterClient(System::TObject* Client, Db::TConnectChangeEvent Event = 0x0);
	virtual void __fastcall UnRegisterClient(System::TObject* Client);
	virtual System::TClass __fastcall SQLMonitorClass(void);
	virtual TConnectDialogClass __fastcall ConnectDialogClass(void);
	virtual void __fastcall DoConnect(void);
	virtual void __fastcall DoDisconnect(void);
	virtual void __fastcall DisconnectTransaction(void);
	virtual void __fastcall InternalConnect(void);
	virtual void __fastcall InternalDisconnect(void);
	virtual System::UnicodeString __fastcall InternalGetServer(void);
	virtual bool __fastcall IsConnectedStored(void);
	virtual bool __fastcall NeedPrompt(void);
	virtual int __fastcall PushOperation(Memdata::TConnLostCause Operation, bool AllowFailOver = true);
	virtual Memdata::TConnLostCause __fastcall PopOperation(void);
	virtual void __fastcall ResetOnFatalError(void);
	virtual void __fastcall RestoreAfterFailOver(void);
	virtual bool __fastcall IsFailOverAllowed(void);
	virtual Memdata::TConnLostCause __fastcall DetectConnLostCause(System::TObject* Component);
	virtual void __fastcall DoError(Sysutils::Exception* E, bool &Fail, bool &Reconnect, bool &Reexecute, int ReconnectAttempt, Memdata::TConnLostCause &ConnLostCause);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual bool __fastcall GetConnected(void);
	virtual void __fastcall SetConnected(bool Value);
	virtual System::UnicodeString __fastcall GetConnectString(void);
	virtual void __fastcall SetConnectString(System::UnicodeString Value);
	virtual void __fastcall SetServer(const System::UnicodeString Value);
	void __fastcall SuppressAutoCommit(void);
	void __fastcall RestoreAutoCommit(void);
	virtual bool __fastcall DetectInTransaction(bool CanActivate = false);
	virtual bool __fastcall GetInTransaction(void);
	virtual TDATransaction* __fastcall UsedTransaction(void);
	void __fastcall SetConvertEOL(bool Value);
	virtual void __fastcall CheckCommand(void);
	virtual void __fastcall AssignConnectOptions(TCustomDAConnection* Source);
	virtual TDAConnectionOptions* __fastcall CreateOptions(void);
	void __fastcall SetOptions(TDAConnectionOptions* Value);
	virtual TPoolingOptions* __fastcall CreatePoolingOptions(void);
	void __fastcall SetPoolingOptions(TPoolingOptions* Value);
	int __fastcall InternalAddTransaction(TDATransaction* TR);
	void __fastcall InternalRemoveTransaction(TDATransaction* TR);
	virtual int __fastcall DoAddTransaction(TDATransaction* TR);
	virtual void __fastcall DoRemoveTransaction(TDATransaction* TR);
	virtual void __fastcall DoCommitRetaining(void);
	virtual void __fastcall DoRollbackRetaining(void);
	virtual void __fastcall DoSavepoint(const System::UnicodeString Name);
	virtual void __fastcall DoRollbackToSavepoint(const System::UnicodeString Name);
	virtual void __fastcall DoReleaseSavepoint(const System::UnicodeString Name);
	__property TDATransaction* DefaultTransaction = {read=GetDefaultTransaction, write=SetDefaultTransaction};
	__property int TransactionCount = {read=GetTransactionsCount, nodefault};
	__property TDATransaction* Transactions[int Index] = {read=GetTransaction};
	__property bool AutoCommit = {read=FAutoCommit, write=SetAutoCommit, default=1};
	__property System::UnicodeString ConnectString = {read=GetConnectString, write=SetConnectString, stored=false};
	__property Crvio::TCRIOHandler* IOHandler = {read=FIOHandler, write=SetIOHandler};
	
public:
	__fastcall virtual TCustomDAConnection(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomDAConnection(void);
	void __fastcall Connect(void);
	void __fastcall Disconnect(void);
	void __fastcall PerformConnect(bool Retry = false);
	void __fastcall AssignConnect(TCustomDAConnection* Source);
	TDAParam* __fastcall ParamByName(System::UnicodeString Name);
	virtual System::Variant __fastcall ExecSQL(System::UnicodeString Text, System::Variant const *Params, const int Params_Size);
	virtual System::Variant __fastcall ExecSQLEx(System::UnicodeString Text, System::Variant const *Params, const int Params_Size);
	virtual System::Variant __fastcall ExecProc(System::UnicodeString Name, System::Variant const *Params, const int Params_Size);
	virtual System::Variant __fastcall ExecProcEx(System::UnicodeString Name, System::Variant const *Params, const int Params_Size);
	virtual void __fastcall GetTableNames(Classes::TStrings* List, bool AllTables = false);
	virtual void __fastcall GetDatabaseNames(Classes::TStrings* List);
	virtual void __fastcall GetStoredProcNames(Classes::TStrings* List, bool AllProcs = false);
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual void __fastcall ApplyUpdates(void)/* overload */;
	virtual void __fastcall ApplyUpdates(TCustomDADataSet* *DataSets, const int DataSets_Size)/* overload */;
	virtual TDATransaction* __fastcall CreateTransaction(void);
	virtual TCustomDADataSet* __fastcall CreateDataSet(void);
	virtual TCustomDASQL* __fastcall CreateSQL(void);
	virtual TDAMetaData* __fastcall CreateMetaData(void);
	void __fastcall RemoveFromPool(void);
	void __fastcall MonitorMessage(const System::UnicodeString Msg);
	__property System::UnicodeString Username = {read=FUsername, write=SetUsername};
	__property System::UnicodeString Password = {read=FPassword, write=SetPassword};
	__property System::UnicodeString Server = {read=FServer, write=SetServer};
	__property bool InTransaction = {read=GetInTransaction, nodefault};
	__property TCustomConnectDialog* ConnectDialog = {read=FConnectDialog, write=SetConnectDialog};
	__property TDAConnectionErrorEvent OnError = {read=FOnError, write=FOnError};
	__property TConnectionLostEvent OnConnectionLost = {read=FOnConnectionLost, write=FOnConnectionLost};
	__property LoginPrompt = {default=1};
	__property bool ConvertEOL = {read=FConvertEOL, write=SetConvertEOL, default=0};
	__property bool Debug = {read=FDebug, write=SetDebug, default=0};
	__property TDAConnectionOptions* Options = {read=FOptions, write=SetOptions};
	__property TPoolingOptions* PoolingOptions = {read=FPoolingOptions, write=SetPoolingOptions};
	__property bool Pooling = {read=FPooling, write=SetPooling, default=0};
};


class DELPHICLASS TDAConnections;
class PASCALIMPLEMENTATION TDAConnections : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TCustomDAConnection* operator[](int Index) { return Items[Index]; }
	
private:
	TCustomDAConnection* __fastcall GetItems(int Index);
	
public:
	__property TCustomDAConnection* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TList.Destroy */ inline __fastcall virtual ~TDAConnections(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TDAConnections(void) : Classes::TList() { }
	
};


class PASCALIMPLEMENTATION TDATransactions : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TDATransaction* operator[](int Index) { return Items[Index]; }
	
private:
	TDATransaction* __fastcall GetItems(int Index);
	
public:
	__property TDATransaction* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TList.Destroy */ inline __fastcall virtual ~TDATransactions(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TDATransactions(void) : Classes::TList() { }
	
};


#pragma option push -b-
enum TTransactionType { ttNative, ttMTS };
#pragma option pop

typedef void __fastcall (__closure *TDATransactionErrorEvent)(System::TObject* Sender, EDAError* E, bool &Fail);

class PASCALIMPLEMENTATION TDATransaction : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	void __fastcall SetDefaultConnection(TCustomDAConnection* Value);
	void __fastcall SetIsolationLevel(Craccess::TCRIsolationLevel Value);
	void __fastcall SetReadOnly(bool Value);
	void __fastcall SetTransactionType(TTransactionType Value);
	TCustomDAConnection* __fastcall GetConnection(int Index);
	int __fastcall GetConnectionsCount(void);
	bool __fastcall GetActive(void);
	
protected:
	bool FDesignCreate;
	TCustomDAConnection* FDefaultConnection;
	int FTrStartCount;
	int FUnCommitedStatementCount;
	bool FExplicitlyStarted;
	bool FDisconnectedMode;
	int FFailOverSatus;
	bool FPrepared;
	TTransactionType FTransactionType;
	Craccess::TCRTransactionAction FDefaultCloseAction;
	Craccess::TCRIsolationLevel FIsolationLevel;
	bool FReadOnly;
	bool FInProcessError;
	TDATransactionErrorEvent FOnError;
	Craccess::TCRTransaction* FITransaction;
	bool FShareTransaction;
	TDAConnections* FConnections;
	bool __fastcall IsInternalTrStored(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual Craccess::TCRTransactionClass __fastcall GetITransactionClass(void);
	void __fastcall CheckITransaction(void);
	void __fastcall CreateITransaction(void);
	virtual void __fastcall SetITransaction(Craccess::TCRTransaction* Value);
	void __fastcall FreeITransaction(void);
	void __fastcall ClearRefs(void);
	virtual bool __fastcall DetectInTransaction(bool CanActivate = false);
	void __fastcall CheckActive(void);
	void __fastcall CheckInactive(void);
	void __fastcall Reset(void);
	void __fastcall Restore(void);
	void __fastcall CloseDataSets(void);
	virtual void __fastcall CloseTransaction(bool Force = false);
	virtual void __fastcall GainTransaction(void);
	virtual void __fastcall AutoCommitTransaction(bool NeedCommit);
	virtual void __fastcall ReleaseTransaction(void);
	virtual bool __fastcall CanAutoCommitExplicitTransaction(void);
	virtual System::TClass __fastcall SQLMonitorClass(void);
	virtual TCustomDAConnection* __fastcall UsedConnection(void);
	void __fastcall PrepareTransaction(bool CheckOnly = false);
	void __fastcall UnPrepareTransaction(void);
	virtual void __fastcall DoCommitRetaining(void);
	virtual void __fastcall DoRollbackRetaining(void);
	virtual void __fastcall DoSavepoint(const System::UnicodeString Name);
	virtual void __fastcall DoReleaseSavepoint(const System::UnicodeString Name);
	virtual void __fastcall DoRollbackToSavepoint(const System::UnicodeString Name);
	int __fastcall InternalAddConnection(TCustomDAConnection* Connection);
	void __fastcall InternalRemoveConnection(TCustomDAConnection* Connection);
	virtual int __fastcall DoAddConnection(TCustomDAConnection* Connection);
	virtual void __fastcall DoRemoveConnection(TCustomDAConnection* Connection);
	void __fastcall DoClearConnections(void);
	void __fastcall DoError(Sysutils::Exception* E, bool &Fail);
	__property TCustomDAConnection* Connections[int Index] = {read=GetConnection};
	__property int ConnectionsCount = {read=GetConnectionsCount, nodefault};
	__property TTransactionType TransactionType = {read=FTransactionType, write=SetTransactionType, default=0};
	__property Craccess::TCRIsolationLevel IsolationLevel = {read=FIsolationLevel, write=SetIsolationLevel, default=0};
	__property bool ReadOnly = {read=FReadOnly, write=SetReadOnly, default=0};
	
public:
	__fastcall virtual TDATransaction(Classes::TComponent* AOwner);
	__fastcall virtual ~TDATransaction(void);
	__property bool Active = {read=GetActive, nodefault};
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	__property TCustomDAConnection* DefaultConnection = {read=FDefaultConnection, write=SetDefaultConnection};
	__property Craccess::TCRTransactionAction DefaultCloseAction = {read=FDefaultCloseAction, write=FDefaultCloseAction, default=1};
	__property TDATransactionErrorEvent OnError = {read=FOnError, write=FOnError};
};


typedef TMetaClass* TDAParamInfoClass;

class DELPHICLASS TDAParamInfo;
class PASCALIMPLEMENTATION TDAParamInfo : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
protected:
	Db::TField* FField;
	bool FOld;
	int FParamIndex;
	
public:
	__property Db::TField* Field = {read=FField, write=FField};
	__property bool Old = {read=FOld, write=FOld, nodefault};
	__property int ParamIndex = {read=FParamIndex, write=FParamIndex, nodefault};
public:
	/* TCollectionItem.Create */ inline __fastcall virtual TDAParamInfo(Classes::TCollection* Collection) : Classes::TCollectionItem(Collection) { }
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TDAParamInfo(void) { }
	
};


class DELPHICLASS TDAParamsInfo;
class PASCALIMPLEMENTATION TDAParamsInfo : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
public:
	TDAParamInfo* operator[](int Index) { return Items[Index]; }
	
protected:
	HIDESBASE TDAParamInfo* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TDAParamInfo* Value);
	
public:
	__property TDAParamInfo* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Create */ inline __fastcall TDAParamsInfo(Classes::TCollectionItemClass ItemClass) : Classes::TCollection(ItemClass) { }
	/* TCollection.Destroy */ inline __fastcall virtual ~TDAParamsInfo(void) { }
	
};


class PASCALIMPLEMENTATION TDAParam : public Db::TParam
{
	typedef Db::TParam inherited;
	
private:
	int FSize;
	System::Word FSubDataType;
	bool __fastcall IsDataTypeStored(void);
	bool __fastcall IsValueStored(void);
	
protected:
	Memdata::TSharedObject* FParamObject;
	bool FNational;
	virtual Memdata::TSharedObject* __fastcall GetNativeParamObject(void);
	virtual void __fastcall SetParamObject(Memdata::TSharedObject* Value);
	virtual bool __fastcall IsObjectDataType(Db::TFieldType DataType)/* overload */;
	bool __fastcall IsObjectDataType(void)/* overload */;
	virtual bool __fastcall IsBlobDataType(Db::TFieldType DataType)/* overload */;
	virtual bool __fastcall IsBlobDataType(void)/* overload */;
	HIDESBASE virtual Db::TFieldType __fastcall GetDataType(void);
	HIDESBASE virtual void __fastcall SetDataType(Db::TFieldType Value);
	virtual int __fastcall GetSize(void);
	virtual void __fastcall SetSize(int Value);
	HIDESBASE virtual System::UnicodeString __fastcall GetAsString(void);
	HIDESBASE virtual void __fastcall SetAsString(const System::UnicodeString Value);
	HIDESBASE virtual System::AnsiString __fastcall GetAsAnsiString(void);
	HIDESBASE virtual void __fastcall SetAsAnsiString(const System::AnsiString Value);
	HIDESBASE virtual System::WideString __fastcall GetAsWideString(void);
	HIDESBASE virtual void __fastcall SetAsWideString(const System::WideString Value);
	HIDESBASE virtual Sysutils::TBytes __fastcall GetAsBytes(void);
	HIDESBASE virtual void __fastcall SetAsBytes(const Sysutils::TBytes Value);
	HIDESBASE virtual int __fastcall GetAsInteger(void);
	HIDESBASE virtual void __fastcall SetAsInteger(int Value);
	HIDESBASE virtual void __fastcall SetAsSmallInt(int Value);
	HIDESBASE virtual void __fastcall SetAsWord(int Value);
	HIDESBASE virtual double __fastcall GetAsFloat(void);
	HIDESBASE virtual void __fastcall SetAsFloat(double Value);
	HIDESBASE virtual __int64 __fastcall GetAsLargeInt(void);
	HIDESBASE virtual void __fastcall SetAsLargeInt(const __int64 Value);
	HIDESBASE virtual void __fastcall SetAsShortInt(int Value);
	HIDESBASE virtual void __fastcall SetAsByte(int Value);
	HIDESBASE virtual void __fastcall SetAsBlob(const Sysutils::TBytes Value);
	HIDESBASE virtual void __fastcall SetAsMemo(const System::UnicodeString Value);
	virtual Memdata::TBlob* __fastcall GetAsBlobRef(void);
	virtual void __fastcall SetAsBlobRef(const Memdata::TBlob* Value);
	virtual Memdata::TBlob* __fastcall GetAsMemoRef(void);
	virtual void __fastcall SetAsMemoRef(const Memdata::TBlob* Value);
	HIDESBASE virtual System::Variant __fastcall GetAsVariant(void);
	HIDESBASE virtual void __fastcall SetAsVariant(const System::Variant &Value);
	HIDESBASE virtual Sqltimst::TSQLTimeStamp __fastcall GetAsSQLTimeStamp(void);
	HIDESBASE virtual void __fastcall SetAsSQLTimeStamp(const Sqltimst::TSQLTimeStamp &Value);
	Craccess::TCRCursor* __fastcall GetAsCursor(void);
	void __fastcall SetAsCursor(Craccess::TCRCursor* Value);
	HIDESBASE virtual void __fastcall SetText(const System::UnicodeString Value);
	HIDESBASE virtual bool __fastcall GetIsNull(void);
	void __fastcall SetIsNull(bool Value);
	bool __fastcall GetNational(void);
	virtual void __fastcall SetNational(bool Value);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadExtDataType(Classes::TReader* Reader);
	void __fastcall WriteExtDataType(Classes::TWriter* Writer);
	virtual void __fastcall CreateObject(void);
	virtual void __fastcall FreeObject(void);
	HIDESBASE void __fastcall AssignParam(Db::TParam* Param);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	__property Memdata::TSharedObject* ParamObject = {read=FParamObject, write=SetParamObject};
	__property System::Word SubDataType = {read=FSubDataType, write=FSubDataType, nodefault};
	__property bool National = {read=GetNational, write=SetNational, nodefault};
	__property Craccess::TCRCursor* AsCursor = {read=GetAsCursor, write=SetAsCursor};
	
public:
	__fastcall virtual TDAParam(Classes::TCollection* Collection)/* overload */;
	__fastcall virtual ~TDAParam(void);
	HIDESBASE virtual void __fastcall Clear(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	HIDESBASE void __fastcall AssignField(Db::TField* Field);
	HIDESBASE virtual void __fastcall AssignFieldValue(Db::TField* Field, const System::Variant &Value);
	HIDESBASE void __fastcall LoadFromFile(const System::UnicodeString FileName, Db::TBlobType BlobType);
	HIDESBASE virtual void __fastcall LoadFromStream(Classes::TStream* Stream, Db::TBlobType BlobType);
	HIDESBASE void __fastcall SetBlobData(void * Buffer, int Size)/* overload */;
	HIDESBASE void __fastcall SetBlobData(void * Buffer)/* overload */;
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	__property System::AnsiString AsAnsiString = {read=GetAsAnsiString, write=SetAsAnsiString};
	__property System::WideString AsWideString = {read=GetAsWideString, write=SetAsWideString};
	__property Sysutils::TBytes AsBytes = {read=GetAsBytes, write=SetAsBytes};
	__property int AsInteger = {read=GetAsInteger, write=SetAsInteger, nodefault};
	__property int AsSmallInt = {read=GetAsInteger, write=SetAsSmallInt, nodefault};
	__property int AsWord = {read=GetAsInteger, write=SetAsWord, nodefault};
	__property double AsFloat = {read=GetAsFloat, write=SetAsFloat};
	__property __int64 AsLargeInt = {read=GetAsLargeInt, write=SetAsLargeInt};
	__property int AsShortInt = {read=GetAsInteger, write=SetAsShortInt, nodefault};
	__property int AsByte = {read=GetAsInteger, write=SetAsByte, nodefault};
	__property Sysutils::TBytes AsBlob = {read=GetAsBytes, write=SetAsBlob};
	__property System::UnicodeString AsMemo = {read=GetAsString, write=SetAsMemo};
	__property Memdata::TBlob* AsBlobRef = {read=GetAsBlobRef, write=SetAsBlobRef};
	__property Memdata::TBlob* AsMemoRef = {read=GetAsMemoRef, write=SetAsMemoRef};
	__property Sqltimst::TSQLTimeStamp AsSQLTimeStamp = {read=GetAsSQLTimeStamp, write=SetAsSQLTimeStamp};
	__property bool IsNull = {read=GetIsNull, nodefault};
	__property System::UnicodeString Text = {read=GetAsString, write=SetText};
	
__published:
	__property Db::TFieldType DataType = {read=GetDataType, write=SetDataType, stored=IsDataTypeStored, nodefault};
	__property ParamType = {default=0};
	__property int Size = {read=GetSize, write=SetSize, default=0};
	__property System::Variant Value = {read=GetAsVariant, write=SetAsVariant, stored=IsValueStored};
};


class DELPHICLASS TDAParams;
class PASCALIMPLEMENTATION TDAParams : public Db::TParams
{
	typedef Db::TParams inherited;
	
public:
	TDAParam* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TDAParam* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TDAParam* Value);
	
protected:
	Classes::TPersistent* FOwner;
	bool FNeedsUpdateItem;
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	void __fastcall Disconnect(void);
	
public:
	__fastcall TDAParams(Classes::TPersistent* Owner)/* overload */;
	HIDESBASE TDAParam* __fastcall ParamByName(const System::UnicodeString Value);
	HIDESBASE TDAParam* __fastcall FindParam(const System::UnicodeString Value);
	HIDESBASE TDAParam* __fastcall CreateParam(Db::TFieldType FldType, const System::UnicodeString ParamName, Db::TParamType ParamType);
	__property TDAParam* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TDAParams(void) { }
	
};


class DELPHICLASS TDACursorField;
class PASCALIMPLEMENTATION TDACursorField : public Db::TField
{
	typedef Db::TField inherited;
	
private:
	Craccess::TCRCursor* __fastcall GetAsCursor(void);
	
protected:
	bool __fastcall GetValue(Craccess::TCRCursor* &Value);
	
public:
	__fastcall virtual TDACursorField(Classes::TComponent* Owner);
	__property Craccess::TCRCursor* AsCursor = {read=GetAsCursor};
public:
	/* TField.Destroy */ inline __fastcall virtual ~TDACursorField(void) { }
	
};


class DELPHICLASS TDADetailDataLink;
class PASCALIMPLEMENTATION TDADetailDataLink : public Db::TDetailDataLink
{
	typedef Db::TDetailDataLink inherited;
	
private:
	TCustomDADataSet* FDataSet;
	
protected:
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall RecordChanged(Db::TField* Field);
	virtual void __fastcall CheckBrowseMode(void);
	virtual Db::TDataSet* __fastcall GetDetailDataSet(void);
	
public:
	__fastcall TDADetailDataLink(TCustomDADataSet* DataSet);
public:
	/* TDataLink.Destroy */ inline __fastcall virtual ~TDADetailDataLink(void) { }
	
};


#pragma option push -b-
enum TLockMode { lmNone, lmPessimistic, lmOptimistic };
#pragma option pop

typedef DynamicArray<Db::TField*> TFieldArray;

typedef DynamicArray<Craccess::TCRFieldDesc*> TFieldDescArray;

struct TKeyAndDataFields
{
	
public:
	TFieldDescArray KeyFieldDescs;
	TFieldDescArray DataFieldDescs;
};


#pragma option push -b-
enum TStatementType { stQuery, stInsert, stUpdate, stDelete, stLock, stRefresh, stCustom, stRefreshQuick, stRefreshCheckDeleted, stBatchUpdate };
#pragma option pop

typedef Set<TStatementType, stQuery, stBatchUpdate>  TStatementTypes;

class DELPHICLASS TDASQLGenerator;
class DELPHICLASS TDADataSetService;
class PASCALIMPLEMENTATION TDASQLGenerator : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TCustomDADataSet* FDataSet;
	TDADataSetService* FDataSetService;
	Clrclasses::WideStringBuilder* FHeaderSB;
	Clrclasses::WideStringBuilder* FFldSB;
	Clrclasses::WideStringBuilder* FMiddleSB;
	Clrclasses::WideStringBuilder* FFldParamSB;
	Clrclasses::WideStringBuilder* FCondSB;
	Clrclasses::WideStringBuilder* FFooterSB;
	void *FOldRecBuf;
	void *FNewRecBuf;
	TDAParams* FParams;
	TDAParamsInfo* FParamsInfo;
	Craccess::TCRTableInfo* FTableInfo;
	bool FDesignMode;
	virtual void __fastcall Clear(void);
	virtual System::UnicodeString __fastcall AssembleSB(const TStatementType StatementType);
	Craccess::TCRRecordSet* __fastcall GetIRecordSet(void);
	Craccess::TSQLInfo* __fastcall SQLInfo(void);
	void * __fastcall OldRecBuf(void);
	void * __fastcall NewRecBuf(void);
	virtual bool __fastcall IsBlobDataType(System::Word DataType);
	virtual bool __fastcall IsObjectDataType(System::Word DataType);
	virtual bool __fastcall FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf)/* overload */;
	virtual bool __fastcall FieldIsNull(Craccess::TCRFieldDesc* FieldDesc, bool OldValue)/* overload */;
	virtual bool __fastcall FieldModified(Craccess::TCRFieldDesc* FieldDesc, Memdata::TData* Data, void * OldRecBuf, void * NewRecBuf)/* overload */;
	virtual bool __fastcall FieldModified(Craccess::TCRFieldDesc* FieldDesc)/* overload */;
	virtual System::UnicodeString __fastcall GetActualFieldName(Craccess::TCRFieldDesc* FieldDesc, bool IsRefresh);
	System::UnicodeString __fastcall IndexedPrefix(void);
	virtual System::UnicodeString __fastcall GenerateIndexName(System::UnicodeString Name);
	virtual int __fastcall DecodeFieldIndex(System::UnicodeString FieldName);
	virtual int __fastcall MaxIdentLength(void);
	virtual bool __fastcall IsSubstituteParamName(void);
	void __fastcall AddParam(Clrclasses::WideStringBuilder* SB, Memdata::TFieldDesc* FieldDesc, const TStatementType StatementType, int Index = 0xffffffff, bool Old = false)/* overload */;
	virtual void __fastcall AddParam(Clrclasses::WideStringBuilder* SB, Memdata::TFieldDesc* FieldDesc, const TStatementType StatementType, const Db::TParamType ParamType, int Index = 0xffffffff, bool Old = false)/* overload */;
	virtual void __fastcall AddFieldToInsertSQL(Craccess::TCRFieldDesc* FieldDesc, const int Index = 0xffffffff);
	virtual void __fastcall AddFieldToUpdateSQL(Craccess::TCRFieldDesc* FieldDesc, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall AddFieldToRefreshSQL(Craccess::TCRFieldDesc* FieldDesc);
	virtual void __fastcall AddFieldToCondition(Clrclasses::WideStringBuilder* SB, Craccess::TCRFieldDesc* FieldDesc, const TStatementType StatementType, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateInsertSQL(const TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateUpdateSQL(const TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateDeleteSQL(const TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly, const int Index = 0xffffffff);
	virtual void __fastcall GenerateLockSQL(const TKeyAndDataFields &KeyAndDataFields, const int Index = 0xffffffff);
	virtual void __fastcall GenerateRefreshSQLSelectPart(const TKeyAndDataFields &KeyAndDataFields);
	virtual void __fastcall GenerateRefreshSQLFromPart(void);
	virtual void __fastcall GenerateRefreshSQL(const TKeyAndDataFields &KeyAndDataFields, const bool ModifiedFieldsOnly);
	virtual void __fastcall GenerateRefreshQuickSQL(const TKeyAndDataFields &KeyAndDataFields);
	virtual void __fastcall GenerateRefreshCheckDeletedSQL(const TKeyAndDataFields &KeyAndDataFields);
	virtual void __fastcall GenerateConditions(Clrclasses::WideStringBuilder* SB, const TStatementType StatementType, const bool ModifiedFieldsOnly, const TKeyAndDataFields &KeyAndDataFields, const int Index = 0xffffffff);
	virtual TDAParamInfoClass __fastcall GetParamInfoClass(void);
	
public:
	__fastcall virtual TDASQLGenerator(TDADataSetService* AOwner);
	__fastcall virtual ~TDASQLGenerator(void);
	virtual System::UnicodeString __fastcall GenerateSQLforUpdTable(Craccess::TCRTableInfo* TableInfo, const TKeyAndDataFields &KeyAndDataFields, const TStatementType StatementType, const bool ModifiedFieldsOnly, TDAParams* Params, const int Index = 0xffffffff);
	virtual System::UnicodeString __fastcall GenerateSQL(const TStatementType StatementType, const bool ModifiedFieldsOnly, TDAParams* Params, const int Index = 0xffffffff);
	virtual System::UnicodeString __fastcall GenerateTableSQL(const System::UnicodeString TableName, const System::UnicodeString OrderFields);
	virtual System::UnicodeString __fastcall GenerateSelectValues(const System::UnicodeString ValuesList);
	__property TDAParamsInfo* ParamsInfo = {read=FParamsInfo};
	__property bool DesignMode = {read=FDesignMode, write=FDesignMode, nodefault};
};


class DELPHICLASS TDADataSetUpdater;
class DELPHICLASS TCustomDAUpdateSQL;
class PASCALIMPLEMENTATION TDADataSetUpdater : public Memds::TDataSetUpdater
{
	typedef Memds::TDataSetUpdater inherited;
	
protected:
	TCustomDADataSet* FDataSet;
	TDADataSetService* FDataSetService;
	TDATransaction* FFixedTransaction;
	bool FIsLockTrStart;
	StaticArray<Classes::TComponent*, 10> FUpdateComponents;
	Classes::TComponent* FUpdateQuery;
	Clrclasses::WideStringBuilder* FBatchSQLs;
	TDAParams* FBatchParams;
	int FBatchStatements;
	bool FRefreshInUpdate;
	bool FCheckOnLock;
	virtual bool __fastcall UseParamType(void);
	virtual bool __fastcall NeedReturnParams(void);
	virtual bool __fastcall RetunParamsAsFields(void);
	virtual bool __fastcall RefreshAfterInsertAllowed(void);
	virtual bool __fastcall IsNeedInsertPreconnect(void);
	virtual bool __fastcall IsNeedEditPreconnect(void);
	virtual bool __fastcall IsPreconnected(void);
	virtual bool __fastcall CanRefreshByLock(void);
	Craccess::TCRCommand* __fastcall GetICommand(void);
	Craccess::TCRRecordSet* __fastcall GetIRecordSet(void);
	void __fastcall CheckIRecordSet(void);
	TLockMode __fastcall GetLockMode(void);
	TCustomDAUpdateSQL* __fastcall GetUpdateObject(void);
	System::UnicodeString __fastcall GetUpdateSQL(TStatementType StatementType);
	TCustomDAConnection* __fastcall UsedConnection(void);
	TDATransaction* __fastcall UsedTransaction(void);
	TDATransaction* __fastcall UsedUpdateTransaction(void);
	void __fastcall SetRowsAffected(int Value);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall SetIdentityFieldValue(void);
	virtual bool __fastcall GetIdentityFieldValue(System::Variant &Value);
	System::UnicodeString __fastcall GetSavepointName(void);
	virtual bool __fastcall SavepointAllowed(void);
	virtual void __fastcall SetSavepoint(void);
	virtual Db::TField* __fastcall FieldByParamName(System::UnicodeString &ParamName, bool &Old, int &AFieldNo);
	virtual System::UnicodeString __fastcall GetUpdateStatement(const TStatementType StatementType);
	virtual void __fastcall CheckUpdateQuery(const TStatementType StatementType);
	virtual void __fastcall SetUpdateQueryOptions(const TStatementType StatementType);
	virtual void __fastcall CheckUpdateSQL(const System::UnicodeString SQL, const TStatementTypes StatementTypes, /* out */ TDAParamsInfo* &ParamsInfo, bool UseGenerator = true);
	virtual void __fastcall UpdateExecute(const TStatementTypes StatementTypes);
	virtual bool __fastcall IsRefreshQuickField(Memdata::TFieldDesc* FieldDesc);
	virtual void __fastcall SaveMaxRefreshQuickValue(Memdata::TFieldDesc* FieldDesc, const System::Variant &Value);
	virtual void __fastcall PrepareAppend(void);
	virtual void __fastcall PrepareUpdate(void);
	virtual void __fastcall UnPrepareAppendUpdate(void);
	virtual bool __fastcall PerformLock(void);
	virtual bool __fastcall PerformUnLock(void);
	void __fastcall EndUpdate(bool Success);
	virtual bool __fastcall PerformAppend(void);
	virtual bool __fastcall PerformDelete(void);
	virtual bool __fastcall PerformUpdate(void);
	virtual bool __fastcall PerformRefreshRecord(void);
	virtual bool __fastcall PerformRefreshRecordInUpdate(void);
	virtual bool __fastcall PerformRefreshQuick(const bool CheckDeleted);
	bool __fastcall PerformPSUpdateRecord(Db::TUpdateKind UpdateKind, Db::TDataSet* Delta);
	virtual bool __fastcall BatchUpdate(void);
	virtual bool __fastcall CanFlushBatch(void);
	void __fastcall ClearBatch(void);
	virtual void __fastcall FlushBatch(void);
	virtual System::UnicodeString __fastcall PrepareBatch(System::UnicodeString SQL);
	void __fastcall UnprepareUpdateObjects(void);
	virtual bool __fastcall LockCompare(const System::Variant &Value1, const System::Variant &Value2);
	
public:
	__fastcall virtual TDADataSetUpdater(Memds::TDataSetService* AOwner);
	__fastcall virtual ~TDADataSetUpdater(void);
	System::Variant __fastcall SelectDbValue(const System::UnicodeString OperationName, const System::UnicodeString SQL);
	virtual bool __fastcall GetDefaultExpressionValue(System::UnicodeString DefExpr, System::Variant &Value);
	virtual bool __fastcall PerformSQL(const System::UnicodeString SQL, const TStatementTypes StatementTypes);
	__property Classes::TComponent* UpdateQuery = {read=FUpdateQuery};
	__property bool CheckOnLock = {read=FCheckOnLock, write=FCheckOnLock, nodefault};
};


class PASCALIMPLEMENTATION TDADataSetService : public Memds::TDataSetService
{
	typedef Memds::TDataSetService inherited;
	
private:
	typedef StaticArray<TFieldDescArray, 2> _TDADataSetService__1;
	
	typedef StaticArray<TFieldDescArray, 2> _TDADataSetService__2;
	
	
private:
	Craccess::TCRTableInfo* __fastcall GetUpdatingTableInfo(void);
	
protected:
	TCustomDADataSet* FDataSet;
	TDADataSetUpdater* FUpdater;
	TDASQLGenerator* FSQLGenerator;
	int FUpdatingTableInfoIdx;
	bool FUpdTableIsArtificial;
	bool FCursorPreinited;
	Craccess::TCRFieldDesc* FIdentityField;
	Db::TField* FKeyGeneratorField;
	bool FIsAnyFieldCanBeModified;
	_TDADataSetService__1 FCachedKeyFieldDescs;
	StaticArray<bool, 2> FKeyFieldDescsIsCached;
	_TDADataSetService__2 FCachedDataFieldDescs;
	StaticArray<bool, 2> FDataFieldDescsIsCached;
	virtual void __fastcall SetDataSetUpdater(Memds::TDataSetUpdater* Value);
	virtual void __fastcall CreateSQLGenerator(void);
	void __fastcall FreeSQLGenerator(void);
	virtual void __fastcall SetSQLGenerator(TDASQLGenerator* Value);
	virtual void __fastcall PreInitCursor(void);
	virtual void __fastcall InitCursor(void);
	virtual void __fastcall CloseCursor(void);
	virtual void __fastcall InitUpdatingTableIdx(void);
	virtual void __fastcall InitUpdatingTableFields(void);
	virtual void __fastcall InitUpdatingTable(void);
	virtual void __fastcall SetFieldOrigin(Db::TField* Field, Craccess::TCRFieldDesc* FieldDesc);
	virtual void __fastcall FillFieldsDefaultValues(void);
	virtual void __fastcall SetFieldsReadOnly(void);
	void __fastcall SetFieldsReadOnlyOld(void);
	void __fastcall GetExtFieldsInfo(void);
	virtual bool __fastcall ExtFieldsInfoIsInternal(void);
	virtual void __fastcall RequestFieldsInfo(Craccess::TExtTablesInfo Tables, Craccess::TColumnsInfo* Columns);
	virtual Craccess::TCRFieldDesc* __fastcall DetectIdentityField(void);
	virtual Db::TField* __fastcall DetectKeyGeneratorField(void);
	virtual TFieldArray __fastcall DetectHiddenFields(void);
	virtual bool __fastcall DetectCanModify(void);
	virtual bool __fastcall CanUseAllKeyFields(void);
	virtual bool __fastcall IdentityFieldIsData(void);
	void __fastcall FillKeyFieldDescs(/* out */ TFieldDescArray &KeyFieldDescs, System::UnicodeString KeyFields, bool CheckKeyFields = true)/* overload */;
	virtual void __fastcall FillKeyFieldDescs(/* out */ TFieldDescArray &KeyFieldDescs, bool ForceUseAllKeyFields)/* overload */;
	virtual void __fastcall FillDataFieldDescs(/* out */ TFieldDescArray &DataFieldDescs, bool ForceUseAllKeyFields);
	virtual int __fastcall GetRecCount(void);
	virtual System::UnicodeString __fastcall GetCurrentSchema(void);
	virtual void __fastcall WriteFieldXMLAttributeType(Db::TField* Field, Memdata::TFieldDesc* FieldDesc, const System::UnicodeString FieldAlias, Crxml::XmlTextWriter* XMLWriter);
	Craccess::TCRCommand* __fastcall GetICommand(void);
	Craccess::TCRRecordSet* __fastcall GetIRecordSet(void);
	void __fastcall CheckIRecordSet(void);
	Craccess::TCRTablesInfo* __fastcall GetTablesInfo(void);
	TCustomDAConnection* __fastcall UsedConnection(void);
	bool __fastcall IsFullRefresh(void);
	bool __fastcall IsDMLRefresh(void);
	bool __fastcall IsInCacheProcessing(void);
	bool __fastcall IsAutoCommit(void);
	bool __fastcall IsFetchAll(void);
	void __fastcall SetAutoCommit(bool Value);
	void __fastcall SetNeedAddRef(bool Value);
	System::UnicodeString __fastcall GetKeyFields(void);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	virtual bool __fastcall PreventPSKeyFields(System::UnicodeString &PSKeyFields);
	virtual bool __fastcall NeedPreparePSExecuteCommand(void);
	
public:
	__fastcall virtual TDADataSetService(Memds::TMemDataSet* AOwner);
	__fastcall virtual ~TDADataSetService(void);
	void __fastcall ClearCachedKeyFieldDescs(void);
	void __fastcall ClearCachedDataFieldDescs(void);
	void __fastcall ClearCachedKeyAndDataFields(void);
	void __fastcall GetKeyFieldDescs(/* out */ TFieldDescArray &KeyFieldDescs, bool ForceUseAllFields = false);
	void __fastcall GetDataFieldDescs(/* out */ TFieldDescArray &DataFieldDescs, bool ForceUseAllFields = false);
	void __fastcall GetKeyAndDataFields(/* out */ TKeyAndDataFields &KeyAndDataFields, bool ForceUseAllFields);
	virtual System::UnicodeString __fastcall GetDBKeyList(System::UnicodeString TableName);
	virtual bool __fastcall OpenNext(void);
	virtual bool __fastcall NeedParamValuesOnPrepare(void);
	System::UnicodeString __fastcall QuoteName(const System::UnicodeString AName);
	__property Craccess::TCRFieldDesc* IdentityField = {read=FIdentityField};
	__property Db::TField* KeyGeneratorField = {read=FKeyGeneratorField};
	__property int UpdatingTableInfoIdx = {read=FUpdatingTableInfoIdx, nodefault};
	__property Craccess::TCRTableInfo* UpdatingTableInfo = {read=GetUpdatingTableInfo};
	__property TDADataSetUpdater* Updater = {read=FUpdater};
	__property TDASQLGenerator* SQLGenerator = {read=FSQLGenerator};
};


#pragma option push -b-
enum TRefreshOption { roAfterInsert, roAfterUpdate, roBeforeEdit };
#pragma option pop

typedef Set<TRefreshOption, roAfterInsert, roBeforeEdit>  TRefreshOptions;

typedef void __fastcall (__closure *TAfterExecuteEvent)(System::TObject* Sender, bool Result);

typedef void __fastcall (__closure *TUpdateExecuteEvent)(Db::TDataSet* Sender, TStatementTypes StatementTypes, TDAParams* Params);

typedef void __fastcall (__closure *TBeforeFetchEvent)(TCustomDADataSet* DataSet, bool &Cancel);

typedef void __fastcall (__closure *TAfterFetchEvent)(TCustomDADataSet* DataSet);

struct TQuickOpenInfo
{
	
public:
	bool OldActive;
	bool OldDebug;
	bool OldFetchAll;
	int OldFetchRows;
};


class DELPHICLASS TDADataSetOptions;
class PASCALIMPLEMENTATION TDADataSetOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	bool FSetFieldsReadOnly;
	bool FRequiredFields;
	bool FStrictUpdate;
	bool FNumberRange;
	bool FQueryRecCount;
	bool FAutoPrepare;
	bool FReturnParams;
	bool FTrimFixedChar;
	bool FTrimVarChar;
	bool FLongStrings;
	bool FRemoveOnRefresh;
	bool FFlatBuffers;
	bool FQuoteNames;
	int FDetailDelay;
	Memdata::TCompressBlobMode FCompressBlobMode;
	bool FFullRefresh;
	bool FLocalMasterDetail;
	bool FFieldsOrigin;
	bool FDefaultValues;
	bool FExtendedFieldsInfo;
	int FUpdateBatchSize;
	bool FUpdateAllFields;
	bool FPrepareUpdateSQL;
	bool FEnableBCD;
	bool FEnableFMTBCD;
	void __fastcall SetRequiredFields(bool Value);
	void __fastcall SetNumberRange(bool Value);
	void __fastcall SetTrimFixedChar(bool Value);
	void __fastcall SetTrimVarChar(bool Value);
	void __fastcall SetLongStrings(bool Value);
	void __fastcall SetAutoPrepare(bool Value);
	void __fastcall SetFlatBuffers(const bool Value);
	void __fastcall SetDetailDelay(int Value);
	void __fastcall SetCompressBlobMode(Memdata::TCompressBlobMode Value);
	void __fastcall SetLocalMasterDetail(bool Value);
	bool __fastcall GetCacheCalcFields(void);
	void __fastcall SetCacheCalcFields(bool Value);
	void __fastcall SetQuoteNames(bool Value);
	void __fastcall SetFieldsOrigin(bool Value);
	void __fastcall SetDefaultValues(bool Value);
	void __fastcall SetExtendedFieldsInfo(bool Value);
	void __fastcall SetEnableBCD(bool Value);
	void __fastcall SetEnableFMTBCD(bool Value);
	
protected:
	TCustomDADataSet* FOwner;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	__property bool FullRefresh = {read=FFullRefresh, write=FFullRefresh, default=0};
	__property bool TrimVarChar = {read=FTrimVarChar, write=SetTrimVarChar, default=0};
	__property bool PrepareUpdateSQL = {read=FPrepareUpdateSQL, write=FPrepareUpdateSQL, default=0};
	__property bool ExtendedFieldsInfo = {read=FExtendedFieldsInfo, write=SetExtendedFieldsInfo, default=0};
	__property bool EnableBCD = {read=FEnableBCD, write=SetEnableBCD, default=0};
	__property bool EnableFMTBCD = {read=FEnableFMTBCD, write=SetEnableFMTBCD, default=0};
	
public:
	__fastcall TDADataSetOptions(TCustomDADataSet* Owner);
	__property bool SetFieldsReadOnly = {read=FSetFieldsReadOnly, write=FSetFieldsReadOnly, default=1};
	__property bool RequiredFields = {read=FRequiredFields, write=SetRequiredFields, default=1};
	__property bool StrictUpdate = {read=FStrictUpdate, write=FStrictUpdate, default=1};
	__property bool NumberRange = {read=FNumberRange, write=SetNumberRange, default=0};
	__property bool QueryRecCount = {read=FQueryRecCount, write=FQueryRecCount, default=0};
	__property bool AutoPrepare = {read=FAutoPrepare, write=SetAutoPrepare, default=0};
	__property bool ReturnParams = {read=FReturnParams, write=FReturnParams, default=0};
	__property bool TrimFixedChar = {read=FTrimFixedChar, write=SetTrimFixedChar, default=1};
	__property bool LongStrings = {read=FLongStrings, write=SetLongStrings, default=1};
	__property bool FlatBuffers = {read=FFlatBuffers, write=SetFlatBuffers, default=0};
	__property bool RemoveOnRefresh = {read=FRemoveOnRefresh, write=FRemoveOnRefresh, default=1};
	__property bool QuoteNames = {read=FQuoteNames, write=SetQuoteNames, default=0};
	__property int DetailDelay = {read=FDetailDelay, write=SetDetailDelay, default=0};
	__property Memdata::TCompressBlobMode CompressBlobMode = {read=FCompressBlobMode, write=SetCompressBlobMode, default=0};
	__property bool LocalMasterDetail = {read=FLocalMasterDetail, write=SetLocalMasterDetail, default=0};
	__property bool CacheCalcFields = {read=GetCacheCalcFields, write=SetCacheCalcFields, default=0};
	__property bool FieldsOrigin = {read=FFieldsOrigin, write=SetFieldsOrigin, default=0};
	__property bool DefaultValues = {read=FDefaultValues, write=SetDefaultValues, default=0};
	__property int UpdateBatchSize = {read=FUpdateBatchSize, write=FUpdateBatchSize, default=1};
	__property bool UpdateAllFields = {read=FUpdateAllFields, write=FUpdateAllFields, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TDADataSetOptions(void) { }
	
};


class DELPHICLASS TMacros;
class DELPHICLASS TMacro;
class PASCALIMPLEMENTATION TCustomDADataSet : public Memds::TMemDataSet
{
	typedef Memds::TMemDataSet inherited;
	
private:
	TCustomDAConnection* FConnection;
	TDATransaction* FTransaction;
	TDATransaction* FUpdateTransaction;
	TDAParams* FParams;
	TMacros* FMacros;
	int FFetchRows;
	TDADetailDataLink* FDataLink;
	bool FDebug;
	bool FReadOnly;
	bool FUniDirectional;
	bool FAutoCommit;
	TCustomDAUpdateSQL* FUpdateObject;
	TRefreshOptions FRefreshOptions;
	TDADataSetOptions* FOptions;
	System::UnicodeString FBaseSQL;
	Win32timer::TWin32Timer* FDetailRefreshTimer;
	TLocalMDLinks FLocalMDLinks;
	TLockMode FLockMode;
	System::UnicodeString FKeyFields;
	bool FDMLRefresh;
	Memdata::TLocateExOptions FFindKeyOptions;
	bool FDisconnected;
	TAfterExecuteEvent FAfterExecute;
	TBeforeFetchEvent FBeforeFetch;
	TAfterFetchEvent FAfterFetch;
	TUpdateExecuteEvent FBeforeUpdateExecute;
	TUpdateExecuteEvent FAfterUpdateExecute;
	void __fastcall SetUpdateTransaction(TDATransaction* Value);
	Classes::TStrings* __fastcall GetSQL(void);
	void __fastcall SetSQL(Classes::TStrings* Value);
	void __fastcall SetFetchRows(int Value);
	void __fastcall SetMasterSource(Db::TDataSource* Value);
	TDAParams* __fastcall GetParams(void);
	void __fastcall SetParams(TDAParams* Value);
	System::Word __fastcall GetParamCount(void);
	bool __fastcall GetParamCheck(void);
	void __fastcall SetParamCheck(bool Value);
	TMacros* __fastcall GetMacros(void);
	void __fastcall SetMacros(TMacros* Value);
	System::Word __fastcall GetMacroCount(void);
	int __fastcall GetRowsAffected(void);
	HIDESBASE void __fastcall SetUniDirectional(bool Value);
	void __fastcall SetAutoCommit(bool Value);
	void __fastcall SetUpdateObject(TCustomDAUpdateSQL* Value);
	void __fastcall SetOptions(TDADataSetOptions* Value);
	void __fastcall SetMasterFields(System::UnicodeString Value);
	void __fastcall SetForeignKeyFields(System::UnicodeString Value);
	void __fastcall SaveModifiedSQL(System::UnicodeString NewSQL);
	System::UnicodeString __fastcall GetBaseSQL(void);
	void __fastcall CheckRefreshDetailTimer(void);
	
protected:
	System::UnicodeString FOldKeyFields;
	System::UnicodeString FOldTableName;
	virtual bool __fastcall PSInTransaction(void);
	virtual void __fastcall PSStartTransaction(void);
	virtual void __fastcall PSEndTransaction(bool Commit);
	virtual void __fastcall PSExecute(void);
	virtual int __fastcall PSExecuteStatement(const System::UnicodeString ASQL, Db::TParams* AParams, void * ResultSet = (void *)(0x0))/* overload */;
	virtual Db::TParams* __fastcall PSGetParams(void);
	virtual System::UnicodeString __fastcall PSGetQuoteChar(void);
	virtual System::UnicodeString __fastcall PSGetTableName(void);
	virtual bool __fastcall PSIsSQLBased(void);
	virtual bool __fastcall PSIsSQLSupported(void);
	virtual void __fastcall PSReset(void);
	virtual void __fastcall PSSetParams(Db::TParams* AParams);
	virtual void __fastcall PSSetCommandText(const System::UnicodeString CommandText)/* overload */;
	virtual bool __fastcall PSUpdateRecord(Db::TUpdateKind UpdateKind, Db::TDataSet* Delta);
	virtual Db::TIndexDef* __fastcall PSGetDefaultOrder(void);
	virtual System::UnicodeString __fastcall PSGetKeyFields(void);
	int FRowsAffected;
	Craccess::TCRRecordSet* FIRecordSet;
	Craccess::TCRCommand* FICommand;
	TCustomDASQL* FCommand;
	TDADataSetService* FDataSetService;
	System::UnicodeString FFilterSQL;
	System::UnicodeString FUpdatingTable;
	System::UnicodeString FMasterFields;
	System::UnicodeString FDetailFields;
	bool FDesignCreate;
	bool FNonBlocking;
	bool FLockDebug;
	StaticArray<Classes::TStrings*, 10> FUpdateSQL;
	int FRecordCount;
	__int64 FLastInsertId;
	bool FFetchAll;
	bool FFetchCanceled;
	bool FStreamedOpen;
	Memdata::TSharedObject* __fastcall GetFieldObject(Db::TField* Field)/* overload */;
	Memdata::TSharedObject* __fastcall GetFieldObject(Memdata::TFieldDesc* FieldDesc)/* overload */;
	virtual void __fastcall CheckInactive(void);
	virtual void __fastcall CreateIRecordSet(void);
	HIDESBASE void __fastcall FreeIRecordSet(void);
	virtual void __fastcall SetIRecordSet(Memdata::TData* Value);
	void __fastcall CheckIRecordSet(void);
	virtual void __fastcall CreateCommand(void);
	void __fastcall FreeCommand(void);
	void __fastcall SetCommand(TCustomDASQL* Value);
	virtual void __fastcall SetDataSetService(Memds::TDataSetService* Value);
	virtual TDADataSetOptions* __fastcall CreateOptions(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall SetConnection(TCustomDAConnection* Value);
	virtual TCustomDAConnection* __fastcall UsedConnection(void);
	virtual void __fastcall CheckConnection(void);
	virtual void __fastcall BeginConnection(bool NoConnectCheck = true);
	virtual void __fastcall EndConnection(void);
	virtual void __fastcall Disconnect(bool NeedClose = true);
	virtual void __fastcall ConnectChange(System::TObject* Sender, bool Connecting);
	bool __fastcall IsTransactionStored(void);
	virtual TDATransaction* __fastcall GetTransaction(void);
	virtual void __fastcall SetTransaction(TDATransaction* Value);
	TDATransaction* __fastcall GetUsedTransaction(void);
	virtual TDATransaction* __fastcall UsedTransaction(void);
	virtual TDATransaction* __fastcall UsedUpdateTransaction(void);
	virtual void __fastcall SetKeyFields(const System::UnicodeString Value);
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMap(void);
	Craccess::TCRTablesInfo* __fastcall GetTablesInfo(void);
	Craccess::TSQLInfo* __fastcall GetSQLInfo(void);
	virtual void __fastcall SetUpdatingTable(const System::UnicodeString Value);
	virtual void __fastcall SetActive(bool Value);
	virtual void __fastcall BeforeOpenCursor(bool InfoQuery);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall AfterOpenCursor(bool InfoQuery);
	virtual void __fastcall CloseCursor(void);
	Craccess::TCRCursor* __fastcall GetCursor(void);
	virtual Craccess::TCRCursor* __fastcall GetCRCursor(void);
	virtual void __fastcall SetCRCursor(Craccess::TCRCursor* Value);
	void __fastcall GetCurrentKeys(/* out */ TFieldArray &KeyFields, /* out */ System::Variant &Values);
	virtual void __fastcall DataReopen(void);
	virtual void __fastcall InternalRefresh(void);
	virtual void __fastcall InternalRefreshQuick(const bool CheckDeleted);
	virtual void __fastcall InternalExecute(void);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall DoAfterOpen(void);
	virtual void __fastcall SetRefreshOptions(TRefreshOptions Value);
	virtual bool __fastcall GetFetchAll(void);
	virtual void __fastcall SetFetchAll(bool Value);
	virtual bool __fastcall SQLAutoGenerated(void);
	virtual void __fastcall BeforeExecute(void);
	bool __fastcall DoOpenNext(void);
	virtual void __fastcall QuickOpen(TQuickOpenInfo &Info, bool Refresh = false);
	virtual void __fastcall Restore(const TQuickOpenInfo &Info, bool RestoreActive = true);
	virtual void __fastcall SetReadOnly(bool Value);
	virtual void __fastcall InternalEdit(void);
	virtual void __fastcall InternalInsert(void);
	virtual void __fastcall InternalCancel(void);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalDeferredPost(void);
	virtual TStatementTypes __fastcall GetUpdateSQLStatementTypes(void);
	Classes::TStrings* __fastcall GetUpdateSQLIndex(int Index);
	void __fastcall SetUpdateSQLIndex(int Index, Classes::TStrings* Value);
	virtual void __fastcall SetFilterSQL(const System::UnicodeString Value);
	virtual void __fastcall SetFiltered(bool Value);
	virtual bool __fastcall GetCanModify(void);
	virtual void __fastcall SetStateFieldValue(Db::TDataSetState State, Db::TField* Field, const System::Variant &Value);
	virtual bool __fastcall CanRefreshField(Db::TField* Field);
	virtual void __fastcall AssignFieldValue(TDAParam* Param, Db::TField* Field, bool Old)/* overload */;
	virtual void __fastcall AssignFieldValue(TDAParam* Param, Memdata::TFieldDesc* FieldDesc, bool Old)/* overload */;
	virtual void __fastcall SetDefaultExpressionValues(void);
	void __fastcall RefreshParams(void);
	virtual bool __fastcall NeedDetailRefresh(TDAParam* Param, Memdata::TSharedObject* FieldValue);
	void __fastcall RefreshDetail(System::TObject* Sender);
	bool __fastcall SetMasterParams(TDAParams* AParams);
	bool __fastcall IsConnectedToMaster(void);
	void __fastcall RefreshDetailSQL(void);
	bool __fastcall LocalDetailFilter(void * RecBuf);
	void __fastcall AssembleSQL(void);
	void __fastcall InternalCreateProcCall(const System::UnicodeString Name, bool NeedDescribe, bool IsQuery = false);
	virtual void __fastcall ScanMacros(System::TObject* Sender = (System::TObject*)(0x0));
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall DoAfterExecute(bool Result);
	void __fastcall DoAfterExecFetch(bool Result);
	void __fastcall DoAfterFetchAll(bool Result);
	virtual void __fastcall DoAfterScroll(void);
	virtual void __fastcall DoOnBeforeFetch(/* out */ bool &Cancel);
	virtual void __fastcall DoOnAfterFetch(void);
	void __fastcall DoOnDataChanged(void);
	virtual void __fastcall DoOnNewRecord(void);
	virtual Db::TDataSource* __fastcall GetDataSource(void);
	virtual int __fastcall GetRecordCount(void);
	virtual bool __fastcall GetIsQuery(void);
	virtual bool __fastcall AssignedBeforeUpdateExecute(void);
	virtual void __fastcall DoBeforeUpdateExecute(Db::TDataSet* Sender, TStatementTypes StatementTypes, TDAParams* Params);
	virtual bool __fastcall AssignedAfterUpdateExecute(void);
	virtual void __fastcall DoAfterUpdateExecute(Db::TDataSet* Sender, TStatementTypes StatementTypes, TDAParams* Params);
	virtual void __fastcall InternalOpen(void);
	virtual System::UnicodeString __fastcall SQLGetFrom(System::UnicodeString SQLText);
	virtual System::UnicodeString __fastcall SQLAddWhere(System::UnicodeString SQLText, System::UnicodeString Condition);
	virtual System::UnicodeString __fastcall SQLDeleteWhere(System::UnicodeString SQLText);
	virtual System::UnicodeString __fastcall SQLGetWhere(System::UnicodeString SQLText);
	virtual System::UnicodeString __fastcall SQLSetOrderBy(System::UnicodeString SQLText, System::UnicodeString Fields);
	virtual System::UnicodeString __fastcall SQLGetOrderBy(System::UnicodeString SQLText);
	virtual System::UnicodeString __fastcall GetFinalSQL(void);
	__property Craccess::TCRTablesInfo* TablesInfo = {read=GetTablesInfo};
	__property Craccess::TSQLInfo* SQLInfo = {read=GetSQLInfo};
	__property System::UnicodeString UpdatingTable = {read=FUpdatingTable, write=SetUpdatingTable};
	__property TDATransaction* Transaction = {read=GetTransaction, write=SetTransaction, stored=IsTransactionStored};
	__property TDATransaction* UpdateTransaction = {read=FUpdateTransaction, write=SetUpdateTransaction};
	__property bool AutoCommit = {read=FAutoCommit, write=SetAutoCommit, default=1};
	__property bool FetchAll = {read=GetFetchAll, write=SetFetchAll, default=0};
	__property TCustomDAUpdateSQL* UpdateObject = {read=FUpdateObject, write=SetUpdateObject};
	__property bool DMLRefresh = {read=FDMLRefresh, write=FDMLRefresh, default=0};
	__property TLockMode LockMode = {read=FLockMode, write=FLockMode, default=0};
	__property Craccess::TCRCursor* Cursor = {read=GetCRCursor, write=SetCRCursor};
	
public:
	__fastcall virtual TCustomDADataSet(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomDADataSet(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall UnPrepare(void);
	virtual void __fastcall Execute(void);
	bool __fastcall Executing(void);
	bool __fastcall Fetching(void);
	bool __fastcall FetchingAll(void);
	virtual bool __fastcall Fetched(void);
	virtual void __fastcall Resync(Db::TResyncMode Mode);
	virtual void __fastcall GetDetailLinkFields(Classes::TList* MasterFields, Classes::TList* DetailFields);
	bool __fastcall FindKey(System::TVarRec const *KeyValues, const int KeyValues_Size);
	void __fastcall FindNearest(System::TVarRec const *KeyValues, const int KeyValues_Size);
	void __fastcall GotoCurrent(TCustomDADataSet* DataSet);
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
	virtual void __fastcall ApplyUpdates(void);
	__property Classes::TStrings* SQLInsert = {read=GetUpdateSQLIndex, write=SetUpdateSQLIndex, index=1};
	__property Classes::TStrings* SQLDelete = {read=GetUpdateSQLIndex, write=SetUpdateSQLIndex, index=3};
	__property Classes::TStrings* SQLUpdate = {read=GetUpdateSQLIndex, write=SetUpdateSQLIndex, index=2};
	__property Classes::TStrings* SQLRefresh = {read=GetUpdateSQLIndex, write=SetUpdateSQLIndex, index=5};
	__property Classes::TStrings* SQLLock = {read=GetUpdateSQLIndex, write=SetUpdateSQLIndex, index=4};
	void __fastcall RefreshRecord(void);
	virtual void __fastcall Lock(void);
	void __fastcall UnLock(void);
	TDAParam* __fastcall FindParam(const System::UnicodeString Value);
	TDAParam* __fastcall ParamByName(const System::UnicodeString Value);
	TMacro* __fastcall FindMacro(const System::UnicodeString Value);
	TMacro* __fastcall MacroByName(const System::UnicodeString Value);
	void __fastcall SaveSQL(void);
	void __fastcall RestoreSQL(void);
	bool __fastcall SQLSaved(void);
	void __fastcall AddWhere(System::UnicodeString Condition);
	void __fastcall DeleteWhere(void);
	void __fastcall SetOrderBy(System::UnicodeString Fields);
	System::UnicodeString __fastcall GetOrderBy(void);
	Db::TField* __fastcall GetField(Memdata::TFieldDesc* FieldDesc);
	virtual int __fastcall GetDataType(const System::UnicodeString FieldName);
	HIDESBASE Memdata::TFieldDesc* __fastcall GetFieldDesc(const System::UnicodeString FieldName)/* overload */;
	HIDESBASE virtual Memdata::TFieldDesc* __fastcall GetFieldDesc(const int FieldNo)/* overload */;
	int __fastcall GetFieldPrecision(const System::UnicodeString FieldName);
	int __fastcall GetFieldScale(const System::UnicodeString FieldName);
	Memdata::TSharedObject* __fastcall GetFieldObject(const System::UnicodeString FieldName)/* overload */;
	__property TCustomDAConnection* Connection = {read=FConnection, write=SetConnection};
	__property bool ParamCheck = {read=GetParamCheck, write=SetParamCheck, default=1};
	__property Classes::TStrings* SQL = {read=GetSQL, write=SetSQL};
	__property int FetchRows = {read=FFetchRows, write=SetFetchRows, default=25};
	__property bool Debug = {read=FDebug, write=FDebug, default=0};
	__property Db::TDataSource* MasterSource = {read=GetDataSource, write=SetMasterSource};
	__property TDAParams* Params = {read=GetParams, write=SetParams, stored=false};
	__property System::Word ParamCount = {read=GetParamCount, nodefault};
	__property TMacros* Macros = {read=GetMacros, write=SetMacros, stored=false};
	__property System::Word MacroCount = {read=GetMacroCount, nodefault};
	__property bool UniDirectional = {read=FUniDirectional, write=SetUniDirectional, default=0};
	__property bool ReadOnly = {read=FReadOnly, write=SetReadOnly, default=0};
	__property int RowsAffected = {read=GetRowsAffected, nodefault};
	__property bool IsQuery = {read=GetIsQuery, nodefault};
	__property TRefreshOptions RefreshOptions = {read=FRefreshOptions, write=SetRefreshOptions, default=0};
	__property TDADataSetOptions* Options = {read=FOptions, write=SetOptions};
	__property System::UnicodeString BaseSQL = {read=GetBaseSQL};
	__property System::UnicodeString FinalSQL = {read=GetFinalSQL};
	__property System::UnicodeString FilterSQL = {read=FFilterSQL, write=SetFilterSQL};
	__property System::UnicodeString MasterFields = {read=FMasterFields, write=SetMasterFields};
	__property System::UnicodeString DetailFields = {read=FDetailFields, write=SetForeignKeyFields};
	__property System::UnicodeString KeyFields = {read=FKeyFields, write=SetKeyFields};
	__property bool Disconnected = {read=FDisconnected, write=FDisconnected, nodefault};
	__property TAfterExecuteEvent AfterExecute = {read=FAfterExecute, write=FAfterExecute};
	__property TUpdateExecuteEvent BeforeUpdateExecute = {read=FBeforeUpdateExecute, write=FBeforeUpdateExecute};
	__property TUpdateExecuteEvent AfterUpdateExecute = {read=FAfterUpdateExecute, write=FAfterUpdateExecute};
	__property TBeforeFetchEvent BeforeFetch = {read=FBeforeFetch, write=FBeforeFetch};
	__property TAfterFetchEvent AfterFetch = {read=FAfterFetch, write=FAfterFetch};
	
/* Hoisted overloads: */
	
protected:
	inline int __fastcall  PSExecuteStatement [[deprecated]](const System::WideString ASQL, Db::TParams* AParams, void * ResultSet = (void *)(0x0)){ return Db::TDataSet::PSExecuteStatement(ASQL, AParams, ResultSet); }
	inline void __fastcall  PSSetCommandText [[deprecated]](const System::WideString CommandText){ Db::TDataSet::PSSetCommandText(CommandText); }
	
public:
	inline Memdata::TFieldDesc* __fastcall  GetFieldDesc(const Db::TField* Field){ return Memds::TMemDataSet::GetFieldDesc(Field); }
	
};


class PASCALIMPLEMENTATION TCustomDASQL : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
public:
	System::Variant operator[](System::UnicodeString ParamName) { return ParamValues[ParamName]; }
	
private:
	TCustomDAConnection* FConnection;
	TDATransaction* FTransaction;
	Classes::TStrings* FSQL;
	TDAParams* FParams;
	bool FParamCheck;
	TMacros* FMacros;
	bool FDebug;
	bool FChangeCursor;
	TAfterExecuteEvent FAfterExecute;
	void __fastcall SetTransaction(TDATransaction* Value);
	void __fastcall SetSQL(Classes::TStrings* Value);
	bool __fastcall GetPrepared(void);
	void __fastcall SetPrepared(bool Value);
	void __fastcall SetParams(TDAParams* Value);
	System::Word __fastcall GetParamCount(void);
	void __fastcall SetParamCheck(bool Value);
	System::Variant __fastcall GetParamValues(System::UnicodeString ParamName);
	void __fastcall SetParamValues(System::UnicodeString ParamName, const System::Variant &Value);
	void __fastcall SetMacros(TMacros* Value);
	System::Word __fastcall GetMacroCount(void);
	int __fastcall GetRowsAffected(void);
	
protected:
	bool FAutoCommit;
	Craccess::TCRCommand* FICommand;
	TCustomDADataSet* FDataSet;
	bool FDesignCreate;
	bool FNonBlocking;
	bool FLockDebug;
	bool FLockAssembleSQL;
	bool FLockMacros;
	bool FLockScanParams;
	System::UnicodeString FStoredProcName;
	bool FStoredProcIsQuery;
	__int64 FLastInsertId;
	bool __fastcall IsTransactionStored(void);
	virtual void __fastcall CreateICommand(void);
	void __fastcall FreeICommand(void);
	virtual void __fastcall SetICommand(Craccess::TCRCommand* Value);
	void __fastcall CheckICommand(void);
	virtual TDAParams* __fastcall CreateParamsObject(void);
	virtual Memds::TDataTypesMapClass __fastcall GetDataTypesMap(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	void __fastcall SetAutoCommit(bool Value);
	void __fastcall SetConnection(TCustomDAConnection* Value);
	virtual TCustomDAConnection* __fastcall UsedConnection(void);
	virtual void __fastcall CheckConnection(void);
	virtual void __fastcall BeginConnection(bool NoConnectCheck = true);
	virtual void __fastcall EndConnection(void);
	virtual void __fastcall Disconnect(void);
	virtual void __fastcall ConnectChange(System::TObject* Sender, bool Connecting);
	virtual TDATransaction* __fastcall GetTransaction(void);
	virtual TDATransaction* __fastcall UsedTransaction(void);
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalUnPrepare(void);
	virtual void __fastcall InternalExecute(int Iters);
	virtual void __fastcall InternalCreateProcCall(const System::UnicodeString Name, bool NeedDescribe, bool IsQuery = false);
	virtual void __fastcall DoAfterExecute(bool Result);
	virtual System::UnicodeString __fastcall ParseSQL(const System::UnicodeString SQL, TDAParams* Params, System::UnicodeString RenamePrefix = L"");
	void __fastcall SQLChanged(System::TObject* Sender);
	void __fastcall ProcessSQLChanged(bool LockMacros, bool SaveBaseSQL);
	virtual void __fastcall ScanMacros(void);
	virtual System::UnicodeString __fastcall GetFinalSQL(void);
	void __fastcall SetICommandSQL(void);
	virtual void __fastcall AssembleSQL(void);
	virtual bool __fastcall NeedRecreateProcCall(void);
	virtual void __fastcall CheckSQL(int Iters = 0x1);
	virtual bool __fastcall IsInOutParamSupported(void);
	virtual bool __fastcall NeedConvertEOLForBlob(void);
	virtual void __fastcall AssignParam(Craccess::TParamDesc* ParamDesc, TDAParam* Param);
	virtual void __fastcall AssignParamValue(Craccess::TParamDesc* ParamDesc, TDAParam* Param);
	virtual void __fastcall AssignParamDesc(TDAParam* Param, Craccess::TParamDesc* ParamDesc);
	virtual void __fastcall AssignParamDescValue(TDAParam* Param, Craccess::TParamDesc* ParamDesc);
	virtual void __fastcall CreateParams(void)/* overload */;
	virtual void __fastcall CreateParams(TDAParams* Params, Craccess::TParamDescs* ParamDescs)/* overload */;
	virtual void __fastcall WriteParams(bool WriteValue = true);
	virtual void __fastcall ReadParams(void);
	void __fastcall UpdateParams(void);
	virtual TDAParam* __fastcall FindResultParam(void);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	void __fastcall ReadParamData(Classes::TReader* Reader);
	void __fastcall WriteParamData(Classes::TWriter* Writer);
	void __fastcall ReadMacroData(Classes::TReader* Reader);
	void __fastcall WriteMacroData(Classes::TWriter* Writer);
	void __fastcall ReadStoredProcName(Classes::TReader* Reader);
	void __fastcall WriteStoredProcName(Classes::TWriter* Writer);
	void __fastcall SetStoredProcName(const System::UnicodeString StoredProcName);
	void __fastcall ReadStoredProcIsQuery(Classes::TReader* Reader);
	void __fastcall WriteStoredProcIsQuery(Classes::TWriter* Writer);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	__property TDATransaction* Transaction = {read=GetTransaction, write=SetTransaction, stored=IsTransactionStored};
	__property bool AutoCommit = {read=FAutoCommit, write=SetAutoCommit, default=0};
	__property bool StoredProcIsQuery = {read=FStoredProcIsQuery, write=FStoredProcIsQuery, nodefault};
	
public:
	__fastcall virtual TCustomDASQL(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomDASQL(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall UnPrepare(void);
	virtual void __fastcall Execute(void)/* overload */;
	virtual void __fastcall Execute(int Iters)/* overload */;
	bool __fastcall Executing(void);
	bool __fastcall WaitExecuting(int TimeOut = 0x0);
	TDAParam* __fastcall FindParam(const System::UnicodeString Value);
	TDAParam* __fastcall ParamByName(const System::UnicodeString Value);
	TMacro* __fastcall FindMacro(const System::UnicodeString Value);
	TMacro* __fastcall MacroByName(const System::UnicodeString Value);
	__property TCustomDAConnection* Connection = {read=FConnection, write=SetConnection};
	__property bool ParamCheck = {read=FParamCheck, write=SetParamCheck, default=1};
	__property Classes::TStrings* SQL = {read=FSQL, write=SetSQL};
	__property bool Prepared = {read=GetPrepared, write=SetPrepared, nodefault};
	__property TDAParams* Params = {read=FParams, write=SetParams, stored=false};
	__property System::Word ParamCount = {read=GetParamCount, nodefault};
	__property System::Variant ParamValues[System::UnicodeString ParamName] = {read=GetParamValues, write=SetParamValues/*, default*/};
	__property TMacros* Macros = {read=FMacros, write=SetMacros, stored=false};
	__property System::Word MacroCount = {read=GetMacroCount, nodefault};
	__property bool Debug = {read=FDebug, write=FDebug, default=0};
	__property bool ChangeCursor = {read=FChangeCursor, write=FChangeCursor, nodefault};
	__property int RowsAffected = {read=GetRowsAffected, nodefault};
	__property System::UnicodeString FinalSQL = {read=GetFinalSQL};
	__property TAfterExecuteEvent AfterExecute = {read=FAfterExecute, write=FAfterExecute};
};


class PASCALIMPLEMENTATION TDAMetaData : public Memds::TMemDataSet
{
	typedef Memds::TMemDataSet inherited;
	
private:
	TCustomDAConnection* FConnection;
	TDATransaction* FTransaction;
	System::UnicodeString FMetaDataKind;
	Classes::TStrings* FRestrictions;
	Craccess::TCRMetaData* FIMetaData;
	bool FDesignCreate;
	void __fastcall SetConnection(TCustomDAConnection* Value);
	void __fastcall ConnectChange(System::TObject* Sender, bool Connecting);
	void __fastcall SetMetaDataKind(const System::UnicodeString Value);
	void __fastcall SetRestrictions(Classes::TStrings* Value);
	void __fastcall RestrictionsChanged(System::TObject* Sender);
	
protected:
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	TCustomDAConnection* __fastcall UsedConnection(void);
	virtual TDATransaction* __fastcall UsedTransaction(void);
	virtual TDATransaction* __fastcall GetTransaction(void);
	virtual void __fastcall SetTransaction(TDATransaction* Value);
	bool __fastcall IsTransactionStored(void);
	virtual void __fastcall BeginConnection(void);
	virtual void __fastcall EndConnection(void);
	void __fastcall CheckIMetaData(void);
	virtual void __fastcall OpenCursor(bool InfoQuery);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall CloseCursor(void);
	__property TDATransaction* Transaction = {read=GetTransaction, write=SetTransaction, stored=IsTransactionStored};
	
public:
	__fastcall virtual TDAMetaData(Classes::TComponent* AOwner);
	__fastcall virtual ~TDAMetaData(void);
	void __fastcall GetMetaDataKinds(Classes::TStrings* List);
	void __fastcall GetRestrictions(Classes::TStrings* List, const System::UnicodeString MetaDataKind);
	__property TCustomDAConnection* Connection = {read=FConnection, write=SetConnection};
	__property System::UnicodeString MetaDataKind = {read=FMetaDataKind, write=SetMetaDataKind};
	__property Classes::TStrings* Restrictions = {read=FRestrictions, write=SetRestrictions};
};


class PASCALIMPLEMENTATION TCustomDAUpdateSQL : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	TCustomDADataSet* FDataSet;
	StaticArray<Classes::TStrings*, 10> FSQLText;
	StaticArray<Classes::TComponent*, 10> FUpdateObject;
	
protected:
	bool FDesignCreate;
	Classes::TStrings* __fastcall GetSQLIndex(int Index);
	void __fastcall SetSQLIndex(int Index, Classes::TStrings* Value);
	virtual Classes::TStrings* __fastcall GetSQL(Db::TUpdateKind UpdateKind);
	void __fastcall SetSQL(Db::TUpdateKind UpdateKind, Classes::TStrings* Value);
	Classes::TComponent* __fastcall GetObjectIndex(int Index);
	void __fastcall SetObjectIndex(int Index, Classes::TComponent* Value);
	virtual TCustomDADataSet* __fastcall GetDataSet(void);
	virtual void __fastcall SetDataSet(TCustomDADataSet* DataSet);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual TCustomDADataSetClass __fastcall DataSetClass(void);
	virtual TCustomDASQLClass __fastcall SQLClass(void);
	void __fastcall CheckUpdateComponent(Classes::TComponent* Component)/* overload */;
	void __fastcall CheckUpdateComponent(Classes::TComponent* Component, TCustomDADataSet* NewDataset)/* overload */;
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TCustomDAUpdateSQL(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomDAUpdateSQL(void);
	virtual void __fastcall Apply(Db::TUpdateKind UpdateKind);
	void __fastcall ExecSQL(Db::TUpdateKind UpdateKind);
	__property TCustomDADataSet* DataSet = {read=GetDataSet, write=SetDataSet};
	__property Classes::TStrings* SQL[Db::TUpdateKind UpdateKind] = {read=GetSQL, write=SetSQL};
	
__published:
	__property Classes::TStrings* InsertSQL = {read=GetSQLIndex, write=SetSQLIndex, index=1};
	__property Classes::TStrings* DeleteSQL = {read=GetSQLIndex, write=SetSQLIndex, index=3};
	__property Classes::TStrings* ModifySQL = {read=GetSQLIndex, write=SetSQLIndex, index=2};
	__property Classes::TStrings* RefreshSQL = {read=GetSQLIndex, write=SetSQLIndex, index=5};
	__property Classes::TStrings* LockSQL = {read=GetSQLIndex, write=SetSQLIndex, index=4};
	__property Classes::TComponent* InsertObject = {read=GetObjectIndex, write=SetObjectIndex, index=1};
	__property Classes::TComponent* DeleteObject = {read=GetObjectIndex, write=SetObjectIndex, index=3};
	__property Classes::TComponent* ModifyObject = {read=GetObjectIndex, write=SetObjectIndex, index=2};
	__property Classes::TComponent* RefreshObject = {read=GetObjectIndex, write=SetObjectIndex, index=5};
	__property Classes::TComponent* LockObject = {read=GetObjectIndex, write=SetObjectIndex, index=4};
};


class PASCALIMPLEMENTATION TMacro : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	System::UnicodeString FName;
	System::UnicodeString FValue;
	bool FActive;
	void __fastcall SetValue(System::UnicodeString Value);
	void __fastcall SetActive(bool Value);
	System::TDateTime __fastcall GetAsDateTime(void);
	void __fastcall SetAsDateTime(System::TDateTime Value);
	double __fastcall GetAsFloat(void);
	void __fastcall SetAsFloat(double Value);
	int __fastcall GetAsInteger(void);
	void __fastcall SetAsInteger(int Value);
	System::UnicodeString __fastcall GetAsString(void);
	void __fastcall SetAsString(System::UnicodeString Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	bool __fastcall IsEqual(TMacro* Value);
	virtual System::UnicodeString __fastcall GetDisplayName(void);
	
public:
	__fastcall virtual TMacro(Classes::TCollection* Collection);
	__property System::TDateTime AsDateTime = {read=GetAsDateTime, write=SetAsDateTime};
	__property double AsFloat = {read=GetAsFloat, write=SetAsFloat};
	__property int AsInteger = {read=GetAsInteger, write=SetAsInteger, nodefault};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	
__published:
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::UnicodeString Value = {read=FValue, write=SetValue};
	__property bool Active = {read=FActive, write=SetActive, default=1};
public:
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TMacro(void) { }
	
};


class PASCALIMPLEMENTATION TMacros : public Classes::TCollection
{
	typedef Classes::TCollection inherited;
	
public:
	TMacro* operator[](int Index) { return Items[Index]; }
	
private:
	Classes::TPersistent* FOwner;
	void __fastcall ReadBinaryData(Classes::TStream* Stream);
	HIDESBASE TMacro* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TMacro* Value);
	void __fastcall NotifyOwner(TMacro* Item);
	
protected:
	Crparser::TSQLParserClass FParserClass;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall DefineProperties(Classes::TFiler* Filer);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall Update(Classes::TCollectionItem* Item);
	virtual System::UnicodeString __fastcall GetMacroValue(TMacro* Macro);
	
public:
	__fastcall TMacros(Classes::TPersistent* Owner);
	void __fastcall Scan(System::UnicodeString SQL);
	void __fastcall AssignValues(TMacros* Value);
	bool __fastcall IsEqual(TMacros* Value);
	TMacro* __fastcall FindMacro(const System::UnicodeString Value);
	TMacro* __fastcall MacroByName(const System::UnicodeString Value);
	void __fastcall Expand(System::UnicodeString &SQL);
	void __fastcall SetParserClass(Crparser::TSQLParserClass Value);
	__property TMacro* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TMacros(void) { }
	
};


class DELPHICLASS TCRServerEnumerator;
class PASCALIMPLEMENTATION TCRServerEnumerator : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__fastcall virtual TCRServerEnumerator(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	virtual void __fastcall GetServerList(Classes::TStrings* List);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRServerEnumerator(void) { }
	
};


typedef TMetaClass* TCRServerEnumeratorClass;

#pragma option push -b-
enum TLabelSet { lsCustom, lsEnglish, lsFrench, lsGerman, lsItalian, lsPolish, lsPortuguese, lsRussian, lsSpanish };
#pragma option pop

class PASCALIMPLEMENTATION TCustomConnectDialog : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	TCustomDAConnection* FConnection;
	System::Word FRetries;
	System::UnicodeString FDialogClass;
	bool FSavePassword;
	bool FStoreLogInfo;
	bool FUseServerHistory;
	bool FNeedConnect;
	TLabelSet FLabelSet;
	System::UnicodeString FCaption;
	System::UnicodeString FUsernameLabel;
	System::UnicodeString FPasswordLabel;
	System::UnicodeString FServerLabel;
	System::UnicodeString FConnectButton;
	System::UnicodeString FCancelButton;
	void __fastcall SetCaption(System::UnicodeString Value);
	void __fastcall SetUsernameLabel(System::UnicodeString Value);
	void __fastcall SetPasswordLabel(System::UnicodeString Value);
	void __fastcall SetServerLabel(System::UnicodeString Value);
	void __fastcall SetConnectButton(System::UnicodeString Value);
	void __fastcall SetCancelButton(System::UnicodeString Value);
	
protected:
	TCRServerEnumerator* FServerEnumerator;
	virtual TCRServerEnumeratorClass __fastcall GetServerEnumeratorClass(void);
	virtual void __fastcall SetServerEnumerator(TCRServerEnumerator* Value);
	void __fastcall CreateServerEnumerator(void);
	void __fastcall FreeServerEnumerator(void);
	void __fastcall CheckServerEnumerator(void);
	System::UnicodeString __fastcall GetString(int Id);
	virtual void __fastcall SetLabelSet(TLabelSet Value);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	virtual System::TClass __fastcall DefDialogClass(void);
	virtual System::UnicodeString __fastcall GetKeyPath(void);
	virtual System::UnicodeString __fastcall GetServerStoreName(void);
	System::UnicodeString __fastcall GetApplicationKeyPath(void);
	virtual System::UnicodeString __fastcall GetServerListKeyPath(void);
	virtual void __fastcall SaveServerListToRegistry(void);
	virtual void __fastcall LoadServerListFromRegistry(Classes::TStrings* List);
	virtual void __fastcall SaveInfoToRegistry(Registry::TRegistry* Registry);
	virtual void __fastcall LoadInfoFromRegistry(Registry::TRegistry* Registry);
	__property bool UseServerHistory = {read=FUseServerHistory, write=FUseServerHistory, default=1};
	
public:
	__fastcall virtual TCustomConnectDialog(Classes::TComponent* Owner);
	__fastcall virtual ~TCustomConnectDialog(void);
	virtual bool __fastcall Execute(void);
	virtual void __fastcall GetServerList(Classes::TStrings* List);
	__property TCustomDAConnection* Connection = {read=FConnection};
	__property System::Word Retries = {read=FRetries, write=FRetries, default=3};
	__property bool SavePassword = {read=FSavePassword, write=FSavePassword, default=0};
	__property bool StoreLogInfo = {read=FStoreLogInfo, write=FStoreLogInfo, default=1};
	__property System::UnicodeString DialogClass = {read=FDialogClass, write=FDialogClass};
	__property System::UnicodeString Caption = {read=FCaption, write=SetCaption};
	__property System::UnicodeString UsernameLabel = {read=FUsernameLabel, write=SetUsernameLabel};
	__property System::UnicodeString PasswordLabel = {read=FPasswordLabel, write=SetPasswordLabel};
	__property System::UnicodeString ServerLabel = {read=FServerLabel, write=SetServerLabel};
	__property System::UnicodeString ConnectButton = {read=FConnectButton, write=SetConnectButton};
	__property System::UnicodeString CancelButton = {read=FCancelButton, write=SetCancelButton};
	__property TLabelSet LabelSet = {read=FLabelSet, write=SetLabelSet, default=1};
};


struct TTableInfo
{
	
public:
	System::UnicodeString Name;
	System::UnicodeString Alias;
};


typedef DynamicArray<TTableInfo> TTablesInfo;

#pragma option push -b-
enum TCRServiceStatus { ssStopped, ssStartPending, ssStopPending, ssRunning, ssContinuePending, ssPausePending, ssPaused };
#pragma option pop

struct TCRServiceInfo
{
	
public:
	System::UnicodeString ServiceName;
	System::UnicodeString DisplayName;
	TCRServiceStatus Status;
};


typedef DynamicArray<TCRServiceInfo> TCRServicesInfo;

class DELPHICLASS TCRServicesThread;
class PASCALIMPLEMENTATION TCRServicesThread : public Classes::TThread
{
	typedef Classes::TThread inherited;
	
private:
	Classes::TStrings* FList;
	System::UnicodeString FKeywords;
	
protected:
	__property Terminated;
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TCRServicesThread(Classes::TStrings* List, const System::UnicodeString Keywords);
public:
	/* TThread.Destroy */ inline __fastcall virtual ~TCRServicesThread(void) { }
	
};


class DELPHICLASS TCRServiceNamesThread;
class PASCALIMPLEMENTATION TCRServiceNamesThread : public Classes::TThread
{
	typedef Classes::TThread inherited;
	
protected:
	System::UnicodeString FKeywords;
	TCRServicesThread* FServices;
	System::UnicodeString FServer;
	TCRServicesInfo FServiceNames;
	virtual void __fastcall Execute(void);
	
public:
	__fastcall TCRServiceNamesThread(const System::UnicodeString Server, TCRServicesThread* Services, const System::UnicodeString Keywords);
public:
	/* TThread.Destroy */ inline __fastcall virtual ~TCRServiceNamesThread(void) { }
	
};


typedef unsigned SC_HANDLE;

class DELPHICLASS TCRNetManager;
class PASCALIMPLEMENTATION TCRNetManager : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Syncobjs::TCriticalSection* FServicesCS;
	Classes::TStringList* FCachedServerList;
	unsigned FLastTickCount;
	__classmethod void __fastcall ServiceManagerOpen(const System::UnicodeString Server, const bool ReadOnly, /* out */ unsigned &sch);
	__classmethod void __fastcall ServiceManagerClose(const unsigned sch);
	__classmethod void __fastcall ServiceOpen(const System::UnicodeString Server, const System::UnicodeString ServiceName, const bool ReadOnly, /* out */ unsigned &sch, /* out */ unsigned &sh);
	__classmethod void __fastcall ServiceClose(const unsigned sch, const unsigned sh);
	void __fastcall ClearCachedServerList(void);
	void __fastcall AddToCachedServerList(const System::UnicodeString Keywords, const System::UnicodeString Server);
	
public:
	__fastcall TCRNetManager(void);
	__fastcall virtual ~TCRNetManager(void);
	__classmethod TCRServicesInfo __fastcall GetServiceNames(const System::UnicodeString Server);
	__classmethod TCRServiceStatus __fastcall GetServiceStatus(const System::UnicodeString Server, const System::UnicodeString ServiceName);
	__classmethod void __fastcall ServiceStart(const System::UnicodeString Server, const System::UnicodeString ServiceName, System::UnicodeString ParamStr = L"");
	__classmethod void __fastcall ServiceStop(const System::UnicodeString Server, const System::UnicodeString ServiceName);
	__classmethod void __fastcall GetServerList(Classes::TStrings* List)/* overload */;
	void __fastcall GetServerList(Classes::TStrings* List, const System::UnicodeString Keywords, const unsigned Timeout = (unsigned)(0x1), const unsigned CacheTimeout = (unsigned)(0x78))/* overload */;
};


class DELPHICLASS TCRDataSource;
class PASCALIMPLEMENTATION TCRDataSource : public Db::TDataSource
{
	typedef Db::TDataSource inherited;
	
protected:
	bool FDesignCreate;
	virtual void __fastcall Loaded(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall virtual TCRDataSource(Classes::TComponent* Owner);
public:
	/* TDataSource.Destroy */ inline __fastcall virtual ~TCRDataSource(void) { }
	
};


class DELPHICLASS TDBAccessUtils;
class PASCALIMPLEMENTATION TDBAccessUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod bool __fastcall IsObjectDataType(TDAParam* Obj, Db::TFieldType DataType);
	__classmethod bool __fastcall GetNational(TDAParam* Obj);
	__classmethod void __fastcall CheckConnection(TCustomDADataSet* Obj)/* overload */;
	__classmethod void __fastcall CheckConnection(TCustomDASQL* Obj)/* overload */;
	__classmethod TCustomDAConnection* __fastcall UsedConnection(TCustomDADataSet* Obj)/* overload */;
	__classmethod TCustomDAConnection* __fastcall UsedConnection(TCustomDASQL* Obj)/* overload */;
	__classmethod TCustomDAConnection* __fastcall UsedConnection(TDAMetaData* Obj)/* overload */;
	__classmethod void __fastcall SetAutoCommit(Classes::TComponent* Obj, bool Value);
	__classmethod bool __fastcall GetAutoCommit(TCustomDAConnection* Obj)/* overload */;
	__classmethod bool __fastcall GetAutoCommit(TCustomDADataSet* Obj)/* overload */;
	__classmethod bool __fastcall GetAutoCommit(TCustomDASQL* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TDATransaction* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TDATransaction* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TCustomDADataSet* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TCustomDADataSet* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TCustomDASQL* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TCustomDASQL* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TCustomDAUpdateSQL* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TCustomDAUpdateSQL* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TDAMetaData* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TDAMetaData* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TCRDataSource* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TCRDataSource* Obj)/* overload */;
	__classmethod void __fastcall SetLockLoginPrompt(TCustomDAConnection* Obj, bool Value);
	__classmethod Craccess::TCRRecordSet* __fastcall CreateIRecordSet(TCustomDAConnection* Obj);
	__classmethod Craccess::TCRConnection* __fastcall GetIConnection(TCustomDAConnection* Obj);
	__classmethod void __fastcall CreateIConnection(TCustomDAConnection* Obj);
	__classmethod Classes::TComponent* __fastcall GetUpdateQuery(TCustomDADataSet* Obj);
	__classmethod Craccess::TCRTablesInfo* __fastcall GetTablesInfo(TCustomDADataSet* Obj);
	__classmethod Craccess::TSQLInfo* __fastcall GetSQLInfo(TCustomDADataSet* Obj);
	__classmethod System::UnicodeString __fastcall GetUpdatingTable(TCustomDADataSet* Obj);
	__classmethod void __fastcall SetUpdatingTable(TCustomDADataSet* Obj, System::UnicodeString Value);
	__classmethod int __fastcall GetUpdatingTableIdx(TCustomDADataSet* Obj);
	__classmethod void __fastcall InternalConnect(TCustomDAConnection* Obj);
	__classmethod void __fastcall InternalDisconnect(TCustomDAConnection* Obj);
	__classmethod void __fastcall DisconnectTransaction(TCustomDAConnection* Obj);
	__classmethod void __fastcall SuppressAutoCommit(TCustomDAConnection* Obj);
	__classmethod void __fastcall RestoreAutoCommit(TCustomDAConnection* Obj);
	__classmethod bool __fastcall IsMultipleTransactionsSupported(TCustomDAConnection* Obj);
	__classmethod TDATransaction* __fastcall UsedTransaction(TCustomDAConnection* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall UsedTransaction(TCustomDADataSet* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall UsedTransaction(TCustomDASQL* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetTransaction(TCustomDADataSet* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetTransaction(TCustomDASQL* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetTransaction(TDAMetaData* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetDefaultTransaction(TCustomDAConnection* Obj);
	__classmethod void __fastcall SetTransaction(TCustomDADataSet* Obj, TDATransaction* Value)/* overload */;
	__classmethod void __fastcall SetTransaction(TCustomDASQL* Obj, TDATransaction* Value)/* overload */;
	__classmethod void __fastcall SetTransaction(TDAMetaData* Obj, TDATransaction* Value)/* overload */;
	__classmethod void __fastcall SetDefaultTransaction(TCustomDAConnection* Obj, TDATransaction* Value);
	__classmethod TDATransaction* __fastcall GetFTransaction(TCustomDADataSet* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetFTransaction(TCustomDASQL* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetFTransaction(TDAMetaData* Obj)/* overload */;
	__classmethod TDATransaction* __fastcall GetFDefaultTransaction(TCustomDAConnection* Obj);
	__classmethod Craccess::TCRTransaction* __fastcall GetITransaction(TDATransaction* Obj);
	__classmethod int __fastcall GetConnectionCount(TDATransaction* Obj);
	__classmethod TCustomDAConnection* __fastcall GetConnection(TDATransaction* Obj, int Index);
	__classmethod void __fastcall Savepoint(TDATransaction* Obj, const System::UnicodeString Name);
	__classmethod void __fastcall RollbackToSavepoint(TDATransaction* Obj, const System::UnicodeString Name);
	__classmethod void __fastcall ReleaseSavepoint(TDATransaction* Obj, const System::UnicodeString Name);
	__classmethod void __fastcall CommitRetaining(TDATransaction* Obj);
	__classmethod void __fastcall RollbackRetaining(TDATransaction* Obj);
	__classmethod void __fastcall GainTransaction(TDATransaction* Obj);
	__classmethod void __fastcall ReleaseTransaction(TDATransaction* Obj);
	__classmethod void __fastcall AutoCommitTransaction(TDATransaction* Obj, bool NeedCommit);
	__classmethod void __fastcall Disconnect(TCustomDASQL* Obj);
	__classmethod TDASQLGenerator* __fastcall SQLGenerator(TCustomDADataSet* Obj);
	__classmethod Classes::TList* __fastcall GetSQLs(TCustomDAConnection* Obj);
	__classmethod void __fastcall GetKeyAndDataFields(TCustomDADataSet* Obj, /* out */ TKeyAndDataFields &KeyAndDataFields, const bool ForceUseAllKeyFields);
	__classmethod bool __fastcall GetLockDebug(Classes::TComponent* Obj);
	__classmethod void __fastcall SetLockDebug(Classes::TComponent* Obj, bool Value);
	__classmethod TCustomDAConnection* __fastcall FOwner(TDAConnectionOptions* Obj)/* overload */;
	__classmethod TCustomDADataSet* __fastcall FOwner(TDADataSetOptions* Obj)/* overload */;
	__classmethod System::TClass __fastcall SQLMonitorClass(TCustomDAConnection* Obj);
	__classmethod TConnectDialogClass __fastcall ConnectDialogClass(TCustomDAConnection* Obj);
	__classmethod System::UnicodeString __fastcall QuoteName(TCustomDADataSet* Obj, const System::UnicodeString AName);
	__classmethod void __fastcall RegisterClient(TCustomDAConnection* Obj, System::TObject* Client, Db::TConnectChangeEvent Event = 0x0);
	__classmethod void __fastcall UnRegisterClient(TCustomDAConnection* Obj, System::TObject* Client);
	__classmethod Craccess::TCRFieldDesc* __fastcall GetIdentityField(TCustomDADataSet* Obj);
	__classmethod Classes::TStrings* __fastcall GetSQL(Classes::TComponent* Obj);
	__classmethod void __fastcall SetSQL(Classes::TComponent* Obj, Classes::TStrings* Value);
	__classmethod void __fastcall SetSQLText(Classes::TComponent* Obj, const System::UnicodeString SQLText, const bool LockScanParams, const bool LockMacros);
	__classmethod TDAParams* __fastcall GetParams(Classes::TComponent* Obj);
	__classmethod void __fastcall Execute(Classes::TComponent* Obj);
	__classmethod void __fastcall Open(Classes::TComponent* Obj);
	__classmethod int __fastcall GetRowsAffected(Classes::TComponent* Obj);
	__classmethod TStatementTypes __fastcall GetUpdateSQLStatementTypes(TCustomDADataSet* Obj);
	__classmethod Classes::TStrings* __fastcall GetUpdateSQLIndex(TCustomDADataSet* Obj, TStatementType StatementType);
	__classmethod System::UnicodeString __fastcall ParseSQL(TCustomDASQL* Obj, const System::UnicodeString SQL, TDAParams* Params, System::UnicodeString RenamePrefix = L"");
	__classmethod TDAParams* __fastcall CreateParamsObject(TCustomDASQL* Obj);
	__classmethod void __fastcall SetDesigning(Classes::TComponent* Obj, bool Value, bool SetChildren = true);
	__classmethod Craccess::TCRRecordSet* __fastcall GetIRecordSet(TCustomDADataSet* Obj);
	__classmethod void __fastcall CheckIRecordSet(TCustomDADataSet* Obj);
	__classmethod Craccess::TCRCommand* __fastcall GetICommand(TCustomDADataSet* Obj)/* overload */;
	__classmethod Craccess::TCRCommand* __fastcall GetICommand(TCustomDASQL* Obj)/* overload */;
	__classmethod TDADataSetUpdater* __fastcall GetUpdater(TCustomDADataSet* Obj);
	__classmethod TDADataSetService* __fastcall GetDataSetService(TCustomDADataSet* Obj);
	__classmethod TCustomDADataSetClass __fastcall GetDataSetClass(TCustomDAUpdateSQL* Obj);
	__classmethod TCustomDASQLClass __fastcall GetSQLClass(TCustomDAUpdateSQL* Obj);
	__classmethod Crparser::TSQLParserClass __fastcall GetParserClass(TMacros* Obj);
	__classmethod void __fastcall SaveServerListToRegistry(TCustomConnectDialog* Obj);
	__classmethod void __fastcall SetConnection(TCustomConnectDialog* Obj, TCustomDAConnection* Value);
	__classmethod void __fastcall SetUseServerHistory(TCustomConnectDialog* Obj, bool Value);
	__classmethod bool __fastcall GetNeedConnect(TCustomConnectDialog* Obj);
	__classmethod void __fastcall SetNeedConnect(TCustomConnectDialog* Obj, bool Value);
	__classmethod void __fastcall CreateProcCall(TCustomDASQL* Obj, const System::UnicodeString Name, bool NeedDescribe, bool IsQuery = false)/* overload */;
	__classmethod void __fastcall CreateProcCall(TCustomDADataSet* Obj, const System::UnicodeString Name, bool NeedDescribe, bool IsQuery = false)/* overload */;
	__classmethod TCustomDASQL* __fastcall GetCommand(TCustomDAConnection* Obj);
	__classmethod bool __fastcall GetStreamedConnected(TCustomDAConnection* Obj);
	__classmethod void __fastcall Loaded(TCustomDAConnection* Obj);
	__classmethod Craccess::TCRCursor* __fastcall GetAsCursor(TDAParam* Obj);
	__classmethod Craccess::TCRCursor* __fastcall GetCursor(TCustomDADataSet* Obj);
	__classmethod void __fastcall SetCursor(TCustomDADataSet* Obj, Craccess::TCRCursor* Value);
	__classmethod bool __fastcall GetFetchAll(TCustomDADataSet* Obj);
	__classmethod void __fastcall SetFetchAll(TCustomDADataSet* Obj, bool Value);
	__classmethod System::UnicodeString __fastcall GetKeyFields(TCustomDADataSet* Obj);
	__classmethod void __fastcall SetKeyFields(TCustomDADataSet* Obj, const System::UnicodeString Value);
	__classmethod void __fastcall QuickOpen(TCustomDADataSet* Obj, TQuickOpenInfo &Info);
	__classmethod void __fastcall Restore(TCustomDADataSet* Obj, const TQuickOpenInfo &Info);
	__classmethod TLockMode __fastcall GetLockMode(TCustomDADataSet* Obj);
	__classmethod void __fastcall SetLockMode(TCustomDADataSet* Obj, const TLockMode Value);
	__classmethod __int64 __fastcall GetLastInsertId(TCustomDADataSet* Obj);
public:
	/* TObject.Create */ inline __fastcall TDBAccessUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TDBAccessUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt OperationsStackDelta = 0x32;
extern PACKAGE TCRNetManager* CRNetManager;
static const ShortInt crSQLArrow = -30;
extern PACKAGE bool ChangeCursor;
extern PACKAGE System::WideChar MacroChar;
extern PACKAGE void __fastcall (*SetCursorProc)(int Value);
extern PACKAGE bool __fastcall (*ShowConnectFormProc)(TCustomConnectDialog* ConnectDialog);
extern PACKAGE bool BaseSQLOldBehavior;
extern PACKAGE bool SQLGeneratorCompatibility;
extern PACKAGE bool RefreshParamsOnInsert;
extern PACKAGE bool ResyncBeforeFetch;
extern PACKAGE bool BoundParams;
extern PACKAGE bool OldFieldsReadOnly;
extern PACKAGE bool ParamStringAsAnsiString;
extern PACKAGE void __fastcall SetCursor(int Value);
extern PACKAGE System::UnicodeString __fastcall _AddWhere(const System::UnicodeString SQL, System::UnicodeString Condition, Crparser::TSQLParserClass ParserClass, bool OmitComment);
extern PACKAGE System::UnicodeString __fastcall _SetWhere(const System::UnicodeString SQL, System::UnicodeString Condition, Crparser::TSQLParserClass ParserClass, bool OmitComment);
extern PACKAGE System::UnicodeString __fastcall _GetFrom(const System::UnicodeString SQL, Crparser::TSQLParserClass ParserClass, bool OmitComment);
extern PACKAGE System::UnicodeString __fastcall _GetWhere(const System::UnicodeString SQL, Crparser::TSQLParserClass ParserClass, bool OmitComment);
extern PACKAGE System::UnicodeString __fastcall _SetOrderBy(const System::UnicodeString SQL, System::UnicodeString Fields, Crparser::TSQLParserClass ParserClass);
extern PACKAGE System::UnicodeString __fastcall _GetOrderBy(const System::UnicodeString SQL, Crparser::TSQLParserClass ParserClass);
extern PACKAGE TStatementType __fastcall UpdateKindToStatementType(const Db::TUpdateKind UpdateKind);
extern PACKAGE Db::TUpdateKind __fastcall StatementTypeToUpdateKind(const TStatementType StatementType);

}	/* namespace Dbaccess */
using namespace Dbaccess;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DbaccessHPP
