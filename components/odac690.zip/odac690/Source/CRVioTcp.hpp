// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crviotcp.pas' rev: 21.00

#ifndef CrviotcpHPP
#define CrviotcpHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Winsock.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crvio.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crviotcp
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS SocketException;
class PASCALIMPLEMENTATION SocketException : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
protected:
	int FErrorCode;
	
public:
	__fastcall SocketException(int errorCode);
	__property int ErrorCode = {read=FErrorCode, nodefault};
public:
	/* Exception.CreateFmt */ inline __fastcall SocketException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall SocketException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall SocketException(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall SocketException(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall SocketException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall SocketException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall SocketException(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~SocketException(void) { }
	
};


class DELPHICLASS TCRVioTcp;
class PASCALIMPLEMENTATION TCRVioTcp : public Crvio::TCRVio
{
	typedef Crvio::TCRVio inherited;
	
protected:
	System::AnsiString Fhostname;
	int Fport;
	int Ftimeout;
	int FSd;
	int ffcntl_mode;
	virtual int __fastcall GetTimeout(void);
	virtual void __fastcall SetTimeout(int Value);
	int __fastcall fastsend(void);
	int __fastcall keepalive(bool onoff);
	int __fastcall IPByHostName(const System::AnsiString HostName);
	
public:
	__fastcall TCRVioTcp(const System::AnsiString hostname, const int port)/* overload */;
	virtual void __fastcall Connect(void);
	virtual void __fastcall Close(void);
	virtual int __fastcall ReadNoWait(char * buffer, int offset, int count);
	virtual int __fastcall WriteNoWait(const char * buffer, int offset, int count);
	virtual int __fastcall Write(const char * buffer, int offset, int count);
	virtual bool __fastcall WaitForData(int Timeout = 0xffffffff);
	virtual int __fastcall GetSocket(void);
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRVioTcp(void) { }
	
};


class DELPHICLASS THostNameResolver;
class PASCALIMPLEMENTATION THostNameResolver : public Classes::TThread
{
	typedef Classes::TThread inherited;
	
private:
	TCRVioTcp* FVio;
	int FIPAddr;
	
protected:
	virtual void __fastcall Execute(void);
	
public:
	__fastcall THostNameResolver(TCRVioTcp* Vio);
public:
	/* TThread.Destroy */ inline __fastcall virtual ~THostNameResolver(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
#define LOCAL_HOST L"localhost"
static const Word CR_IPSOCK_ERROR = 0x7d5;
static const Word CR_UNKNOWN_HOST = 0x7d5;
static const Word CR_CONN_HOST_ERROR = 0x7d3;
static const Word CR_SELECT_ERROR = 0x7d6;

}	/* namespace Crviotcp */
using namespace Crviotcp;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrviotcpHPP
