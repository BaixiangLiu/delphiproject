// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dadump.pas' rev: 21.00

#ifndef DadumpHPP
#define DadumpHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Dascript.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dadump
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TDADumpProcessorClass;

typedef void __fastcall (__closure *TDABackupProgressEvent)(System::TObject* Sender, System::UnicodeString ObjectName, int ObjectNum, int ObjectCount, int Percent);

typedef void __fastcall (__closure *TDARestoreProgressEvent)(System::TObject* Sender, int Percent);

class DELPHICLASS TDADumpOptions;
class DELPHICLASS TDADump;
class PASCALIMPLEMENTATION TDADumpOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
protected:
	TDADump* FOwner;
	bool FGenerateHeader;
	bool FAddDrop;
	bool FQuoteNames;
	bool FCompleteInsert;
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TDADumpOptions(TDADump* Owner);
	
__published:
	__property bool GenerateHeader = {read=FGenerateHeader, write=FGenerateHeader, default=1};
	__property bool AddDrop = {read=FAddDrop, write=FAddDrop, default=1};
	__property bool QuoteNames = {read=FQuoteNames, write=FQuoteNames, default=0};
	__property bool CompleteInsert = {read=FCompleteInsert, write=FCompleteInsert, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TDADumpOptions(void) { }
	
};


class DELPHICLASS TDADumpProcessor;
class PASCALIMPLEMENTATION TDADumpProcessor : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	TDADump* FOwner;
	Dbaccess::TCustomDADataSet* FQuery;
	Dbaccess::TCustomDAConnection* __fastcall GetConnection(void);
	Classes::TStrings* __fastcall GetSQL(void);
	Classes::TStringList* __fastcall GetTables(void);
	void __fastcall Add(const System::UnicodeString Line)/* overload */;
	void __fastcall Add(const Classes::TStringList* sl)/* overload */;
	void __fastcall AddLineToSQL(const System::UnicodeString Line)/* overload */;
	void __fastcall AddLineToSQL(const System::UnicodeString Line, System::TVarRec const *Args, const int Args_Size)/* overload */;
	virtual void __fastcall Backup(System::UnicodeString Query);
	virtual void __fastcall CheckTables(const System::UnicodeString QueryText);
	void __fastcall AddHeader(void);
	virtual Dbaccess::TCustomDADataSet* __fastcall CreateQuery(void);
	virtual Dbaccess::TCustomDADataSet* __fastcall CreateDataQuery(void);
	void __fastcall CheckQuery(void);
	virtual void __fastcall AddSettings(void);
	virtual void __fastcall RestoreSettings(void);
	virtual void __fastcall BackupObjects(const System::UnicodeString QueryText);
	virtual void __fastcall BackupData(const System::UnicodeString TableName, const System::UnicodeString QueryText, int TableNum, int TableCount);
	virtual System::UnicodeString __fastcall GetFieldValueForDump(Db::TField* Field);
	void __fastcall DoBackupProgress(System::UnicodeString ObjectName, int ObjectNum, int ObjectCount, int Percent);
	virtual Craccess::TSQLInfo* __fastcall SQLInfo(void);
	virtual System::UnicodeString __fastcall QuoteName(const System::UnicodeString AName);
	
public:
	__fastcall virtual TDADumpProcessor(TDADump* Owner);
	__fastcall virtual ~TDADumpProcessor(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
};


class PASCALIMPLEMENTATION TDADump : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	TDADumpProcessor* FProcessor;
	Dbaccess::TCustomDAConnection* FConnection;
	Classes::TStrings* FSQL;
	Classes::TStream* FStream;
	TDADumpOptions* FOptions;
	bool FDebug;
	bool FDesignCreate;
	Classes::TStringList* FTables;
	TDABackupProgressEvent FOnBackupProgress;
	TDARestoreProgressEvent FOnRestoreProgress;
	Dascript::TOnErrorEvent FOnError;
	virtual TDADumpProcessorClass __fastcall GetProcessorClass(void);
	virtual void __fastcall SetProcessor(TDADumpProcessor* Value);
	void __fastcall CreateProcessor(void);
	void __fastcall FreeProcessor(void);
	void __fastcall CheckProcessor(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual System::UnicodeString __fastcall GetTableNames(void);
	virtual void __fastcall SetTableNames(System::UnicodeString Value);
	virtual TDADumpOptions* __fastcall CreateOptions(void);
	virtual Dascript::TDAScript* __fastcall CreateScript(void);
	virtual void __fastcall Notification(Classes::TComponent* Component, Classes::TOperation Operation);
	void __fastcall SetConnection(Dbaccess::TCustomDAConnection* Value);
	virtual void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall SetSQL(Classes::TStrings* Value);
	void __fastcall SetOptions(TDADumpOptions* Value);
	virtual void __fastcall Loaded(void);
	void __fastcall InternalBackup(System::UnicodeString Query);
	virtual System::UnicodeString __fastcall GenerateHeader(void) = 0 ;
	__property TDADumpProcessor* Processor = {read=FProcessor};
	
public:
	__fastcall virtual TDADump(Classes::TComponent* Owner);
	__fastcall virtual ~TDADump(void);
	void __fastcall Backup(void);
	void __fastcall BackupToStream(Classes::TStream* Stream, const System::UnicodeString Query = L"");
	void __fastcall BackupToFile(const System::UnicodeString FileName, const System::UnicodeString Query = L"");
	void __fastcall BackupQuery(const System::UnicodeString Query);
	void __fastcall Restore(void);
	void __fastcall RestoreFromStream(Classes::TStream* Stream);
	void __fastcall RestoreFromFile(const System::UnicodeString FileName);
	__property Dbaccess::TCustomDAConnection* Connection = {read=FConnection, write=SetConnection};
	__property TDADumpOptions* Options = {read=FOptions, write=SetOptions};
	
__published:
	__property System::UnicodeString TableNames = {read=GetTableNames, write=SetTableNames};
	__property Classes::TStrings* SQL = {read=FSQL, write=SetSQL};
	__property bool Debug = {read=FDebug, write=FDebug, default=0};
	__property TDABackupProgressEvent OnBackupProgress = {read=FOnBackupProgress, write=FOnBackupProgress};
	__property TDARestoreProgressEvent OnRestoreProgress = {read=FOnRestoreProgress, write=FOnRestoreProgress};
	__property Dascript::TOnErrorEvent OnError = {read=FOnError, write=FOnError};
};


class DELPHICLASS TDADumpUtils;
class PASCALIMPLEMENTATION TDADumpUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TDADump* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TDADump* Obj);
public:
	/* TObject.Create */ inline __fastcall TDADumpUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TDADumpUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dadump */
using namespace Dadump;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DadumpHPP
