// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Orascript.pas' rev: 21.00

#ifndef OrascriptHPP
#define OrascriptHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Oraparser.hpp>	// Pascal unit
#include <Dascript.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Orascript
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOraStatement;
class PASCALIMPLEMENTATION TOraStatement : public Dascript::TDAStatement
{
	typedef Dascript::TDAStatement inherited;
	
private:
	HIDESBASE Ora::TOraParams* __fastcall GetParams(void);
	
public:
	__property Ora::TOraParams* Params = {read=GetParams};
public:
	/* TDAStatement.Destroy */ inline __fastcall virtual ~TOraStatement(void) { }
	
public:
	/* TCollectionItem.Create */ inline __fastcall virtual TOraStatement(Classes::TCollection* Collection) : Dascript::TDAStatement(Collection) { }
	
};


class DELPHICLASS TOraStatements;
class PASCALIMPLEMENTATION TOraStatements : public Dascript::TDAStatements
{
	typedef Dascript::TDAStatements inherited;
	
public:
	TOraStatement* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TOraStatement* __fastcall GetItem(int Index);
	
public:
	__property TOraStatement* Items[int Index] = {read=GetItem/*, default*/};
public:
	/* TDAStatements.Create */ inline __fastcall TOraStatements(Classes::TCollectionItemClass ItemClass, Dascript::TDAScript* Script) : Dascript::TDAStatements(ItemClass, Script) { }
	
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TOraStatements(void) { }
	
};


class DELPHICLASS TOraScript;
class PASCALIMPLEMENTATION TOraScript : public Dascript::TDAScript
{
	typedef Dascript::TDAScript inherited;
	
protected:
	Ora::TOraSession* __fastcall GetSession(void);
	void __fastcall SetSession(Ora::TOraSession* Value);
	HIDESBASE Ora::TOraDataSet* __fastcall GetDataSet(void);
	HIDESBASE void __fastcall SetDataSet(Ora::TOraDataSet* Value);
	HIDESBASE Ora::TOraParams* __fastcall GetParams(void);
	HIDESBASE TOraStatements* __fastcall GetStatements(void);
	virtual Dascript::TDAScriptProcessorClass __fastcall GetProcessorClass(void);
	virtual Dascript::TDAStatements* __fastcall CreateStatementsObject(void);
	virtual Dbaccess::TCustomDASQL* __fastcall CreateCommand(void);
	virtual void __fastcall CalculateErrorOffset(Sysutils::Exception* E);
	
public:
	__fastcall virtual TOraScript(Classes::TComponent* Owner);
	__property TOraStatements* Statements = {read=GetStatements};
	
__published:
	__property Ora::TOraSession* Session = {read=GetSession, write=SetSession};
	__property Ora::TOraDataSet* DataSet = {read=GetDataSet, write=SetDataSet};
public:
	/* TDAScript.Destroy */ inline __fastcall virtual ~TOraScript(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Orascript */
using namespace Orascript;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OrascriptHPP
