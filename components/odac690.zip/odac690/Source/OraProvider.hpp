// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraprovider.pas' rev: 21.00

#ifndef OraproviderHPP
#define OraproviderHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Provider.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dbclient.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraprovider
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOraProvider;
class PASCALIMPLEMENTATION TOraProvider : public Provider::TDataSetProvider
{
	typedef Provider::TDataSetProvider inherited;
	
__published:
	virtual System::OleVariant __fastcall InternalGetParams(Db::TParamTypes Types = (Db::TParamTypes() << ptUnknown << ptInput << ptOutput << ptInputOutput << ptResult ));
public:
	/* TDataSetProvider.Create */ inline __fastcall virtual TOraProvider(Classes::TComponent* AOwner) : Provider::TDataSetProvider(AOwner) { }
	/* TDataSetProvider.Destroy */ inline __fastcall virtual ~TOraProvider(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall UseOraProv(void);
extern PACKAGE void __fastcall Register(void);

}	/* namespace Oraprovider */
using namespace Oraprovider;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraproviderHPP
