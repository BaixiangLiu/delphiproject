// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraconnectionpool.pas' rev: 21.00

#ifndef OraconnectionpoolHPP
#define OraconnectionpoolHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Crconnectionpool.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraconnectionpool
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TOraPoolingType { optLocal, optOCI, optMTS };
#pragma option pop

class DELPHICLASS TOraConnectionParameters;
class PASCALIMPLEMENTATION TOraConnectionParameters : public Crconnectionpool::TCRConnectionParameters
{
	typedef Crconnectionpool::TCRConnectionParameters inherited;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	bool Direct;
	System::UnicodeString HomeName;
	bool UseUnicode;
	Oraclasses::TConnectMode ConnectMode;
	bool UseOCI7;
	TOraPoolingType PoolingType;
	bool StatementCache;
	int StatementCacheSize;
	int ConnectionTimeout;
	Oraclasses::TOptimizerMode OptimizerMode;
	System::UnicodeString ClientIdentifier;
	System::UnicodeString Schema;
	System::UnicodeString ProxyUserName;
	System::UnicodeString ProxyPassword;
	virtual bool __fastcall Equals(Crconnectionpool::TCRConnectionParameters* Obj);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
public:
	/* TCRConnectionParameters.Create */ inline __fastcall virtual TOraConnectionParameters(void) : Crconnectionpool::TCRConnectionParameters() { }
	/* TCRConnectionParameters.Destroy */ inline __fastcall virtual ~TOraConnectionParameters(void) { }
	
};


class DELPHICLASS TOraLocalConnectionPool;
class PASCALIMPLEMENTATION TOraLocalConnectionPool : public Crconnectionpool::TCRLocalConnectionPool
{
	typedef Crconnectionpool::TCRLocalConnectionPool inherited;
	
protected:
	virtual Craccess::TCRConnection* __fastcall CreateNewConnector(void);
public:
	/* TCRLocalConnectionPool.Create */ inline __fastcall virtual TOraLocalConnectionPool(Crconnectionpool::TCRConnectionPoolManager* Manager, Crconnectionpool::TCRConnectionParameters* ConnectionParameters) : Crconnectionpool::TCRLocalConnectionPool(Manager, ConnectionParameters) { }
	/* TCRLocalConnectionPool.Destroy */ inline __fastcall virtual ~TOraLocalConnectionPool(void) { }
	
};


class DELPHICLASS TOraOCIConnectionPool;
class PASCALIMPLEMENTATION TOraOCIConnectionPool : public Crconnectionpool::TCRConnectionPool
{
	typedef Crconnectionpool::TCRConnectionPool inherited;
	
private:
	void *hOCISPool;
	System::UnicodeString FPoolName;
	void __fastcall CreateOCIPool(void);
	void __fastcall FreeOCIPool(void);
	
protected:
	virtual void __fastcall InternalPutConnection(Craccess::TCRConnection* CRConnection);
	
public:
	__fastcall virtual ~TOraOCIConnectionPool(void);
	virtual Craccess::TCRConnection* __fastcall GetConnection(void);
public:
	/* TCRConnectionPool.Create */ inline __fastcall virtual TOraOCIConnectionPool(Crconnectionpool::TCRConnectionPoolManager* Manager, Crconnectionpool::TCRConnectionParameters* ConnectionParameters) : Crconnectionpool::TCRConnectionPool(Manager, ConnectionParameters) { }
	
};


class DELPHICLASS TOraMTSConnectionPool;
class PASCALIMPLEMENTATION TOraMTSConnectionPool : public Crconnectionpool::TCRConnectionPool
{
	typedef Crconnectionpool::TCRConnectionPool inherited;
	
protected:
	virtual void __fastcall InternalPutConnection(Craccess::TCRConnection* CRConnection);
	
public:
	virtual Craccess::TCRConnection* __fastcall GetConnection(void);
public:
	/* TCRConnectionPool.Create */ inline __fastcall virtual TOraMTSConnectionPool(Crconnectionpool::TCRConnectionPoolManager* Manager, Crconnectionpool::TCRConnectionParameters* ConnectionParameters) : Crconnectionpool::TCRConnectionPool(Manager, ConnectionParameters) { }
	/* TCRConnectionPool.Destroy */ inline __fastcall virtual ~TOraMTSConnectionPool(void) { }
	
};


class DELPHICLASS TOraConnectionPoolManager;
class PASCALIMPLEMENTATION TOraConnectionPoolManager : public Crconnectionpool::TCRConnectionPoolManager
{
	typedef Crconnectionpool::TCRConnectionPoolManager inherited;
	
protected:
	virtual Crconnectionpool::TCRConnectionPool* __fastcall CreateCRConnectionPool(Crconnectionpool::TCRConnectionParameters* ConnectionParameters);
	virtual Craccess::TCRConnection* __fastcall InternalGetConnection(Crconnectionpool::TCRConnectionParameters* ConnectionParameters);
	virtual Craccess::TCRConnection* __fastcall InternalCheckConnection(Craccess::TCRConnection* Connection);
	
public:
	__classmethod void __fastcall Clear();
	__classmethod void __fastcall AsyncClear();
	__classmethod virtual Craccess::TCRConnection* __fastcall GetConnection(Crconnectionpool::TCRConnectionParameters* ConnectionParameters);
public:
	/* TCRConnectionPoolManager.Create */ inline __fastcall TOraConnectionPoolManager(void) : Crconnectionpool::TCRConnectionPoolManager() { }
	/* TCRConnectionPoolManager.Destroy */ inline __fastcall virtual ~TOraConnectionPoolManager(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt prPoolingType = 0x65;

}	/* namespace Oraconnectionpool */
using namespace Oraconnectionpool;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraconnectionpoolHPP
