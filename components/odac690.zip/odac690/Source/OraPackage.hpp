// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Orapackage.pas' rev: 21.00

#ifndef OrapackageHPP
#define OrapackageHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Orapackage
{
//-- type declarations -------------------------------------------------------
struct TPlSqlRecordParameter
{
	
public:
	System::UnicodeString Name;
	Db::TParamType ParamType;
};


typedef DynamicArray<TPlSqlRecordParameter> TPlSqlRecordParameters;

class DELPHICLASS TVariable;
class DELPHICLASS TCustomOraPackage;
class PASCALIMPLEMENTATION TVariable : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	TCustomOraPackage* FPackage;
	void __fastcall SetName(const System::UnicodeString Value);
	void __fastcall CheckPackage(void);
	System::TDateTime __fastcall GetAsDateTime(void);
	double __fastcall GetAsFloat(void);
	int __fastcall GetAsInteger(void);
	System::UnicodeString __fastcall GetAsString(void);
	void __fastcall SetAsDateTime(const System::TDateTime Value);
	void __fastcall SetAsFloat(const double Value);
	void __fastcall SetAsInteger(const int Value);
	void __fastcall SetAsString(const System::UnicodeString Value);
	
public:
	__fastcall TVariable(TCustomOraPackage* APackage);
	__property System::UnicodeString Name = {read=FName, write=SetName};
	__property TCustomOraPackage* Package = {read=FPackage};
	__property System::TDateTime AsDateTime = {read=GetAsDateTime, write=SetAsDateTime};
	__property double AsFloat = {read=GetAsFloat, write=SetAsFloat};
	__property int AsInteger = {read=GetAsInteger, write=SetAsInteger, nodefault};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TVariable(void) { }
	
};


class DELPHICLASS TCustomPlSqlRecord;
class PASCALIMPLEMENTATION TCustomPlSqlRecord : public Memdata::TSharedObject
{
	typedef Memdata::TSharedObject inherited;
	
private:
	void *FSvcCtx;
	Classes::TList* FParentRecordList;
	void __fastcall SetParentRecordList(const Classes::TList* Value);
	
protected:
	virtual void __fastcall SetOCISvcCtx(const void * Value);
	void __fastcall KeepReferences(const Memdata::TSharedObject* OldValue, const Memdata::TSharedObject* NewValue);
	
public:
	__fastcall virtual ~TCustomPlSqlRecord(void);
	virtual void __fastcall Assign(TCustomPlSqlRecord* Source);
	__property Classes::TList* ParentRecordList = {read=FParentRecordList, write=SetParentRecordList};
	__property void * OCISvcCtx = {read=FSvcCtx, write=SetOCISvcCtx};
public:
	/* TSharedObject.Create */ inline __fastcall TCustomPlSqlRecord(void) : Memdata::TSharedObject() { }
	
};


class PASCALIMPLEMENTATION TCustomOraPackage : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	System::UnicodeString FPackageName;
	Ora::TOraSession* FSession;
	Classes::TList* FVariables;
	Ora::TOraParams* FParams;
	bool FDebug;
	bool FRestoreOld;
	bool FOldDebug;
	bool FOldParamCheck;
	TPlSqlRecordParameters FPlSqlRecordStack;
	System::UnicodeString FPlSqlDeclSt;
	System::UnicodeString FPlSqlInSt;
	System::UnicodeString FPlSqlRetSt;
	System::UnicodeString FPlSqlParamSt;
	System::UnicodeString FPlSqlOutSt;
	Classes::TList* FPlSqlRecordList;
	void __fastcall SetPackageName(const System::UnicodeString Value);
	void __fastcall SetSession(const Ora::TOraSession* Value);
	Ora::TOraSession* __fastcall UsedConnection(void);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall CheckPackage(void);
	void __fastcall SetDebug(const bool Value);
	
protected:
	bool FDesignCreate;
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	Db::TParam* __fastcall GetVariable(System::UnicodeString Name, Db::TFieldType DataType);
	void __fastcall SetVariable(System::UnicodeString Name, Db::TFieldType DataType, const System::Variant &Value);
	void __fastcall ClearPlSqlRecordList(void);
	void __fastcall BeginExecPlSql(void);
	void __fastcall ExecProc(const System::UnicodeString Name)/* overload */;
	void __fastcall EndExecPlSql(void);
	Ora::TOraParam* __fastcall AddParam(const System::UnicodeString Name, const Db::TFieldType DataType, const Db::TParamType ParamType = (Db::TParamType)(0x0));
	void __fastcall BeginRecordParam(const System::UnicodeString Name, const System::UnicodeString DataTypeStr, const Db::TParamType ParamType = (Db::TParamType)(0x0));
	void __fastcall EndRecordParam(void);
	void * __fastcall OCISvcCtx(void);
	__property Classes::TList* PlSqlRecordList = {read=FPlSqlRecordList};
	
public:
	__fastcall virtual TCustomOraPackage(Classes::TComponent* AOwner);
	__fastcall virtual ~TCustomOraPackage(void);
	TVariable* __fastcall VariableByName(System::UnicodeString Name);
	System::Variant __fastcall ExecProc(System::UnicodeString Name, System::Variant const *Params, const int Params_Size)/* overload */;
	System::Variant __fastcall ExecProcEx(System::UnicodeString Name, System::Variant const *Params, const int Params_Size);
	__property Ora::TOraParams* Params = {read=FParams};
	__property System::UnicodeString PackageName = {read=FPackageName, write=SetPackageName};
	
__published:
	__property bool Debug = {read=FDebug, write=SetDebug, default=0};
	__property Ora::TOraSession* Session = {read=FSession, write=SetSession};
};


class DELPHICLASS TOraPackage;
class PASCALIMPLEMENTATION TOraPackage : public TCustomOraPackage
{
	typedef TCustomOraPackage inherited;
	
__published:
	__property PackageName;
public:
	/* TCustomOraPackage.Create */ inline __fastcall virtual TOraPackage(Classes::TComponent* AOwner) : TCustomOraPackage(AOwner) { }
	/* TCustomOraPackage.Destroy */ inline __fastcall virtual ~TOraPackage(void) { }
	
};


class DELPHICLASS TOraPackageUtils;
class PASCALIMPLEMENTATION TOraPackageUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TCustomOraPackage* Obj, bool Value);
	__classmethod bool __fastcall GetDesignCreate(TCustomOraPackage* Obj);
	__classmethod Ora::TOraSession* __fastcall UsedConnection(TCustomOraPackage* Obj);
public:
	/* TObject.Create */ inline __fastcall TOraPackageUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraPackageUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Orapackage */
using namespace Orapackage;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OrapackageHPP
