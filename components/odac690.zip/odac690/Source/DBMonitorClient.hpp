// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dbmonitorclient.pas' rev: 21.00

#ifndef DbmonitorclientHPP
#define DbmonitorclientHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Dbmonitorintf.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dbmonitorclient
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::UnicodeString __fastcall WhereMonitor(void);
extern PACKAGE bool __fastcall HasMonitor(void);
extern PACKAGE Dbmonitorintf::_di_IDBMonitor __fastcall GetDBMonitor(void);
extern PACKAGE System::AnsiString __fastcall GetDBMonitorVersion(void);

}	/* namespace Dbmonitorclient */
using namespace Dbmonitorclient;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DbmonitorclientHPP
