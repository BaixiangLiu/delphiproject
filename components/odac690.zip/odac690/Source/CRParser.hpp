// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crparser.pas' rev: 21.00

#ifndef CrparserHPP
#define CrparserHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crparser
{
//-- type declarations -------------------------------------------------------
typedef TMetaClass* TParserClass;

typedef TMetaClass* TSQLParserClass;

typedef DynamicArray<int> TClausesArr;

class DELPHICLASS TParser;
class PASCALIMPLEMENTATION TParser : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	__int64 OldPos;
	__int64 OldOldPos;
	bool FOmitBlank;
	bool FOmitComment;
	bool FUppered;
	__int64 FCurrLine;
	__int64 FPrevLine;
	int FCurrBegLine;
	__int64 FPrevBegLine;
	bool FQuotedString;
	bool FAdvancedStringParsing;
	int FSavedPos;
	int FLexemPos;
	int FLexemLength;
	Classes::TStream* FStream;
	Clrclasses::Encoding* FEncoding;
	__int64 FStartOffset;
	Classes::TStringList* FStoredBlocks;
	System::UnicodeString FCurrentBlock;
	int FFirstBlockOffset;
	int FBlockOffset;
	int FBlockSize;
	bool FAlternativeQuoting;
	bool FDollarQuoting;
	__int64 __fastcall GetCharSize(__int64 ByteSize);
	void __fastcall ReadNextBlock(void);
	System::WideChar __fastcall GetChar(int Index);
	System::WideChar __fastcall GetStoredChar(int Index);
	void __fastcall DecreaseBlockParameters(void);
	int __fastcall CurBlockSize(void);
	int TextLength;
	int Pos;
	__int64 StreamLength;
	__int64 Offset;
	Classes::TStringList* FSymbolLexems;
	Classes::TStringList* FKeywordLexems;
	bool FOmitKeywords;
	System::UnicodeString FDesiredLexem;
	bool FDesiredLexemFound;
	System::UnicodeString FLexem;
	virtual void __fastcall InitParser(void);
	virtual bool __fastcall IsBlank(System::WideChar Ch);
	virtual bool __fastcall IsSymbol(System::WideChar Ch);
	virtual bool __fastcall IsAlpha(System::WideChar Ch);
	virtual bool __fastcall IsNumber(System::WideChar Ch);
	virtual bool __fastcall IsStringQuote(System::WideChar Ch);
	virtual void __fastcall ToRightQuoteP(System::WideChar RightQuote);
	virtual void __fastcall ToRightQuote(System::WideChar RightQuote);
	virtual bool __fastcall IsIdentQuote(System::WideChar Ch);
	virtual bool __fastcall IsInlineComment(int Pos);
	int __fastcall FindLexemIndex(const int LexemPos, const int LexemLength, Classes::TStringList* Lexems);
	int __fastcall InternalGetNext(void);
	System::UnicodeString __fastcall CopyText(const int Pos, const int Count);
	void __fastcall AddToLexemArray(int Index, const int Len);
	__property System::WideChar Text[int Index] = {read=GetChar};
	__property bool AlternativeQuoting = {read=FAlternativeQuoting, write=FAlternativeQuoting, nodefault};
	__property bool DollarQuoting = {read=FDollarQuoting, write=FDollarQuoting, nodefault};
	
public:
	System::UnicodeString CommentBegin;
	System::UnicodeString CommentEnd;
	System::UnicodeString DecSeparator;
	__fastcall virtual TParser(const System::UnicodeString Text)/* overload */;
	__fastcall virtual TParser(const Classes::TStream* Stream, Clrclasses::Encoding* AEncoding)/* overload */;
	__fastcall virtual ~TParser(void);
	void __fastcall SetText(const System::UnicodeString Text);
	virtual void __fastcall ToBegin(void);
	void __fastcall Back(void);
	virtual int __fastcall GetNext(/* out */ System::UnicodeString &Lexem);
	int __fastcall GetNextCode(void);
	int __fastcall ToLexem(const int Code)/* overload */;
	bool __fastcall ToLexem(const System::UnicodeString Lexem)/* overload */;
	__int64 __fastcall CurrPos(void);
	__int64 __fastcall PrevPos(void);
	__int64 __fastcall PrevPrevPos(void);
	__int64 __fastcall CurrLine(void);
	__int64 __fastcall PrevLine(void);
	__int64 __fastcall CurrCol(void);
	__int64 __fastcall PrevCol(void);
	__property bool OmitBlank = {read=FOmitBlank, write=FOmitBlank, nodefault};
	__property bool OmitComment = {read=FOmitComment, write=FOmitComment, nodefault};
	__property bool Uppered = {read=FUppered, write=FUppered, nodefault};
	__property bool QuotedString = {read=FQuotedString, write=FQuotedString, nodefault};
	__property bool AdvancedStringParsing = {read=FAdvancedStringParsing, write=FAdvancedStringParsing, nodefault};
	__property Classes::TStringList* SymbolLexems = {read=FSymbolLexems};
	__property Classes::TStringList* KeywordLexems = {read=FKeywordLexems};
};


class DELPHICLASS TSQLParser;
class PASCALIMPLEMENTATION TSQLParser : public TParser
{
	typedef TParser inherited;
	
protected:
	TClausesArr FClauses;
	virtual void __fastcall InitParser(void);
	virtual bool __fastcall IsAlpha(System::WideChar Ch);
	virtual bool __fastcall IsStringQuote(System::WideChar Ch);
	virtual bool __fastcall IsIdentQuote(System::WideChar Ch);
	virtual bool __fastcall IsInlineComment(int Pos);
	
public:
	bool __fastcall IsClauseLexem(int Code);
	int __fastcall PosClauseLexem(int Code);
	int __fastcall CompareClauseLexems(const int Code1, const int Code2);
	virtual bool __fastcall IsMacroAllowed(int Code);
	__classmethod virtual bool __fastcall IsNumericMacroNameAllowed();
	__classmethod virtual bool __fastcall IsSelectModifier(int Code);
	__classmethod virtual bool __fastcall IsFunctionOrConst(const System::UnicodeString UpperedName);
	__classmethod virtual bool __fastcall IsQuasiColumn(const System::UnicodeString UpperedName);
public:
	/* TParser.Create */ inline __fastcall virtual TSQLParser(const System::UnicodeString Text)/* overload */ : TParser(Text) { }
	/* TParser.Destroy */ inline __fastcall virtual ~TSQLParser(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt lcEnd = 0x0;
static const ShortInt lcLexem = -100;
static const ShortInt lcSymbol = -102;
static const ShortInt lcIdent = -103;
static const ShortInt lcNumber = -105;
static const ShortInt lcString = -106;
static const ShortInt lcBlank = -107;
static const ShortInt lcComment = -108;
static const ShortInt lxSQLFirst = 0x64;
static const ShortInt lxALL = 0x64;
static const ShortInt lxAND = 0x65;
static const ShortInt lxAS = 0x66;
static const ShortInt lxBEGIN = 0x67;
static const ShortInt lxBY = 0x68;
static const ShortInt lxCOMMIT = 0x69;
static const ShortInt lxDELETE = 0x6a;
static const ShortInt lxDISTINCT = 0x6b;
static const ShortInt lxEXECUTE = 0x6c;
static const ShortInt lxFETCH = 0x6d;
static const ShortInt lxFOR = 0x6e;
static const ShortInt lxFROM = 0x6f;
static const ShortInt lxFULL = 0x70;
static const ShortInt lxGROUP = 0x71;
static const ShortInt lxHAVING = 0x72;
static const ShortInt lxINNER = 0x73;
static const ShortInt lxINSERT = 0x74;
static const ShortInt lxINTERSECT = 0x75;
static const ShortInt lxINTO = 0x76;
static const ShortInt lxIS = 0x77;
static const ShortInt lxJOIN = 0x78;
static const ShortInt lxLEFT = 0x79;
static const ShortInt lxLIMIT = 0x7a;
static const ShortInt lxLOCK = 0x7b;
static const ShortInt lxMINUS = 0x7c;
static const ShortInt lxNOT = 0x7d;
static const ShortInt lxOFFSET = 0x7e;
static const ShortInt lxON = 0x7f;
static const Byte lxOR = 0x80;
static const Byte lxORDER = 0x81;
static const Byte lxOUTER = 0x82;
static const Byte lxRELEASE = 0x83;
static const Byte lxRETURNING = 0x84;
static const Byte lxRIGHT = 0x85;
static const Byte lxROLLBACK = 0x86;
static const Byte lxSAVEPOINT = 0x87;
static const Byte lxSELECT = 0x88;
static const Byte lxSET = 0x89;
static const Byte lxTO = 0x8a;
static const Byte lxTRANSACTION = 0x8b;
static const Byte lxUNION = 0x8c;
static const Byte lxUPDATE = 0x8d;
static const Byte lxWHERE = 0x8e;
static const int BlockSize = 0x10000;
extern PACKAGE Classes::TStringList* CommonSymbolLexems;
extern PACKAGE Classes::TStringList* CommonKeywordLexems;
extern PACKAGE Classes::TStringList* SQLSymbolLexems;
extern PACKAGE Classes::TStringList* SQLKeywordLexems;
extern PACKAGE int __fastcall CRCmpStrings(Classes::TStringList* List, int Index1, int Index2);

}	/* namespace Crparser */
using namespace Crparser;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrparserHPP
