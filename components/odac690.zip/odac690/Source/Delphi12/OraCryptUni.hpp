// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oracryptuni.pas' rev: 20.00

#ifndef OracryptuniHPP
#define OracryptuniHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oracryptuni
{
//-- type declarations -------------------------------------------------------
typedef Sysutils::TBytes TByteArr;

typedef DynamicArray<int> TIntArr;

typedef DynamicArray<int> TLongArr;

typedef DynamicArray<System::ShortInt> TShortArr;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall ByteArrayCopy(Sysutils::TBytes Src, int SrcPos, Sysutils::TBytes Dest, int DestPos, int Len);
extern PACKAGE Sysutils::TBytes __fastcall encrypt(Sysutils::TBytes key, Sysutils::TBytes buffer, int buf_len);
extern PACKAGE Sysutils::TBytes __fastcall decrypt(Sysutils::TBytes key, Sysutils::TBytes ebuf);
extern PACKAGE Sysutils::TBytes __fastcall encryptAll8BytesBlocks(Sysutils::TBytes value, bool only8bytes);
extern PACKAGE void __fastcall des_enc(Sysutils::TBytes data, int blocks);
extern PACKAGE void __fastcall des_dec(Sysutils::TBytes data, int blocks);
extern PACKAGE void __fastcall des_enc1(Sysutils::TBytes key, Sysutils::TBytes data, int blocks);
extern PACKAGE void __fastcall des_dec1(Sysutils::TBytes key, Sysutils::TBytes data, int blocks);
extern PACKAGE void __fastcall setKeys(Sysutils::TBytes key);
extern PACKAGE System::Byte __fastcall nibbleToHex(System::Byte nibble);
extern PACKAGE System::Byte __fastcall asciiHexToNibble(System::Byte b);
extern PACKAGE void __fastcall bArray2nibbles(Sysutils::TBytes arr, Sysutils::TBytes nibbles);
extern PACKAGE Sysutils::TBytes __fastcall nibbles2bArray(Sysutils::TBytes nibbles);
extern PACKAGE Sysutils::TBytes __fastcall normO(System::UnicodeString user, System::UnicodeString password);
extern PACKAGE Sysutils::TBytes __fastcall wb_decrypt(Sysutils::TBytes key, Sysutils::TBytes evalue);
extern PACKAGE Sysutils::TBytes __fastcall wb_encrypt(Sysutils::TBytes key, Sysutils::TBytes value);
extern PACKAGE Sysutils::TBytes __fastcall normalizeUserPassword(System::UnicodeString user, System::UnicodeString password);
extern PACKAGE Sysutils::TBytes __fastcall oneWayEncryption(Sysutils::TBytes value);
extern PACKAGE Sysutils::TBytes __fastcall StringToWorkbench(System::UnicodeString value);
extern PACKAGE int __fastcall StringToWorkbench1(System::UnicodeString value, Sysutils::TBytes outArray, int offset);

}	/* namespace Oracryptuni */
using namespace Oracryptuni;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OracryptuniHPP
