// CodeGear C++Builder
// Copyright (c) 1995, 2008 by CodeGear
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oranet.pas' rev: 20.00

#ifndef OranetHPP
#define OranetHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Scktcomp.hpp>	// Pascal unit
#include <Winsock.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Rtlconsts.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oracrypt.hpp>	// Pascal unit
#include <Oraparser.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Dateutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oranet
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE bool UseDirectLobs;
extern PACKAGE int SDU;
extern PACKAGE int TDU;
extern PACKAGE void __fastcall InitNet(void);
extern PACKAGE void __fastcall LoadNet(void);
extern PACKAGE void __fastcall FreeNet(void);

}	/* namespace Oranet */
using namespace Oranet;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OranetHPP
