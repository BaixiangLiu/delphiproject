// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraparser.pas' rev: 21.00

#ifndef OraparserHPP
#define OraparserHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraparser
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TOraParser;
class PASCALIMPLEMENTATION TOraParser : public Crparser::TSQLParser
{
	typedef Crparser::TSQLParser inherited;
	
private:
	bool FInWrapped;
	
protected:
	virtual void __fastcall InitParser(void);
	
public:
	virtual int __fastcall GetNext(/* out */ System::UnicodeString &Lexem);
	virtual bool __fastcall IsMacroAllowed(int Code);
	__classmethod virtual bool __fastcall IsNumericMacroNameAllowed();
	__classmethod virtual bool __fastcall IsSelectModifier(int Code);
	__classmethod virtual bool __fastcall IsFunctionOrConst(const System::UnicodeString UpperedName);
	__classmethod virtual bool __fastcall IsQuasiColumn(const System::UnicodeString UpperedName);
public:
	/* TParser.Create */ inline __fastcall virtual TOraParser(const System::UnicodeString Text)/* overload */ : Crparser::TSQLParser(Text) { }
	/* TParser.Destroy */ inline __fastcall virtual ~TOraParser(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE Classes::TStringList* OraKeywordLexems;
static const Word lxOraFirst = 0x3e8;
static const Word lxALTER = 0x3e8;
static const Word lxBODY = 0x3e9;
static const Word lxCONNECT = 0x3ea;
static const Word lxCREATE = 0x3eb;
static const Word lxDECLARE = 0x3ec;
static const Word lxDEFINE = 0x3ed;
static const Word lxDISCONNECT = 0x3ee;
static const Word lxEND = 0x3ef;
static const Word lxEXIT = 0x3f0;
static const Word lxEXPLAIN = 0x3f1;
static const Word lxFUNCTION = 0x3f2;
static const Word lxJAVA = 0x3f3;
static const Word lxPACKAGE = 0x3f4;
static const Word lxPARTITION = 0x3f5;
static const Word lxPAUSE = 0x3f6;
static const Word lxPROCEDURE = 0x3f7;
static const Word lxPROMPT = 0x3f8;
static const Word lxQUIT = 0x3f9;
static const Word lxREM = 0x3fa;
static const Word lxREMARK = 0x3fb;
static const Word lxREPLACE = 0x3fc;
static const Word lxSTART = 0x3fd;
static const Word lxTRIGGER = 0x3fe;
static const Word lxTYPE = 0x3ff;
static const Word lxUNDEFINE = 0x400;
static const Word lxUNIQUE = 0x401;
static const Word lxWITH = 0x402;
static const Word lxWRAPPED = 0x403;

}	/* namespace Oraparser */
using namespace Oraparser;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraparserHPP
