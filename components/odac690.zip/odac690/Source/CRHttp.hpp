// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crhttp.pas' rev: 21.00

#ifndef CrhttpHPP
#define CrhttpHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crdatabuffer.hpp>	// Pascal unit
#include <Crbase64.hpp>	// Pascal unit
#include <Crviotcp.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crhttp
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum HttpMethod { hmGET, hmOPTIONS, hmHEAD, hmPOST, hmPUT, hmTRACE };
#pragma option pop

class DELPHICLASS THeaderInfo;
class PASCALIMPLEMENTATION THeaderInfo : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FLocalAddress;
	System::UnicodeString FLocalProgram;
	System::UnicodeString FCookie;
	System::UnicodeString FReferer;
	System::UnicodeString FUserId;
	System::UnicodeString FPassword;
	System::UnicodeString FProxyUserId;
	System::UnicodeString FProxyPassword;
	
public:
	__property System::UnicodeString LocalMailAddress = {read=FLocalAddress, write=FLocalAddress};
	__property System::UnicodeString LocalProgram = {read=FLocalProgram, write=FLocalProgram};
	__property System::UnicodeString Cookie = {read=FCookie, write=FCookie};
	__property System::UnicodeString Referer = {read=FReferer, write=FReferer};
	__property System::UnicodeString UserId = {read=FUserId, write=FUserId};
	__property System::UnicodeString Password = {read=FPassword, write=FPassword};
	__property System::UnicodeString ProxyUserId = {read=FProxyUserId, write=FProxyUserId};
	__property System::UnicodeString ProxyPassword = {read=FProxyPassword, write=FProxyPassword};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~THeaderInfo(void) { }
	
public:
	/* TObject.Create */ inline __fastcall THeaderInfo(void) : Classes::TPersistent() { }
	
};


class DELPHICLASS TCRHttp;
class PASCALIMPLEMENTATION TCRHttp : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FHeader;
	System::UnicodeString FLocation;
	System::UnicodeString FCookieIn;
	System::AnsiString FSendData;
	System::UnicodeString FURL;
	HttpMethod FRequestMethod;
	Classes::TStringList* FSendHeader;
	THeaderInfo* FHeaderInfo;
	System::UnicodeString FScheme;
	System::UnicodeString FUser;
	System::UnicodeString FPassword;
	System::UnicodeString FNetworkLocation;
	System::UnicodeString FPort;
	System::UnicodeString FQuery;
	System::UnicodeString FResource;
	System::UnicodeString FParameters;
	System::UnicodeString FPath;
	System::UnicodeString FFragment;
	short FReplyNumber;
	int FBytesTotal;
	Crviotcp::TCRVioTcp* FVioTcp;
	int FTimeout;
	int FPortNo;
	System::UnicodeString FProxy;
	int FProxyPort;
	Crdatabuffer::TDataBuffer* FReadDataBuffer;
	Crdatabuffer::TDataBuffer* FWriteDataBuffer;
	Sysutils::TBytes FBuffer;
	bool FKeepAlive;
	Classes::TNotifyEvent FOnAuthenticationNeeded;
	System::UnicodeString __fastcall GetToEnd(const System::WideChar FindChar, System::UnicodeString &ParseString, const bool KeepFirst);
	System::UnicodeString __fastcall ParseFragment(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseScheme(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseNetworkLocation(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseQuery(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseParameters(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseResource(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParsePath(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParsePassword(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParseUserPassword(System::UnicodeString &ParseString);
	System::UnicodeString __fastcall ParsePort(System::UnicodeString &ParseString);
	void __fastcall ParseURL(const System::UnicodeString URL, System::UnicodeString &FScheme, System::UnicodeString &FUser, System::UnicodeString &FPassword, System::UnicodeString &FNetworkLocation, System::UnicodeString &FPort, System::UnicodeString &FPath, System::UnicodeString &FResource, System::UnicodeString &FParameters, System::UnicodeString &FQuery, System::UnicodeString &FFragment);
	
protected:
	int __fastcall GetTimeout(void);
	void __fastcall SetTimeout(int Value);
	void __fastcall HTTPConnect(void);
	void __fastcall SetHTTPHeaders(void);
	void __fastcall RetrieveHeaders(void);
	void __fastcall SendHTTPRequest(void);
	
public:
	__fastcall TCRHttp(const System::UnicodeString URL);
	__fastcall virtual ~TCRHttp(void);
	void __fastcall Get(const System::UnicodeString URL)/* overload */;
	void __fastcall Get(void)/* overload */;
	void __fastcall Post(const System::UnicodeString URL, const System::AnsiString PostData)/* overload */;
	void __fastcall Post(void)/* overload */;
	void __fastcall Head(const System::UnicodeString URL);
	void __fastcall Options(const System::UnicodeString URL);
	void __fastcall Put(const System::UnicodeString URL, const System::AnsiString PutData);
	void __fastcall Trace(const System::UnicodeString URL, const System::AnsiString TraceData);
	void __fastcall Disconnect(void);
	System::UnicodeString __fastcall ReadLine(void);
	int __fastcall Read(const Sysutils::TBytes Buffer, int Offset, int Count);
	bool __fastcall WaitForData(int Timeout = 0xffffffff);
	__property System::UnicodeString CookieIn = {read=FCookieIn};
	__property short ReplyNumber = {read=FReplyNumber, nodefault};
	__property int BytesTotal = {read=FBytesTotal, nodefault};
	__property System::UnicodeString Header = {read=FHeader, write=FHeader};
	__property THeaderInfo* HeaderInfo = {read=FHeaderInfo, write=FHeaderInfo};
	__property Crdatabuffer::TDataBuffer* WriteData = {read=FWriteDataBuffer};
	__property System::UnicodeString Proxy = {read=FProxy, write=FProxy};
	__property int ProxyPort = {read=FProxyPort, write=FProxyPort, nodefault};
	__property bool KeepAlive = {read=FKeepAlive, write=FKeepAlive, nodefault};
	__property int Timeout = {read=GetTimeout, write=SetTimeout, nodefault};
	__property Classes::TNotifyEvent OnAuthenticationNeeded = {read=FOnAuthenticationNeeded, write=FOnAuthenticationNeeded};
};


class DELPHICLASS HttpException;
class PASCALIMPLEMENTATION HttpException : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall HttpException(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall HttpException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall HttpException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall HttpException(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall HttpException(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall HttpException(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall HttpException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall HttpException(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~HttpException(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
#define Prtcl_http L" HTTP/1.0"
#define Prox_Head L"Proxy-Connection: Keep-Alive"
#define Prox_Host L"Host: "
#define Prox_Port L"Port: "
#define Host_Accept1 L"Accept: www/source, text/html, video/mpeg, image/jpeg, ima"\
	L"ge/x-tiff"
#define Host_Accept2 L"Accept: image/x-rgb, image/x-xbm, image/gif, */*, applicat"\
	L"ion/postscript"
#define Host_UserAgent L"User-Agent"
#define Head_From L"From"
#define Head_Host L"Host"
#define Head_Cookie L"Cookie"
#define Head_Referer L"Referer"
#define Head_Content L"Content-type: application/x-www-form-urlencoded"
#define Head_ContentLength L"Content-Length: "
#define Head_SetCookie L"SET-COOKIE:"
#define Head_ContentLength2 L"CONTENT-LENGTH:"
#define Head_Location L"LOCATION:"
#define CRLF L"\r\n"
static const int BUF_SIZE = 0x10000;
extern PACKAGE System::UnicodeString __fastcall NthWord(const System::UnicodeString InputString, const System::WideChar Delimiter, int Number);
extern PACKAGE int __fastcall WordsCount(const System::UnicodeString InputString, const System::WideChar Delimiter);

}	/* namespace Crhttp */
using namespace Crhttp;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrhttpHPP
