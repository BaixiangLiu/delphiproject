// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraerror.pas' rev: 21.00

#ifndef OraerrorHPP
#define OraerrorHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraerror
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS EOraError;
class PASCALIMPLEMENTATION EOraError : public Dbaccess::EDAError
{
	typedef Dbaccess::EDAError inherited;
	
private:
	Classes::TComponent* FSender;
	
public:
	__fastcall EOraError(int ErrorCode, System::UnicodeString Msg, System::TObject* Component);
	__fastcall virtual ~EOraError(void);
	virtual bool __fastcall IsFatalError(void);
	virtual bool __fastcall IsKeyViolation(void);
	__property Classes::TComponent* Sender = {read=FSender, write=FSender};
public:
	/* Exception.CreateFmt */ inline __fastcall EOraError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Dbaccess::EDAError(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EOraError(int Ident)/* overload */ : Dbaccess::EDAError(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EOraError(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Dbaccess::EDAError(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EOraError(const System::UnicodeString Msg, int AHelpContext) : Dbaccess::EDAError(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EOraError(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Dbaccess::EDAError(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EOraError(int Ident, int AHelpContext)/* overload */ : Dbaccess::EDAError(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EOraError(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Dbaccess::EDAError(ResStringRec, Args, Args_Size, AHelpContext) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt erKeyViol = 0x0;
static const ShortInt erRequiredFieldMissing = 0x1;
static const ShortInt erCheck = 0x2;
static const ShortInt erLockRecord = -54;
static const short erParentKeyNotFound = -2291;
static const short erChildRecordCount = -2292;
extern PACKAGE void __fastcall RaiseError(System::UnicodeString Msg);
extern PACKAGE void __fastcall RaiseOraError(int ErrorCode, System::UnicodeString Msg);

}	/* namespace Oraerror */
using namespace Oraerror;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraerrorHPP
