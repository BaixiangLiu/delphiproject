// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Bdesession.pas' rev: 21.00

#ifndef BdesessionHPP
#define BdesessionHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Dbtables.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Bdesession
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TBDESession;
class PASCALIMPLEMENTATION TBDESession : public Ora::TOraSession
{
	typedef Ora::TOraSession inherited;
	
private:
	void *Handle;
	Dbtables::TDBDataSet* DS;
	bool FStreamedConnected;
	Dbtables::TDatabase* __fastcall GetDatabase(void);
	System::UnicodeString __fastcall GetDatabaseName(void);
	void __fastcall SetDatabaseName(const System::UnicodeString Value);
	System::UnicodeString __fastcall GetSessionName(void);
	void __fastcall SetSessionName(const System::UnicodeString Value);
	
protected:
	Oraclasses::TOCIConnection* FIConnection;
	virtual void __fastcall SetIConnection(Craccess::TCRConnection* Value);
	virtual void __fastcall DoConnect(void);
	virtual void __fastcall DoDisconnect(void);
	__property PoolingOptions;
	__property Pooling = {default=0};
	
public:
	__fastcall virtual TBDESession(Classes::TComponent* Owner);
	__fastcall virtual ~TBDESession(void);
	__property Dbtables::TDatabase* Database = {read=GetDatabase};
	
__published:
	__property System::UnicodeString DatabaseName = {read=GetDatabaseName, write=SetDatabaseName};
	__property System::UnicodeString SessionName = {read=GetSessionName, write=SetSessionName};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Bdesession */
using namespace Bdesession;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// BdesessionHPP
