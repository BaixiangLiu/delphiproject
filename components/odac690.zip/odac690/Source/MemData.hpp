// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Memdata.pas' rev: 21.00

#ifndef MemdataHPP
#define MemdataHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Ansistrings.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Memdata
{
//-- type declarations -------------------------------------------------------
typedef System::Word TDataType;

#pragma option push -b-
enum TDANumericType { ntFloat, ntBCD, ntFmtBCD };
#pragma option pop

#pragma option push -b-
enum TConnLostCause { clUnknown, clExecute, clOpen, clRefresh, clApply, clServiceQuery, clTransStart, clConnectionApply, clConnect };
#pragma option pop

struct TBlockHeader;
typedef TBlockHeader *PBlockHeader;

#pragma pack(push,1)
struct TBlockHeader
{
	
public:
	System::Word ItemCount;
	System::Word UsedItems;
	TBlockHeader *Prev;
	TBlockHeader *Next;
	System::Byte Test;
};
#pragma pack(pop)


#pragma option push -b-
enum TItemStatus { isUnmodified, isUpdated, isAppended, isDeleted };
#pragma option pop

typedef Set<TItemStatus, isUnmodified, isDeleted>  TItemTypes;

#pragma option push -b-
enum TUpdateRecAction { urFail, urAbort, urSkip, urRetry, urApplied, urNone, urSuspended };
#pragma option pop

#pragma option push -b-
enum TItemFilterState { fsNotChecked, fsNotOmitted, fsOmitted };
#pragma option pop

struct TItemHeader;
typedef TItemHeader *PItemHeader;

#pragma pack(push,1)
struct TItemHeader
{
	
public:
	TBlockHeader *Block;
	TItemHeader *Prev;
	TItemHeader *Next;
	TItemHeader *Rollback;
	TItemStatus Status;
	TUpdateRecAction UpdateResult;
	int Order;
	System::Byte Flag;
	TItemFilterState FilterResult;
	System::Byte AlignByte;
};
#pragma pack(pop)


class DELPHICLASS TBlockManager;
class PASCALIMPLEMENTATION TBlockManager : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TItemHeader *FirstFree;
	TBlockHeader *FirstBlock;
	int RecordSize;
	System::Word DefaultItemCount;
	__fastcall TBlockManager(void);
	__fastcall virtual ~TBlockManager(void);
	void __fastcall AllocBlock(PBlockHeader &Block, System::Word ItemCount);
	void __fastcall FreeBlock(PBlockHeader Block);
	void __fastcall AddFreeBlock(void);
	void __fastcall FreeAllBlock(void);
	void __fastcall AllocItem(PItemHeader &Item);
	void __fastcall FreeItem(PItemHeader Item);
	void __fastcall InitItem(PItemHeader Item);
	void __fastcall PutRecord(PItemHeader Item, void * Rec);
	void __fastcall GetRecord(PItemHeader Item, void * Rec);
	void * __fastcall GetRecordPtr(PItemHeader Item);
	void __fastcall CopyRecord(PItemHeader ItemSrc, PItemHeader ItemDest);
};


struct TBlock;
typedef TBlock *PBlock;

typedef StaticArray<System::Byte, 16380> TStrData;

#pragma pack(push,1)
struct TBlock
{
	
public:
	TBlock *Next;
	TStrData Data;
};
#pragma pack(pop)


typedef StaticArray<void *, 250> TSmallTab;

class DELPHICLASS TStringHeap;
class PASCALIMPLEMENTATION TStringHeap : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TSmallTab FSmallTab;
	int FFree;
	TBlock *FRoot;
	bool FEmpty;
	bool FSysGetMem;
	bool FUseSysMemSize;
	bool FThreadSafety;
	Syncobjs::TCriticalSection* FThreadSafetyCS;
	void __fastcall SetThreadSafety(const bool Value);
	bool __fastcall UseSmallTabs(int divSize);
	
public:
	__fastcall TStringHeap(void);
	__fastcall virtual ~TStringHeap(void);
	void * __fastcall NewBuf(int Size);
	void * __fastcall AllocStr(void * Str, bool Trim = false, int Len = 0xffffffff);
	void * __fastcall AllocWideStr(void * Str, bool Trim = false, int Len = 0xffffffff);
	void * __fastcall ReAllocStr(void * Str, bool Trim = false);
	void * __fastcall ReAllocWideStr(void * Str, bool Trim = false);
	void __fastcall DisposeBuf(void * Buf);
	void __fastcall AddRef(void * Buf);
	void __fastcall Clear(void);
	__property bool Empty = {read=FEmpty, nodefault};
	__property bool SysGetMem = {read=FSysGetMem, nodefault};
	__property bool ThreadSafety = {read=FThreadSafety, write=SetThreadSafety, nodefault};
};


typedef Set<System::Byte, 0, 255>  TFieldTypeSet;

#pragma option push -b-
enum TDateFormat { dfMSecs, dfDateTime, dfTime, dfDate };
#pragma option pop

#pragma option push -b-
enum TFieldDescKind { fdkData, fdkCached, fdkCalculated };
#pragma option pop

class DELPHICLASS TFieldDesc;
class DELPHICLASS TObjectType;
class PASCALIMPLEMENTATION TFieldDesc : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	System::UnicodeString FName;
	System::UnicodeString FActualName;
	System::Word FDataType;
	System::Word FSubDataType;
	System::Word FLength;
	System::Word FScale;
	System::Word FFieldNo;
	System::Word FActualFieldNo;
	System::Word FSize;
	int FOffset;
	int FDataOffset;
	bool FRequired;
	bool FReadOnly;
	bool FIsKey;
	bool FFixed;
	bool FHidden;
	TObjectType* FObjectType;
	TFieldDesc* FParentField;
	bool FHiddenObject;
	void *FHandle;
	bool FReserved;
	TFieldDescKind FFieldDescKind;
	void __fastcall SetObjectType(TObjectType* Value);
	
public:
	__fastcall virtual TFieldDesc(void);
	__fastcall virtual ~TFieldDesc(void);
	bool __fastcall HasParent(void);
	void __fastcall Assign(TFieldDesc* FieldDesc);
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::UnicodeString ActualName = {read=FActualName, write=FActualName};
	__property System::Word DataType = {read=FDataType, write=FDataType, nodefault};
	__property System::Word SubDataType = {read=FSubDataType, write=FSubDataType, nodefault};
	__property System::Word Length = {read=FLength, write=FLength, nodefault};
	__property System::Word Scale = {read=FScale, write=FScale, nodefault};
	__property System::Word FieldNo = {read=FFieldNo, write=FFieldNo, nodefault};
	__property System::Word ActualFieldNo = {read=FActualFieldNo, write=FActualFieldNo, nodefault};
	__property System::Word Size = {read=FSize, write=FSize, nodefault};
	__property int Offset = {read=FOffset, write=FOffset, nodefault};
	__property int DataOffset = {read=FDataOffset, write=FDataOffset, nodefault};
	__property bool Required = {read=FRequired, write=FRequired, nodefault};
	__property bool ReadOnly = {read=FReadOnly, write=FReadOnly, nodefault};
	__property bool IsKey = {read=FIsKey, write=FIsKey, nodefault};
	__property bool Fixed = {read=FFixed, write=FFixed, nodefault};
	__property bool Hidden = {read=FHidden, write=FHidden, nodefault};
	__property TObjectType* ObjectType = {read=FObjectType, write=SetObjectType};
	__property TFieldDesc* ParentField = {read=FParentField, write=FParentField};
	__property bool HiddenObject = {read=FHiddenObject, write=FHiddenObject, nodefault};
	__property void * Handle = {read=FHandle, write=FHandle};
	__property TFieldDescKind FieldDescKind = {read=FFieldDescKind, write=FFieldDescKind, nodefault};
};


typedef TMetaClass* TFieldDescClass;

class DELPHICLASS TFieldDescs;
class PASCALIMPLEMENTATION TFieldDescs : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TFieldDesc* operator[](int Index) { return Items[Index]; }
	
private:
	TFieldDesc* __fastcall GetItems(int Index);
	
public:
	__fastcall virtual ~TFieldDescs(void);
	virtual void __fastcall Clear(void);
	TFieldDesc* __fastcall FindField(System::UnicodeString Name);
	TFieldDesc* __fastcall FieldByName(System::UnicodeString Name);
	__property TFieldDesc* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TObject.Create */ inline __fastcall TFieldDescs(void) : Classes::TList() { }
	
};


class DELPHICLASS TSharedObject;
class PASCALIMPLEMENTATION TSharedObject : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	int FRefCount;
	void *FGCHandle;
	void * __fastcall GetGCHandle(void);
	
public:
	__fastcall TSharedObject(void);
	__fastcall virtual ~TSharedObject(void);
	HIDESBASE void __fastcall Free(void);
	void __fastcall CheckValid(void);
	void __fastcall AddRef(void);
	void __fastcall Release(void);
	virtual void __fastcall Disconnect(void);
	__property int RefCount = {read=FRefCount, nodefault};
	__property void * GCHandle = {read=GetGCHandle};
};


class DELPHICLASS TAttribute;
class PASCALIMPLEMENTATION TAttribute : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FName;
	System::Word FDataType;
	System::Word FSubDataType;
	System::Word FLength;
	System::Word FScale;
	System::Word FSize;
	System::Word FDataSize;
	System::Word FOffset;
	System::Word FIndicatorOffset;
	System::Word FAttributeNo;
	TObjectType* FObjectType;
	TObjectType* FOwner;
	bool FFixed;
	void __fastcall SetObjectType(TObjectType* Value);
	
public:
	__fastcall TAttribute(void);
	__fastcall virtual ~TAttribute(void);
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::Word DataType = {read=FDataType, write=FDataType, nodefault};
	__property System::Word SubDataType = {read=FSubDataType, write=FSubDataType, nodefault};
	__property bool Fixed = {read=FFixed, write=FFixed, nodefault};
	__property System::Word Length = {read=FLength, write=FLength, nodefault};
	__property System::Word Scale = {read=FScale, write=FScale, nodefault};
	__property System::Word Size = {read=FSize, write=FSize, nodefault};
	__property System::Word DataSize = {read=FDataSize, write=FDataSize, nodefault};
	__property System::Word Offset = {read=FOffset, write=FOffset, nodefault};
	__property System::Word IndicatorOffset = {read=FIndicatorOffset, write=FIndicatorOffset, nodefault};
	__property System::Word AttributeNo = {read=FAttributeNo, write=FAttributeNo, nodefault};
	__property TObjectType* ObjectType = {read=FObjectType, write=SetObjectType};
	__property TObjectType* Owner = {read=FOwner, write=FOwner};
};


class PASCALIMPLEMENTATION TObjectType : public TSharedObject
{
	typedef TSharedObject inherited;
	
private:
	TAttribute* __fastcall GetAttributes(int Index);
	int __fastcall GetAttributeCount(void);
	
protected:
	System::UnicodeString FName;
	System::Word FDataType;
	int FSize;
	Classes::TList* FAttributes;
	void __fastcall ClearAttributes(void);
	
public:
	__fastcall TObjectType(void);
	__fastcall virtual ~TObjectType(void);
	TAttribute* __fastcall FindAttribute(System::UnicodeString Name);
	TAttribute* __fastcall AttributeByName(System::UnicodeString Name);
	__property System::UnicodeString Name = {read=FName};
	__property System::Word DataType = {read=FDataType, nodefault};
	__property int Size = {read=FSize, nodefault};
	__property int AttributeCount = {read=GetAttributeCount, nodefault};
	__property TAttribute* Attributes[int Index] = {read=GetAttributes};
};


class DELPHICLASS TDBObject;
class PASCALIMPLEMENTATION TDBObject : public TSharedObject
{
	typedef TSharedObject inherited;
	
private:
	TObjectType* FObjectType;
	
protected:
	void __fastcall SetObjectType(TObjectType* Value);
	virtual void __fastcall GetAttributeValue(const System::UnicodeString Name, void * &AttrBuf, bool &IsBlank, bool &NativeBuffer);
	virtual void __fastcall SetAttributeValue(const System::UnicodeString Name, void * Source);
	virtual bool __fastcall GetAttrIsNull(const System::UnicodeString Name);
	
public:
	__fastcall TDBObject(void);
	__property TObjectType* ObjectType = {read=FObjectType};
public:
	/* TSharedObject.Destroy */ inline __fastcall virtual ~TDBObject(void) { }
	
};


class DELPHICLASS TCacheItem;
class PASCALIMPLEMENTATION TCacheItem : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TItemHeader *Item;
	TCacheItem* Next;
public:
	/* TObject.Create */ inline __fastcall TCacheItem(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCacheItem(void) { }
	
};


struct TRecBookmark;
typedef TRecBookmark *PRecBookmark;

struct TRecBookmark
{
	
public:
	int RefreshIteration;
	TItemHeader *Item;
	int Order;
};


typedef bool __fastcall (__closure *TFilterFunc)(void * RecBuf);

class DELPHICLASS TBoolParser;
class PASCALIMPLEMENTATION TBoolParser : public Crparser::TParser
{
	typedef Crparser::TParser inherited;
	
protected:
	virtual void __fastcall ToRightQuote(System::WideChar LeftQuote);
	
public:
	__fastcall virtual TBoolParser(const System::UnicodeString Text)/* overload */;
public:
	/* TParser.Destroy */ inline __fastcall virtual ~TBoolParser(void) { }
	
};


#pragma option push -b-
enum TExpressionType { ntEqual, ntMore, ntLess, ntMoreEqual, ntLessEqual, ntNoEqual, ntAnd, ntOr, ntNot, ntField, ntValue, ntTrue, ntFalse, ntLike, ntNotLike };
#pragma option pop

class DELPHICLASS TExpressionNode;
class PASCALIMPLEMENTATION TExpressionNode : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TExpressionNode* NextAlloc;
	TExpressionType NodeType;
	TExpressionNode* LeftOperand;
	TExpressionNode* RightOperand;
	TExpressionNode* NextOperand;
	TFieldDesc* FieldDesc;
	System::Variant Value;
public:
	/* TObject.Create */ inline __fastcall TExpressionNode(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TExpressionNode(void) { }
	
};


#pragma option push -b-
enum TUpdateRecKind { ukUpdate, ukInsert, ukDelete };
#pragma option pop

typedef void __fastcall (__closure *TOnModifyRecord)(void);

typedef void __fastcall (__closure *TOnApplyRecord)(TUpdateRecKind UpdateKind, TUpdateRecAction &Action, bool LastItem);

typedef void __fastcall (__closure *TOnGetCachedFields)(void);

typedef void __fastcall (__closure *TOnGetCachedBuffer)(void * Buffer, void * Source = (void *)(0x0));

class DELPHICLASS TData;
class PASCALIMPLEMENTATION TData : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	int FRecordSize;
	int FCalcRecordSize;
	bool FCachedUpdates;
	TOnModifyRecord FOnAppend;
	TOnModifyRecord FOnDelete;
	TOnModifyRecord FOnUpdate;
	TOnApplyRecord FOnApplyRecord;
	bool FAutoInitFields;
	bool FTrimFixedChar;
	bool FTrimVarChar;
	TFilterFunc FFilterFunc;
	TFilterFunc FFilterMDFunc;
	System::UnicodeString FFilterText;
	bool FFilterCaseInsensitive;
	bool FFilterNoPartialCompare;
	TItemTypes FFilterItemTypes;
	TBoolParser* Parser;
	int Code;
	System::UnicodeString StrLexem;
	TExpressionNode* FilterExpression;
	TExpressionNode* FirstAlloc;
	void *FilterRecBuf;
	bool FEnableEmptyStrings;
	bool FHasComplexFields;
	bool FSparseArrays;
	TOnGetCachedFields FOnGetCachedFields;
	TOnGetCachedBuffer FOnGetCachedBuffer;
	void __fastcall FilterError(void);
	TExpressionNode* __fastcall AllocNode(void);
	TExpressionNode* __fastcall OrExpr(void);
	TExpressionNode* __fastcall AndExpr(void);
	TExpressionNode* __fastcall Condition(void);
	TExpressionNode* __fastcall Argument(void);
	void __fastcall CreateFilterExpression(System::UnicodeString Text);
	void __fastcall FreeFilterExpression(void);
	bool __fastcall Eval(TExpressionNode* Node);
	System::Word __fastcall GetFieldCount(void);
	void __fastcall SetCachedUpdates(bool Value);
	
protected:
	int FRecordNoOffset;
	int FRecordCount;
	bool FBOF;
	bool FEOF;
	int DataSize;
	int CalcDataSize;
	TFieldDescs* FFields;
	TStringHeap* StringHeap;
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalUnPrepare(void);
	virtual void __fastcall InternalOpen(bool DisableInitFields = false);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall InitData(void);
	virtual void __fastcall FreeData(void);
	virtual void __fastcall InternalInitFields(void);
	void __fastcall InitObjectFields(TObjectType* ObjectType, TFieldDesc* Parent);
	TSharedObject* __fastcall InternalGetObject(System::Word FieldNo, void * RecBuf);
	virtual System::UnicodeString __fastcall GetArrayFieldName(TObjectType* ObjectType, int ItemIndex);
	virtual System::Word __fastcall GetIndicatorSize(void);
	void __fastcall GetChildFieldInfo(TFieldDesc* Field, TFieldDesc* &RootField, System::UnicodeString &AttrName);
	void __fastcall GetChildField(TFieldDesc* Field, void * RecBuf, void * &AttrBuf, bool &IsBlank, bool &NativeBuffer);
	bool __fastcall GetChildFieldIsNull(TFieldDesc* Field, void * RecBuf);
	void __fastcall PutChildField(TFieldDesc* Field, void * RecBuf, void * Source);
	virtual bool __fastcall NeedConvertEOL(void);
	virtual bool __fastcall GetEOF(void);
	virtual bool __fastcall GetBOF(void);
	virtual int __fastcall GetRecordCount(void);
	virtual int __fastcall GetRecordNo(void);
	virtual void __fastcall SetRecordNo(int Value);
	virtual void __fastcall InternalAppend(void * RecBuf);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalUpdate(void * RecBuf);
	__property System::Word IndicatorSize = {read=GetIndicatorSize, nodefault};
	bool __fastcall Filtered(void);
	virtual void __fastcall SetFilterText(System::UnicodeString Value);
	virtual bool __fastcall GetUpdatesPending(void);
	virtual void __fastcall SetFilterItemTypes(TItemTypes Value);
	
public:
	bool Active;
	bool Prepared;
	void *NewCacheRecBuf;
	void *OldCacheRecBuf;
	__property System::Word FieldCount = {read=GetFieldCount, nodefault};
	__property TFieldDescs* Fields = {read=FFields};
	__property bool Bof = {read=GetBOF, nodefault};
	__property bool Eof = {read=GetEOF, nodefault};
	__fastcall TData(void);
	__fastcall virtual ~TData(void);
	virtual void __fastcall Open(void);
	virtual void __fastcall Close(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall UnPrepare(void);
	virtual bool __fastcall IsFullReopen(void);
	virtual void __fastcall Reopen(void);
	virtual TFieldDescClass __fastcall GetFieldDescType(void);
	virtual void __fastcall InitFields(void);
	virtual void __fastcall ExplicitInitFields(void);
	virtual void __fastcall ClearFields(void);
	virtual void __fastcall GetField(System::Word FieldNo, void * RecBuf, void * Dest, bool &IsBlank);
	virtual void __fastcall GetFieldData(TFieldDesc* Field, void * FieldBuf, void * Dest);
	void * __fastcall GetFieldBuf(void * RecBuf, TFieldDesc* FieldDesc, int &DataType, bool &IsBlank, bool &NativeBuffer);
	void __fastcall PutField(System::Word FieldNo, void * RecBuf, void * Source);
	virtual void __fastcall PutFieldData(TFieldDesc* Field, void * FieldBuf, void * Source);
	virtual bool __fastcall GetNull(System::Word FieldNo, void * RecBuf);
	virtual void __fastcall SetNull(System::Word FieldNo, void * RecBuf, bool Value);
	bool __fastcall GetNullByBlob(System::Word FieldNo, void * RecBuf);
	virtual void __fastcall GetFieldAsVariant(System::Word FieldNo, void * RecBuf, System::Variant &Value);
	virtual void __fastcall PutFieldAsVariant(System::Word FieldNo, void * RecBuf, const System::Variant &Value);
	virtual void __fastcall GetDateFromBuf(void * Buf, TFieldDesc* Field, void * Date, TDateFormat Format);
	virtual void __fastcall PutDateToBuf(void * Buf, TFieldDesc* Field, void * Date, TDateFormat Format);
	TFieldDesc* __fastcall FindField(System::UnicodeString Name);
	TFieldDesc* __fastcall FieldByName(System::UnicodeString Name);
	__classmethod virtual bool __fastcall IsBlobFieldType(System::Word DataType);
	__classmethod virtual bool __fastcall IsComplexFieldType(System::Word DataType);
	bool __fastcall HasFields(const TFieldTypeSet &FieldTypes);
	bool __fastcall HasBlobFields(void);
	bool __fastcall CheckHasComplexFields(void);
	void * __fastcall AllocRecBuf(void * &RecBuf);
	void __fastcall FreeRecBuf(void * RecBuf);
	void __fastcall InitRecord(void * RecBuf);
	virtual void __fastcall GetRecord(void * RecBuf) = 0 ;
	virtual void __fastcall GetNextRecord(void * RecBuf) = 0 ;
	virtual void __fastcall GetPriorRecord(void * RecBuf) = 0 ;
	virtual void __fastcall PutRecord(void * RecBuf) = 0 ;
	virtual void __fastcall AppendRecord(void * RecBuf) = 0 ;
	void __fastcall AppendBlankRecord(void);
	virtual void __fastcall InsertRecord(void * RecBuf) = 0 ;
	virtual void __fastcall UpdateRecord(void * RecBuf) = 0 ;
	virtual void __fastcall DeleteRecord(void) = 0 ;
	void __fastcall EditRecord(void * RecBuf);
	void __fastcall PostRecord(void * RecBuf);
	virtual void __fastcall CancelRecord(void * RecBuf);
	virtual void __fastcall CreateComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CreateComplexField(void * RecBuf, int FieldIndex, bool WithBlob);
	virtual void __fastcall FreeComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CopyComplexFields(void * Source, void * Dest, bool WithBlob);
	virtual void __fastcall AddRefComplexFields(void * RecBuf);
	virtual void __fastcall SetToBegin(void);
	virtual void __fastcall SetToEnd(void);
	virtual void __fastcall GetBookmark(PRecBookmark Bookmark);
	virtual void __fastcall SetToBookmark(PRecBookmark Bookmark);
	virtual bool __fastcall BookmarkValid(PRecBookmark Bookmark);
	virtual int __fastcall CompareBookmarks(PRecBookmark Bookmark1, PRecBookmark Bookmark2);
	virtual TItemStatus __fastcall GetUpdateStatus(void);
	virtual TUpdateRecAction __fastcall GetUpdateResult(void);
	virtual void __fastcall SetCacheRecBuf(void * NewBuf, void * OldBuf);
	virtual void __fastcall ApplyUpdates(void);
	virtual void __fastcall CommitUpdates(void);
	virtual void __fastcall CancelUpdates(void);
	virtual void __fastcall RestoreUpdates(void);
	virtual void __fastcall RevertRecord(void);
	virtual void __fastcall ApplyRecord(TUpdateRecKind UpdateKind, TUpdateRecAction &Action, bool LastItem);
	virtual void __fastcall GetOldRecord(void * RecBuf);
	virtual void __fastcall FilterUpdated(void);
	TSharedObject* __fastcall GetObject(System::Word FieldNo, void * RecBuf);
	void __fastcall SetObject(System::Word FieldNo, void * RecBuf, TSharedObject* Obj);
	int __fastcall ReadBlob(System::Word FieldNo, void * RecBuf, int Position, int Count, void * Dest, bool FromRollback = false, bool TrueUnicode = false);
	void __fastcall WriteBlob(System::Word FieldNo, void * RecBuf, int Position, int Count, void * Source, bool TrueUnicode = false);
	void __fastcall TruncateBlob(System::Word FieldNo, void * RecBuf, int Size, bool TrueUnicode = false);
	int __fastcall GetBlobSize(System::Word FieldNo, void * RecBuf, bool FromRollback = false, bool TrueUnicode = false);
	void __fastcall SetBlobSize(System::Word FieldNo, void * RecBuf, int NewSize, bool FromRollback = false, bool TrueUnicode = false);
	__property int RecordSize = {read=FRecordSize, nodefault};
	__property int CalcRecordSize = {read=FCalcRecordSize, nodefault};
	__property int RecordCount = {read=GetRecordCount, nodefault};
	__property int RecordNo = {read=GetRecordNo, write=SetRecordNo, nodefault};
	__property bool CachedUpdates = {read=FCachedUpdates, write=SetCachedUpdates, default=0};
	__property bool UpdatesPending = {read=GetUpdatesPending, nodefault};
	__property TFilterFunc FilterFunc = {read=FFilterFunc, write=FFilterFunc};
	__property TFilterFunc FilterMDFunc = {read=FFilterMDFunc, write=FFilterMDFunc};
	__property System::UnicodeString FilterText = {read=FFilterText, write=SetFilterText};
	__property bool FilterCaseInsensitive = {read=FFilterCaseInsensitive, write=FFilterCaseInsensitive, nodefault};
	__property bool FilterNoPartialCompare = {read=FFilterNoPartialCompare, write=FFilterNoPartialCompare, nodefault};
	__property TItemTypes FilterItemTypes = {read=FFilterItemTypes, write=SetFilterItemTypes, nodefault};
	__property bool AutoInitFields = {read=FAutoInitFields, write=FAutoInitFields, nodefault};
	__property bool TrimFixedChar = {read=FTrimFixedChar, write=FTrimFixedChar, nodefault};
	__property bool TrimVarChar = {read=FTrimVarChar, write=FTrimVarChar, nodefault};
	__property bool EnableEmptyStrings = {read=FEnableEmptyStrings, write=FEnableEmptyStrings, nodefault};
	__property bool SparseArrays = {read=FSparseArrays, write=FSparseArrays, nodefault};
	__property TOnModifyRecord OnAppend = {read=FOnAppend, write=FOnAppend};
	__property TOnModifyRecord OnDelete = {write=FOnDelete};
	__property TOnModifyRecord OnUpdate = {write=FOnUpdate};
	__property TOnApplyRecord OnApplyRecord = {write=FOnApplyRecord};
	__property TOnGetCachedFields OnGetCachedFields = {write=FOnGetCachedFields};
	__property TOnGetCachedBuffer OnGetCachedBuffer = {write=FOnGetCachedBuffer};
	__property bool HasComplexFields = {read=FHasComplexFields, write=FHasComplexFields, nodefault};
};


#pragma option push -b-
enum TReorderOption { roInsert, roDelete, roFull };
#pragma option pop

#pragma option push -b-
enum TSortType { stCaseSensitive, stCaseInsensitive, stBinary };
#pragma option pop

class DELPHICLASS TSortColumn;
class PASCALIMPLEMENTATION TSortColumn : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TFieldDesc* FieldDesc;
	bool DescendingOrder;
	TSortType SortType;
public:
	/* TObject.Create */ inline __fastcall TSortColumn(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TSortColumn(void) { }
	
};


class DELPHICLASS TSortColumns;
class PASCALIMPLEMENTATION TSortColumns : public Classes::TList
{
	typedef Classes::TList inherited;
	
public:
	TSortColumn* operator[](int Index) { return Items[Index]; }
	
private:
	TSortColumn* __fastcall GetItems(int Index);
	
public:
	__fastcall virtual ~TSortColumns(void);
	virtual void __fastcall Clear(void);
	__property TSortColumn* Items[int Index] = {read=GetItems/*, default*/};
public:
	/* TObject.Create */ inline __fastcall TSortColumns(void) : Classes::TList() { }
	
};


typedef DynamicArray<PItemHeader> TRecordNoCache;

#pragma option push -b-
enum TLocateExOption { lxCaseInsensitive, lxPartialKey, lxNearest, lxNext, lxUp, lxPartialCompare };
#pragma option pop

typedef Set<TLocateExOption, lxCaseInsensitive, lxPartialCompare>  TLocateExOptions;

#pragma option push -b-
enum TCompareOption { coCaseInsensitive, coPartialKey, coPartialCompare, coOrdinalCompare };
#pragma option pop

typedef Set<TCompareOption, coCaseInsensitive, coOrdinalCompare>  TCompareOptions;

class DELPHICLASS TMemData;
class PASCALIMPLEMENTATION TMemData : public TData
{
	typedef TData inherited;
	
private:
	TCacheItem* Cache;
	TCacheItem* LastCacheItem;
	int FRefreshIteration;
	System::UnicodeString FIndexFieldNames;
	TSortColumns* FIndexFields;
	TRecordNoCache FRecordNoCache;
	void __fastcall UpdateIndexFields(void);
	int __fastcall CompareRecords(void * RecBuf1, void * RecBuf2);
	void __fastcall Exchange(PItemHeader I, PItemHeader J);
	void __fastcall MoveSortedRecord(int Dir);
	void __fastcall QuickSort(PItemHeader L, PItemHeader R, PItemHeader P);
	void __fastcall RollbackItem(PItemHeader Item);
	
protected:
	TItemHeader *FirstItem;
	TItemHeader *LastItem;
	TItemHeader *CurrentItem;
	TBlockManager* BlockMan;
	PItemHeader __fastcall InsertItem(void);
	PItemHeader __fastcall AppendItem(void);
	void __fastcall DeleteItem(PItemHeader Item);
	void __fastcall RevertItem(PItemHeader Item);
	virtual void __fastcall InitData(void);
	virtual void __fastcall FreeData(void);
	void __fastcall ReorderItems(PItemHeader Item, TReorderOption ReorderOption);
	virtual bool __fastcall GetEOF(void);
	virtual bool __fastcall GetBOF(void);
	virtual int __fastcall GetRecordCount(void);
	virtual int __fastcall GetRecordNo(void);
	virtual void __fastcall SetRecordNo(int Value);
	virtual bool __fastcall Fetch(bool FetchBack = false);
	void __fastcall InitFetchedItems(void * FetchedItem, bool NoData, bool FetchBack);
	virtual void __fastcall SetSortDefaults(TSortColumn* SortColumn);
	virtual int __fastcall InternalAnsiStrComp(const void * Value1, const void * Value2, const TCompareOptions Options);
	virtual int __fastcall InternalAnsiCompareText(const System::AnsiString Value1, const System::AnsiString Value2, const TCompareOptions Options);
	virtual int __fastcall InternalWStrLComp(const System::WideString Value1, const System::WideString Value2, const TCompareOptions Options);
	virtual int __fastcall InternalWStrComp(const System::WideString Value1, const System::WideString Value2, const TCompareOptions Options);
	virtual int __fastcall CompareStrValues(const System::AnsiString Value, const System::AnsiString FieldValue, const TCompareOptions Options);
	virtual int __fastcall CompareWideStrValues(const System::WideString Value, const System::WideString FieldValue, const TCompareOptions Options);
	int __fastcall CompareBinValues(const void * Value, const int ValueLen, const void * FieldValue, const int FieldValueLen, const TCompareOptions Options);
	void __fastcall AddCacheItem(TCacheItem* CacheItem);
	virtual bool __fastcall GetUpdatesPending(void);
	virtual void __fastcall SetFilterItemTypes(TItemTypes Value);
	
public:
	__fastcall TMemData(void);
	__fastcall virtual ~TMemData(void);
	virtual void __fastcall Open(void);
	virtual void __fastcall Reopen(void);
	virtual void __fastcall InitFields(void);
	virtual void __fastcall ClearFields(void);
	virtual void __fastcall GetRecord(void * RecBuf);
	virtual void __fastcall GetNextRecord(void * RecBuf);
	virtual void __fastcall GetPriorRecord(void * RecBuf);
	virtual void __fastcall PutRecord(void * RecBuf);
	virtual void __fastcall AppendRecord(void * RecBuf);
	virtual void __fastcall InsertRecord(void * RecBuf);
	virtual void __fastcall UpdateRecord(void * RecBuf);
	virtual void __fastcall DeleteRecord(void);
	void __fastcall AddRecord(void * RecBuf);
	void __fastcall RemoveRecord(void);
	bool __fastcall OmitRecord(PItemHeader Item);
	void __fastcall UpdateCachedBuffer(PItemHeader FItem, PItemHeader LItem);
	virtual void __fastcall SetToBegin(void);
	virtual void __fastcall SetToEnd(void);
	void __fastcall PrepareRecNoCache(void);
	virtual void __fastcall GetBookmark(PRecBookmark Bookmark);
	virtual void __fastcall SetToBookmark(PRecBookmark Bookmark);
	virtual bool __fastcall BookmarkValid(PRecBookmark Bookmark);
	virtual int __fastcall CompareBookmarks(PRecBookmark Bookmark1, PRecBookmark Bookmark2);
	virtual TItemStatus __fastcall GetUpdateStatus(void);
	virtual TUpdateRecAction __fastcall GetUpdateResult(void);
	virtual void __fastcall SetCacheRecBuf(void * NewBuf, void * OldBuf);
	virtual void __fastcall ApplyUpdates(void);
	virtual void __fastcall CommitUpdates(void);
	virtual void __fastcall CancelUpdates(void);
	virtual void __fastcall RestoreUpdates(void);
	virtual void __fastcall RevertRecord(void);
	virtual void __fastcall GetOldRecord(void * RecBuf);
	virtual int __fastcall CompareFieldValue(void * ValuePtr, const int ValueType, TFieldDesc* FieldDesc, void * RecBuf, const TCompareOptions Options);
	virtual int __fastcall CompareFields(void * RecBuf1, void * RecBuf2, TSortColumn* SortColumn)/* overload */;
	virtual int __fastcall CompareFields(void * RecBuf1, void * RecBuf2, TFieldDesc* FieldDesc, TCompareOptions Options = TCompareOptions() )/* overload */;
	virtual void __fastcall FilterUpdated(void);
	void __fastcall ClearItemsOmittedStatus(void);
	virtual void __fastcall SetIndexFieldNames(System::UnicodeString Value);
	virtual void __fastcall SortItems(void);
	__property TSortColumns* IndexFields = {read=FIndexFields};
};


struct TPieceHeader;
typedef TPieceHeader *PPieceHeader;

#pragma pack(push,1)
struct TPieceHeader
{
	
public:
	int Blob;
	unsigned Size;
	unsigned Used;
	TPieceHeader *Prev;
	TPieceHeader *Next;
	System::Word Test;
};
#pragma pack(pop)


class DELPHICLASS TCRBlobData;
class PASCALIMPLEMENTATION TCRBlobData : public TSharedObject
{
	typedef TSharedObject inherited;
	
private:
	TPieceHeader *FFirstPiece;
	unsigned FPieceSize;
	
public:
	__fastcall TCRBlobData(void);
	__fastcall virtual ~TCRBlobData(void);
	__classmethod void __fastcall AllocPiece(PPieceHeader &Piece, unsigned Size);
	void __fastcall ReallocPiece(PPieceHeader &Piece, unsigned Size);
	void __fastcall FreePiece(PPieceHeader Piece);
	void __fastcall AppendPiece(PPieceHeader Piece);
	void __fastcall DeletePiece(PPieceHeader Piece);
	void __fastcall CompressPiece(PPieceHeader &Piece);
	unsigned __fastcall GetDataSize(void);
	virtual unsigned __fastcall GetSize(void);
	virtual void __fastcall SetSize(unsigned Value);
	virtual void __fastcall Clear(void);
	virtual void __fastcall Truncate(unsigned NewSize);
	virtual unsigned __fastcall Read(unsigned Position, unsigned Count, void * Dest);
	virtual void __fastcall Write(unsigned Position, unsigned Count, void * Source);
	void __fastcall Compress(void);
	void __fastcall Defrag(void);
	void __fastcall CopyTo(TCRBlobData* Dest);
	void __fastcall AddCRUnicode(void);
	void __fastcall RemoveCRUnicode(void);
	void __fastcall AddCRString(void);
	void __fastcall RemoveCRString(void);
	int __fastcall TranslatePosition(int Position);
	int __fastcall GetSizeAnsi(void);
};


class DELPHICLASS TBlob;
class PASCALIMPLEMENTATION TBlob : public TSharedObject
{
	typedef TSharedObject inherited;
	
protected:
	TCRBlobData* FData;
	bool FIsUnicode;
	bool FNeedRollback;
	TCRBlobData* FRollback;
	TCRBlobData* FStoredData;
	System::UnicodeString __fastcall GetAsString(void);
	void __fastcall SetAsString(const System::UnicodeString Value);
	System::AnsiString __fastcall GetAsAnsiString(void);
	void __fastcall SetAsAnsiString(const System::AnsiString Value);
	System::WideString __fastcall GetAsWideString(void);
	void __fastcall SetAsWideString(const System::WideString Value);
	Sysutils::TBytes __fastcall GetAsBytes(void);
	void __fastcall SetAsBytes(const Sysutils::TBytes Value);
	unsigned __fastcall GetPieceSize(void);
	void __fastcall SetPieceSize(unsigned Value);
	bool __fastcall GetUseRollback(void);
	void __fastcall SetUseRollback(bool Value);
	virtual TCRBlobData* __fastcall CreateBlobData(void);
	HIDESBASE void __fastcall CheckValid(void);
	void __fastcall CheckCached(void);
	virtual void __fastcall CheckValue(void);
	virtual void __fastcall SaveToRollback(void);
	virtual unsigned __fastcall GetSize(void);
	virtual void __fastcall SetSize(unsigned Value);
	virtual void __fastcall SetIsUnicode(bool Value);
	int __fastcall TranslatePosition(int Position);
	virtual int __fastcall GetSizeAnsi(void);
	__property bool UseRollback = {read=GetUseRollback, write=SetUseRollback, nodefault};
	
public:
	System::Byte Test;
	__fastcall TBlob(bool IsUnicode);
	__fastcall virtual ~TBlob(void);
	virtual void __fastcall FreeBlob(void);
	__classmethod void __fastcall AllocPiece(PPieceHeader &Piece, unsigned Size);
	void __fastcall ReallocPiece(PPieceHeader &Piece, unsigned Size);
	void __fastcall FreePiece(PPieceHeader Piece);
	void __fastcall AppendPiece(PPieceHeader Piece);
	void __fastcall DeletePiece(PPieceHeader Piece);
	void __fastcall CompressPiece(PPieceHeader &Piece);
	PPieceHeader __fastcall FirstPiece(void);
	virtual unsigned __fastcall Read(unsigned Position, unsigned Count, void * Dest);
	virtual void __fastcall Write(unsigned Position, unsigned Count, void * Source);
	virtual void __fastcall Clear(void);
	virtual void __fastcall Truncate(unsigned NewSize);
	void __fastcall Compress(void);
	virtual void __fastcall Defrag(void);
	void __fastcall AddCR(void);
	void __fastcall RemoveCR(void);
	virtual void __fastcall LoadFromStream(Classes::TStream* Stream);
	virtual void __fastcall SaveToStream(Classes::TStream* Stream);
	void __fastcall LoadFromFile(const System::UnicodeString FileName);
	void __fastcall SaveToFile(const System::UnicodeString FileName);
	void __fastcall Assign(TBlob* Source);
	TCRBlobData* __fastcall GetData(void);
	void __fastcall SetData(TCRBlobData* Value);
	void __fastcall EnableRollback(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Cancel(void);
	bool __fastcall CanRollback(void);
	__property unsigned Size = {read=GetSize, write=SetSize, nodefault};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	__property System::AnsiString AsAnsiString = {read=GetAsAnsiString, write=SetAsAnsiString};
	__property System::WideString AsWideString = {read=GetAsWideString, write=SetAsWideString};
	__property Sysutils::TBytes AsBytes = {read=GetAsBytes, write=SetAsBytes};
	__property bool IsUnicode = {read=FIsUnicode, write=SetIsUnicode, nodefault};
	__property unsigned PieceSize = {read=GetPieceSize, write=SetPieceSize, nodefault};
	__property bool RollbackEnabled = {read=FNeedRollback, write=FNeedRollback, nodefault};
};


#pragma option push -b-
enum TCompressBlobMode { cbNone, cbClient, cbServer, cbClientServer };
#pragma option pop

class DELPHICLASS TCompressedBlobData;
class PASCALIMPLEMENTATION TCompressedBlobData : public TCRBlobData
{
	typedef TCRBlobData inherited;
	
protected:
	bool __fastcall CompressFrom(void * source, const int sourceLen);
	void __fastcall UncompressTo(void * dest, int &destlen);
	
public:
	bool __fastcall IsCompressed(void);
	bool __fastcall SetCompressed(bool Value);
	unsigned __fastcall UnCompressedSize(void);
	virtual unsigned __fastcall GetSize(void);
	virtual void __fastcall SetSize(unsigned Value);
	unsigned __fastcall GetCompressedSize(void);
	virtual unsigned __fastcall Read(unsigned Position, unsigned Count, void * Dest);
	virtual void __fastcall Write(unsigned Position, unsigned Count, void * Source);
	virtual void __fastcall Truncate(unsigned NewSize);
public:
	/* TCRBlobData.Create */ inline __fastcall TCompressedBlobData(void) : TCRBlobData() { }
	/* TCRBlobData.Destroy */ inline __fastcall virtual ~TCompressedBlobData(void) { }
	
};


class DELPHICLASS TCompressedBlob;
class PASCALIMPLEMENTATION TCompressedBlob : public TBlob
{
	typedef TBlob inherited;
	
protected:
	bool __fastcall GetCompressed(void);
	void __fastcall SetCompressed(bool Value);
	unsigned __fastcall GetCompressedSize(void);
	virtual TCRBlobData* __fastcall CreateBlobData(void);
	
public:
	__property bool Compressed = {read=GetCompressed, write=SetCompressed, nodefault};
	__property unsigned CompressedSize = {read=GetCompressedSize, nodefault};
public:
	/* TBlob.Create */ inline __fastcall TCompressedBlob(bool IsUnicode) : TBlob(IsUnicode) { }
	/* TBlob.Destroy */ inline __fastcall virtual ~TCompressedBlob(void) { }
	
};


class DELPHICLASS TVariantObject;
class PASCALIMPLEMENTATION TVariantObject : public TSharedObject
{
	typedef TSharedObject inherited;
	
private:
	System::Variant FValue;
	
public:
	__property System::Variant Value = {read=FValue, write=FValue};
public:
	/* TSharedObject.Create */ inline __fastcall TVariantObject(void) : TSharedObject() { }
	/* TSharedObject.Destroy */ inline __fastcall virtual ~TVariantObject(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const Byte btSign = 0xdd;
static const Byte flUsed = 0xee;
static const Byte flFree = 0xdd;
static const ShortInt FlatBufferLimit = 0x20;
static const ShortInt dtUnknown = 0x0;
static const ShortInt dtString = 0x1;
static const ShortInt dtInt8 = 0x2;
static const ShortInt dtInt16 = 0x3;
static const ShortInt dtSmallint = 0x3;
static const ShortInt dtInt32 = 0x4;
static const ShortInt dtInteger = 0x4;
static const ShortInt dtFloat = 0x5;
static const ShortInt dtDate = 0x6;
static const ShortInt dtTime = 0x7;
static const ShortInt dtDateTime = 0x8;
static const ShortInt dtUInt16 = 0x9;
static const ShortInt dtWord = 0x9;
static const ShortInt dtBoolean = 0xa;
static const ShortInt dtInt64 = 0xb;
static const ShortInt dtLargeint = 0xb;
static const ShortInt dtCurrency = 0xc;
static const ShortInt dtBlob = 0xd;
static const ShortInt dtMemo = 0xe;
static const ShortInt dtObject = 0xf;
static const ShortInt dtReference = 0x10;
static const ShortInt dtArray = 0x11;
static const ShortInt dtTable = 0x12;
static const ShortInt dtVariant = 0x13;
static const ShortInt dtExtString = 0x14;
static const ShortInt dtBytes = 0x15;
static const ShortInt dtVarBytes = 0x16;
static const ShortInt dtExtVarBytes = 0x17;
static const ShortInt dtUInt32 = 0x18;
static const ShortInt dtLongword = 0x18;
static const ShortInt dtWideString = 0x19;
static const ShortInt dtExtWideString = 0x1a;
static const ShortInt dtBCD = 0x1b;
static const ShortInt dtFMTBCD = 0x1c;
static const ShortInt dtGuid = 0x1d;
static const ShortInt dtWideMemo = 0x1e;
static const ShortInt dtSQLTimeStamp = 0x1f;
static const ShortInt dtCursor = 0x20;
static const Word BlockSize = 0x4000;
static const Word SmallSize = 0x7d0;
static const ShortInt Align = 0x8;
static const ShortInt RefNull = 0x65;
static const int SizeOfTBcd = 0x22;
static const Word SizeOf_TStrData = 0x3ffc;
static const Word SizeOf_TBlock = 0x4000;
static const Word SizeOf_TSmallTab = 0x3e8;
extern PACKAGE int DefaultPieceSize;
static const ShortInt CCompressBlobHeaderGuidSize = 0x10;
static const ShortInt CCompressBlobHeaderSize = 0x14;
extern PACKAGE StaticArray<System::Byte, 16> CCompressBlobHeaderGuid;
extern PACKAGE int MaxArrayItem;
static const ShortInt varDecimal = 0xe;
static const ShortInt varLongWord = 0x13;
extern PACKAGE void __fastcall (*StartWaitProc)(void);
extern PACKAGE void __fastcall (*StopWaitProc)(void);
extern PACKAGE System::UnicodeString __fastcall (*ApplicationTitleProc)(void);
extern PACKAGE double FloatFilterDelta;
extern PACKAGE void __fastcall DataError(System::UnicodeString Msg);
extern PACKAGE void __fastcall StartWait(void);
extern PACKAGE void __fastcall StopWait(void);
extern PACKAGE System::UnicodeString __fastcall ApplicationTitle(void);
extern PACKAGE int __fastcall AddCRString(void * Source, void * Dest, int Count)/* overload */;
extern PACKAGE int __fastcall RemoveCRString(void * Source, void * Dest, int DestLen, int Count)/* overload */;
extern PACKAGE int __fastcall AddCRUnicode(void * Source, void * Dest, int Count)/* overload */;
extern PACKAGE int __fastcall RemoveCRUnicode(void * Source, void * Dest, int DestLen, int Count)/* overload */;
extern PACKAGE PPieceHeader __fastcall NextPiece(PPieceHeader Piece);
extern PACKAGE void * __fastcall PieceData(PPieceHeader Piece);
extern PACKAGE void * __fastcall PieceUsedPtr(PPieceHeader Piece);

}	/* namespace Memdata */
using namespace Memdata;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// MemdataHPP
