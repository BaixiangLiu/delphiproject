// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Connectform.pas' rev: 21.00

#ifndef ConnectformHPP
#define ConnectformHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Connectform
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TConnectForm;
class PASCALIMPLEMENTATION TConnectForm : public Forms::TForm
{
	typedef Forms::TForm inherited;
	
__published:
	Extctrls::TPanel* Panel;
	Stdctrls::TLabel* lbUsername;
	Stdctrls::TLabel* lbPassword;
	Stdctrls::TLabel* lbServer;
	Stdctrls::TEdit* edUsername;
	Stdctrls::TButton* btConnect;
	Stdctrls::TButton* btCancel;
	Stdctrls::TEdit* edPassword;
	Stdctrls::TComboBox* edServer;
	void __fastcall btConnectClick(System::TObject* Sender);
	
private:
	Dbaccess::TCustomConnectDialog* FConnectDialog;
	int FRetries;
	bool FRetry;
	bool FOldCreateOrder;
	void __fastcall SetConnectDialog(Dbaccess::TCustomConnectDialog* Value);
	
protected:
	virtual void __fastcall DoInit(void);
	virtual void __fastcall DoConnect(void);
	
__published:
	__property Dbaccess::TCustomConnectDialog* ConnectDialog = {read=FConnectDialog, write=SetConnectDialog};
	__property bool OldCreateOrder = {read=FOldCreateOrder, write=FOldCreateOrder, nodefault};
public:
	/* TCustomForm.Create */ inline __fastcall virtual TConnectForm(Classes::TComponent* AOwner) : Forms::TForm(AOwner) { }
	/* TCustomForm.CreateNew */ inline __fastcall virtual TConnectForm(Classes::TComponent* AOwner, int Dummy) : Forms::TForm(AOwner, Dummy) { }
	/* TCustomForm.Destroy */ inline __fastcall virtual ~TConnectForm(void) { }
	
public:
	/* TWinControl.CreateParented */ inline __fastcall TConnectForm(HWND ParentWindow) : Forms::TForm(ParentWindow) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Connectform */
using namespace Connectform;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ConnectformHPP
