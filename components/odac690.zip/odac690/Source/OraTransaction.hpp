// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oratransaction.pas' rev: 21.00

#ifndef OratransactionHPP
#define OratransactionHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Oraerror.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oratransaction
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TGlobalCoordinator { gcInternal, gcMTS };
#pragma option pop

typedef Craccess::TCRTransactionAction TOraTransactionAction;

class DELPHICLASS TOraTransaction;
class PASCALIMPLEMENTATION TOraTransaction : public Dbaccess::TDATransaction
{
	typedef Dbaccess::TDATransaction inherited;
	
private:
	typedef DynamicArray<DynamicArray<System::Byte> > _TOraTransaction__1;
	
	
private:
	System::UnicodeString FTransactionName;
	System::UnicodeString FRollbackSegment;
	int FInactiveTimeOut;
	int FResumeTimeOut;
	Sysutils::TBytes FTransactionId;
	_TOraTransaction__1 FBranchQualifiers;
	bool FResume;
	Ora::TOraSession* __fastcall GetSession(int Index);
	int __fastcall GetSessionsCount(void);
	Ora::TOraSession* __fastcall GetDefaultSession(void);
	void __fastcall SetDefaultSession(Ora::TOraSession* Value);
	Ora::TOraIsolationLevel __fastcall GetIsolationLevel(void);
	HIDESBASE void __fastcall SetIsolationLevel(Ora::TOraIsolationLevel Value);
	void __fastcall SetTransactionName(const System::UnicodeString Value);
	void __fastcall SetRollbackSegment(const System::UnicodeString Value);
	Sysutils::TBytes __fastcall GetTransactionId(void);
	void __fastcall SetTransactionId(Sysutils::TBytes Value);
	Sysutils::TBytes __fastcall GetBranchQualifier(int Index);
	TGlobalCoordinator __fastcall GetGlobalCoordinator(void);
	void __fastcall SetGlobalCoordinator(TGlobalCoordinator Value);
	void __fastcall SetInactiveTimeOut(int Value);
	void __fastcall SetResumeTimeOut(int Value);
	
protected:
	virtual Craccess::TCRTransactionClass __fastcall GetITransactionClass(void);
	virtual void __fastcall SetITransaction(Craccess::TCRTransaction* Value);
	virtual System::TClass __fastcall SQLMonitorClass(void);
	virtual bool __fastcall DetectInTransaction(bool CanActivate = false);
	
public:
	__fastcall virtual TOraTransaction(Classes::TComponent* Owner);
	void __fastcall AddSession(Ora::TOraSession* Session, Sysutils::TBytes BranchQualifier)/* overload */;
	void __fastcall AddSession(Ora::TOraSession* Session)/* overload */;
	void __fastcall RemoveSession(Ora::TOraSession* Session);
	void __fastcall ClearSessions(void);
	virtual void __fastcall StartTransaction(void)/* overload */;
	HIDESBASE void __fastcall StartTransaction(bool Resume)/* overload */;
	void __fastcall Detach(void);
	void __fastcall Resume(void);
	void __fastcall Savepoint(const System::UnicodeString Savepoint);
	void __fastcall RollbackToSavepoint(const System::UnicodeString Savepoint);
	__property Active;
	__property Ora::TOraSession* Sessions[int Index] = {read=GetSession};
	__property int SessionsCount = {read=GetSessionsCount, nodefault};
	__property System::UnicodeString RollbackSegment = {read=FRollbackSegment, write=SetRollbackSegment};
	__property Sysutils::TBytes TransactionId = {read=GetTransactionId, write=SetTransactionId};
	__property Sysutils::TBytes BranchQualifiers[int Index] = {read=GetBranchQualifier};
	
__published:
	__property System::UnicodeString TransactionName = {read=FTransactionName, write=SetTransactionName};
	__property Ora::TOraIsolationLevel IsolationLevel = {read=GetIsolationLevel, write=SetIsolationLevel, default=0};
	__property Ora::TOraSession* DefaultSession = {read=GetDefaultSession, write=SetDefaultSession};
	__property TGlobalCoordinator GlobalCoordinator = {read=GetGlobalCoordinator, write=SetGlobalCoordinator, default=0};
	__property int InactiveTimeOut = {read=FInactiveTimeOut, write=SetInactiveTimeOut, default=0};
	__property int ResumeTimeOut = {read=FResumeTimeOut, write=SetResumeTimeOut, default=0};
	__property DefaultCloseAction = {default=0};
	__property OnError;
public:
	/* TDATransaction.Destroy */ inline __fastcall virtual ~TOraTransaction(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Oratransaction */
using namespace Oratransaction;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OratransactionHPP
