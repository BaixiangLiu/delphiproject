// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Crvio.pas' rev: 21.00

#ifndef CrvioHPP
#define CrvioHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Crvio
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TCRVio;
class PASCALIMPLEMENTATION TCRVio : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	System::UnicodeString FLastError;
	Sysutils::TBytes FBuffer;
	int FBufferLen;
	int FBufferPos;
	virtual int __fastcall GetTimeout(void) = 0 ;
	virtual void __fastcall SetTimeout(int Value) = 0 ;
	
public:
	virtual void __fastcall Connect(void);
	virtual void __fastcall Close(void) = 0 ;
	virtual int __fastcall ReadNoWait(char * buffer, int offset, int count) = 0 ;
	virtual int __fastcall WriteNoWait(const char * buffer, int offset, int count) = 0 ;
	virtual int __fastcall Read(char * buffer, int offset, int count);
	virtual int __fastcall Write(const char * buffer, int offset, int count);
	virtual bool __fastcall WaitForData(int Timeout = 0xffffffff);
	__property int Timeout = {read=GetTimeout, write=SetTimeout, nodefault};
	__property System::UnicodeString LastError = {read=FLastError};
public:
	/* TObject.Create */ inline __fastcall TCRVio(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCRVio(void) { }
	
};


typedef System::TObject TCRIOHandle;

class DELPHICLASS TCRIOHandler;
class PASCALIMPLEMENTATION TCRIOHandler : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	virtual void __fastcall RegisterClient(System::TObject* Client);
	virtual void __fastcall UnRegisterClient(System::TObject* Client);
	__classmethod virtual void __fastcall SetIsSecure(System::TObject* Handle, const bool Value);
	__classmethod virtual bool __fastcall GetIsSecure(System::TObject* Handle);
	virtual System::UnicodeString __fastcall GetHandlerType(void);
	
public:
	virtual System::TObject* __fastcall Connect(const System::UnicodeString Server, const int Port, const System::UnicodeString SSL_key, const System::UnicodeString SSL_cert, const System::UnicodeString SSL_ca) = 0 ;
	__classmethod virtual void __fastcall Disconnect(System::TObject* Handle);
	__classmethod virtual int __fastcall ReadNoWait(System::TObject* Handle, char * buffer, int offset, int count);
	__classmethod virtual int __fastcall Read(System::TObject* Handle, char * buffer, int offset, int count);
	__classmethod virtual int __fastcall Write(System::TObject* Handle, const char * buffer, int offset, int count);
	__classmethod virtual int __fastcall GetTimeout(System::TObject* Handle);
	__classmethod virtual void __fastcall SetTimeout(System::TObject* Handle, int Value);
	__property System::UnicodeString HandlerType = {read=GetHandlerType};
public:
	/* TComponent.Create */ inline __fastcall virtual TCRIOHandler(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	/* TComponent.Destroy */ inline __fastcall virtual ~TCRIOHandler(void) { }
	
};


class DELPHICLASS TCRVioHandler;
class PASCALIMPLEMENTATION TCRVioHandler : public TCRVio
{
	typedef TCRVio inherited;
	
protected:
	TCRIOHandler* FIOHandler;
	System::TObject* FHandle;
	System::UnicodeString Fhostname;
	int Fport;
	int FTimeout;
	System::UnicodeString FSSL_key;
	System::UnicodeString FSSL_cert;
	System::UnicodeString FSSL_ca;
	virtual int __fastcall GetTimeout(void);
	virtual void __fastcall SetTimeout(int Value);
	void __fastcall SetIsSecure(const bool Value);
	bool __fastcall GetIsSecure(void);
	
public:
	__fastcall TCRVioHandler(const System::UnicodeString hostname, const int port, TCRIOHandler* IOHandler, const System::UnicodeString SSL_key, const System::UnicodeString SSL_cert, const System::UnicodeString SSL_ca);
	virtual void __fastcall Connect(void);
	virtual void __fastcall Close(void);
	virtual int __fastcall ReadNoWait(char * buffer, int offset, int count);
	virtual int __fastcall WriteNoWait(const char * buffer, int offset, int count);
	virtual int __fastcall Read(char * buffer, int offset, int count);
	virtual int __fastcall Write(const char * buffer, int offset, int count);
	__property bool IsSecure = {read=GetIsSecure, write=SetIsSecure, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCRVioHandler(void) { }
	
};


class DELPHICLASS TCRIOHandlerUtils;
class PASCALIMPLEMENTATION TCRIOHandlerUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall RegisterClient(TCRIOHandler* Obj, System::TObject* Client);
	__classmethod void __fastcall UnRegisterClient(TCRIOHandler* Obj, System::TObject* Client);
public:
	/* TObject.Create */ inline __fastcall TCRIOHandlerUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TCRIOHandlerUtils(void) { }
	
};


class DELPHICLASS TProxyOptions;
class PASCALIMPLEMENTATION TProxyOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FHostname;
	int FPort;
	System::UnicodeString FUsername;
	System::UnicodeString FPassword;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
__published:
	__property System::UnicodeString Hostname = {read=FHostname, write=FHostname};
	__property int Port = {read=FPort, write=FPort, nodefault};
	__property System::UnicodeString Username = {read=FUsername, write=FUsername};
	__property System::UnicodeString Password = {read=FPassword, write=FPassword};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TProxyOptions(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TProxyOptions(void) : Classes::TPersistent() { }
	
};


class DELPHICLASS THttpOptions;
class PASCALIMPLEMENTATION THttpOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FUrl;
	System::UnicodeString FUsername;
	System::UnicodeString FPassword;
	TProxyOptions* FProxyOptions;
	void __fastcall SetProxyOptions(TProxyOptions* Value);
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall THttpOptions(void);
	__fastcall virtual ~THttpOptions(void);
	HIDESBASE bool __fastcall Equals(THttpOptions* HttpOptions);
	
__published:
	__property System::UnicodeString Url = {read=FUrl, write=FUrl};
	__property System::UnicodeString Username = {read=FUsername, write=FUsername};
	__property System::UnicodeString Password = {read=FPassword, write=FPassword};
	__property TProxyOptions* ProxyOptions = {read=FProxyOptions, write=SetProxyOptions};
};


//-- var, const, procedure ---------------------------------------------------
static const Word VIO_READ_BUFFER_SIZE = 0x4000;
static const Word VIO_UNBUFFERED_READ_MIN_SIZE = 0x800;

}	/* namespace Crvio */
using namespace Crvio;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// CrvioHPP
