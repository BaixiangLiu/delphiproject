// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dacvcl.pas' rev: 21.00

#ifndef DacvclHPP
#define DacvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Dasqlmonitor.hpp>	// Pascal unit
#include <Typinfo.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Stdctrls.hpp>	// Pascal unit
#include <Extctrls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dacvcl
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall SetCursor(int Value);
extern PACKAGE void __fastcall ShowDebugForm(Dasqlmonitor::TDASQLMonitorClass DASQLMonitorClass, Classes::TComponent* Component, System::UnicodeString SQL, Dbaccess::TDAParams* Params, System::UnicodeString Caption);
extern PACKAGE bool __fastcall ShowConnectForm(Dbaccess::TCustomConnectDialog* ConnectDialog);
extern PACKAGE void __fastcall StartWait(void);
extern PACKAGE void __fastcall StopWait(void);
extern PACKAGE System::UnicodeString __fastcall ApplicationTitle(void);
extern PACKAGE System::UnicodeString __fastcall GetHelpFileName(const System::UnicodeString ProjectName, bool UseCHM = false);

}	/* namespace Dacvcl */
using namespace Dacvcl;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DacvclHPP
