// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Odacvcl.pas' rev: 21.00

#ifndef OdacvclHPP
#define OdacvclHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Registry.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Dacvcl.hpp>	// Pascal unit
#include <Dbaccess.hpp>	// Pascal unit
#include <Connectform.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Oraclasses.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Odacvcl
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TConnectDialog;
class PASCALIMPLEMENTATION TConnectDialog : public Dbaccess::TCustomConnectDialog
{
	typedef Dbaccess::TCustomConnectDialog inherited;
	
private:
	Ora::TOraSession* __fastcall GetSession(void);
	bool __fastcall GetReadAliases(void);
	void __fastcall SetReadAliases(bool Value);
	
protected:
	virtual Dbaccess::TCRServerEnumeratorClass __fastcall GetServerEnumeratorClass(void);
	virtual void __fastcall SetServerEnumerator(Dbaccess::TCRServerEnumerator* Value);
	virtual System::UnicodeString __fastcall GetKeyPath(void);
	virtual System::UnicodeString __fastcall GetServerStoreName(void);
	virtual System::TClass __fastcall DefDialogClass(void);
	
public:
	__fastcall virtual TConnectDialog(Classes::TComponent* Owner);
	__property Ora::TOraSession* Session = {read=GetSession};
	
__published:
	__property bool ReadAliases = {read=GetReadAliases, write=SetReadAliases, default=0};
	__property Retries = {default=3};
	__property SavePassword = {default=0};
	__property StoreLogInfo = {default=1};
	__property DialogClass;
	__property Caption;
	__property UsernameLabel;
	__property PasswordLabel;
	__property ServerLabel;
	__property ConnectButton;
	__property CancelButton;
	__property LabelSet = {default=1};
public:
	/* TCustomConnectDialog.Destroy */ inline __fastcall virtual ~TConnectDialog(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::TClass __fastcall DefConnectDialogClass(void);

}	/* namespace Odacvcl */
using namespace Odacvcl;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OdacvclHPP
