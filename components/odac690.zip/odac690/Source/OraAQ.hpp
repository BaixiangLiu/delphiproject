// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraaq.pas' rev: 21.00

#ifndef OraaqHPP
#define OraaqHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Variants.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Ora.hpp>	// Pascal unit
#include <Oraobjects.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraaq
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TQueueMessageState { qmsReady, qmsWaiting, qmsProcessed, qmsExpired };
#pragma option pop

#pragma option push -b-
enum TQueueDeliveryMode { qdmPersistent, qdmBuffered, qdmPersistentOrBuffered };
#pragma option pop

#pragma option push -b-
enum TQueueVisibility { qvOnCommit, qvImmediate };
#pragma option pop

#pragma option push -b-
enum TQueueSequenceDeviation { qsdNone, qsdBefore, qsdTop };
#pragma option pop

#pragma option push -b-
enum TDequeueMode { dqmBrowse, dqmLocked, dqmRemove, dqmRemoveNoData };
#pragma option pop

#pragma option push -b-
enum TQueueNavigation { qnNextMessage, qnNextTransaction, qnFirstMessage, qnFirstMessageMultiGroup, qnNextMessageMultiGroup };
#pragma option pop

typedef System::UnicodeString TMessageId;

typedef DynamicArray<System::UnicodeString> TMessageIds;

class DELPHICLASS TQueueAgent;
class PASCALIMPLEMENTATION TQueueAgent : public Classes::TCollectionItem
{
	typedef Classes::TCollectionItem inherited;
	
private:
	System::UnicodeString FName;
	System::UnicodeString FAddress;
	int FProtocol;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TQueueAgent(void)/* overload */;
	
__published:
	__property System::UnicodeString Name = {read=FName, write=FName};
	__property System::UnicodeString Address = {read=FAddress, write=FAddress};
	__property int Protocol = {read=FProtocol, write=FProtocol, default=0};
public:
	/* TCollectionItem.Destroy */ inline __fastcall virtual ~TQueueAgent(void) { }
	
};


class DELPHICLASS TQueueAgents;
class PASCALIMPLEMENTATION TQueueAgents : public Classes::TOwnedCollection
{
	typedef Classes::TOwnedCollection inherited;
	
public:
	TQueueAgent* operator[](int Index) { return Items[Index]; }
	
private:
	HIDESBASE TQueueAgent* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TQueueAgent* Value);
	
public:
	__fastcall TQueueAgents(void)/* overload */;
	__fastcall TQueueAgents(Classes::TPersistent* AOwner)/* overload */;
	HIDESBASE TQueueAgent* __fastcall Add(void);
	HIDESBASE TQueueAgent* __fastcall Insert(int Index);
	__property TQueueAgent* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	/* TCollection.Destroy */ inline __fastcall virtual ~TQueueAgents(void) { }
	
};


class DELPHICLASS TQueueMessageProperties;
class PASCALIMPLEMENTATION TQueueMessageProperties : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	Classes::TPersistent* FOwner;
	TQueueAgents* FRecipientList;
	int FAttempts;
	System::TDateTime FEnqueueTime;
	TQueueMessageState FState;
	int FPriority;
	int FDelay;
	int FExpiration;
	System::UnicodeString FCorrelation;
	System::UnicodeString FExceptionQueue;
	TQueueAgent* FSenderId;
	System::UnicodeString FOriginalMessageId;
	System::UnicodeString FTransactionGroup;
	TQueueDeliveryMode FDeliveryMode;
	void __fastcall SetRecipientList(TQueueAgents* Value);
	bool __fastcall IsRecipientListStored(void);
	void __fastcall SetSenderId(TQueueAgent* Value);
	
protected:
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TQueueMessageProperties(void)/* overload */;
	__fastcall TQueueMessageProperties(Classes::TPersistent* AOwner)/* overload */;
	__fastcall virtual ~TQueueMessageProperties(void);
	__property int Attempts = {read=FAttempts, nodefault};
	__property System::TDateTime EnqueueTime = {read=FEnqueueTime};
	__property TQueueMessageState State = {read=FState, nodefault};
	__property System::UnicodeString TransactionGroup = {read=FTransactionGroup};
	__property System::UnicodeString Correlation = {read=FCorrelation, write=FCorrelation};
	__property System::UnicodeString OriginalMessageId = {read=FOriginalMessageId, write=FOriginalMessageId};
	
__published:
	__property TQueueAgents* RecipientList = {read=FRecipientList, write=SetRecipientList, stored=IsRecipientListStored};
	__property int Priority = {read=FPriority, write=FPriority, default=1};
	__property int Delay = {read=FDelay, write=FDelay, default=0};
	__property int Expiration = {read=FExpiration, write=FExpiration, default=-1};
	__property System::UnicodeString ExceptionQueue = {read=FExceptionQueue, write=FExceptionQueue};
	__property TQueueAgent* SenderId = {read=FSenderId, write=SetSenderId};
	__property TQueueDeliveryMode DeliveryMode = {read=FDeliveryMode, write=FDeliveryMode, default=0};
};


class DELPHICLASS TQueueMessage;
class PASCALIMPLEMENTATION TQueueMessage : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Sysutils::TBytes FRawPayload;
	Oraobjects::TOraObject* FObjectPayload;
	TQueueMessageProperties* FMessageProperties;
	System::UnicodeString FMessageId;
	Sysutils::TBytes __fastcall GetRawPayload(void);
	void __fastcall SetRawPayload(const Sysutils::TBytes Value);
	System::UnicodeString __fastcall GetStringPayload(void);
	void __fastcall SetStringPayload(const System::UnicodeString Value);
	Oraobjects::TOraObject* __fastcall GetObjectPayload(void);
	void __fastcall SetObjectPayload(Oraobjects::TOraObject* Value);
	void __fastcall SetMessageProperties(TQueueMessageProperties* Value);
	
public:
	__fastcall TQueueMessage(void)/* overload */;
	__fastcall TQueueMessage(const System::UnicodeString Payload, TQueueMessageProperties* MessageProperties)/* overload */;
	__fastcall TQueueMessage(const Sysutils::TBytes Payload, TQueueMessageProperties* MessageProperties)/* overload */;
	__fastcall TQueueMessage(Oraobjects::TOraObject* Payload, TQueueMessageProperties* MessageProperties)/* overload */;
	__fastcall virtual ~TQueueMessage(void);
	__property System::UnicodeString MessageId = {read=FMessageId};
	__property Sysutils::TBytes RawPayload = {read=GetRawPayload, write=SetRawPayload};
	__property System::UnicodeString StringPayload = {read=GetStringPayload, write=SetStringPayload};
	__property Oraobjects::TOraObject* ObjectPayload = {read=GetObjectPayload, write=SetObjectPayload};
	__property TQueueMessageProperties* MessageProperties = {read=FMessageProperties, write=SetMessageProperties};
};


class DELPHICLASS TEnqueueOptions;
class PASCALIMPLEMENTATION TEnqueueOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	TQueueVisibility FVisibility;
	System::UnicodeString FRelativeMessageId;
	TQueueSequenceDeviation FSequenceDeviation;
	System::UnicodeString FTransformation;
	TQueueDeliveryMode FDeliveryMode;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__property System::UnicodeString RelativeMessageId = {read=FRelativeMessageId, write=FRelativeMessageId};
	
__published:
	__property TQueueVisibility Visibility = {read=FVisibility, write=FVisibility, default=0};
	__property TQueueSequenceDeviation SequenceDeviation = {read=FSequenceDeviation, write=FSequenceDeviation, default=0};
	__property System::UnicodeString Transformation = {read=FTransformation, write=FTransformation};
	__property TQueueDeliveryMode DeliveryMode = {read=FDeliveryMode, write=FDeliveryMode, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TEnqueueOptions(void) { }
	
public:
	/* TObject.Create */ inline __fastcall TEnqueueOptions(void) : Classes::TPersistent() { }
	
};


class DELPHICLASS TDequeueOptions;
class PASCALIMPLEMENTATION TDequeueOptions : public Classes::TPersistent
{
	typedef Classes::TPersistent inherited;
	
private:
	System::UnicodeString FConsumerName;
	TDequeueMode FDequeueMode;
	TQueueNavigation FNavigation;
	TQueueVisibility FVisibility;
	int FWaitTimeout;
	System::UnicodeString FMessageId;
	System::UnicodeString FCorrelation;
	System::UnicodeString FDequeueCondition;
	System::UnicodeString FTransformation;
	TQueueDeliveryMode FDeliveryMode;
	
protected:
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	
public:
	__fastcall TDequeueOptions(void);
	__property System::UnicodeString MessageId = {read=FMessageId, write=FMessageId};
	
__published:
	__property System::UnicodeString ConsumerName = {read=FConsumerName, write=FConsumerName};
	__property TDequeueMode DequeueMode = {read=FDequeueMode, write=FDequeueMode, default=2};
	__property TQueueNavigation Navigation = {read=FNavigation, write=FNavigation, default=0};
	__property TQueueVisibility Visibility = {read=FVisibility, write=FVisibility, default=0};
	__property int WaitTimeout = {read=FWaitTimeout, write=FWaitTimeout, default=-1};
	__property System::UnicodeString Correlation = {read=FCorrelation, write=FCorrelation};
	__property System::UnicodeString DequeueCondition = {read=FDequeueCondition, write=FDequeueCondition};
	__property System::UnicodeString Transformation = {read=FTransformation, write=FTransformation};
	__property TQueueDeliveryMode DeliveryMode = {read=FDeliveryMode, write=FDeliveryMode, default=0};
public:
	/* TPersistent.Destroy */ inline __fastcall virtual ~TDequeueOptions(void) { }
	
};


class DELPHICLASS TOraQueue;
typedef void __fastcall (__closure *TQueueMessageEvent)(TOraQueue* Sender, const System::UnicodeString MessageId, const TQueueMessageProperties* MessageProperties);

class PASCALIMPLEMENTATION TOraQueue : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Ora::TOraSession* FSession;
	Ora::TOraSQL* FSQL;
	System::UnicodeString FQueueName;
	System::UnicodeString FPayloadTypeName;
	System::UnicodeString FPayloadArrayTypeName;
	Oraobjects::TOraType* FPayloadOraType;
	TQueueMessageProperties* FEnqueueMessageProperties;
	TEnqueueOptions* FEnqueueOptions;
	TDequeueOptions* FDequeueOptions;
	bool FAsyncNotification;
	TQueueMessageEvent FOnMessage;
	void *hOCISubscription;
	HWND hWindow;
	void *FGCHandle;
	System::Word FOracleVersion;
	void __fastcall SetSession(Ora::TOraSession* Value);
	System::UnicodeString __fastcall GetPayloadTypeName(void);
	void __fastcall SetQueueName(const System::UnicodeString Value);
	void __fastcall SetEnqueueMessageProperties(TQueueMessageProperties* Value);
	void __fastcall SetEnqueueOptions(TEnqueueOptions* Value);
	void __fastcall SetDequeueOptions(TDequeueOptions* Value);
	void __fastcall SetAsyncNotification(bool Value);
	void * __fastcall GetGCHandle(void);
	
protected:
	bool FDesignCreate;
	void __fastcall Init(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	Ora::TOraSession* __fastcall UsedConnection(void);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall CheckOracleVersion(void);
	void __fastcall CheckPayloadType(void);
	void __fastcall CheckPayloadArrayType(void);
	void __fastcall AllocWnd(void);
	void __fastcall RegisterSubscription(void);
	void __fastcall UnregisterSubscription(void);
	int __fastcall CallbackSubscription(void * pCtx, void * pSubscrHp, void * pPayload, unsigned iPayloadLen, void * pDescriptor, unsigned iMode);
	__property void * GCHandle = {read=GetGCHandle};
	
public:
	__fastcall virtual TOraQueue(Classes::TComponent* AOwner)/* overload */;
	__fastcall TOraQueue(Classes::TComponent* AOwner, Ora::TOraSession* Session, const System::UnicodeString QueueName)/* overload */;
	__fastcall virtual ~TOraQueue(void);
	System::UnicodeString __fastcall Enqueue(const System::UnicodeString Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TEnqueueOptions* EnqueueOptions = (TEnqueueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Enqueue(const Sysutils::TBytes Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TEnqueueOptions* EnqueueOptions = (TEnqueueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Enqueue(Oraobjects::TOraObject* Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TEnqueueOptions* EnqueueOptions = (TEnqueueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Enqueue(TQueueMessage* Message, TEnqueueOptions* EnqueueOptions = (TEnqueueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Dequeue(/* out */ System::UnicodeString &Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TDequeueOptions* DequeueOptions = (TDequeueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Dequeue(/* out */ Sysutils::TBytes &Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TDequeueOptions* DequeueOptions = (TDequeueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Dequeue(Oraobjects::TOraObject* Payload, TQueueMessageProperties* MessageProperties = (TQueueMessageProperties*)(0x0), TDequeueOptions* DequeueOptions = (TDequeueOptions*)(0x0))/* overload */;
	System::UnicodeString __fastcall Dequeue(TQueueMessage* Message, TDequeueOptions* DequeueOptions = (TDequeueOptions*)(0x0))/* overload */;
	TMessageIds __fastcall EnqueueArray(TQueueMessage* const *MessageArray, const int MessageArray_Size, TEnqueueOptions* EnqueueOptions = (TEnqueueOptions*)(0x0));
	TMessageIds __fastcall DequeueArray(TQueueMessage* const *MessageArray, const int MessageArray_Size, /* out */ int &DequeuedSize, TDequeueOptions* DequeueOptions = (TDequeueOptions*)(0x0));
	void __fastcall Listen(TQueueAgents* Agents, TQueueAgent* Agent, int WaitTimeout = 0xffffffff)/* overload */;
	void __fastcall Listen(TQueueAgents* Agents, TQueueDeliveryMode ListDeliveryMode, TQueueAgent* Agent, TQueueDeliveryMode &MessageDeliveryMode, int WaitTimeout = 0xffffffff)/* overload */;
	__property System::UnicodeString PayloadTypeName = {read=GetPayloadTypeName, write=FPayloadTypeName};
	__property System::UnicodeString PayloadArrayTypeName = {read=FPayloadArrayTypeName, write=FPayloadArrayTypeName};
	
__published:
	__property Ora::TOraSession* Session = {read=FSession, write=SetSession};
	__property System::UnicodeString QueueName = {read=FQueueName, write=SetQueueName};
	__property TQueueMessageProperties* EnqueueMessageProperties = {read=FEnqueueMessageProperties, write=SetEnqueueMessageProperties};
	__property TEnqueueOptions* EnqueueOptions = {read=FEnqueueOptions, write=SetEnqueueOptions};
	__property TDequeueOptions* DequeueOptions = {read=FDequeueOptions, write=SetDequeueOptions};
	__property bool AsyncNotification = {read=FAsyncNotification, write=SetAsyncNotification, default=0};
	__property TQueueMessageEvent OnMessage = {read=FOnMessage, write=FOnMessage};
};


#pragma option push -b-
enum TQueueSortList { qslDefault, qslPriority, qslEnqueueTime, qslPriorityEnqueueTime, qslEnqueueTimePriority };
#pragma option pop

#pragma option push -b-
enum TQueueMessageGrouping { qmgNone, qmgTransactional };
#pragma option pop

#pragma option push -b-
enum TQueueCompatible { qcDefault, qc80, qc81, qc100 };
#pragma option pop

#pragma option push -b-
enum TQueuePrivilege { qpEnqueue, qpDequeue, qpAll };
#pragma option pop

#pragma option push -b-
enum TQueueSystemPrivilege { qspEnqueueAny, qspDequeueAny, qspManageAny };
#pragma option pop

#pragma option push -b-
enum TQueueType { qtNormalQueue, qtExceptionQueue };
#pragma option pop

class DELPHICLASS TOraQueueTable;
class PASCALIMPLEMENTATION TOraQueueTable : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Ora::TOraSession* FSession;
	Ora::TOraSQL* FSQL;
	System::UnicodeString FQueueTableName;
	System::UnicodeString FStorageClause;
	System::UnicodeString FPayloadTypeName;
	TQueueSortList FSortList;
	bool FMultipleConsumers;
	TQueueMessageGrouping FMessageGrouping;
	System::UnicodeString FComment;
	int FPrimaryInstance;
	int FSecondaryInstance;
	TQueueCompatible FCompatible;
	bool FSecure;
	System::Word FOracleVersion;
	void __fastcall SetSession(Ora::TOraSession* Value);
	bool __fastcall IsPayloadTypeNameStored(void);
	
protected:
	bool FDesignCreate;
	void __fastcall Init(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	Ora::TOraSession* __fastcall UsedConnection(void);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall CheckOracleVersion(void);
	
public:
	__fastcall virtual TOraQueueTable(Classes::TComponent* AOwner)/* overload */;
	__fastcall TOraQueueTable(Classes::TComponent* AOwner, Ora::TOraSession* Session, const System::UnicodeString QueueTableName)/* overload */;
	__fastcall virtual ~TOraQueueTable(void);
	void __fastcall CreateQueueTable(void);
	void __fastcall ReadQueueTableProperties(void);
	void __fastcall AlterQueueTable(const System::UnicodeString Comment, int PrimaryInstance = 0xffffffff, int SecondaryInstance = 0xffffffff);
	void __fastcall AlterComment(const System::UnicodeString Comment);
	void __fastcall AlterPrimaryInstance(int PrimaryInstance);
	void __fastcall AlterSecondaryInstance(int SecondaryInstance);
	void __fastcall DropQueueTable(bool Force = false);
	void __fastcall PurgeQueueTable(const System::UnicodeString PurgeCondition, bool Block = false, TQueueDeliveryMode DeliveryMode = (TQueueDeliveryMode)(0x0));
	void __fastcall MigrateQueueTable(TQueueCompatible Compatible);
	void __fastcall GrantSystemPrivilege(TQueueSystemPrivilege Privilege, const System::UnicodeString Grantee, bool AdminOption = false);
	void __fastcall RevokeSystemPrivilege(TQueueSystemPrivilege Privilege, const System::UnicodeString Grantee);
	
__published:
	__property Ora::TOraSession* Session = {read=FSession, write=SetSession};
	__property System::UnicodeString QueueTableName = {read=FQueueTableName, write=FQueueTableName};
	__property System::UnicodeString StorageClause = {read=FStorageClause, write=FStorageClause};
	__property System::UnicodeString PayloadTypeName = {read=FPayloadTypeName, write=FPayloadTypeName, stored=IsPayloadTypeNameStored};
	__property TQueueSortList SortList = {read=FSortList, write=FSortList, default=0};
	__property bool MultipleConsumers = {read=FMultipleConsumers, write=FMultipleConsumers, default=0};
	__property TQueueMessageGrouping MessageGrouping = {read=FMessageGrouping, write=FMessageGrouping, default=0};
	__property System::UnicodeString Comment = {read=FComment, write=FComment};
	__property int PrimaryInstance = {read=FPrimaryInstance, write=FPrimaryInstance, default=0};
	__property int SecondaryInstance = {read=FSecondaryInstance, write=FSecondaryInstance, default=0};
	__property TQueueCompatible Compatible = {read=FCompatible, write=FCompatible, default=0};
	__property bool Secure = {read=FSecure, write=FSecure, default=0};
};


class DELPHICLASS TOraQueueAdmin;
class PASCALIMPLEMENTATION TOraQueueAdmin : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
private:
	Ora::TOraSession* FSession;
	Ora::TOraSQL* FSQL;
	System::UnicodeString FQueueName;
	TQueueType FQueueType;
	int FMaxRetries;
	int FRetryDelay;
	int FRetentionTime;
	System::UnicodeString FComment;
	System::UnicodeString FQueueTableName;
	bool FMultipleConsumers;
	System::Word FOracleVersion;
	void __fastcall SetSession(Ora::TOraSession* Value);
	
protected:
	bool FDesignCreate;
	void __fastcall Init(void);
	virtual void __fastcall AssignTo(Classes::TPersistent* Dest);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	Ora::TOraSession* __fastcall UsedConnection(void);
	void __fastcall BeginConnection(void);
	void __fastcall EndConnection(void);
	void __fastcall CheckOracleVersion(void);
	void __fastcall CreateNonPersistentQueue(void);
	System::UnicodeString __fastcall GetNameWithSchema(const System::UnicodeString Name);
	
public:
	__fastcall virtual TOraQueueAdmin(Classes::TComponent* AOwner)/* overload */;
	__fastcall TOraQueueAdmin(Classes::TComponent* AOwner, Ora::TOraSession* Session, const System::UnicodeString QueueName)/* overload */;
	void __fastcall CreateQueue(bool NonPersistent = false);
	void __fastcall ReadQueueProperties(void);
	void __fastcall DropQueue(void);
	void __fastcall AlterQueue(int MaxRetries, int RetryDelay = 0xffffffff, int RetentionTime = 0xffffffff, const System::UnicodeString Comment = L"");
	void __fastcall AlterComment(const System::UnicodeString Comment);
	void __fastcall AlterMaxRetries(int MaxRetries);
	void __fastcall AlterRetryDelay(int RetryDelay);
	void __fastcall AlterRetentionTime(int RetentionTime);
	void __fastcall StartEnqueue(void);
	void __fastcall StartDequeue(void);
	void __fastcall StartQueue(bool Enqueue = true, bool Dequeue = true);
	void __fastcall StopEnqueue(bool Wait = true);
	void __fastcall StopDequeue(bool Wait = true);
	void __fastcall StopQueue(bool Enqueue = true, bool Dequeue = true, bool Wait = true);
	void __fastcall GetSubscribers(TQueueAgents* Subscribers);
	void __fastcall AddSubscriber(TQueueAgent* Subscriber, const System::UnicodeString Rule = L"", const System::UnicodeString Transformation = L"", bool QueueToQueue = false, TQueueDeliveryMode DeliveryMode = (TQueueDeliveryMode)(0x0));
	void __fastcall RemoveSubscriber(TQueueAgent* Subscriber);
	void __fastcall AlterSubscriber(TQueueAgent* Subscriber, const System::UnicodeString Rule, const System::UnicodeString Transformation = L"");
	void __fastcall GrantQueuePrivilege(TQueuePrivilege Privilege, const System::UnicodeString Grantee, bool GrantOption = false);
	void __fastcall RevokeQueuePrivilege(TQueuePrivilege Privilege, const System::UnicodeString Grantee);
	void __fastcall SchedulePropagation(const System::UnicodeString Destination, System::TDateTime StartTime, int Duration, const System::UnicodeString NextTime, int Latency, const System::UnicodeString DestinationQueue = L"");
	void __fastcall UnschedulePropagation(const System::UnicodeString Destination, const System::UnicodeString DestinationQueue = L"");
	void __fastcall AlterPropagationSchedule(const System::UnicodeString Destination, int Duration, const System::UnicodeString NextTime, int Latency, const System::UnicodeString DestinationQueue = L"");
	void __fastcall EnablePropagationSchedule(const System::UnicodeString Destination, const System::UnicodeString DestinationQueue = L"");
	void __fastcall DisablePropagationSchedule(const System::UnicodeString Destination, const System::UnicodeString DestinationQueue = L"");
	bool __fastcall VerifyQueueTypes(const System::UnicodeString DestQueueName, const System::UnicodeString Destination);
	
__published:
	__property Ora::TOraSession* Session = {read=FSession, write=SetSession};
	__property System::UnicodeString QueueName = {read=FQueueName, write=FQueueName};
	__property TQueueType QueueType = {read=FQueueType, write=FQueueType, default=0};
	__property int MaxRetries = {read=FMaxRetries, write=FMaxRetries, default=-1};
	__property int RetryDelay = {read=FRetryDelay, write=FRetryDelay, default=0};
	__property int RetentionTime = {read=FRetentionTime, write=FRetentionTime, default=0};
	__property System::UnicodeString Comment = {read=FComment, write=FComment};
	__property System::UnicodeString QueueTableName = {read=FQueueTableName, write=FQueueTableName};
	__property bool MultipleConsumers = {read=FMultipleConsumers, write=FMultipleConsumers, default=0};
public:
	/* TComponent.Destroy */ inline __fastcall virtual ~TOraQueueAdmin(void) { }
	
};


class DELPHICLASS TOraAQUtils;
class PASCALIMPLEMENTATION TOraAQUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall SetDesignCreate(TOraQueue* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TOraQueue* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TOraQueueTable* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TOraQueueTable* Obj)/* overload */;
	__classmethod void __fastcall SetDesignCreate(TOraQueueAdmin* Obj, bool Value)/* overload */;
	__classmethod bool __fastcall GetDesignCreate(TOraQueueAdmin* Obj)/* overload */;
public:
	/* TObject.Create */ inline __fastcall TOraAQUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraAQUtils(void) { }
	
};


class DELPHICLASS TQueueTableList;
class PASCALIMPLEMENTATION TQueueTableList : public Classes::TThreadList
{
	typedef Classes::TThreadList inherited;
	
public:
	TOraQueueTable* operator[](int Index) { return Items[Index]; }
	
private:
	int __fastcall GetCount(void);
	TOraQueueTable* __fastcall GetTable(int Index);
	
public:
	__property int Count = {read=GetCount, nodefault};
	__property TOraQueueTable* Items[int Index] = {read=GetTable/*, default*/};
public:
	/* TThreadList.Create */ inline __fastcall TQueueTableList(void) : Classes::TThreadList() { }
	/* TThreadList.Destroy */ inline __fastcall virtual ~TQueueTableList(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt AQ_NO_DELAY = 0x0;
static const ShortInt AQ_NEVER = -1;
static const ShortInt AQ_FOREVER = -1;
static const ShortInt AQ_NO_WAIT = 0x0;
static const ShortInt AQ_PERSISTENT = 0x1;
static const ShortInt AQ_BUFFERED = 0x2;
static const ShortInt AQ_PERSISTENT_OR_BUFFERED = 0x3;
static const ShortInt AQ_IMMEDIATE = 0x1;
static const ShortInt AQ_ON_COMMIT = 0x2;
static const ShortInt AQ_BEFORE = 0x2;
static const ShortInt AQ_TOP = 0x3;
static const ShortInt AQ_BROWSE = 0x1;
static const ShortInt AQ_LOCKED = 0x2;
static const ShortInt AQ_REMOVE = 0x3;
static const ShortInt AQ_REMOVE_NODATA = 0x4;
static const ShortInt AQ_FIRST_MESSAGE = 0x1;
static const ShortInt AQ_NEXT_TRANSACTION = 0x2;
static const ShortInt AQ_NEXT_MESSAGE = 0x3;
static const ShortInt AQ_FIRST_MESSAGE_MULTI_GROUP = 0x4;
static const ShortInt AQ_NEXT_MESSAGE_MULTI_GROUP = 0x5;
static const ShortInt AQ_READY = 0x0;
static const ShortInt AQ_WAITING = 0x1;
static const ShortInt AQ_PROCESSED = 0x2;
static const ShortInt AQ_EXPIRED = 0x3;
static const ShortInt AQ_NONE = 0x0;
static const ShortInt AQ_TRANSACTIONAL = 0x1;
static const ShortInt AQ_NORMAL_QUEUE = 0x0;
static const ShortInt AQ_EXCEPTION_QUEUE = 0x1;
static const ShortInt AQ_INFINITE = -1;
static const ShortInt AQ_NOT_DEFINED = -1;
extern PACKAGE TQueueTableList* QueueTableList;

}	/* namespace Oraaq */
using namespace Oraaq;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraaqHPP
