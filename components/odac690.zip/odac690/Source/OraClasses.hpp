// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Oraclasses.pas' rev: 21.00

#ifndef OraclassesHPP
#define OraclassesHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Clrclasses.hpp>	// Pascal unit
#include <Fmtbcd.hpp>	// Pascal unit
#include <Sqltimst.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Syncobjs.hpp>	// Pascal unit
#include <Memdata.hpp>	// Pascal unit
#include <Craccess.hpp>	// Pascal unit
#include <Memutils.hpp>	// Pascal unit
#include <Crparser.hpp>	// Pascal unit
#include <Oracall.hpp>	// Pascal unit
#include <Oraerror.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Oraclasses
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TTransactionMode { tmReadOnly, tmReadWrite, tmReadCommitted, tmSerializable };
#pragma option pop

#pragma option push -b-
enum TConnectMode { cmNormal, cmSysOper, cmSysDBA, cmSysASM };
#pragma option pop

class DELPHICLASS TOraParamDesc;
class DELPHICLASS TOCICommand;
class DELPHICLASS TOraCursor;
class DELPHICLASS TOraLob;
class DELPHICLASS TOraFile;
class DELPHICLASS TOraTimeStamp;
class DELPHICLASS TOraInterval;
class DELPHICLASS TOraNumber;
class PASCALIMPLEMENTATION TOraParamDesc : public Craccess::TParamDesc
{
	typedef Craccess::TParamDesc inherited;
	
private:
	void *FValue;
	int FValueSize;
	void *FActualLengthPtr;
	void *FDefIndicator;
	void *FIndicator;
	bool FTable;
	int FLength;
	void *FHandle;
	int FBindBufferSize;
	int FBlobPiece;
	bool FQuotedName;
	int FLen;
	bool FTableIndicator;
	bool FHasDefault;
	bool FBufferAllocated;
	bool FIsResult;
	TOCICommand* FOwner;
	int __fastcall GetActualLength(void);
	void __fastcall SetActualLength(int Value);
	__property int ActualLength = {read=GetActualLength, write=SetActualLength, nodefault};
	
protected:
	void __fastcall AllocBuffer(void);
	void __fastcall FreeBuffer(void);
	void __fastcall CheckRange(int Index);
	__property Name;
	__property DataType;
	__property SubDataType;
	__property ParamType;
	__property Size;
	void __fastcall ClearBindData(void);
	
public:
	__fastcall virtual TOraParamDesc(void);
	__fastcall virtual ~TOraParamDesc(void);
	virtual void __fastcall SetDataType(System::Word Value);
	virtual void __fastcall SetSize(int Value);
	void __fastcall SetTable(bool Value);
	void __fastcall SetLength(int Value);
	void __fastcall SetHasDefault(bool Value);
	void __fastcall SetIsResult(bool Value);
	bool __fastcall GetTable(void);
	int __fastcall GetLength(void);
	bool __fastcall GetHasDefault(void);
	bool __fastcall GetIsResult(void);
	short __fastcall GetIndicator(int Index);
	void __fastcall SetIndicator(int Index, short Value);
	void * __fastcall ValuePtr(void);
	int __fastcall GetValueSize(void);
	void __fastcall SetValuePtr(void * Buf);
	void * __fastcall IndicatorPtr(void);
	void __fastcall SyncIndicator(void);
	System::TDateTime __fastcall GetItemAsDateTime(int Index);
	void __fastcall SetItemAsDateTime(int Index, System::TDateTime Value);
	double __fastcall GetItemAsFloat(int Index);
	void __fastcall SetItemAsFloat(int Index, double Value);
	int __fastcall GetItemAsInteger(int Index);
	void __fastcall SetItemAsInteger(int Index, int Value);
	System::Currency __fastcall GetItemAsCurrency(int Index);
	void __fastcall SetItemAsCurrency(int Index, System::Currency Value);
	__int64 __fastcall GetItemAsLargeInt(int Index);
	void __fastcall SetItemAsLargeInt(int Index, __int64 Value);
	void __fastcall GetItemAsBcd(int Index, Fmtbcd::TBcd &Value);
	void __fastcall SetItemAsBcd(int Index, const Fmtbcd::TBcd &Value);
	void __fastcall GetItemAsSQLTimeStamp(int Index, Sqltimst::TSQLTimeStamp &Value);
	void __fastcall SetItemAsSQLTimeStamp(int Index, const Sqltimst::TSQLTimeStamp &Value);
	System::AnsiString __fastcall GetItemAsAnsiString(int Index);
	void __fastcall SetItemAsAnsiString(int Index, const System::AnsiString Value);
	System::WideString __fastcall GetItemAsWideString(int Index);
	void __fastcall SetItemAsWideString(int Index, const System::WideString Value);
	bool __fastcall GetItemAsBoolean(int Index);
	void __fastcall SetItemAsBoolean(int Index, bool Value);
	void __fastcall SetItemAsObject(int Index, Memdata::TSharedObject* Value);
	Memdata::TSharedObject* __fastcall GetItemAsObject(int Index);
	System::Variant __fastcall GetItemAsVariant(int Index);
	void __fastcall SetItemAsVariant(int Index, const System::Variant &Value);
	virtual System::Variant __fastcall GetValue(void);
	virtual void __fastcall SetValue(const System::Variant &Value);
	Memdata::TBlob* __fastcall GetAsBlobRef(void);
	TOraCursor* __fastcall GetAsCursor(void);
	TOraLob* __fastcall GetAsOraBlob(void);
	TOraFile* __fastcall GetAsBFile(void);
	TOraTimeStamp* __fastcall GetAsTimeStamp(void);
	TOraInterval* __fastcall GetAsInterval(void);
	TOraNumber* __fastcall GetAsNumber(void);
	virtual Memdata::TSharedObject* __fastcall GetObject(void);
	virtual void __fastcall SetObject(Memdata::TSharedObject* Value);
	virtual bool __fastcall GetNull(void);
	virtual void __fastcall SetNull(const bool Value);
	bool __fastcall GetItemNull(int Index);
	void __fastcall SetItemNull(int Index, bool Value);
};


typedef void __fastcall (__closure *TRunMethod)(void);

typedef void __fastcall (__closure *TEndMethod)(Sysutils::Exception* E);

class DELPHICLASS TMethodDesc;
class PASCALIMPLEMENTATION TMethodDesc : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	TRunMethod RunMethod;
	TEndMethod EndMethod;
	HWND hWindow;
public:
	/* TObject.Create */ inline __fastcall TMethodDesc(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TMethodDesc(void) { }
	
};


#pragma option push -b-
enum TNlsParamType { nlsDateLanguage, nlsDateFormat, nlsNumericCharacters, nlsTimeStampFormat, nlsTimeStampTZFormat };
#pragma option pop

struct TNlsSessionParam
{
	
public:
	System::UnicodeString Name;
	System::UnicodeString Value;
	bool IsUserDefined;
};


typedef void __fastcall (__closure *TFailoverCallback)(unsigned FailoverState, unsigned FailoverType, bool &Retry);

#pragma option push -b-
enum TConnectionType { ctDefault, ctOCIPooled, ctMTSPooled };
#pragma option pop

#pragma option push -b-
enum TOptimizerMode { omDefault, omFirstRows1000, omFirstRows100, omFirstRows10, omFirstRows1, omFirstRows, omAllRows, omChoose, omRule };
#pragma option pop

class DELPHICLASS TOCIConnection;
class PASCALIMPLEMENTATION TOCIConnection : public Craccess::TCRConnection
{
	typedef Craccess::TCRConnection inherited;
	
private:
	typedef StaticArray<TNlsSessionParam, 5> _TOCIConnection__1;
	
	
private:
	bool FThreadSafety;
	System::Word FMaxStringSize;
	Oracall::TOCICallStyle FOCICallStyle;
	Oracall::TOCICallStyle FOCICallStyleCommand;
	int FLastError;
	TConnectMode FConnectMode;
	bool FEnableIntegers;
	bool FEnableLargeint;
	bool FEnableNumbers;
	bool FEnableWideOraClob;
	System::UnicodeString FInternalName;
	TOCICommand* FCommand;
	System::UnicodeString FOracleVersionSt;
	System::UnicodeString FOracleVersionFull;
	System::Word FOracleVersion;
	TOCIConnection* FProxyConnection;
	bool FDisconnectMode;
	int FConnectionTimeout;
	System::UnicodeString FOCIPoolName;
	bool FStatementCache;
	int FStatementCacheSize;
	System::UnicodeString FHomeName;
	bool FDirect;
	bool FUnicodeEnv;
	System::UnicodeString FClientIdentifier;
	TOptimizerMode FOptimizerMode;
	System::UnicodeString FSchema;
	System::UnicodeString FCachedSchema;
	bool FEnableSQLTimeStamp;
	bool FIntervalAsString;
	int FSmallintPrecision;
	int FIntegerPrecision;
	int FLargeIntPrecision;
	int FFloatPrecision;
	int FBCDPrecision;
	int FBCDScale;
	int FFmtBCDPrecision;
	int FFmtBCDScale;
	System::UnicodeString FCharset;
	System::Word FCharsetId;
	System::Word FCharLength;
	bool FQueryCharLength;
	bool FUseUnicode;
	_TOCIConnection__1 FNlsParams;
	Oracall::TCDA *LDA;
	Oracall::THDA *HDA;
	void *hSvcCtx;
	void *hServer;
	void *hSession;
	void *hOCIError;
	void *hOCIEnv;
	void *hOCIAuthInfo;
	TConnectionType FConnectionType;
	unsigned hBusy;
	void *hMTSSvcCtx;
	void __fastcall CheckCommand(void);
	void __fastcall GetSessionParameters(void);
	void __fastcall SetNlsParameter(const System::UnicodeString Name, const System::UnicodeString Value);
	System::Word __fastcall GetMaxStringSize(void);
	
protected:
	TFailoverCallback FOnFailover;
	void __fastcall SetStatementCacheSize(int Size);
	void __fastcall SetupEnvironment(void);
	void __fastcall SetOptimizerMode(void);
	void __fastcall SetClientIdentifier(void);
	virtual void __fastcall RaiseError(const System::UnicodeString Msg);
	virtual void __fastcall DoError(Sysutils::Exception* E, bool &Fail);
	virtual Craccess::TCRTransactionClass __fastcall GetTransactionClass(void);
	void __fastcall MTSCheck(int status);
	void __fastcall MTSError(int &ErrorCode, bool UseCallback);
	virtual void __fastcall Enlist(Craccess::TMTSTransaction* Transaction);
	virtual void __fastcall UnEnlist(Craccess::TMTSTransaction* Transaction);
	__property AutoCommit;
	__property EnableBCD;
	__property EnableFMTBCD;
	__property bool ConvertEOL = {read=FConvertEOL, nodefault};
	
public:
	__fastcall virtual TOCIConnection(void);
	__fastcall virtual ~TOCIConnection(void);
	void __fastcall CheckOCI(void);
	void __fastcall CheckOCI73(void);
	void __fastcall CheckOCI80(void);
	void __fastcall Check(int Status);
	virtual void __fastcall OraError(Oracall::TOCICallStyle FOCICallStyle, int &ErrorCode, bool UseCallback, System::TObject* Component);
	void __fastcall SetConnectionType(TConnectionType ConnectionType);
	virtual void __fastcall Connect(const System::UnicodeString ConnectString);
	virtual void __fastcall Disconnect(void);
	System::Word __fastcall GetOracleVersion(void);
	virtual System::UnicodeString __fastcall GetServerVersion(void);
	virtual System::UnicodeString __fastcall GetServerVersionFull(void);
	virtual System::UnicodeString __fastcall GetClientVersion(void);
	void __fastcall SetCurrentSchema(System::UnicodeString SchemaName);
	System::UnicodeString __fastcall GetCurrentSchema(void);
	System::UnicodeString __fastcall GetDefaultSchema(void);
	System::UnicodeString __fastcall GetCachedSchema(void);
	void __fastcall BreakExec(void);
	void __fastcall Busy(void);
	void __fastcall BusyWait(void);
	void __fastcall Release(void);
	Classes::TThread* __fastcall RunThread(TRunMethod RunMethod, TEndMethod EndMethod);
	bool __fastcall StopThread(Classes::TThread* &hThread, bool APeekMessage = false);
	Oracall::PCDA __fastcall GetLDA(void);
	void __fastcall SetLDA(Oracall::PCDA Value);
	void * __fastcall GetSvcCtx(void);
	void __fastcall SetSvcCtx(void * Value);
	void __fastcall ChangePassword(System::UnicodeString NewPassword);
	virtual void __fastcall AssignConnect(Craccess::TCRConnection* Source);
	void __fastcall SetNonBlocking(bool Value);
	Oracall::TOCICallStyle __fastcall GetOCICallStyle(void);
	void __fastcall SetOCICallStyle(Oracall::TOCICallStyle Value);
	Oracall::TOCICallStyle __fastcall GetOCICallStyleCommand(void);
	int __fastcall GetLastError(void);
	void __fastcall SetLastError(int Value);
	void __fastcall GetTableFields(System::UnicodeString TableName, Classes::TStringList* Fields);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	virtual bool __fastcall CheckIsValid(void);
	virtual void __fastcall ReturnToPool(void);
	__property TFailoverCallback OnFailover = {read=FOnFailover, write=FOnFailover};
	__property TOCIConnection* ProxyConnection = {read=FProxyConnection, write=FProxyConnection};
	__property void * OCIEnv = {read=hOCIEnv};
	__property bool UnicodeEnv = {read=FUnicodeEnv, nodefault};
};


class PASCALIMPLEMENTATION TOraCursor : public Craccess::TCRCursor
{
	typedef Craccess::TCRCursor inherited;
	
private:
	Oracall::TCDA *FCDA;
	void * *phOCIStmt;
	void *hOCIError;
	void *hOCIEnv;
	bool FUnicodeEnv;
	Craccess::TCursorState FState;
	Oracall::TOCICallStyle FOCICallStyle;
	bool FScrollable;
	bool FStatementCache;
	int FPrefetchRows;
	void __fastcall DisablePrefetching(void);
	Oracall::PCDA __fastcall GetCDA(void);
	void * __fastcall GethOCIStmt(void);
	void __fastcall SethOCIStmt(void * Value);
	void * __fastcall GetOCIStmt(void);
	Oracall::ppOCIStmt __fastcall GetOCIStmtPtr(void);
	void __fastcall SetOCICallStyle(Oracall::TOCICallStyle Value);
	void __fastcall SetPrefetchRows(int Value);
	__property void * hOCIStmt = {read=GethOCIStmt, write=SethOCIStmt};
	
protected:
	void __fastcall Check(int Status);
	void __fastcall CheckOCI(void);
	void __fastcall CheckOCI73(void);
	void __fastcall CheckOCI80(void);
	
public:
	__fastcall TOraCursor(void);
	__fastcall virtual ~TOraCursor(void);
	void __fastcall AllocCursor(bool StatementCache = false);
	void __fastcall FreeCursor(void);
	virtual void __fastcall Disconnect(void);
	virtual bool __fastcall CanFetch(void);
	__property Oracall::PCDA CDA = {read=GetCDA};
	__property void * OCIStmt = {read=GetOCIStmt};
	__property Oracall::ppOCIStmt OCIStmtPtr = {read=GetOCIStmtPtr};
	__property Craccess::TCursorState State = {read=FState, write=FState, nodefault};
	__property Oracall::TOCICallStyle OCICallStyle = {read=FOCICallStyle, write=SetOCICallStyle, nodefault};
	__property int PrefetchRows = {read=FPrefetchRows, write=SetPrefetchRows, nodefault};
};


#pragma option push -b-
enum TChangeNotifyEventType { cneNone, cneStartup, cneShutdown, cneShutdownAny, cneDropDB, cneDereg, cneObjChange };
#pragma option pop

class DELPHICLASS TCustomNotifyChanges;
class PASCALIMPLEMENTATION TCustomNotifyChanges : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	typedef DynamicArray<System::TObject*> _TCustomNotifyChanges__1;
	
	
private:
	int __fastcall GetCount(void);
	
protected:
	_TCustomNotifyChanges__1 FItems;
	virtual System::TObject* __fastcall CreateItem(void * ChangeDescriptor) = 0 ;
	
public:
	__fastcall TCustomNotifyChanges(void * OCIColl);
	__fastcall virtual ~TCustomNotifyChanges(void);
	__property int Count = {read=GetCount, nodefault};
};


class DELPHICLASS TNotifyRowChange;
class PASCALIMPLEMENTATION TNotifyRowChange : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FRowId;
	Oracall::TChangeNotifyOperations FOperations;
	
public:
	__fastcall TNotifyRowChange(void * ChangeDescriptor);
	__property System::UnicodeString RowId = {read=FRowId};
	__property Oracall::TChangeNotifyOperations Operations = {read=FOperations, nodefault};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TNotifyRowChange(void) { }
	
};


class DELPHICLASS TNotifyRowChanges;
class PASCALIMPLEMENTATION TNotifyRowChanges : public TCustomNotifyChanges
{
	typedef TCustomNotifyChanges inherited;
	
public:
	TNotifyRowChange* operator[](int Index) { return Changes[Index]; }
	
private:
	TNotifyRowChange* __fastcall GetChanges(int Index);
	
protected:
	virtual System::TObject* __fastcall CreateItem(void * ChangeDescriptor);
	
public:
	__property TNotifyRowChange* Changes[int Index] = {read=GetChanges/*, default*/};
public:
	/* TCustomNotifyChanges.Create */ inline __fastcall TNotifyRowChanges(void * OCIColl) : TCustomNotifyChanges(OCIColl) { }
	/* TCustomNotifyChanges.Destroy */ inline __fastcall virtual ~TNotifyRowChanges(void) { }
	
};


class DELPHICLASS TNotifyTableChange;
class PASCALIMPLEMENTATION TNotifyTableChange : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::UnicodeString FTableName;
	Oracall::TChangeNotifyOperations FOperations;
	TNotifyRowChanges* FRowChanges;
	
public:
	__fastcall TNotifyTableChange(void * ChangeDescriptor);
	__fastcall virtual ~TNotifyTableChange(void);
	__property System::UnicodeString TableName = {read=FTableName};
	__property Oracall::TChangeNotifyOperations Operations = {read=FOperations, nodefault};
	__property TNotifyRowChanges* RowChanges = {read=FRowChanges};
};


class DELPHICLASS TNotifyTableChanges;
class PASCALIMPLEMENTATION TNotifyTableChanges : public TCustomNotifyChanges
{
	typedef TCustomNotifyChanges inherited;
	
public:
	TNotifyTableChange* operator[](int Index) { return Changes[Index]; }
	
private:
	TNotifyTableChange* __fastcall GetChanges(int Index);
	
protected:
	virtual System::TObject* __fastcall CreateItem(void * ChangeDescriptor);
	
public:
	__property TNotifyTableChange* Changes[int Index] = {read=GetChanges/*, default*/};
public:
	/* TCustomNotifyChanges.Create */ inline __fastcall TNotifyTableChanges(void * OCIColl) : TCustomNotifyChanges(OCIColl) { }
	/* TCustomNotifyChanges.Destroy */ inline __fastcall virtual ~TNotifyTableChanges(void) { }
	
};


class DELPHICLASS TNotifyChange;
class PASCALIMPLEMENTATION TNotifyChange : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TChangeNotifyEventType FNotifyType;
	TNotifyTableChanges* FTableChanges;
	
public:
	__fastcall TNotifyChange(void * ChangeDescriptor);
	__fastcall virtual ~TNotifyChange(void);
	__property TChangeNotifyEventType NotifyType = {read=FNotifyType, nodefault};
	__property TNotifyTableChanges* TableChanges = {read=FTableChanges};
};


typedef void __fastcall (__closure *TChangeNotifyCallback)(TChangeNotifyEventType NotifyType, TNotifyTableChanges* TableChanges);

class DELPHICLASS TOCIChangeNotification;
class PASCALIMPLEMENTATION TOCIChangeNotification : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	void *FGCHandle;
	bool FEnabled;
	bool FPersistent;
	int FTimeOut;
	Oracall::TChangeNotifyDMLOperations FOperations;
	TChangeNotifyCallback FOnChange;
	void *hOCISubscription;
	void * __fastcall GetGCHandle(void);
	void __fastcall SetEnabled(bool Value);
	int __fastcall CallbackChangeNotify(void * pCtx, void * pSubscrHp, void * pPayload, unsigned iPayloadLen, void * pDescriptor, unsigned iMode);
	
protected:
	__property void * GCHandle = {read=GetGCHandle};
	
public:
	__fastcall TOCIChangeNotification(void);
	__fastcall virtual ~TOCIChangeNotification(void);
	bool __fastcall SetProp(int Prop, const System::Variant &Value);
	bool __fastcall GetProp(int Prop, System::Variant &Value);
	void * __fastcall GetSubscriptionHandle(TOCIConnection* Connection);
	void __fastcall Register(TOCIConnection* Connection);
	void __fastcall Unregister(TOCIConnection* Connection);
	bool __fastcall IsActive(void);
	__property TChangeNotifyCallback OnChange = {read=FOnChange, write=FOnChange};
};


class PASCALIMPLEMENTATION TOCICommand : public Craccess::TCRCommand
{
	typedef Craccess::TCRCommand inherited;
	
private:
	TOraCursor* FCursor;
	TOraCursor* FCursorRef;
	Oracall::TOCICallStyle FOCICallStyle;
	bool FNonBlocking;
	System::Word FSQLType;
	System::Word FLastSQLType;
	int FRowsProcessed;
	int FFetchedRows;
	System::Word FErrorOffset;
	int FIterCount;
	bool FFieldsAsString;
	bool FCacheLobs;
	bool FStoreRowId;
	System::UnicodeString FRowId;
	bool FRawAsString;
	bool FNumberAsString;
	bool FUseDefaultDataTypes;
	int FSmallintPrecision;
	int FIntegerPrecision;
	int FLargeIntPrecision;
	int FFloatPrecision;
	int FBCDPrecision;
	int FBCDScale;
	int FFmtBCDPrecision;
	int FFmtBCDScale;
	bool FForceUnprepare;
	void *FGCHandle;
	bool FTemporaryLobUpdate;
	bool FStatementCache;
	TOCIChangeNotification* FChangeNotification;
	bool FCheckParamHasDefault;
	bool FUseResultParams;
	void *hOCIError;
	unsigned hBusy;
	Classes::TThread* hExecThread;
	Syncobjs::TEvent* hExecuted;
	void * __fastcall GetGCHandle(void);
	System::UnicodeString __fastcall RemoveCRSymbols(System::UnicodeString SQLText, int &ErrorOffset);
	
protected:
	TOCIConnection* FConnection;
	void __fastcall DoExecute(void);
	void __fastcall EndExecute(Sysutils::Exception* E);
	virtual void __fastcall RaiseError(const System::UnicodeString Msg);
	void __fastcall CheckOCI(void);
	void __fastcall CheckOCI73(void);
	void __fastcall CheckOCI80(void);
	void __fastcall CheckActive(void);
	void __fastcall CheckInactive(void);
	void __fastcall CheckSession(void);
	void __fastcall Check(int Status);
	int __fastcall GetSmallintPrecision(void);
	int __fastcall GetIntegerPrecision(void);
	int __fastcall GetLargeintPrecision(void);
	int __fastcall GetFloatPrecision(void);
	int __fastcall GetBCDPrecision(void);
	int __fastcall GetBCDScale(void);
	int __fastcall GetFmtBCDPrecision(void);
	int __fastcall GetFmtBCDScale(void);
	int __fastcall GetOraType7(int DataType, int SubDataType);
	bool __fastcall GetFieldDesc7(int FieldNo, Memdata::TFieldDesc* &Field, bool LongString, bool FlatBuffer);
	System::Word __fastcall InternalFetch7(System::Word Rows);
	int __fastcall InternalFetchPiece7(void);
	int __fastcall DescSP(const System::UnicodeString objnam, Oracall::pub2 ovrld, Oracall::pub2 pos, Oracall::pub2 level, void * argnam, Oracall::pub2 arnlen, Oracall::pub2 dtype, Oracall::pub1 defsup, Oracall::pub1 mode, Oracall::pub4 dtsiz, Oracall::psb2 prec, Oracall::psb2 scale, Oracall::pub1 radix, Oracall::pub4 spare, unsigned &arrsiz);
	void __fastcall InitProcParams7(System::UnicodeString Name, int Overload);
	int __fastcall GetOraType8(int DataType, int SubDataType);
	bool __fastcall GetFieldDesc8(int FieldNo, Memdata::TFieldDesc* &Field, bool LongString, bool FlatBuffer);
	System::Word __fastcall InternalFetch8(System::Word Rows, int Orientation, int Offset);
	System::Word __fastcall InternalExecuteFetch8(System::Word Rows);
	int __fastcall InternalFetchPiece8(int Orientation, int Offset);
	void __fastcall InitProcParams8(System::UnicodeString Name, int Overload);
	int __fastcall CallbackInBind(void * Bind, unsigned Iter, unsigned Index, void * &Buf, unsigned &BufLen, System::Byte &PieceStatus, void * &Ind);
	int __fastcall CallbackOutBind(void * Bind, unsigned Iter, unsigned Index, void * &Buf, Oracall::pub4 &BufLen, System::Byte &PieceStatus, void * &Ind);
	void __fastcall SetArrayLength(int Value);
	bool __fastcall GetActive(void);
	__property Params;
	__property Executing;
	__property void * GCHandle = {read=GetGCHandle};
	
public:
	__fastcall virtual TOCICommand(void);
	__fastcall virtual ~TOCICommand(void);
	__classmethod virtual Craccess::TSQLInfoClass __fastcall GetSQLInfoClass();
	__classmethod virtual Crparser::TSQLParserClass __fastcall GetParserClass();
	int __fastcall GetOraType(int DataType, int SubDataType);
	void __fastcall InternalOpen(void);
	void __fastcall InternalParse(void);
	void __fastcall InternalPrepare(void);
	virtual System::UnicodeString __fastcall ParseSQL(const System::UnicodeString SQL, Craccess::TParamDescs* Params, bool ReplaceAll = true, const System::UnicodeString RenamePrefix = L"")/* overload */;
	void __fastcall InitProcParams(System::UnicodeString Name, int Overload);
	virtual System::UnicodeString __fastcall CreateProcCall(const System::UnicodeString Name, bool NeedDescribe, bool IsQuery);
	bool __fastcall NeedBindParam(TOraParamDesc* Param);
	void __fastcall BindParam(TOraParamDesc* Param);
	int __fastcall InternalExecute(int Mode, int Rows = 0x0);
	void __fastcall Exec(void);
	bool __fastcall GetFieldDesc(int FieldNo, Memdata::TFieldDesc* &Field, bool LongString, bool FlatBuffer);
	void __fastcall DefineData(Memdata::TFieldDesc* Field, void * Buf, Oracall::psb2 Ind);
	void __fastcall DefineArrayData(Memdata::TFieldDesc* Field, void * Buf, Oracall::psb2 Ind, int BufSkip, int IndSkip);
	void __fastcall DefinePieceData(Memdata::TFieldDesc* Field, void * Buf, Oracall::psb2 Ind);
	void __fastcall DefineDynamic(Memdata::TFieldDesc* Field, void * Owner, void * Proc, int CharsetId);
	System::Word __fastcall InternalFetch(System::Word Rows, int Orientation = 0x2, int Offset = 0x0);
	int __fastcall InternalFetchPiece(int Orientation = 0x2, int Offset = 0x0);
	void __fastcall InternalCancel(void);
	void __fastcall InternalClose(void);
	void __fastcall Finish(void);
	void __fastcall GetPI(void * &Handle, System::Byte &Piece, void * &Buf, unsigned &Iteration, unsigned &Index, Craccess::TParamDirection &Mode);
	void __fastcall SetPI(void * Handle, unsigned HType, System::Byte Piece, void * Buf, unsigned &BufLen, Oracall::psb2 Ind);
	bool __fastcall NativeCursor(void);
	bool __fastcall RowsReturn(void);
	void __fastcall CheckRowsReturn(void);
	virtual Craccess::TParamDesc* __fastcall AddParam(void);
	void __fastcall BindParams(void);
	HIDESBASE TOraParamDesc* __fastcall GetParam(int Index);
	void __fastcall BreakExec(void);
	void __fastcall HardBreak(void);
	void __fastcall Busy(void);
	void __fastcall Release(void);
	virtual void __fastcall Prepare(void);
	virtual void __fastcall Unprepare(void);
	virtual bool __fastcall GetPrepared(void);
	virtual void __fastcall Execute(int Iters = 0x1);
	virtual void __fastcall SetConnection(Craccess::TCRConnection* Value);
	virtual Craccess::TCRCursor* __fastcall GetCursor(void);
	virtual void __fastcall SetCursor(Craccess::TCRCursor* Value);
	TOraCursor* __fastcall GetNextCursor(void);
	void __fastcall SetOCICallStyle(Oracall::TOCICallStyle Value);
	virtual Craccess::TCursorState __fastcall GetCursorState(void);
	virtual void __fastcall SetCursorState(Craccess::TCursorState Value);
	int __fastcall GetSQLType(void);
	System::UnicodeString __fastcall GetRowId(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	__property TOCIChangeNotification* ChangeNotification = {read=FChangeNotification, write=FChangeNotification};
	
/* Hoisted overloads: */
	
public:
	inline void __fastcall  ParseSQL(bool ReplaceAll = true){ Craccess::TCRCommand::ParseSQL(ReplaceAll); }
	
};


class DELPHICLASS TOCISQLInfo;
class PASCALIMPLEMENTATION TOCISQLInfo : public Craccess::TSQLInfo
{
	typedef Craccess::TSQLInfo inherited;
	
public:
	virtual Craccess::TIdentCase __fastcall IdentCase(void);
	virtual System::UnicodeString __fastcall NormalizeName(const System::UnicodeString Value, const System::WideChar LeftQ, const System::WideChar RightQ, bool QuoteNames = false, bool UnQuoteNames = false)/* overload */;
	virtual System::UnicodeString __fastcall NormalizeName(const System::UnicodeString Value, bool QuoteNames = false, bool UnQuoteNames = false)/* overload */;
	virtual void __fastcall SplitObjectName(const System::UnicodeString Name, Craccess::TExtTableInfo &Info);
	virtual void __fastcall ParseTablesInfo(const System::UnicodeString SQL, Craccess::TCRTablesInfo* TablesInfo);
public:
	/* TSQLInfo.Create */ inline __fastcall virtual TOCISQLInfo(void) : Craccess::TSQLInfo() { }
	
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TOCISQLInfo(void) { }
	
};


class DELPHICLASS TOCIFieldDesc;
class PASCALIMPLEMENTATION TOCIFieldDesc : public Craccess::TCRFieldDesc
{
	typedef Craccess::TCRFieldDesc inherited;
	
public:
	virtual bool __fastcall IsNational(void);
public:
	/* TFieldDesc.Create */ inline __fastcall virtual TOCIFieldDesc(void) : Craccess::TCRFieldDesc() { }
	/* TFieldDesc.Destroy */ inline __fastcall virtual ~TOCIFieldDesc(void) { }
	
};


typedef void __fastcall (__closure *TModifyAction)(void);

class DELPHICLASS TOCIRecordSet;
class PASCALIMPLEMENTATION TOCIRecordSet : public Craccess::TCRRecordSet
{
	typedef Craccess::TCRRecordSet inherited;
	
private:
	bool FAutoClose;
	bool FDeferredLobRead;
	Classes::TThread* hExecFetchThread;
	Classes::TThread* hFetchAllThread;
	TOraCursor* FFetchCursor;
	void *FFetchBlock;
	int FFetchBlockItemSize;
	bool FPieceFetch;
	void *FFetchItems;
	bool FFetchAbsolute;
	int FFetchStart;
	int FFetchEnd;
	bool FNoData;
	void *FGCHandle;
	bool FHasConvertedFields;
	Syncobjs::TEvent* hEvent;
	bool FStopFetch;
	bool FFetching;
	bool FHasObjectFields;
	System::UnicodeString FTempFilterText;
	bool FDisableInitFields;
	bool FDisconnectedMode;
	bool FUseUnicode;
	int FCharLength;
	void __fastcall InitFetchCursor(void);
	bool __fastcall FetchArray(bool FetchBack = false);
	bool __fastcall FetchPiece(bool FetchBack = false);
	void __fastcall AllocFetchBlock(void);
	void __fastcall FreeFetchBlock(void);
	bool __fastcall GetNonBlocking(void);
	void * __fastcall GetGCHandle(void);
	bool __fastcall GetDisconnectedMode(void);
	bool __fastcall GetUseUnicode(void);
	int __fastcall GetCharLength(void);
	bool __fastcall IsConvertedFieldType(System::Word DataType);
	
protected:
	TOCICommand* FCommand;
	TOCIConnection* FConnection;
	virtual void __fastcall CreateCommand(void);
	virtual void __fastcall SetCommand(Craccess::TCRCommand* Value);
	virtual void __fastcall InternalPrepare(void);
	virtual void __fastcall InternalUnPrepare(void);
	virtual void __fastcall InternalOpen(bool DisableInitFields = false);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall InternalInitFields(void);
	virtual void __fastcall ExecFetch(bool DisableInitFields);
	virtual System::Word __fastcall GetIndicatorSize(void);
	virtual bool __fastcall GetEOF(void);
	virtual void __fastcall SetFilterText(System::UnicodeString Value);
	virtual bool __fastcall Fetch(bool FetchBack = false);
	virtual bool __fastcall CanFetchBack(void);
	void __fastcall FreeAllItems(void);
	void __fastcall DoExecFetch(void);
	void __fastcall EndExecFetch(Sysutils::Exception* E);
	void __fastcall DoFetchAll(void);
	void __fastcall DoFetchAllPulse(void);
	void __fastcall EndFetchAll(Sysutils::Exception* E);
	int __fastcall CallbackDefine(void * Define, unsigned Iter, void * &Buf, Oracall::pub4 &BufLen, System::Byte &PieceStatus, void * &Ind);
	__property void * GCHandle = {read=GetGCHandle};
	__property bool DisconnectedMode = {read=GetDisconnectedMode, nodefault};
	__property bool UseUnicode = {read=GetUseUnicode, nodefault};
	__property int CharLength = {read=GetCharLength, nodefault};
	
public:
	__fastcall virtual TOCIRecordSet(void);
	__fastcall virtual ~TOCIRecordSet(void);
	virtual bool __fastcall IsFullReopen(void);
	virtual void __fastcall Reopen(void);
	void __fastcall SetCommandType(void);
	virtual void __fastcall ExecCommand(void);
	void __fastcall BreakExec(void);
	virtual void __fastcall Disconnect(void);
	virtual void __fastcall FetchAll(void);
	virtual bool __fastcall RowsReturn(void);
	virtual Memdata::TFieldDescClass __fastcall GetFieldDescType(void);
	virtual void __fastcall SetNull(System::Word FieldNo, void * RecBuf, bool Value);
	virtual bool __fastcall GetNull(System::Word FieldNo, void * RecBuf);
	virtual void __fastcall GetDateFromBuf(void * Buf, Memdata::TFieldDesc* Field, void * Date, Memdata::TDateFormat Format);
	virtual void __fastcall PutDateToBuf(void * Buf, Memdata::TFieldDesc* Field, void * Date, Memdata::TDateFormat Format);
	__classmethod virtual bool __fastcall IsBlobFieldType(System::Word DataType);
	__classmethod virtual bool __fastcall IsComplexFieldType(System::Word DataType);
	virtual void __fastcall GetFieldData(Memdata::TFieldDesc* Field, void * FieldBuf, void * Dest);
	virtual void __fastcall GetFieldAsVariant(System::Word FieldNo, void * RecBuf, System::Variant &Value);
	virtual void __fastcall PutFieldAsVariant(System::Word FieldNo, void * RecBuf, const System::Variant &Value);
	virtual void __fastcall CreateComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall FreeComplexFields(void * RecBuf, bool WithBlob);
	virtual void __fastcall CopyComplexFields(void * Source, void * Dest, bool WithBlob);
	virtual int __fastcall CompareFieldValue(void * ValuePtr, const int ValueType, Memdata::TFieldDesc* FieldDesc, void * RecBuf, const Memdata::TCompareOptions Options);
	virtual int __fastcall CompareFields(void * RecBuf1, void * RecBuf2, Memdata::TFieldDesc* FieldDesc, Memdata::TCompareOptions Options = Memdata::TCompareOptions() )/* overload */;
	virtual void __fastcall SortItems(void);
	virtual void __fastcall FilterUpdated(void);
	virtual void __fastcall SetToBegin(void);
	virtual void __fastcall SetToEnd(void);
	virtual void __fastcall GetBookmark(Memdata::PRecBookmark Bookmark);
	virtual void __fastcall SetToBookmark(Memdata::PRecBookmark Bookmark);
	int __fastcall GetBlockFetchPos(Memdata::PBlockHeader Block);
	int __fastcall GetItemFetchPos(Memdata::PItemHeader Item);
	virtual void __fastcall SetConnection(Craccess::TCRConnection* Value);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	
/* Hoisted overloads: */
	
public:
	inline int __fastcall  CompareFields(void * RecBuf1, void * RecBuf2, Memdata::TSortColumn* SortColumn){ return Memdata::TMemData::CompareFields(RecBuf1, RecBuf2, SortColumn); }
	
};


#pragma option push -b-
enum TLobType { ltBlob, ltClob, ltNClob };
#pragma option pop

class PASCALIMPLEMENTATION TOraLob : public Memdata::TCompressedBlob
{
	typedef Memdata::TCompressedBlob inherited;
	
private:
	TOCIConnection* FConnection;
	void *FSvcCtx;
	void * *phLobLocator;
	void *hOCIEnv;
	bool FUnicodeEnv;
	bool FNativeHandle;
	bool FCached;
	int FCharsetForm;
	TLobType FLobType;
	System::Byte FCharLength;
	bool FIsTemporary;
	void * __fastcall GetOCILobLocator(void);
	void * __fastcall GethOCILobLocator(void);
	void __fastcall SethOCILobLocator(void * Value);
	void __fastcall SetOCILobLocator(void * Value);
	Oracall::ppOCILobLocator __fastcall GetOCILobLocatorPtr(void);
	void __fastcall SetCached(const bool Value);
	void __fastcall SetOCISvcCtx(const void * Value);
	void __fastcall SetConnection(const TOCIConnection* Value);
	__property void * hLobLocator = {read=GethOCILobLocator, write=SethOCILobLocator};
	
protected:
	bool FNeedReadLob;
	void __fastcall Check(int Status);
	virtual void __fastcall CheckValue(void);
	virtual unsigned __fastcall GetSize(void);
	virtual int __fastcall GetSizeAnsi(void);
	void __fastcall CheckAlloc(void);
	void __fastcall CheckSession(void);
	void __fastcall CheckInit(void);
	void __fastcall CheckCharSetForm(void);
	virtual System::Byte __fastcall CharSize(void);
	void __fastcall ReadLob(Memdata::PPieceHeader &SharedPiece)/* overload */;
	
public:
	__fastcall TOraLob(void * ASvcCtx);
	__fastcall virtual ~TOraLob(void);
	virtual void __fastcall AllocLob(void);
	virtual void __fastcall FreeBlob(void);
	void __fastcall FreeLob(void);
	virtual void __fastcall Disconnect(void);
	void __fastcall Init(void);
	void __fastcall CreateTemporary(TLobType LobType);
	void __fastcall FreeTemporary(void);
	BOOL __fastcall IsTemporary(void);
	bool __fastcall IsInit(void);
	int __fastcall LengthLob(void);
	void __fastcall EnableBuffering(void);
	void __fastcall DisableBuffering(void);
	void __fastcall ReadLob(void)/* overload */;
	void __fastcall WriteLob(void);
	virtual unsigned __fastcall Read(unsigned Position, unsigned Count, void * Dest);
	virtual void __fastcall Write(unsigned Position, unsigned Count, void * Source);
	virtual void __fastcall Clear(void);
	virtual void __fastcall Truncate(unsigned NewSize);
	__property void * OCISvcCtx = {read=FSvcCtx, write=SetOCISvcCtx};
	__property TOCIConnection* Connection = {read=FConnection, write=SetConnection};
	__property void * OCILobLocator = {read=GetOCILobLocator, write=SetOCILobLocator};
	__property Oracall::ppOCILobLocator OCILobLocatorPtr = {read=GetOCILobLocatorPtr};
	__property bool Cached = {read=FCached, write=SetCached, nodefault};
	__property TLobType LobType = {read=FLobType, write=FLobType, nodefault};
};


class PASCALIMPLEMENTATION TOraFile : public TOraLob
{
	typedef TOraLob inherited;
	
private:
	bool FNeedRollback;
	System::UnicodeString FRollbackFileDir;
	System::UnicodeString FRollbackFileName;
	System::UnicodeString __fastcall GetFileDir(void);
	void __fastcall SetFileDir(const System::UnicodeString Value);
	System::UnicodeString __fastcall GetFileName(void);
	void __fastcall SetFileName(const System::UnicodeString Value);
	void __fastcall SetFileDirAndName(const System::UnicodeString FileDir, const System::UnicodeString FileName);
	
protected:
	bool CanRollback;
	virtual void __fastcall CheckValue(void);
	virtual System::Byte __fastcall CharSize(void);
	virtual void __fastcall SaveToRollback(void);
	
public:
	__fastcall virtual ~TOraFile(void);
	virtual void __fastcall AllocLob(void);
	virtual void __fastcall FreeBlob(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	HIDESBASE void __fastcall EnableRollback(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Cancel(void);
	void __fastcall Refresh(void);
	bool __fastcall IsOpen(void);
	bool __fastcall Exists(void);
	__property System::UnicodeString FileDir = {read=GetFileDir, write=SetFileDir};
	__property System::UnicodeString FileName = {read=GetFileName, write=SetFileName};
public:
	/* TOraLob.Create */ inline __fastcall TOraFile(void * ASvcCtx) : TOraLob(ASvcCtx) { }
	
};


class PASCALIMPLEMENTATION TOraTimeStamp : public Memdata::TSharedObject
{
	typedef Memdata::TSharedObject inherited;
	
private:
	void * *phOCIDateTime;
	unsigned FDescriptorType;
	System::Byte FPrecision;
	System::UnicodeString FFormat;
	bool FNativeHandle;
	void *FIndicator;
	System::UnicodeString __fastcall GetAsString(void);
	void __fastcall SetAsString(const System::UnicodeString Value);
	System::TDateTime __fastcall GetAsDateTime(void);
	void __fastcall SetAsDateTime(System::TDateTime Value);
	System::UnicodeString __fastcall GetTimeZone(void);
	void * __fastcall GethOCIDateTime(void);
	void __fastcall SethOCIDateTime(void * Value);
	void * __fastcall GetOCIDateTime(void);
	void __fastcall SetOCIDateTime(const void * Value);
	void __fastcall SetDescriptorType(const unsigned Value);
	Oracall::ppOCIDateTime __fastcall GetOCIDateTimePtr(void);
	HIDESBASE void __fastcall CheckValid(void);
	void __fastcall SetFormat(const System::UnicodeString AFormat);
	__property void * hOCIDateTime = {read=GethOCIDateTime, write=SethOCIDateTime};
	
public:
	__fastcall TOraTimeStamp(System::Word DataType);
	__fastcall virtual ~TOraTimeStamp(void);
	void __fastcall AllocDateTime(void);
	void __fastcall FreeDateTime(void);
	virtual void __fastcall Disconnect(void);
	void __fastcall AssignTo(TOraTimeStamp* Dest);
	int __fastcall Compare(TOraTimeStamp* Dest);
	bool __fastcall GetIsNull(void);
	void __fastcall SetIsNull(bool Value);
	void __fastcall Construct(short Year, System::Byte Month, System::Byte Day, System::Byte Hour, System::Byte Min, System::Byte Sec, unsigned FSec, System::UnicodeString TimeZone);
	void __fastcall GetDate(short &Year, System::Byte &Month, System::Byte &Day);
	void __fastcall SetDate(short Year, System::Byte Month, System::Byte Day);
	void __fastcall GetTime(System::Byte &Hour, System::Byte &Min, System::Byte &Sec, unsigned &FSec);
	void __fastcall SetTime(System::Byte Hour, System::Byte Min, System::Byte Sec, unsigned FSec);
	void __fastcall GetTimeZoneOffset(System::ShortInt &Hour, System::ShortInt &Min);
	void __fastcall SetTimeZoneOffset(System::ShortInt TZHour, System::ShortInt TZMin);
	__property unsigned DescriptorType = {read=FDescriptorType, write=SetDescriptorType, nodefault};
	__property void * OCIDateTime = {read=GetOCIDateTime, write=SetOCIDateTime};
	__property Oracall::ppOCIDateTime OCIDateTimePtr = {read=GetOCIDateTimePtr};
	__property System::UnicodeString Format = {read=FFormat, write=SetFormat};
	__property System::Byte Precision = {read=FPrecision, write=FPrecision, nodefault};
	__property System::UnicodeString TimeZone = {read=GetTimeZone};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	__property System::TDateTime AsDateTime = {read=GetAsDateTime, write=SetAsDateTime};
	__property bool IsNull = {read=GetIsNull, write=SetIsNull, nodefault};
};


class PASCALIMPLEMENTATION TOraInterval : public Memdata::TSharedObject
{
	typedef Memdata::TSharedObject inherited;
	
private:
	void * *phOCIInterval;
	unsigned FDescriptorType;
	bool FNativeHandle;
	System::Byte FFracPrecision;
	System::Byte FLeadPrecision;
	void *FIndicator;
	void __fastcall Init(void);
	HIDESBASE void __fastcall CheckValid(void);
	System::UnicodeString __fastcall GetAsString(void);
	void * __fastcall GethOCIInterval(void);
	void __fastcall SethOCIInterval(void * Value);
	void * __fastcall GetOCIInterval(void);
	Oracall::ppOCIInterval __fastcall GetOCIIntervalPtr(void);
	void __fastcall SetAsString(const System::UnicodeString Value);
	void __fastcall SetDescriptorType(const unsigned Value);
	void __fastcall SetOCIInterval(const void * Value);
	__property void * hOCIInterval = {read=GethOCIInterval, write=SethOCIInterval};
	
public:
	__fastcall TOraInterval(System::Word DataType);
	__fastcall virtual ~TOraInterval(void);
	void __fastcall AllocInterval(void);
	void __fastcall FreeInterval(void);
	virtual void __fastcall Disconnect(void);
	void __fastcall AssignTo(TOraInterval* Dest);
	int __fastcall Compare(TOraInterval* Dest);
	bool __fastcall GetIsNull(void);
	void __fastcall SetIsNull(bool Value);
	void __fastcall GetYearMonth(int &Year, int &Month);
	void __fastcall SetYearMonth(int Year, int Month);
	void __fastcall GetDaySecond(int &Day, int &Hour, int &Min, int &Sec, int &FSec);
	void __fastcall SetDaySecond(int Day, int Hour, int Min, int Sec, int FSec);
	__property unsigned DescriptorType = {read=FDescriptorType, write=SetDescriptorType, nodefault};
	__property void * OCIInterval = {read=GetOCIInterval, write=SetOCIInterval};
	__property Oracall::ppOCIInterval OCIIntervalPtr = {read=GetOCIIntervalPtr};
	__property System::Byte LeadPrecision = {read=FLeadPrecision, write=FLeadPrecision, nodefault};
	__property System::Byte FracPrecision = {read=FFracPrecision, write=FFracPrecision, nodefault};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	__property bool IsNull = {read=GetIsNull, write=SetIsNull, nodefault};
};


class PASCALIMPLEMENTATION TOraNumber : public Memdata::TSharedObject
{
	typedef Memdata::TSharedObject inherited;
	
private:
	void *phOCINumber;
	void *FIndicator;
	bool FNativeHandle;
	void * __fastcall GetOCINumberPtr(void);
	void __fastcall SetOCINumberPtr(void * Value);
	Oracall::OCINumber __fastcall GetOCINumber(void);
	void __fastcall SetOCINumber(const Oracall::OCINumber &Value);
	System::UnicodeString __fastcall GetAsString(void);
	void __fastcall SetAsString(const System::UnicodeString Value);
	int __fastcall GetAsInteger(void);
	void __fastcall SetAsInteger(const int Value);
	__int64 __fastcall GetAsLargeInt(void);
	void __fastcall SetAsLargeInt(const __int64 Value);
	double __fastcall GetAsFloat(void);
	void __fastcall SetAsFloat(const double Value);
	bool __fastcall GetIsNull(void);
	void __fastcall SetIsNull(bool Value);
	Fmtbcd::TBcd __fastcall GetAsBCD(void);
	void __fastcall SetAsBCD(const Fmtbcd::TBcd &Value);
	
public:
	__fastcall TOraNumber(void);
	__fastcall virtual ~TOraNumber(void);
	void __fastcall AssignTo(TOraNumber* Dest);
	int __fastcall Compare(TOraNumber* Dest);
	__property Oracall::OCINumber OCINumber = {read=GetOCINumber, write=SetOCINumber};
	__property void * OCINumberPtr = {read=GetOCINumberPtr, write=SetOCINumberPtr};
	__property System::UnicodeString AsString = {read=GetAsString, write=SetAsString};
	__property int AsInteger = {read=GetAsInteger, write=SetAsInteger, nodefault};
	__property __int64 AsLargeInt = {read=GetAsLargeInt, write=SetAsLargeInt};
	__property double AsFloat = {read=GetAsFloat, write=SetAsFloat};
	__property bool IsNull = {read=GetIsNull, write=SetIsNull, nodefault};
	__property Fmtbcd::TBcd AsBCD = {read=GetAsBCD, write=SetAsBCD};
};


#pragma option push -b-
enum TOraTransactionState { tsInactive, tsActive, tsPrepared, tsFinished };
#pragma option pop

struct TTransactionLink
{
	
public:
	Sysutils::TBytes BranchQualifier;
	TOraTransactionState State;
	void *OCITrans;
};


class DELPHICLASS TOCITransaction;
class PASCALIMPLEMENTATION TOCITransaction : public Craccess::TCRTransaction
{
	typedef Craccess::TCRTransaction inherited;
	
private:
	typedef DynamicArray<TTransactionLink> _TOCITransaction__1;
	
	
private:
	System::UnicodeString FLocalTransactionId;
	System::UnicodeString FTransactionName;
	System::UnicodeString FRollbackSegment;
	_TOCITransaction__1 FTransactionLinks;
	int FInactiveTimeOut;
	int FResumeTimeOut;
	void *FXID;
	Sysutils::TBytes FTransactionId;
	bool FResume;
	
protected:
	void __fastcall WriteTransactionId(void);
	void __fastcall WriteBranchQualifier(const TTransactionLink &TransactionLink);
	void __fastcall FreeTransaction(void);
	System::UnicodeString __fastcall LocalTransactionId(bool CreateTransaction = false);
	void __fastcall StartTransactionLocal(void);
	void __fastcall CommitLocal(void);
	void __fastcall RollbackLocal(void);
	
public:
	__fastcall virtual TOCITransaction(void);
	__fastcall virtual ~TOCITransaction(void);
	void __fastcall Check(int Status);
	void __fastcall OraError(int &ErrorCode, bool UseCallback);
	void __fastcall SetTransactionId(Sysutils::TBytes TransactionId);
	void __fastcall SetBranchQualifier(int Index, Sysutils::TBytes BranchQualifier);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	virtual bool __fastcall DetectInTransaction(bool CanActivate);
	virtual void __fastcall AssignConnect(Craccess::TCRTransaction* Source);
	virtual void __fastcall StartTransaction(void);
	virtual void __fastcall Commit(void);
	virtual void __fastcall Rollback(void);
	virtual void __fastcall Savepoint(const System::UnicodeString Name);
	virtual void __fastcall RollbackToSavepoint(const System::UnicodeString Name);
	void __fastcall Detach(void);
};


class DELPHICLASS TOCIMetaData;
class PASCALIMPLEMENTATION TOCIMetaData : public Craccess::TCRMetaData
{
	typedef Craccess::TCRMetaData inherited;
	
protected:
	System::UnicodeString __fastcall GetTypesForSQL(const System::UnicodeString ObjectTypes, System::UnicodeString *AllTypes, const int AllTypes_Size);
	virtual Craccess::TCRRecordSet* __fastcall CreateRecordSet(void);
	virtual Memdata::TData* __fastcall InternalGetMetaData(const System::UnicodeString MetaDataKind, Classes::TStrings* Restrictions)/* overload */;
	virtual void __fastcall InternalGetMetaDataKindsList(Classes::TStringList* List)/* overload */;
	virtual void __fastcall InternalGetRestrictionsList(Classes::TStringList* List, const System::UnicodeString MetaDataKind)/* overload */;
	virtual Memdata::TData* __fastcall GetTables(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetColumns(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetProcedures(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetProcedureParameters(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetIndexes(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetIndexColumns(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetConstraints(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetDataTypes(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetUsers(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetUDTs(Classes::TStrings* Restrictions);
	virtual Memdata::TData* __fastcall GetPackages(Classes::TStrings* Restrictions);
	Memdata::TData* __fastcall GetSequences(Classes::TStrings* Restrictions);
public:
	/* TCRMetaData.Create */ inline __fastcall virtual TOCIMetaData(void) : Craccess::TCRMetaData() { }
	/* TCRMetaData.Destroy */ inline __fastcall virtual ~TOCIMetaData(void) { }
	
};


class DELPHICLASS TOCILoaderColumn;
class PASCALIMPLEMENTATION TOCILoaderColumn : public Craccess::TCRLoaderColumn
{
	typedef Craccess::TCRLoaderColumn inherited;
	
private:
	System::UnicodeString FDateFormat;
	int FOffset;
	int FColumnType;
	
public:
	__property System::UnicodeString DateFormat = {read=FDateFormat, write=FDateFormat};
public:
	/* TCRLoaderColumn.Create */ inline __fastcall virtual TOCILoaderColumn(void) : Craccess::TCRLoaderColumn() { }
	
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TOCILoaderColumn(void) { }
	
};


#pragma option push -b-
enum _TDPErrorAction { _dpAbort, _dpFail, _dpIgnore };
#pragma option pop

typedef void __fastcall (__closure *_TDPErrorEvent)(Sysutils::Exception* E, int Col, int Row, _TDPErrorAction &Action);

class DELPHICLASS TOCILoader;
class PASCALIMPLEMENTATION TOCILoader : public Craccess::TCRLoader
{
	typedef Craccess::TCRLoader inherited;
	
private:
	TOCIConnection* FConnection;
	bool FIsDirectMode;
	_TDPErrorEvent FOnError;
	TOCICommand* FDML;
	Oracall::OCIDirPathCtx *hDirPathCtx;
	Oracall::OCIDirPathColArray *hColumnArray;
	Oracall::OCIDirPathStream *hStream;
	int FBufNumRows;
	System::Word FBufNumCols;
	System::Word FRowSize;
	void *FBuffer;
	
protected:
	__classmethod virtual Craccess::TCRRecordSetClass __fastcall GetRecordSetClass();
	virtual void __fastcall SetConnection(Craccess::TCRConnection* Value);
	virtual void __fastcall FillColumn(Craccess::TCRLoaderColumn* Column, Memdata::TFieldDesc* FieldDesc);
	
public:
	__fastcall virtual TOCILoader(void);
	__fastcall virtual ~TOCILoader(void);
	virtual bool __fastcall SetProp(int Prop, const System::Variant &Value);
	virtual bool __fastcall GetProp(int Prop, System::Variant &Value);
	__classmethod virtual Craccess::TCRLoaderColumnClass __fastcall GetColumnClass();
	virtual void __fastcall Prepare(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall PutColumnData(int Col, int Row, const System::Variant &Value);
	virtual void __fastcall DoLoad(void);
	virtual void __fastcall Finish(void);
	__property _TDPErrorEvent OnError = {read=FOnError, write=FOnError};
};


class DELPHICLASS TOraClassesUtils;
class PASCALIMPLEMENTATION TOraClassesUtils : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	__classmethod void __fastcall InternalUnPrepare(TOCIRecordSet* Obj);
public:
	/* TObject.Create */ inline __fastcall TOraClassesUtils(void) : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TOraClassesUtils(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------
static const ShortInt dtRowId = 0x64;
static const ShortInt dtOraBlob = 0x66;
static const ShortInt dtOraClob = 0x67;
static const ShortInt dtBFILE = 0x68;
static const ShortInt dtCFILE = 0x69;
static const ShortInt dtLabel = 0x6a;
static const ShortInt dtFixedChar = 0x6b;
static const ShortInt dtUndefined = 0x6c;
static const ShortInt dtTimeStamp = 0x6d;
static const ShortInt dtTimeStampTZ = 0x6e;
static const ShortInt dtTimeStampLTZ = 0x6f;
static const ShortInt dtIntervalYM = 0x70;
static const ShortInt dtIntervalDS = 0x71;
static const ShortInt dtURowId = 0x72;
static const ShortInt dtNumber = 0x73;
static const ShortInt dtXML = 0x74;
static const ShortInt dtFixedWideChar = 0x75;
static const ShortInt dtBFloat = 0x76;
static const ShortInt dtBDouble = 0x77;
static const ShortInt dtNString = 0x78;
static const ShortInt dtNWideString = 0x79;
static const ShortInt dtNClob = 0x7a;
static const ShortInt dtWideOraClob = 0x7b;
static const ShortInt dtBLOBLocator = 0x66;
static const ShortInt dtCLOBLocator = 0x67;
static const Word prOCIBase = 0x3e8;
static const Word prNonBlocking = 0x3e9;
static const Word prThreadSafety = 0x3ea;
static const Word prAutoClose = 0x3eb;
static const Word prErrorOffset = 0x3ec;
static const Word prDateFormat = 0x3ee;
static const Word prDeferredLobRead = 0x3ef;
static const Word prConnectMode = 0x3f0;
static const Word prCharLength = 0x3f1;
static const Word prCacheLobs = 0x3f2;
static const Word prEnableIntegers = 0x3f3;
static const Word prInternalName = 0x3f4;
static const Word prScrollableCursor = 0x3f5;
static const Word prStoreRowId = 0x3f6;
static const Word prCharset = 0x3f7;
static const Word prDateLanguage = 0x3f8;
static const Word prTimeStampFormat = 0x3f9;
static const Word prTimeStampTZFormat = 0x3fa;
static const Word prRawAsString = 0x3fb;
static const Word prNumberAsString = 0x3fc;
static const Word prNumericCharacters = 0x3fd;
static const Word prEnableNumbers = 0x3fe;
static const Word prUseUnicode = 0x3ff;
static const Word prIntegerPrecision = 0x400;
static const Word prFloatPrecision = 0x401;
static const Word prTemporaryLobUpdate = 0x402;
static const Word prDisconnectMode = 0x403;
static const Word prInactiveTimeout = 0x404;
static const Word prResumeTimeout = 0x405;
static const Word prTransactionName = 0x406;
static const Word prConnectionTimeOut = 0x407;
static const Word prHasObjectFields = 0x408;
static const Word prStatementCache = 0x409;
static const Word prStatementCacheSize = 0x40a;
static const Word prEnabled = 0x40b;
static const Word prTimeout = 0x40c;
static const Word prPersistent = 0x40d;
static const Word prOperations = 0x40e;
static const Word prPrefetchRows = 0x40f;
static const Word prTransactionResume = 0x410;
static const Word prRollbackSegment = 0x411;
static const Word prHomeName = 0x412;
static const Word prDirect = 0x413;
static const Word prClientIdentifier = 0x414;
static const Word prOptimizerMode = 0x415;
static const Word prUseOCI7 = 0x416;
static const Word prSchema = 0x417;
static const Word prEnableSQLTimeStamp = 0x418;
static const Word prIntervalAsString = 0x419;
static const Word prSmallintPrecision = 0x41a;
static const Word prLargeintPrecision = 0x41b;
static const Word prBCDPrecision = 0x41c;
static const Word prFmtBCDPrecision = 0x41d;
static const Word prCheckParamHasDefault = 0x41e;
static const Word prUseResultParams = 0x41f;
static const Word prUseDefaultDataTypes = 0x420;
static const Word prEnableLargeint = 0x421;
static const Word prUnicodeEnvironment = 0x422;
static const Word prDirectPath = 0x423;
static const Word prEnableWideOraClob = 0x424;
static const ShortInt RowIdSize = 0x12;
extern PACKAGE int MaxBlobSize;
static const ShortInt MaxTransactionIdLength = 0x40;
extern PACKAGE int SmallintPrecision;
extern PACKAGE int IntegerPrecision;
extern PACKAGE int LargeIntPrecision;
extern PACKAGE int FloatPrecision;
extern PACKAGE System::UnicodeString BCDPrecision;
extern PACKAGE System::UnicodeString FmtBCDPrecision;
extern PACKAGE bool EnableWideOraClob;
extern PACKAGE bool RemoveCRInStringLiterals;
extern PACKAGE bool UseMaxDataSize;
extern PACKAGE bool NumberAsInteger;
extern PACKAGE bool UseOCI7ProcDesc;
extern PACKAGE System::UnicodeString TimeFormat;
extern PACKAGE TOCISQLInfo* OCISQLInfo;
extern PACKAGE void __fastcall OCIInit(void);
extern PACKAGE void __fastcall OCIFinish(void);
extern PACKAGE System::TDateTime __fastcall OraDateToDateTime(void * Buf);
extern PACKAGE double __fastcall OraDateToMSecs(void * Buf);
extern PACKAGE void __fastcall DateTimeToOraDate(System::TDateTime DateTime, void * Buf);
extern PACKAGE void __fastcall MSecsToOraDate(double MSecs, void * Buf);
extern PACKAGE void __fastcall OraTimeStampToSQLTimeStamp(TOraTimeStamp* OraTimeStamp, Sqltimst::TSQLTimeStamp &SQLTimeStamp);
extern PACKAGE void __fastcall SQLTimeStampToOraTimeStamp(TOraTimeStamp* OraTimeStamp, const Sqltimst::TSQLTimeStamp &SQLTimeStamp);
extern PACKAGE void __fastcall AllocODACWnd(void);
extern PACKAGE void __fastcall GetTimeFormat(void);
extern PACKAGE System::UnicodeString __fastcall QuotedOCIName(System::UnicodeString Name);
extern PACKAGE System::UnicodeString __fastcall QuotedSQLName(System::UnicodeString Name);
extern PACKAGE void __fastcall ParseConnectString(const System::UnicodeString ConnectString, System::UnicodeString &Username, System::UnicodeString &Password, System::UnicodeString &Server, TConnectMode &ConnectMode);

}	/* namespace Oraclasses */
using namespace Oraclasses;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// OraclassesHPP
