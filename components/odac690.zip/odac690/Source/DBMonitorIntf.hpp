// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dbmonitorintf.pas' rev: 21.00

#ifndef DbmonitorintfHPP
#define DbmonitorintfHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dbmonitorintf
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TEventType { etAppStarted, etAppFinished, etConnect, etDisconnect, etCommit, etRollback, etPrepare, etUnprepare, etExecute, etBlob, etError, etMisc };
#pragma option pop

#pragma option push -b-
enum TTracePoint { tpBeforeEvent, tpAfterEvent };
#pragma option pop

struct TSQLParam
{
	
public:
	System::AnsiString Name;
	System::AnsiString DataType;
	System::AnsiString ParamType;
	System::AnsiString Value;
};


typedef DynamicArray<TSQLParam> TSQLParams;

typedef TSQLParam *PSQLParam;

struct TMonitorMessage
{
	
public:
	unsigned MessageID;
	int EventType;
	int TracePoint;
	unsigned ObjectID;
	unsigned OwnerID;
	char *ObjectName;
	char *OwnerName;
	char *Description;
};


__interface IDBMonitor;
typedef System::DelphiInterface<IDBMonitor> _di_IDBMonitor;
__interface  INTERFACE_UUID("{89F49E64-F6E0-11D6-9038-00C02631BDC7}") IDBMonitor  : public System::IInterface 
{
	
public:
	virtual HRESULT __stdcall GetVersion(/* out */ char * &pVersion) = 0 ;
	virtual HRESULT __stdcall SetCaption(char * Caption) = 0 ;
	virtual HRESULT __stdcall IsMonitorActive(/* out */ int &Active) = 0 ;
	virtual HRESULT __stdcall OnEvent(TMonitorMessage &Msg, char * ParamStr) = 0 ;
	virtual HRESULT __stdcall OnExecute(TMonitorMessage &Msg, char * SQL, PSQLParam Params, int ParamCount, int RowsAffected) = 0 ;
};

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE GUID IID_IDBMonitor;
extern PACKAGE GUID Class_DBMonitor;

}	/* namespace Dbmonitorintf */
using namespace Dbmonitorintf;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DbmonitorintfHPP
