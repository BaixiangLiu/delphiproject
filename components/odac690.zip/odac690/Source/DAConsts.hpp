// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Daconsts.pas' rev: 21.00

#ifndef DaconstsHPP
#define DaconstsHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Daconsts
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
static const WideChar LineSeparator = (WideChar)(0xd);
#define SLLineSeparator L"\r\n"
static const WideChar Tabulation = (WideChar)(0x9);
static const ShortInt MaxUTF8CharLen = 0x3;
extern PACKAGE System::ResourceString _SUnknownDataType;
#define Daconsts_SUnknownDataType System::LoadResourceString(&Daconsts::_SUnknownDataType)
extern PACKAGE System::ResourceString _SDataTypeNotSupported;
#define Daconsts_SDataTypeNotSupported System::LoadResourceString(&Daconsts::_SDataTypeNotSupported)
extern PACKAGE System::ResourceString _SFieldNotFound;
#define Daconsts_SFieldNotFound System::LoadResourceString(&Daconsts::_SFieldNotFound)
extern PACKAGE System::ResourceString _SAttributeNotFount;
#define Daconsts_SAttributeNotFount System::LoadResourceString(&Daconsts::_SAttributeNotFount)
extern PACKAGE System::ResourceString _SCannotConvertType;
#define Daconsts_SCannotConvertType System::LoadResourceString(&Daconsts::_SCannotConvertType)
extern PACKAGE System::ResourceString _SIllegalFilter;
#define Daconsts_SIllegalFilter System::LoadResourceString(&Daconsts::_SIllegalFilter)
extern PACKAGE System::ResourceString _SNeedBlobType;
#define Daconsts_SNeedBlobType System::LoadResourceString(&Daconsts::_SNeedBlobType)
extern PACKAGE System::ResourceString _SInvalidSharedObject;
#define Daconsts_SInvalidSharedObject System::LoadResourceString(&Daconsts::_SInvalidSharedObject)
extern PACKAGE System::ResourceString _SInvalidBlob;
#define Daconsts_SInvalidBlob System::LoadResourceString(&Daconsts::_SInvalidBlob)
extern PACKAGE System::ResourceString _SBlobMustBeCached;
#define Daconsts_SBlobMustBeCached System::LoadResourceString(&Daconsts::_SBlobMustBeCached)
extern PACKAGE System::ResourceString _SCachedAlreadyEnabled;
#define Daconsts_SCachedAlreadyEnabled System::LoadResourceString(&Daconsts::_SCachedAlreadyEnabled)
extern PACKAGE System::ResourceString _SKeyFieldsRequired;
#define Daconsts_SKeyFieldsRequired System::LoadResourceString(&Daconsts::_SKeyFieldsRequired)
extern PACKAGE System::ResourceString _SKeyFieldsReq;
#define Daconsts_SKeyFieldsReq System::LoadResourceString(&Daconsts::_SKeyFieldsReq)
extern PACKAGE System::ResourceString _SNoKeyFields;
#define Daconsts_SNoKeyFields System::LoadResourceString(&Daconsts::_SNoKeyFields)
extern PACKAGE System::ResourceString _SBadTableInfoName;
#define Daconsts_SBadTableInfoName System::LoadResourceString(&Daconsts::_SBadTableInfoName)
extern PACKAGE System::ResourceString _SBadStatementType;
#define Daconsts_SBadStatementType System::LoadResourceString(&Daconsts::_SBadStatementType)
extern PACKAGE System::ResourceString _SBadUpdatingTable;
#define Daconsts_SBadUpdatingTable System::LoadResourceString(&Daconsts::_SBadUpdatingTable)
extern PACKAGE System::ResourceString _SKeyFieldNotFound;
#define Daconsts_SKeyFieldNotFound System::LoadResourceString(&Daconsts::_SKeyFieldNotFound)
extern PACKAGE System::ResourceString _SNotRows;
#define Daconsts_SNotRows System::LoadResourceString(&Daconsts::_SNotRows)
extern PACKAGE System::ResourceString _SInvalidUnComprBlobSize;
#define Daconsts_SInvalidUnComprBlobSize System::LoadResourceString(&Daconsts::_SInvalidUnComprBlobSize)
extern PACKAGE System::ResourceString _SInvalidComprBlobSize;
#define Daconsts_SInvalidComprBlobSize System::LoadResourceString(&Daconsts::_SInvalidComprBlobSize)
extern PACKAGE System::ResourceString _SInvalidComprBlobHeader;
#define Daconsts_SInvalidComprBlobHeader System::LoadResourceString(&Daconsts::_SInvalidComprBlobHeader)
extern PACKAGE System::ResourceString _SInvalidComprBlobData;
#define Daconsts_SInvalidComprBlobData System::LoadResourceString(&Daconsts::_SInvalidComprBlobData)
extern PACKAGE System::ResourceString _SDataSetIsNotPrepared;
#define Daconsts_SDataSetIsNotPrepared System::LoadResourceString(&Daconsts::_SDataSetIsNotPrepared)
extern PACKAGE System::ResourceString _SInvalidKeyField;
#define Daconsts_SInvalidKeyField System::LoadResourceString(&Daconsts::_SInvalidKeyField)
extern PACKAGE System::ResourceString _SNotCachedUpdate;
#define Daconsts_SNotCachedUpdate System::LoadResourceString(&Daconsts::_SNotCachedUpdate)
extern PACKAGE System::ResourceString _SUpdateWrongDB;
#define Daconsts_SUpdateWrongDB System::LoadResourceString(&Daconsts::_SUpdateWrongDB)
extern PACKAGE System::ResourceString _SConnectionNotDefined;
#define Daconsts_SConnectionNotDefined System::LoadResourceString(&Daconsts::_SConnectionNotDefined)
extern PACKAGE System::ResourceString _SConnectionNotConnected;
#define Daconsts_SConnectionNotConnected System::LoadResourceString(&Daconsts::_SConnectionNotConnected)
extern PACKAGE System::ResourceString _SCannotConnect;
#define Daconsts_SCannotConnect System::LoadResourceString(&Daconsts::_SCannotConnect)
extern PACKAGE System::ResourceString _SMacroNotFound;
#define Daconsts_SMacroNotFound System::LoadResourceString(&Daconsts::_SMacroNotFound)
extern PACKAGE System::ResourceString _SNotInTransaction;
#define Daconsts_SNotInTransaction System::LoadResourceString(&Daconsts::_SNotInTransaction)
extern PACKAGE System::ResourceString _SInTransaction;
#define Daconsts_SInTransaction System::LoadResourceString(&Daconsts::_SInTransaction)
extern PACKAGE System::ResourceString _STransactionNotAssigned;
#define Daconsts_STransactionNotAssigned System::LoadResourceString(&Daconsts::_STransactionNotAssigned)
extern PACKAGE System::ResourceString _SUpdateFailed;
#define Daconsts_SUpdateFailed System::LoadResourceString(&Daconsts::_SUpdateFailed)
extern PACKAGE System::ResourceString _SCustomUpdateFailed;
#define Daconsts_SCustomUpdateFailed System::LoadResourceString(&Daconsts::_SCustomUpdateFailed)
extern PACKAGE System::ResourceString _SRefreshFailed;
#define Daconsts_SRefreshFailed System::LoadResourceString(&Daconsts::_SRefreshFailed)
extern PACKAGE System::ResourceString _SInvalidFetchRows;
#define Daconsts_SInvalidFetchRows System::LoadResourceString(&Daconsts::_SInvalidFetchRows)
extern PACKAGE System::ResourceString _SNoCorrespondParam;
#define Daconsts_SNoCorrespondParam System::LoadResourceString(&Daconsts::_SNoCorrespondParam)
extern PACKAGE System::ResourceString _SUnknownParamDataType;
#define Daconsts_SUnknownParamDataType System::LoadResourceString(&Daconsts::_SUnknownParamDataType)
extern PACKAGE System::ResourceString _SRecordChanged;
#define Daconsts_SRecordChanged System::LoadResourceString(&Daconsts::_SRecordChanged)
extern PACKAGE System::ResourceString _STableNameNotDefined;
#define Daconsts_STableNameNotDefined System::LoadResourceString(&Daconsts::_STableNameNotDefined)
extern PACKAGE System::ResourceString _SStoredProcNotDefined;
#define Daconsts_SStoredProcNotDefined System::LoadResourceString(&Daconsts::_SStoredProcNotDefined)
extern PACKAGE System::ResourceString _SConnectionIsClosed;
#define Daconsts_SConnectionIsClosed System::LoadResourceString(&Daconsts::_SConnectionIsClosed)
extern PACKAGE System::ResourceString _SCannotPerformIfPooling;
#define Daconsts_SCannotPerformIfPooling System::LoadResourceString(&Daconsts::_SCannotPerformIfPooling)
extern PACKAGE System::ResourceString _SMaxConnectionsReached;
#define Daconsts_SMaxConnectionsReached System::LoadResourceString(&Daconsts::_SMaxConnectionsReached)
extern PACKAGE System::ResourceString _SDataSetNotDefined;
#define Daconsts_SDataSetNotDefined System::LoadResourceString(&Daconsts::_SDataSetNotDefined)
extern PACKAGE System::ResourceString _SCannotChangeIsUnicode;
#define Daconsts_SCannotChangeIsUnicode System::LoadResourceString(&Daconsts::_SCannotChangeIsUnicode)
extern PACKAGE System::ResourceString _SColumnNotFound;
#define Daconsts_SColumnNotFound System::LoadResourceString(&Daconsts::_SColumnNotFound)
extern PACKAGE System::ResourceString _SNoTimers;
#define Daconsts_SNoTimers System::LoadResourceString(&Daconsts::_SNoTimers)
extern PACKAGE System::ResourceString _sBlobNotCompressed;
#define Daconsts_sBlobNotCompressed System::LoadResourceString(&Daconsts::_sBlobNotCompressed)
extern PACKAGE System::ResourceString _SCompressorNotLinked;
#define Daconsts_SCompressorNotLinked System::LoadResourceString(&Daconsts::_SCompressorNotLinked)
extern PACKAGE System::ResourceString _SUncompressorNotLinked;
#define Daconsts_SUncompressorNotLinked System::LoadResourceString(&Daconsts::_SUncompressorNotLinked)
extern PACKAGE System::ResourceString _SUpdateComponentCircularReferences;
#define Daconsts_SUpdateComponentCircularReferences System::LoadResourceString(&Daconsts::_SUpdateComponentCircularReferences)
extern PACKAGE System::ResourceString _SUpdateComponentInvalidType;
#define Daconsts_SUpdateComponentInvalidType System::LoadResourceString(&Daconsts::_SUpdateComponentInvalidType)
extern PACKAGE System::ResourceString _SUpdateObjectEmptySQL;
#define Daconsts_SUpdateObjectEmptySQL System::LoadResourceString(&Daconsts::_SUpdateObjectEmptySQL)
extern PACKAGE System::ResourceString _SDateEncodeError;
#define Daconsts_SDateEncodeError System::LoadResourceString(&Daconsts::_SDateEncodeError)
extern PACKAGE System::ResourceString _SInvalidXML;
#define Daconsts_SInvalidXML System::LoadResourceString(&Daconsts::_SInvalidXML)
extern PACKAGE System::ResourceString _SWrongTblCount;
#define Daconsts_SWrongTblCount System::LoadResourceString(&Daconsts::_SWrongTblCount)
extern PACKAGE System::ResourceString _SBackupQueryWrongTableCount;
#define Daconsts_SBackupQueryWrongTableCount System::LoadResourceString(&Daconsts::_SBackupQueryWrongTableCount)
extern PACKAGE System::ResourceString _SBHCaption;
#define Daconsts_SBHCaption System::LoadResourceString(&Daconsts::_SBHCaption)
extern PACKAGE System::ResourceString _SBHTableData;
#define Daconsts_SBHTableData System::LoadResourceString(&Daconsts::_SBHTableData)
extern PACKAGE System::ResourceString _SAreYouSureRestore;
#define Daconsts_SAreYouSureRestore System::LoadResourceString(&Daconsts::_SAreYouSureRestore)
extern PACKAGE System::ResourceString _SInvalidBatchMove;
#define Daconsts_SInvalidBatchMove System::LoadResourceString(&Daconsts::_SInvalidBatchMove)
extern PACKAGE System::ResourceString _SCannotFindField;
#define Daconsts_SCannotFindField System::LoadResourceString(&Daconsts::_SCannotFindField)
extern PACKAGE System::ResourceString _SInvalidLexem;
#define Daconsts_SInvalidLexem System::LoadResourceString(&Daconsts::_SInvalidLexem)
extern PACKAGE System::ResourceString _SEmptySQLStatement;
#define Daconsts_SEmptySQLStatement System::LoadResourceString(&Daconsts::_SEmptySQLStatement)
extern PACKAGE System::ResourceString _SInvalidBlobPosition;
#define Daconsts_SInvalidBlobPosition System::LoadResourceString(&Daconsts::_SInvalidBlobPosition)
extern PACKAGE System::ResourceString _SNoConnectionsInTransaction;
#define Daconsts_SNoConnectionsInTransaction System::LoadResourceString(&Daconsts::_SNoConnectionsInTransaction)
extern PACKAGE System::ResourceString _SMultiConnectionsInTransaction;
#define Daconsts_SMultiConnectionsInTransaction System::LoadResourceString(&Daconsts::_SMultiConnectionsInTransaction)
extern PACKAGE System::ResourceString _SConnectionInTransactionNotActive;
#define Daconsts_SConnectionInTransactionNotActive System::LoadResourceString(&Daconsts::_SConnectionInTransactionNotActive)
extern PACKAGE System::ResourceString _SUnsupportedIsolationLevel;
#define Daconsts_SUnsupportedIsolationLevel System::LoadResourceString(&Daconsts::_SUnsupportedIsolationLevel)
extern PACKAGE System::ResourceString _SIsolationLevelNotSupportedWithMTS;
#define Daconsts_SIsolationLevelNotSupportedWithMTS System::LoadResourceString(&Daconsts::_SIsolationLevelNotSupportedWithMTS)
extern PACKAGE System::ResourceString _SReadOnlyTransactionNotSupported;
#define Daconsts_SReadOnlyTransactionNotSupported System::LoadResourceString(&Daconsts::_SReadOnlyTransactionNotSupported)
extern PACKAGE System::ResourceString _SOperationNotSupported;
#define Daconsts_SOperationNotSupported System::LoadResourceString(&Daconsts::_SOperationNotSupported)
extern PACKAGE System::ResourceString _SMultipleTransactionsNotSupported;
#define Daconsts_SMultipleTransactionsNotSupported System::LoadResourceString(&Daconsts::_SMultipleTransactionsNotSupported)
extern PACKAGE System::ResourceString _SMTSNotSupported;
#define Daconsts_SMTSNotSupported System::LoadResourceString(&Daconsts::_SMTSNotSupported)
extern PACKAGE System::ResourceString _SVarSubtypeNotSupported;
#define Daconsts_SVarSubtypeNotSupported System::LoadResourceString(&Daconsts::_SVarSubtypeNotSupported)
extern PACKAGE System::ResourceString _SInvalidParamsArray;
#define Daconsts_SInvalidParamsArray System::LoadResourceString(&Daconsts::_SInvalidParamsArray)
extern PACKAGE System::ResourceString _SUnsupportedMetaDataKind;
#define Daconsts_SUnsupportedMetaDataKind System::LoadResourceString(&Daconsts::_SUnsupportedMetaDataKind)
extern PACKAGE System::ResourceString _SRestrictionMustBeSet;
#define Daconsts_SRestrictionMustBeSet System::LoadResourceString(&Daconsts::_SRestrictionMustBeSet)

}	/* namespace Daconsts */
using namespace Daconsts;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DaconstsHPP
